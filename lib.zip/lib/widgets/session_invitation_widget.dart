// File: lib/widgets/session_invitation_widget.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:share_plus/share_plus.dart';
import '../models/session_models.dart';
import '../services/session_service.dart';
import '../models/user_profile.dart';
import '../utils/mood_based_learning_engine.dart';
import 'mood_selection_widget.dart';

class SessionInvitationWidget extends StatefulWidget {
  final UserProfile currentUser;
  final List<UserProfile> availableFriends;
  final Function(SwipeSession session) onSessionCreated;

  const SessionInvitationWidget({
    super.key,
    required this.currentUser,
    required this.availableFriends,
    required this.onSessionCreated,
  });

  @override
  State<SessionInvitationWidget> createState() => _SessionInvitationWidgetState();
}

class _SessionInvitationWidgetState extends State<SessionInvitationWidget> {
  bool _isCreatingSession = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(24.r),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF1A1A1A),
            const Color(0xFF0F0F0F),
          ],
        ),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle bar
          Container(
            width: 40.w,
            height: 4.h,
            decoration: BoxDecoration(
              color: Colors.grey[600],
              borderRadius: BorderRadius.circular(2.r),
            ),
          ),
          SizedBox(height: 24.h),
          
          // Title
          Text(
            "Swipe Together",
            style: TextStyle(
              color: Colors.white,
              fontSize: 24.sp,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8.h),
          
          Text(
            "Find movies you'll both love",
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14.sp,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 32.h),
          
          // Primary action: Quick Start (most common use case)
          _buildPrimaryInviteButton(),
          
          SizedBox(height: 24.h),
          
          // Alternative options
          Row(
            children: [
              Expanded(child: Divider(color: Colors.grey[700])),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Text(
                  "OR",
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Expanded(child: Divider(color: Colors.grey[700])),
            ],
          ),
          
          SizedBox(height: 24.h),
          
          // Secondary options in a row
          Row(
            children: [
              Expanded(
                child: _buildSecondaryOption(
                  icon: Icons.person_add_outlined,
                  title: "Invite Friends",
                  subtitle: "Pick mood & invite",
                  onTap: _showFriendSelector,
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: _buildSecondaryOption(
                  icon: Icons.login,
                  title: "Join Session",
                  subtitle: "Enter code",
                  onTap: _showJoinSessionDialog,
                ),
              ),
            ],
          ),
          
          SizedBox(height: 24.h),
        ],
      ),
    );
  }

  Widget _buildPrimaryInviteButton() {
    return SizedBox(
      width: double.infinity,
      height: 64.h,
      child: ElevatedButton.icon(
        onPressed: _isCreatingSession ? null : _createAndShareSession,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFE5A00D),
          disabledBackgroundColor: Colors.grey[700],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.r),
          ),
          elevation: 0,
        ),
        icon: _isCreatingSession
            ? SizedBox(
                width: 24.w,
                height: 24.h,
                child: CircularProgressIndicator(
                  strokeWidth: 2.w,
                  valueColor: const AlwaysStoppedAnimation<Color>(Colors.black),
                ),
              )
            : Icon(
                Icons.share,
                color: Colors.black,
                size: 24.sp,
              ),
        label: Text(
          _isCreatingSession ? "Creating Session..." : "Create & Share Code",
          style: TextStyle(
            color: Colors.black,
            fontSize: 16.sp,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildSecondaryOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: _isCreatingSession ? null : onTap,
      borderRadius: BorderRadius.circular(12.r),
      child: Container(
        padding: EdgeInsets.all(16.r),
        decoration: BoxDecoration(
          color: const Color(0xFF2A2A2A),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: Colors.grey.withValues(alpha: 0.3)),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: const Color(0xFFE5A00D),
              size: 24.sp,
            ),
            SizedBox(height: 8.h),
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 14.sp,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),
            Text(
              subtitle,
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 11.sp,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // ORIGINAL: Create session with mood selection dialog (for "Create & Share Code")
  Future<void> _createAndShareSession() async {
    setState(() => _isCreatingSession = true);
    
    try {
      // Step 1: Let user select mood for the session
      final selectedMood = await _showMoodSelectionDialog();
      
      if (selectedMood == null) {
        // User cancelled mood selection
        setState(() => _isCreatingSession = false);
        return;
      }
      
      // Step 2: Create session with selected mood
      final session = await SessionService.createSession(
        hostName: widget.currentUser.name,
        inviteType: InvitationType.code,
        selectedMood: selectedMood,
      );
      
      if (mounted) {
        widget.onSessionCreated(session);
        _showShareOptionsDialog(session.sessionCode!, selectedMood);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to create session: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isCreatingSession = false);
    }
  }

  // SIMPLE mood selection dialog for "Create & Share Code" flow
  Future<CurrentMood?> _showMoodSelectionDialog() async {
    CurrentMood? selectedMood;
    
    await showDialog<CurrentMood>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Row(
          children: [
            Icon(Icons.mood, color: const Color(0xFFE5A00D), size: 24.sp),
            SizedBox(width: 12.w),
            Text(
              "Choose Session Mood",
              style: TextStyle(color: Colors.white, fontSize: 18.sp),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Pick the vibe for this session. Your friend will see your choice when they join.",
                style: TextStyle(color: Colors.grey[300], fontSize: 14.sp),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20.h),
              
              // Show mood options (exclude perfectForMe since this is collaborative)
              ...CurrentMood.values
                  .where((mood) => mood != CurrentMood.perfectForMe)
                  .map((mood) => Container(
                    margin: EdgeInsets.only(bottom: 8.h),
                    child: ListTile(
                      leading: Container(
                        padding: EdgeInsets.all(8.r),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5A00D).withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8.r),
                        ),
                        child: Text(mood.emoji, style: TextStyle(fontSize: 20.sp)),
                      ),
                      title: Text(
                        mood.displayName,
                        style: TextStyle(color: Colors.white, fontSize: 16.sp, fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text(
                        "Great for collaborative sessions",
                        style: TextStyle(color: Colors.grey[400], fontSize: 12.sp),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      onTap: () {
                        selectedMood = mood;
                        Navigator.of(context).pop(mood);
                      },
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                      tileColor: Colors.grey.withValues(alpha: 0.05),
                      hoverColor: const Color(0xFFE5A00D).withValues(alpha: 0.1),
                    ),
                  ),
              ).toList(),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(null),
            child: Text(
              "Cancel",
              style: TextStyle(color: Colors.grey[400]),
            ),
          ),
        ],
      ),
    );
    
    return selectedMood;
  }

  void _showShareOptionsDialog(String sessionCode, CurrentMood selectedMood) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Row(
          children: [
            Icon(Icons.celebration, color: const Color(0xFFE5A00D), size: 24.sp),
            SizedBox(width: 12.w),
            Text(
              "Session Ready!",
              style: TextStyle(color: Colors.white, fontSize: 18.sp),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Show selected mood
            Container(
              padding: EdgeInsets.all(16.r),
              margin: EdgeInsets.only(bottom: 16.h),
              decoration: BoxDecoration(
                color: const Color(0xFFE5A00D).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.3)),
              ),
              child: Row(
                children: [
                  Text(selectedMood.emoji, style: TextStyle(fontSize: 24.sp)),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "${selectedMood.displayName} Session",
                          style: TextStyle(
                            color: const Color(0xFFE5A00D),
                            fontSize: 16.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          "You set the mood for this session",
                          style: TextStyle(
                            color: Colors.grey[400],
                            fontSize: 12.sp,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            
            Text(
              "Share this code with your friend:",
              style: TextStyle(color: Colors.grey[300], fontSize: 14.sp),
            ),
            SizedBox(height: 20.h),
            
            // Session code display
            Container(
              padding: EdgeInsets.all(20.r),
              decoration: BoxDecoration(
                color: const Color(0xFFE5A00D).withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(16.r),
                border: Border.all(color: const Color(0xFFE5A00D), width: 2.w),
              ),
              child: Column(
                children: [
                  Text(
                    sessionCode,
                    style: TextStyle(
                      color: const Color(0xFFE5A00D),
                      fontSize: 40.sp,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 8.w,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    "6-digit session code",
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 12.sp,
                    ),
                  ),
                ],
              ),
            ),
            
            SizedBox(height: 24.h),
            
            // Action buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: sessionCode));
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: const Text('Code copied! Send it to your friend'),
                          backgroundColor: Colors.green,
                          duration: const Duration(seconds: 2),
                        ),
                      );
                    },
                    icon: Icon(Icons.copy, size: 18.sp),
                    label: Text("Copy Code", style: TextStyle(fontSize: 13.sp)),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFFE5A00D),
                      side: BorderSide(color: const Color(0xFFE5A00D)),
                      padding: EdgeInsets.symmetric(vertical: 12.h),
                    ),
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Share.share(
                        'Join my ${selectedMood.displayName} movie session! ${selectedMood.emoji}\n\nCode: $sessionCode\n\nWe\'ll find movies that match this vibe together! 🎬',
                      );
                    },
                    icon: Icon(Icons.share, size: 18.sp, color: Colors.black),
                    label: Text("Share", style: TextStyle(fontSize: 13.sp, color: Colors.black)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE5A00D),
                      padding: EdgeInsets.symmetric(vertical: 12.h),
                    ),
                  ),
                ),
              ],
            ),
            
            SizedBox(height: 16.h),
            
            // Status indicator
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
              decoration: BoxDecoration(
                color: Colors.blue.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(20.r),
                border: Border.all(color: Colors.blue.withValues(alpha: 0.5)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: 12.w,
                    height: 12.h,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.w,
                      valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Text(
                    "Waiting for friend to join...",
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).pop(); // Close invitation widget
            },
            child: Text(
              "Got it!",
              style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 14.sp),
            ),
          ),
        ],
      ),
    );
  }

  // NEW: Show friend selector for direct invites
  void _showFriendSelector() {
    Navigator.of(context).pop(); // Close current dialog
    showDialog(
      context: context,
      builder: (context) => FriendInviteDialog(
        currentUser: widget.currentUser,
        availableFriends: widget.availableFriends,
        onSessionCreated: widget.onSessionCreated,
      ),
    );
  }

  void _showJoinSessionDialog() {
    Navigator.of(context).pop(); // Close current dialog
    final codeController = TextEditingController();
    bool isJoining = false;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          backgroundColor: const Color(0xFF1F1F1F),
          title: Text(
            "Join Friend's Session",
            style: TextStyle(color: Colors.white, fontSize: 18.sp),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Enter the 6-digit code your friend shared:",
                style: TextStyle(color: Colors.grey[300], fontSize: 14.sp),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20.h),
              
              TextField(
                controller: codeController,
                style: TextStyle(
                  color: Colors.white, 
                  fontSize: 28.sp, 
                  letterSpacing: 6.w,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
                keyboardType: TextInputType.number,
                maxLength: 6,
                autofocus: true,
                decoration: InputDecoration(
                  hintText: "000000",
                  hintStyle: TextStyle(
                    color: Colors.grey[600], 
                    letterSpacing: 6.w,
                    fontWeight: FontWeight.bold,
                  ),
                  filled: true,
                  fillColor: const Color(0xFF2A2A2A),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16.r),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16.r),
                    borderSide: BorderSide(color: const Color(0xFFE5A00D), width: 2.w),
                  ),
                  counterText: "",
                  contentPadding: EdgeInsets.symmetric(vertical: 20.h),
                ),
                onChanged: (value) {
                  if (value.length == 6) {
                    FocusScope.of(context).unfocus();
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: isJoining ? null : () => Navigator.of(context).pop(),
              child: Text(
                "Cancel",
                style: TextStyle(color: Colors.grey[400], fontSize: 14.sp),
              ),
            ),
            ElevatedButton(
              onPressed: isJoining || codeController.text.length != 6 
                  ? null 
                  : () async {
                      setState(() => isJoining = true);
                      
                      try {
                        final session = await SessionService.joinSessionByCode(
                          codeController.text,
                          widget.currentUser.name,
                        );
                        
                        if (session != null) {
                          Navigator.of(context).pop();
                          widget.onSessionCreated(session);
                          
                          // Show session mood if available
                          final moodInfo = session.hasMoodSelected 
                              ? " (${session.selectedMoodName} session)"
                              : "";
                          
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Successfully joined session!$moodInfo'),
                              backgroundColor: Colors.green,
                            ),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Session not found. Check the code and try again.'),
                              backgroundColor: Colors.red,
                            ),
                          );
                        }
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Failed to join: $e'),
                            backgroundColor: Colors.red,
                          ),
                        );
                      } finally {
                        setState(() => isJoining = false);
                      }
                    },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                disabledBackgroundColor: Colors.grey[700],
              ),
              child: isJoining
                  ? SizedBox(
                      width: 16.w,
                      height: 16.h,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.w,
                        valueColor: const AlwaysStoppedAnimation<Color>(Colors.black),
                      ),
                    )
                  : Text(
                      "Join Session",
                      style: TextStyle(color: Colors.black, fontSize: 14.sp, fontWeight: FontWeight.bold),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// NEW: Friend invite dialog that shows mood selection after friend selection
class FriendInviteDialog extends StatefulWidget {
  final UserProfile currentUser;
  final List<UserProfile> availableFriends;
  final Function(SwipeSession session) onSessionCreated;

  const FriendInviteDialog({
    super.key,
    required this.currentUser,
    required this.availableFriends,
    required this.onSessionCreated,
  });

  @override
  State<FriendInviteDialog> createState() => _FriendInviteDialogState();
}

class _FriendInviteDialogState extends State<FriendInviteDialog> {
  final Set<String> selectedFriendIds = {};
  bool isCreatingSession = false;
  bool _showMoodSelection = false;
  CurrentMood? _selectedMood;

  @override
  Widget build(BuildContext context) {
    // Show full mood selection widget after friends are selected
    if (_showMoodSelection) {
      return Container(
        height: MediaQuery.of(context).size.height * 0.9,
        decoration: BoxDecoration(
          color: const Color(0xFF121212),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              // Full mood selection widget
              MoodSelectionWidget(
                onMoodsSelected: _onMoodsSelected,
                isGroupMode: true, // Always true for collaborative sessions
                groupSize: selectedFriendIds.length + 1, // Include current user
              ),
              
              // Back button
              Positioned(
                top: 16.h,
                left: 16.w,
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      _showMoodSelection = false;
                    });
                  },
                  child: Container(
                    padding: EdgeInsets.all(8.r),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.3),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.arrow_back_ios,
                      color: Colors.white.withValues(alpha: 0.8),
                      size: 20.sp,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return AlertDialog(
      backgroundColor: const Color(0xFF1F1F1F),
      title: Text(
        "Invite Friends",
        style: TextStyle(color: Colors.white, fontSize: 18.sp),
      ),
      content: SizedBox(
        width: double.maxFinite,
        height: 400.h,
        child: widget.availableFriends.isEmpty
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.people_outline,
                      size: 64.sp,
                      color: Colors.grey[600],
                    ),
                    SizedBox(height: 16.h),
                    Text(
                      "No friends yet",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8.h),
                    Text(
                      "Add friends to start swiping together!",
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 14.sp,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              )
            : Column(
                children: [
                  Text(
                    "Select friends to invite:",
                    style: TextStyle(color: Colors.grey[300], fontSize: 14.sp),
                  ),
                  SizedBox(height: 16.h),
                  
                  Expanded(
                    child: ListView.builder(
                      itemCount: widget.availableFriends.length,
                      itemBuilder: (context, index) {
                        final friend = widget.availableFriends[index];
                        final isSelected = selectedFriendIds.contains(friend.uid);
                        
                        return CheckboxListTile(
                          value: isSelected,
                          onChanged: isCreatingSession
                              ? null
                              : (selected) {
                                  setState(() {
                                    if (selected == true) {
                                      selectedFriendIds.add(friend.uid);
                                    } else {
                                      selectedFriendIds.remove(friend.uid);
                                    }
                                  });
                                },
                          activeColor: const Color(0xFFE5A00D),
                          checkColor: Colors.black,
                          title: Text(
                            friend.name,
                            style: TextStyle(color: Colors.white, fontSize: 16.sp),
                          ),
                          subtitle: Text(
                            "Ready to swipe",
                            style: TextStyle(color: Colors.grey[400], fontSize: 12.sp),
                          ),
                          secondary: CircleAvatar(
                            backgroundColor: Colors.grey[800],
                            radius: 20.r,
                            child: Text(
                              friend.name.isNotEmpty ? friend.name[0].toUpperCase() : "?",
                              style: TextStyle(color: Colors.white, fontSize: 16.sp),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  
                  if (selectedFriendIds.isNotEmpty) ...[
                    SizedBox(height: 16.h),
                    Container(
                      padding: EdgeInsets.all(12.r),
                      decoration: BoxDecoration(
                        color: const Color(0xFFE5A00D).withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(8.r),
                        border: Border.all(color: const Color(0xFFE5A00D)),
                      ),
                      child: Text(
                        "${selectedFriendIds.length} friend(s) selected",
                        style: TextStyle(
                          color: const Color(0xFFE5A00D),
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
      ),
      actions: [
        TextButton(
          onPressed: isCreatingSession ? null : () => Navigator.of(context).pop(),
          child: Text(
            "Cancel",
            style: TextStyle(color: Colors.grey[400], fontSize: 14.sp),
          ),
        ),
        if (widget.availableFriends.isNotEmpty)
          ElevatedButton(
            onPressed: isCreatingSession || selectedFriendIds.isEmpty
                ? null
                : () {
                    // Show mood selection instead of immediately sending invites
                    setState(() {
                      _showMoodSelection = true;
                    });
                  },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFE5A00D),
            ),
            child: isCreatingSession
                ? SizedBox(
                    width: 16.w,
                    height: 16.h,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.w,
                      valueColor: const AlwaysStoppedAnimation<Color>(Colors.black),
                    ),
                  )
                : Text(
                    "Next: Pick Mood",
                    style: TextStyle(color: Colors.black, fontSize: 14.sp),
                  ),
          ),
      ],
    );
  }

  // Handle mood selection completion
  void _onMoodsSelected(List<CurrentMood> moods) {
    setState(() {
      _selectedMood = moods.isNotEmpty ? moods.first : null;
      _showMoodSelection = false;
    });
    
    // Automatically send invitations after mood is selected
    if (_selectedMood != null) {
      _sendInvitations();
    }
  }

  // Send invitations with selected mood
  Future<void> _sendInvitations() async {
    if (_selectedMood == null) return;
    
    setState(() => isCreatingSession = true);
    
    try {
      // Create session with selected mood
      final session = await SessionService.createSession(
        hostName: widget.currentUser.name,
        inviteType: InvitationType.friend,
        selectedMood: _selectedMood,
      );
      
      // Send invitations to selected friends
      for (final friendId in selectedFriendIds) {
        final friend = widget.availableFriends.firstWhere((f) => f.uid == friendId);
        await SessionService.inviteFriend(
          sessionId: session.sessionId,
          friendId: friendId,
          friendName: friend.name,
          selectedMood: _selectedMood, // Include mood in invitation
        );
      }
      
      if (mounted) {
        Navigator.of(context).pop();
        widget.onSessionCreated(session);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${_selectedMood!.displayName} session invitations sent to ${selectedFriendIds.length} friend(s)!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to send invitations: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => isCreatingSession = false);
    }
  }
}