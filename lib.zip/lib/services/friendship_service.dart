import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_profile.dart';

class FriendshipService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Send a friend request
  static Future<void> sendFriendRequest({
    required String fromUserId,
    required String toUserId,
    required String fromUserName,
    required String toUserName,
  }) async {
    try {
      // Create friend request document
      await _firestore.collection('friend_requests').doc('${fromUserId}_$toUserId').set({
        'fromUserId': fromUserId,
        'toUserId': toUserId,
        'fromUserName': fromUserName,
        'toUserName': toUserName,
        'status': 'pending',
        'sentAt': FieldValue.serverTimestamp(),
      });

      print("✅ Friend request sent from $fromUserName to $toUserName");
    } catch (e) {
      print("❌ Error sending friend request: $e");
      throw e;
    }
  }

  // Accept a friend request
  static Future<void> acceptFriendRequest({
    required String fromUserId,
    required String toUserId,
  }) async {
    try {
      final batch = _firestore.batch();

      // Update the friend request status
      final requestRef = _firestore.collection('friend_requests').doc('${fromUserId}_$toUserId');
      batch.update(requestRef, {
        'status': 'accepted',
        'acceptedAt': FieldValue.serverTimestamp(),
      });

      // Add to both users' friends arrays
      final fromUserRef = _firestore.collection('users').doc(fromUserId);
      batch.update(fromUserRef, {
        'friendIds': FieldValue.arrayUnion([toUserId]),
      });

      final toUserRef = _firestore.collection('users').doc(toUserId);
      batch.update(toUserRef, {
        'friendIds': FieldValue.arrayUnion([fromUserId]),
      });

      // Commit the batch
      await batch.commit();

      print("✅ Friend request accepted. Users are now friends!");
    } catch (e) {
      print("❌ Error accepting friend request: $e");
      throw e;
    }
  }

  // Decline a friend request
  static Future<void> declineFriendRequest({
    required String fromUserId,
    required String toUserId,
  }) async {
    try {
      await _firestore.collection('friend_requests').doc('${fromUserId}_$toUserId').update({
        'status': 'declined',
        'declinedAt': FieldValue.serverTimestamp(),
      });

      print("✅ Friend request declined");
    } catch (e) {
      print("❌ Error declining friend request: $e");
      throw e;
    }
  }

  static Stream<List<Map<String, dynamic>>> getPendingFriendRequests(String userId) {
    return _firestore
        .collection('friend_requests')
        .where('toUserId', isEqualTo: userId)
        .where('status', isEqualTo: 'pending')
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => {
              'id': doc.id,
              ...doc.data(),
            }).toList());
  }

  // Get user's friends list
  static Future<List<UserProfile>> getFriends(String userId) async {
    try {
      // Get the user document to get friendIds
      final userDoc = await _firestore.collection('users').doc(userId).get();
      
      if (!userDoc.exists) {
        return [];
      }

      final userData = userDoc.data()!;
      final List<String> friendIds = List<String>.from(userData['friendIds'] ?? []);

      if (friendIds.isEmpty) {
        return [];
      }

      // Get all friend profiles
      final List<UserProfile> friends = [];
      
      for (String friendId in friendIds) {
        final friendDoc = await _firestore.collection('users').doc(friendId).get();
        if (friendDoc.exists) {
          friends.add(UserProfile.fromJson(friendDoc.data()!));
        }
      }

      return friends;
    } catch (e) {
      print("❌ Error getting friends: $e");
      return [];
    }
  }

  // Remove a friend
  static Future<void> removeFriend({
    required String userId,
    required String friendId,
  }) async {
    try {
      final batch = _firestore.batch();

      // Remove from both users' friends arrays
      final userRef = _firestore.collection('users').doc(userId);
      batch.update(userRef, {
        'friendIds': FieldValue.arrayRemove([friendId]),
      });

      final friendRef = _firestore.collection('users').doc(friendId);
      batch.update(friendRef, {
        'friendIds': FieldValue.arrayRemove([userId]),
      });

      await batch.commit();

      print("✅ Friend removed successfully");
    } catch (e) {
      print("❌ Error removing friend: $e");
      throw e;
    }
  }

  // Search for users by name (to find new friends)
  static Future<List<UserProfile>> searchUsersByName(String searchTerm, String currentUserId) async {
    try {
      if (searchTerm.length < 2) return [];

      final querySnapshot = await _firestore
          .collection('users')
          .where('name', isGreaterThanOrEqualTo: searchTerm)
          .where('name', isLessThanOrEqualTo: searchTerm + '\uf8ff')
          .limit(20)
          .get();

      final List<UserProfile> users = [];
      
      for (var doc in querySnapshot.docs) {
        if (doc.id != currentUserId) { // Don't include current user
          users.add(UserProfile.fromJson(doc.data()));
        }
      }

      return users;
    } catch (e) {
      print("❌ Error searching users: $e");
      return [];
    }
  }

  // Check if two users are friends
  static Future<bool> areFriends(String userId1, String userId2) async {
    try {
      final userDoc = await _firestore.collection('users').doc(userId1).get();
      
      if (!userDoc.exists) return false;

      final userData = userDoc.data()!;
      final List<String> friendIds = List<String>.from(userData['friendIds'] ?? []);

      return friendIds.contains(userId2);
    } catch (e) {
      print("❌ Error checking friendship: $e");
      return false;
    }
  }

  // Check if friend request exists
  static Future<String?> getFriendRequestStatus(String fromUserId, String toUserId) async {
    try {
      final requestDoc = await _firestore.collection('friend_requests').doc('${fromUserId}_$toUserId').get();
      
      if (requestDoc.exists) {
        return requestDoc.data()!['status'];
      }
      
      return null;
    } catch (e) {
      print("❌ Error checking friend request: $e");
      return null;
    }
  }
}