// File: lib/screens/onboarding/swiping_tutorial_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';
import '../../models/user_profile.dart';
import '../../movie.dart';
import '../../data/movie_json_loader.dart';
import '../movie_detail_screen.dart';
import 'learning_demo_screen.dart';
import 'dart:async';
import 'dart:math' as math;

// Tutorial card types
enum CardType { tutorial, movie }

// Tutorial phases
enum TutorialPhase { 
  introduction,
  basicSwiping,
  viewMoreDemo,
  freeSwipe 
}

// Combined card data structure
class TutorialCard {
  final CardType type;
  final Movie? movie;
  final String? tutorialTitle;
  final String? tutorialDescription;
  final IconData? tutorialIcon;
  final TutorialPhase? tutorialPhase;
  
  TutorialCard.movie(this.movie) 
      : type = CardType.movie,
        tutorialTitle = null,
        tutorialDescription = null,
        tutorialIcon = null,
        tutorialPhase = null;
  
  TutorialCard.tutorial({
    required this.tutorialTitle,
    required this.tutorialDescription,
    required this.tutorialIcon,
    required this.tutorialPhase,
  }) : type = CardType.tutorial,
       movie = null;
}

class SwipingTutorialScreen extends StatefulWidget {
  final UserProfile profile;
  final List<Movie> movies;

  const SwipingTutorialScreen({
    super.key,
    required this.profile,
    required this.movies,
  });

  @override
  State<SwipingTutorialScreen> createState() => _SwipingTutorialScreenState();
}

class _SwipingTutorialScreenState extends State<SwipingTutorialScreen> 
    with TickerProviderStateMixin {
  
  List<TutorialCard> tutorialStack = [];
  int currentCardIndex = 0;
  TutorialPhase currentPhase = TutorialPhase.introduction;
  
  // Tutorial progress tracking
  bool hasSwipedMovie = false;
  bool hasUsedViewMore = false;
  int totalMoviesSwiped = 0;
  final int requiredSwipes = 10; // Need 10 swipes to complete tutorial
  
  // Animation controllers
  late AnimationController _celebrationController;
  late Animation<double> _celebrationScale;
  
  // Tutorial tracking - will be sent to Firebase
  final List<String> userLikes = [];
  final List<String> userPasses = [];
  final Set<String> usedMovieIds = <String>{}; // Prevent duplicates

@override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeTutorial();
  }

  void _initializeAnimations() {
    _celebrationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _celebrationScale = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _celebrationController, curve: Curves.elasticOut),
    );
  }

  Future<void> _initializeTutorial() async {
    await _createTutorialStack();
    if (mounted) {
      setState(() {
        // Just trigger a rebuild - tutorialStack is already populated
      });
    }
  }

  Future<void> _createTutorialStack() async {
    final allMovies = await MovieJsonLoader.loadOnboardingMovies();
    tutorialStack = [];
    
    // 1. Introduction card
    tutorialStack.add(TutorialCard.tutorial(
      tutorialTitle: "Welcome to Movie Swiping! 🎬",
      tutorialDescription: "Swipe right (➡️) on movies you'd watch, left (⬅️) on ones you wouldn't. Your choices help us learn your taste!",
      tutorialIcon: Icons.movie_filter,
      tutorialPhase: TutorialPhase.introduction,
    ));
    
    // 2. Basic swiping instruction
    tutorialStack.add(TutorialCard.tutorial(
      tutorialTitle: "How to Swipe 👆",
      tutorialDescription: "➡️ Swipe RIGHT = I'd watch this\n⬅️ Swipe LEFT = Not interested\n\nJust follow your gut - there are no wrong answers!",
      tutorialIcon: Icons.swipe,
      tutorialPhase: TutorialPhase.basicSwiping,
    ));
    
    // 3. Add first batch of movies (5 random movies)
    final shuffledMovies = List<Movie>.from(allMovies)..shuffle();
    for (int i = 0; i < math.min(5, shuffledMovies.length); i++) {
      tutorialStack.add(TutorialCard.movie(shuffledMovies[i]));
      usedMovieIds.add(shuffledMovies[i].id);
    }
    
    // 4. View more demo instruction
    tutorialStack.add(TutorialCard.tutorial(
      tutorialTitle: "Want More Info? 📖",
      tutorialDescription: "Not sure about a movie? Tap 'View more' to see the plot, cast, and other details before deciding!",
      tutorialIcon: Icons.info,
      tutorialPhase: TutorialPhase.viewMoreDemo,
    ));
    
    // 5. Add remaining movies for free swiping (randomized, no duplicates)
    final remainingMovies = allMovies.where((movie) => !usedMovieIds.contains(movie.id)).toList();
    remainingMovies.shuffle();
    
    for (final movie in remainingMovies) {
      tutorialStack.add(TutorialCard.movie(movie));
    }
  }
  
  bool _onSwipe(int previousIndex, int? currentIndex, CardSwiperDirection direction) {
    if (previousIndex >= tutorialStack.length) return false;
    
    final card = tutorialStack[previousIndex];
    final isSwipeRight = direction == CardSwiperDirection.right;
    
    if (card.type == CardType.tutorial) {
      // Tutorial cards: just advance to next phase
      if (isSwipeRight) {
        _advancePhase(card.tutorialPhase!);
      } else {
        // Don't allow left swipes on tutorial cards
        return false;
      }
    } else if (card.type == CardType.movie && card.movie != null) {
      // Movie cards: track preferences for Firebase learning
      final movie = card.movie!;
      
      if (isSwipeRight) {
        userLikes.add(movie.id);
        print("❤️ User liked: ${movie.title}");
      } else {
        userPasses.add(movie.id);
        print("👎 User passed: ${movie.title}");
      }
      
      totalMoviesSwiped++;
      _checkTutorialProgress();
    }
    
    setState(() {
      currentCardIndex = currentIndex ?? 0;
    });
    
    return true;
  }
  
  void _advancePhase(TutorialPhase newPhase) {
    setState(() {
      currentPhase = newPhase;
    });
    
    print("📖 Advanced to phase: ${newPhase.name}");
  }
  
  void _checkTutorialProgress() {
    // Give encouraging feedback at milestones
    if (totalMoviesSwiped == 1 && !hasSwipedMovie) {
      hasSwipedMovie = true;
      _showCelebration("Great first swipe! Keep going! 🎯");
      setState(() {
        currentPhase = TutorialPhase.freeSwipe;
      });
    } else if (totalMoviesSwiped == 5) {
      _showCelebration("You're getting the hang of it! ✨");
    } else if (totalMoviesSwiped >= requiredSwipes) {
      _showCelebration("Perfect! You've built a great starting profile! 🎉");
      Future.delayed(const Duration(seconds: 2), () {
        _completeTutorial();
      });
    }
  }
  
  void _showCelebration(String message) {
    _celebrationController.forward().then((_) {
      Future.delayed(const Duration(seconds: 1), () {
        _celebrationController.reverse();
      });
    });
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFFE5A00D),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.r)),
        duration: const Duration(seconds: 2),
      ),
    );
  }
  
  void _onViewMorePressed() {
    if (currentCardIndex < tutorialStack.length) {
      final card = tutorialStack[currentCardIndex];
      
      if (card.type == CardType.movie && card.movie != null) {
        if (!hasUsedViewMore) {
          hasUsedViewMore = true;
          _showCelebration("Nice! Now you know how to explore details! 📖");
        }
        
        // Show movie details
        showMovieDetails(
          context: context,
          movie: card.movie!,
          currentUser: widget.profile,
        );
      }
    }
  }
  
  void _completeTutorial() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => LearningDemoScreen(
          profile: widget.profile,
          movies: widget.movies,
          tutorialLikes: userLikes,
          tutorialPasses: userPasses,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _celebrationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final progress = totalMoviesSwiped / requiredSwipes;
    
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                // Header
                Padding(
                  padding: EdgeInsets.all(16.w),
                  child: Column(
                    children: [
                      Text(
                        "Let's Learn Your Taste! 🎬",
                        style: TextStyle(
                          fontSize: 24.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      Text(
                        _getCurrentPhaseDescription(),
                        style: TextStyle(
                          fontSize: 14.sp,
                          color: Colors.white70,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
                
                // Progress indicator (only show during movie swiping)
                if (currentPhase == TutorialPhase.freeSwipe) ...[
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 16.w),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Progress",
                              style: TextStyle(
                                fontSize: 14.sp,
                                color: Colors.white,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Text(
                              "$totalMoviesSwiped / $requiredSwipes movies",
                              style: TextStyle(
                                fontSize: 14.sp,
                                color: const Color(0xFFE5A00D),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 8.h),
                        LinearProgressIndicator(
                          value: progress.clamp(0.0, 1.0),
                          backgroundColor: Colors.white24,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            progress >= 1.0 ? Colors.green : const Color(0xFFE5A00D),
                          ),
                          minHeight: 6.h,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16.h),
                ],
                
                // Stats display
                if (totalMoviesSwiped > 0) ...[
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 16.w),
                    padding: EdgeInsets.all(12.w),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1F1F1F),
                      borderRadius: BorderRadius.circular(8.r),
                      border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.3), width: 1.w),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildStatItem("Liked", userLikes.length, Colors.green),
                        _buildStatItem("Passed", userPasses.length, Colors.red),
                        _buildStatItem("Total", totalMoviesSwiped, const Color(0xFFE5A00D)),
                      ],
                    ),
                  ),
                  SizedBox(height: 16.h),
                ],
                
                // Card swiper
                // Card swiper
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(16.w),
                    child: tutorialStack.isEmpty
                        ? Center(
                            child: CircularProgressIndicator(
                              color: const Color(0xFFE5A00D),
                            ),
                          )
                        : CardSwiper(
                            cardsCount: tutorialStack.length,
                            numberOfCardsDisplayed: 1,
                            onSwipe: _onSwipe,
                            threshold: 50,
                            maxAngle: 30,
                            cardBuilder: (context, index, percentX, percentY) {
                              if (index >= tutorialStack.length) return const SizedBox.shrink();
                              
                              final card = tutorialStack[index];
                              
                              if (card.type == CardType.tutorial) {
                                return _buildTutorialCard(card, percentX.toDouble(), percentY.toDouble());
                              } else {
                                return _buildMovieCard(card.movie!, percentX.toDouble(), percentY.toDouble());
                              }
                            },
                          ),
                  ),
                ),
                
                // Bottom instruction
                Container(
                  padding: EdgeInsets.all(16.w),
                  child: Text(
                    _getBottomInstructionText(),
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: Colors.white54,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
            
            // Celebration overlay
            if (_celebrationController.status == AnimationStatus.forward ||
                _celebrationController.status == AnimationStatus.completed)
              _buildCelebrationOverlay(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildStatItem(String label, int value, Color color) {
    return Column(
      children: [
        Text(
          value.toString(),
          style: TextStyle(
            fontSize: 20.sp,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        SizedBox(height: 4.h),
        Text(
          label,
          style: TextStyle(
            fontSize: 12.sp,
            color: Colors.white70,
          ),
        ),
      ],
    );
  }
  
  Widget _buildTutorialCard(TutorialCard card, double percentX, double percentY) {
    final rightIntensity = percentX > 0 ? percentX.clamp(0.0, 1.0) : 0.0;
    final leftIntensity = percentX < 0 ? (-percentX).clamp(0.0, 1.0) : 0.0;
    
    return Container(
      margin: EdgeInsets.all(8.r),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.r),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFFE5A00D).withValues(alpha: 0.9),
            const Color(0xFFFF8A00).withValues(alpha: 0.9),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFE5A00D).withValues(alpha: 0.5),
            blurRadius: 20.r,
            spreadRadius: 2.r,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18.r),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Content
            Padding(
              padding: EdgeInsets.all(32.w),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Icon
                  Container(
                    padding: EdgeInsets.all(20.w),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.2),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      card.tutorialIcon!,
                      size: 64.sp,
                      color: Colors.white,
                    ),
                  ),
                  
                  SizedBox(height: 32.h),
                  
                  Text(
                    card.tutorialTitle!,
                    style: TextStyle(
                      fontSize: 24.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  
                  SizedBox(height: 20.h),
                  
                  Flexible(  // Add this wrapper
                    child: Text(
                      card.tutorialDescription!,
                      style: TextStyle(
                        fontSize: 14.sp,  // Reduced from 16.sp
                        color: Colors.white.withValues(alpha: 0.9),
                        height: 1.4,  // Reduced from 1.5
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 4,  // Add max lines
                      overflow: TextOverflow.ellipsis,  // Add overflow handling
                    ),
                  ),
                  
                  SizedBox(height: 32.h),
                  
                  // Swipe indicator
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(20.r),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.swipe_right, color: Colors.white, size: 20.sp),
                        SizedBox(width: 8.w),
                        Text(
                          "Swipe right to continue",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            
            // Swipe indicators
            if (rightIntensity > 0)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerRight,
                      end: Alignment.centerLeft,
                      colors: [
                        Colors.green.withValues(alpha: 0.8 * rightIntensity),
                        Colors.green.withValues(alpha: 0),
                      ],
                      stops: const [0.0, 0.4],
                    ),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.check_circle,
                      color: Colors.green,
                      size: 64.sp * rightIntensity,
                    ),
                  ),
                ),
              ),
            
            if (leftIntensity > 0)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [
                        Colors.orange.withValues(alpha: 0.6 * leftIntensity),
                        Colors.orange.withValues(alpha: 0),
                      ],
                      stops: const [0.0, 0.4],
                    ),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.arrow_forward,
                          color: Colors.white,
                          size: 48.sp * leftIntensity,
                        ),
                        SizedBox(height: 8.h),
                        Text(
                          "Swipe right to continue",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14.sp * leftIntensity,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildMovieCard(Movie movie, double percentX, double percentY) {
    final leftIntensity = percentX < 0 ? (-percentX).clamp(0.0, 1.0) : 0.0;
    final rightIntensity = percentX > 0 ? percentX.clamp(0.0, 1.0) : 0.0;
    
    // Show hint for view more during that phase
    final showViewMoreHint = currentPhase == TutorialPhase.viewMoreDemo && 
                             !hasUsedViewMore;
    
    return Container(
      margin: EdgeInsets.all(8.r),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: showViewMoreHint ? Colors.cyan : const Color(0xFFE5A00D),
          width: showViewMoreHint ? 3.w : 2.w,
        ),
        boxShadow: [
          BoxShadow(
            color: (showViewMoreHint ? Colors.cyan : const Color(0xFFE5A00D)).withValues(alpha: 0.3),
            blurRadius: showViewMoreHint ? 16.r : 12.r,
            spreadRadius: showViewMoreHint ? 4.r : 2.r,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14.r),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(color: const Color(0xFF1A1A1A)),
            
            Column(
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      Image.network(
                        movie.posterUrl,
                        fit: BoxFit.contain,
                        width: double.infinity,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: Colors.grey[800],
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.movie, size: 64.sp, color: Colors.white30),
                                SizedBox(height: 8.h),
                                Text(
                                  movie.title,
                                  style: TextStyle(color: Colors.white70, fontSize: 16.sp),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      
                      // Hint for view more
                      if (showViewMoreHint)
                        Positioned(
                          top: 12.h,
                          right: 12.w,
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                            decoration: BoxDecoration(
                              color: Colors.cyan,
                              borderRadius: BorderRadius.circular(12.r),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.touch_app, color: Colors.white, size: 12.sp),
                                SizedBox(width: 4.w),
                                Text(
                                  "Try me!",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10.sp,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(16.w),
                  child: Column(
                    children: [
                      Text(
                        movie.title,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18.sp,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 8.h),
                      Text(
                        movie.genres.join(' • '),
                        style: TextStyle(
                          color: const Color(0xFFE5A00D),
                          fontSize: 12.sp,
                        ),
                      ),
                      SizedBox(height: 12.h),
                      
                      // View more button
                      ElevatedButton(
                        onPressed: _onViewMorePressed,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: showViewMoreHint ? Colors.cyan : const Color(0xFFE5A00D),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.r),
                          ),
                          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                        ),
                        child: Text(
                          "View more",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14.sp,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            
            // Swipe indicators
            if (leftIntensity > 0)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [
                        Colors.red.withValues(alpha: 0.7 * leftIntensity),
                        Colors.red.withValues(alpha: 0),
                      ],
                      stops: const [0.0, 0.3],
                    ),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.close, color: Colors.red, size: 64.sp * leftIntensity),
                        SizedBox(height: 8.h),
                        Text(
                          "Pass",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16.sp * leftIntensity,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            
            if (rightIntensity > 0)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerRight,
                      end: Alignment.centerLeft,
                      colors: [
                        Colors.green.withValues(alpha: 0.7 * rightIntensity),
                        Colors.green.withValues(alpha: 0),
                      ],
                      stops: const [0.0, 0.3],
                    ),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.favorite, color: Colors.green, size: 64.sp * rightIntensity),
                        SizedBox(height: 8.h),
                        Text(
                          "Like",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16.sp * rightIntensity,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildCelebrationOverlay() {
    return ScaleTransition(
      scale: _celebrationScale,
      child: Container(
        color: Colors.black.withValues(alpha: 0.3),
        child: Center(
          child: Container(
            padding: EdgeInsets.all(20.w),
            decoration: BoxDecoration(
              color: const Color(0xFFE5A00D),
              borderRadius: BorderRadius.circular(16.r),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.celebration, color: Colors.white, size: 48.sp),
                SizedBox(height: 12.h),
                Text(
                  "Well Done! 🎉",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  
  // Helper methods
  String _getCurrentPhaseDescription() {
    switch (currentPhase) {
      case TutorialPhase.introduction:
        return "Learn the basics of movie swiping";
      case TutorialPhase.basicSwiping:
        return "Understanding how to swipe";
      case TutorialPhase.viewMoreDemo:
        return "Learning to explore movie details";
      case TutorialPhase.freeSwipe:
        return "Swipe naturally - we're learning your taste!";
    }
  }
  
  String _getBottomInstructionText() {
    switch (currentPhase) {
      case TutorialPhase.introduction:
      case TutorialPhase.basicSwiping:
        return "Swipe through the tutorial cards to learn";
      case TutorialPhase.viewMoreDemo:
        return hasUsedViewMore ? "Great! Now swipe based on your preference" : "Try tapping 'View more' to see movie details";
      case TutorialPhase.freeSwipe:
        final remaining = requiredSwipes - totalMoviesSwiped;
        return remaining > 0 ? "Swipe $remaining more movies to complete your profile" : "Tutorial complete! Great job!";
    }
  }
}