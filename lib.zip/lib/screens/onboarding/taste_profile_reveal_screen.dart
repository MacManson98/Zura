// File: lib/screens/onboarding/taste_profile_reveal_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../models/user_profile.dart';
import '../../movie.dart';
import '../../utils/enhanced_learning_engine.dart';
import '../../utils/user_profile_storage.dart';
import '../../main_navigation.dart';
import '../../utils/film_identity_generator.dart';
import 'dart:async';
import 'dart:math' as math;

class TasteProfileRevealScreen extends StatefulWidget {
  final UserProfile profile;
  final List<Movie> movies;
  final List<Map<String, dynamic>> tutorialMatches;

  const TasteProfileRevealScreen({
    super.key,
    required this.profile,
    required this.movies,
    required this.tutorialMatches,
  });

  @override
  State<TasteProfileRevealScreen> createState() => _TasteProfileRevealScreenState();
}

class _TasteProfileRevealScreenState extends State<TasteProfileRevealScreen> 
    with TickerProviderStateMixin {
  
  // Animation controllers
  late AnimationController _revealController;
  late AnimationController _statsController;
  late AnimationController _identityController;
  late AnimationController _particleController;
  late AnimationController _pulseController;
  
  // Animations
  late Animation<double> _revealFade;
  late Animation<Offset> _revealSlide;
  late Animation<double> _statsScale;
  late Animation<double> _identityGlow;
  late Animation<double> _particleRotation;
  late Animation<double> _pulseScale;
  
  // Profile data
  late Map<String, dynamic> profileAnalysis;
  String filmIdentity = '';
  bool showingStats = false;
  bool showingIdentity = false;
  bool showingRecommendations = false;
  bool readyToProceed = false;
  
  // UI state
  int currentRevealStep = 0;
  Timer? _autoAdvanceTimer;
  List<Movie> personalizedRecommendations = [];
  
  // Particle system for background
  final List<Particle> particles = [];
  final int particleCount = 20;

  @override
  void initState() {
    super.initState();
    
    _initializeAnimations();
    _generateProfileAnalysis();
    _createParticles();
    _startRevealSequence();
  }
  
  void _initializeAnimations() {
    _revealController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );
    
    _statsController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _identityController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _particleController = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    );
    
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    
    _revealFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _revealController, curve: Curves.easeOut),
    );
    
    _revealSlide = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _revealController, curve: Curves.elasticOut));
    
    _statsScale = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _statsController, curve: Curves.elasticOut),
    );
    
    _identityGlow = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _identityController, curve: Curves.easeInOut),
    );
    
    _particleRotation = Tween<double>(begin: 0.0, end: 2 * math.pi).animate(
      CurvedAnimation(parent: _particleController, curve: Curves.linear),
    );
    
    _pulseScale = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }
  
  void _generateProfileAnalysis() {
    // Use enhanced learning engine to analyze the complete profile
    profileAnalysis = EnhancedLearningEngine.analyzeTasteProfile(widget.profile);
    
    // Generate film identity
    final topGenre = profileAnalysis['topGenres'].isNotEmpty 
        ? profileAnalysis['topGenres'][0]['name'] 
        : 'Any';
    final topVibe = profileAnalysis['topVibes'].isNotEmpty 
        ? profileAnalysis['topVibes'][0]['name'] 
        : 'Any';
    
    filmIdentity = getFilmIdentity(topGenre, topVibe);
    
    // Generate personalized recommendations based on profile
    _generatePersonalizedRecommendations();
    
    print("🎭 Profile Analysis Complete:");
    print("   Identity: $filmIdentity");
    print("   Top Genre: $topGenre");
    print("   Top Vibe: $topVibe");
    print("   Movies Liked: ${profileAnalysis['totalMoviesLiked']}");
  }
  
  void _generatePersonalizedRecommendations() {
    // This would use your enhanced learning engine in a real app
    // For now, we'll create some smart recommendations based on preferences
    final allMovies = widget.movies;
    final topGenres = profileAnalysis['topGenres'] as List;
    
    if (topGenres.isNotEmpty) {
      final primaryGenre = topGenres[0]['name'];
      personalizedRecommendations = allMovies.where((movie) =>
        movie.genres.contains(primaryGenre) &&
        !widget.profile.likedMovieIds.contains(movie.id)
      ).take(6).toList();
    }
    
    if (personalizedRecommendations.length < 6) {
      // Fallback to popular movies
      personalizedRecommendations.addAll(
        allMovies.where((m) => !personalizedRecommendations.contains(m)).take(6 - personalizedRecommendations.length)
      );
    }
  }
  
  void _createParticles() {
    final random = math.Random();
    for (int i = 0; i < particleCount; i++) {
      particles.add(Particle(
        position: Offset(
          random.nextDouble() * 400,
          random.nextDouble() * 800,
        ),
        velocity: Offset(
          (random.nextDouble() - 0.5) * 2,
          (random.nextDouble() - 0.5) * 2,
        ),
        size: random.nextDouble() * 4 + 2,
        color: _getRandomAccentColor(),
      ));
    }
  }
  
  void _startRevealSequence() async {
    // Start particle animation
    _particleController.repeat();
    
    // Step 1: Welcome message
    await Future.delayed(const Duration(milliseconds: 500));
    _revealController.forward();
    
    // Step 2: Show stats
    await Future.delayed(const Duration(seconds: 2));
    _showStats();
    
    // Step 3: Reveal film identity
    await Future.delayed(const Duration(seconds: 3));
    _showIdentity();
    
    // Step 4: Show recommendations
    await Future.delayed(const Duration(seconds: 3));
    _showRecommendations();
    
    // Step 5: Ready to proceed
    await Future.delayed(const Duration(seconds: 2));
    _enableProceed();
  }
  
  void _showStats() {
    setState(() {
      showingStats = true;
      currentRevealStep = 1;
    });
    _statsController.forward();
  }
  
  void _showIdentity() {
    setState(() {
      showingIdentity = true;
      currentRevealStep = 2;
    });
    _identityController.forward();
    _pulseController.repeat(reverse: true);
  }
  
  void _showRecommendations() {
    setState(() {
      showingRecommendations = true;
      currentRevealStep = 3;
    });
  }
  
  void _enableProceed() {
    setState(() {
      readyToProceed = true;
      currentRevealStep = 4;
    });
  }
  
  Future<void> _completeOnboarding() async {
    // Mark onboarding as complete
    final finalProfile = widget.profile.copyWith(
      hasCompletedOnboarding: true,
    );
    
    // Save the complete profile
    await UserProfileStorage.saveProfile(finalProfile);
    
    // Navigate to main app
    if (mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (_) => MainNavigation(
            profile: finalProfile,
            movies: widget.movies,
          ),
        ),
        (route) => false, // Remove all previous routes
      );
    }
  }

  @override
  void dispose() {
    _revealController.dispose();
    _statsController.dispose();
    _identityController.dispose();
    _particleController.dispose();
    _pulseController.dispose();
    _autoAdvanceTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: Stack(
        children: [
          // Animated particle background
          _buildParticleBackground(),
          
          // Main content
          SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(24.w),
              child: Column(
                children: [
                  // Header reveal
                  FadeTransition(
                    opacity: _revealFade,
                    child: SlideTransition(
                      position: _revealSlide,
                      child: _buildHeader(),
                    ),
                  ),
                  
                  SizedBox(height: 32.h),
                  
                  // Stats section
                  if (showingStats) _buildStatsSection(),
                  
                  // Film identity reveal
                  if (showingIdentity) _buildIdentitySection(),
                  
                  // Recommendations section
                  if (showingRecommendations) _buildRecommendationsSection(),
                  
                  // Completion section
                  if (readyToProceed) _buildCompletionSection(),
                  
                  SizedBox(height: 100.h), // Extra space at bottom
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildParticleBackground() {
    return AnimatedBuilder(
      animation: _particleController,
      builder: (context, child) {
        return CustomPaint(
          size: Size.infinite,
          painter: ParticlePainter(particles, _particleRotation.value),
        );
      },
    );
  }
  
  Widget _buildHeader() {
    return Column(
      children: [
        // Main title with gradient
        Container(
          padding: EdgeInsets.all(24.w),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFFE5A00D).withValues(alpha: 0.1),
                const Color(0xFFFF8A00).withValues(alpha: 0.1),
              ],
            ),
            borderRadius: BorderRadius.circular(20.r),
            border: Border.all(
              color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
              width: 1.w,
            ),
          ),
          child: Column(
            children: [
              Icon(
                Icons.psychology,
                size: 64.sp,
                color: const Color(0xFFE5A00D),
              ),
              SizedBox(height: 16.h),
              Text(
                "Your Movie Profile is Ready! 🎉",
                style: TextStyle(
                  fontSize: 28.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 8.h),
              Text(
                "Based on your preferences, here's what we learned about your taste in movies",
                style: TextStyle(
                  fontSize: 16.sp,
                  color: Colors.white70,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildStatsSection() {
    return ScaleTransition(
      scale: _statsScale,
      child: Container(
        margin: EdgeInsets.only(bottom: 32.h),
        padding: EdgeInsets.all(20.w),
        decoration: BoxDecoration(
          color: const Color(0xFF1F1F1F),
          borderRadius: BorderRadius.circular(16.r),
          border: Border.all(
            color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
            width: 1.w,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Your Movie Journey 📊",
              style: TextStyle(
                fontSize: 20.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            
            SizedBox(height: 20.h),
            
            // Stats grid
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    "Movies Rated",
                    "${profileAnalysis['totalMoviesLiked']}",
                    Icons.movie,
                    Colors.blue,
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: _buildStatCard(
                    "Genres Explored",
                    "${(profileAnalysis['topGenres'] as List).length}",
                    Icons.category,
                    Colors.green,
                  ),
                ),
              ],
            ),
            
            SizedBox(height: 12.h),
            
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    "Friend Matches",
                    "${widget.tutorialMatches.length}",
                    Icons.people,
                    Colors.purple,
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: _buildStatCard(
                    "Profile Strength",
                    "${(profileAnalysis['discoveryScore'] * 10).round()}/10",
                    Icons.star,
                    const Color(0xFFE5A00D),
                  ),
                ),
              ],
            ),
            
            SizedBox(height: 20.h),
            
            // Top preferences
            if ((profileAnalysis['topGenres'] as List).isNotEmpty) ...[
              Text(
                "Your Top Genres:",
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 8.h),
              Wrap(
                spacing: 8.w,
                runSpacing: 8.h,
                children: (profileAnalysis['topGenres'] as List).take(3).map((genre) =>
                  _buildPreferenceChip(
                    genre['name'],
                    _getGenreColor(genre['name']),
                  ),
                ).toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }
  
  Widget _buildIdentitySection() {
    return AnimatedBuilder(
      animation: _identityGlow,
      builder: (context, child) {
        return Container(
          margin: EdgeInsets.only(bottom: 32.h),
          padding: EdgeInsets.all(24.w),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFFE5A00D).withValues(alpha: 0.2 * _identityGlow.value),
                const Color(0xFFFF8A00).withValues(alpha: 0.1 * _identityGlow.value),
              ],
            ),
            borderRadius: BorderRadius.circular(20.r),
            border: Border.all(
              color: const Color(0xFFE5A00D).withValues(alpha: 0.5 * _identityGlow.value),
              width: 2.w,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFE5A00D).withValues(alpha: 0.3 * _identityGlow.value),
                blurRadius: 20.r * _identityGlow.value,
                spreadRadius: 2.r * _identityGlow.value,
              ),
            ],
          ),
          child: ScaleTransition(
            scale: _pulseScale,
            child: Column(
              children: [
                Icon(
                  Icons.auto_awesome,
                  size: 48.sp,
                  color: const Color(0xFFE5A00D),
                ),
                SizedBox(height: 16.h),
                Text(
                  "Your Film Identity",
                  style: TextStyle(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFFE5A00D),
                  ),
                ),
                SizedBox(height: 12.h),
                Text(
                  filmIdentity,
                  style: TextStyle(
                    fontSize: 32.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 16.h),
                Text(
                  _getIdentityDescription(filmIdentity),
                  style: TextStyle(
                    fontSize: 16.sp,
                    color: Colors.white70,
                    height: 1.4,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
  
  Widget _buildRecommendationsSection() {
    return Container(
      margin: EdgeInsets.only(bottom: 32.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Movies We Think You'll Love 🎬",
            style: TextStyle(
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 16.h),
          
          SizedBox(
            height: 200.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: personalizedRecommendations.length,
              itemBuilder: (context, index) {
                final movie = personalizedRecommendations[index];
                return Container(
                  width: 120.w,
                  margin: EdgeInsets.only(right: 12.w),
                  child: Column(
                    children: [
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8.r),
                          child: Image.network(
                            movie.posterUrl,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            errorBuilder: (_, __, ___) => Container(
                              color: Colors.grey[800],
                              child: Icon(Icons.movie, size: 40.sp, color: Colors.white30),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 8.h),
                      Text(
                        movie.title,
                        style: TextStyle(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildCompletionSection() {
    return Container(
      padding: EdgeInsets.all(24.w),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF1F1F1F),
            Color(0xFF2A2A2A),
          ],
        ),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: const Color(0xFFE5A00D).withValues(alpha: 0.5),
          width: 1.w,
        ),
      ),
      child: Column(
        children: [
          Icon(
            Icons.celebration,
            size: 64.sp,
            color: const Color(0xFFE5A00D),
          ),
          SizedBox(height: 16.h),
          Text(
            "You're All Set! 🚀",
            style: TextStyle(
              fontSize: 24.sp,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 12.h),
          Text(
            "Your personalized movie experience awaits. Start swiping, match with friends, and discover your next favorite film!",
            style: TextStyle(
              fontSize: 16.sp,
              color: Colors.white70,
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 24.h),
          
          SizedBox(
            width: double.infinity,
            height: 56.h,
            child: ElevatedButton(
              onPressed: _completeOnboarding,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.r),
                ),
                elevation: 4,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.movie_filter,
                    color: Colors.white,
                    size: 24.sp,
                  ),
                  SizedBox(width: 12.w),
                  Text(
                    "Start Using QueueTogether!",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          SizedBox(height: 16.h),
          
          // Summary of what they can do
          Container(
            padding: EdgeInsets.all(16.w),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(12.r),
            ),
            child: Column(
              children: [
                Text(
                  "What you can do now:",
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFFE5A00D),
                  ),
                ),
                SizedBox(height: 8.h),
                _buildFeatureItem(Icons.swipe_right, "Solo swipe to discover new movies"),
                _buildFeatureItem(Icons.people, "Match with friends and family"),
                _buildFeatureItem(Icons.smart_toy, "Get AI-powered recommendations"),
                _buildFeatureItem(Icons.favorite, "Build your personal movie collection"),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildStatCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: color.withValues(alpha: 0.3), width: 1.w),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24.sp),
          SizedBox(height: 8.h),
          Text(
            value,
            style: TextStyle(
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          SizedBox(height: 4.h),
          Text(
            label,
            style: TextStyle(
              fontSize: 12.sp,
              color: Colors.white70,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  
  Widget _buildPreferenceChip(String label, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: color, width: 1.w),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 12.sp,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
  
  Widget _buildFeatureItem(IconData icon, String text) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4.h),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFFE5A00D), size: 16.sp),
          SizedBox(width: 8.w),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12.sp,
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  // Helper methods
  String _getIdentityDescription(String identity) {
    const descriptions = {
      'The Action Enthusiast': 'You love high-energy movies with excitement and adventure at every turn.',
      'The Comedy Connoisseur': 'You appreciate good humor and enjoy movies that make you laugh out loud.',
      'The Drama Devotee': 'You\'re drawn to meaningful stories with deep character development and emotional depth.',
      'The Horror Aficionado': 'You enjoy the thrill of being scared and appreciate well-crafted suspense.',
      'The Romance Romantic': 'You love heartwarming love stories and emotional connections between characters.',
      'The Sci-Fi Scholar': 'You\'re fascinated by futuristic concepts and imaginative storytelling.',
      'The Fantasy Fan': 'You love escaping into magical worlds full of wonder and adventure.',
      'The Thriller Seeker': 'You enjoy edge-of-your-seat suspense and cleverly plotted mysteries.',
      'Movie Explorer': 'You have diverse tastes and enjoy exploring different types of cinema.',
    };
    
    return descriptions[identity] ?? 'You have unique and interesting taste in movies that makes you special!';
  }
  
  Color _getGenreColor(String genre) {
    switch (genre.toLowerCase()) {
      case 'action': return Colors.red;
      case 'comedy': return Colors.orange;
      case 'drama': return Colors.blue;
      case 'horror': return Colors.purple;
      case 'romance': return Colors.pink;
      case 'sci-fi': return Colors.cyan;
      case 'fantasy': return Colors.deepPurple;
      case 'thriller': return Colors.indigo;
      default: return const Color(0xFFE5A00D);
    }
  }
  
  Color _getRandomAccentColor() {
    final colors = [
      const Color(0xFFE5A00D),
      Colors.blue,
      Colors.purple,
      Colors.green,
      Colors.red,
      Colors.orange,
    ];
    return colors[math.Random().nextInt(colors.length)];
  }
}

// Particle system for animated background
class Particle {
  Offset position;
  Offset velocity;
  double size;
  Color color;
  
  Particle({
    required this.position,
    required this.velocity,
    required this.size,
    required this.color,
  });
  
  void update() {
    position += velocity;
    
    // Wrap around screen edges
    if (position.dx < 0) position = Offset(400, position.dy);
    if (position.dx > 400) position = Offset(0, position.dy);
    if (position.dy < 0) position = Offset(position.dx, 800);
    if (position.dy > 800) position = Offset(position.dx, 0);
  }
}

class ParticlePainter extends CustomPainter {
  final List<Particle> particles;
  final double animationValue;
  
  ParticlePainter(this.particles, this.animationValue);
  
  @override
  void paint(Canvas canvas, Size size) {
    for (final particle in particles) {
      particle.update();
      
      final paint = Paint()
        ..color = particle.color.withValues(alpha: 0.3)
        ..style = PaintingStyle.fill;
      
      canvas.drawCircle(particle.position, particle.size, paint);
    }
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}