import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/user_profile.dart';
import '../models/friend_group.dart';
import '../movie.dart';
import 'friend_profile_screen.dart';
import 'add_friend_screen.dart';
import 'create_group_screen.dart';
import 'group_detail_screen.dart';
import 'matcher_screen.dart';
import '../widgets/friend_card.dart';
import '../widgets/group_card.dart';
import '../services/friendship_service.dart'; // ✅ Add this import

class FriendsScreen extends StatefulWidget {
  final UserProfile currentUser;
  final List<Movie> allMovies;
  final VoidCallback onShowMatches;
  final void Function(UserProfile friend)? onMatchWithFriend;

  const FriendsScreen({
    super.key,
    required this.currentUser,
    required this.allMovies,
    required this.onShowMatches,
    this.onMatchWithFriend,
  });

  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<UserProfile> _friends = [];
  List<FriendGroup> _groups = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this); // ✅ Changed to 3 tabs
    _loadFriends();
    _loadGroups();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // Add this method to debug the friend requests stream
  void _debugFriendRequests() async {
    print("🔍 DEBUG: Current user UID: ${widget.currentUser.uid}");
    
    // Test the stream manually
    final stream = FriendshipService.getPendingFriendRequests(widget.currentUser.uid);
    
    stream.listen((requests) {
      print("🔍 DEBUG: Received ${requests.length} friend requests");
      for (var request in requests) {
        print("   Request: ${request['fromUserName']} → ${request['toUserName']}");
        print("   Status: ${request['status']}");
        print("   ToUserId: ${request['toUserId']}");
      }
    });
    
    // Also check all friend requests in the collection
    final allRequests = await FirebaseFirestore.instance
        .collection('friend_requests')
        .get();
        
    print("🔍 DEBUG: Total friend requests in database: ${allRequests.docs.length}");
    for (var doc in allRequests.docs) {
      final data = doc.data();
      print("   ${data['fromUserName']} → ${data['toUserName']} (${data['status']})");
      print("   Document ID: ${doc.id}");
    }
  }

  Future<void> _loadFriends() async {
    setState(() => _isLoading = true);

    try {
      // ✅ Use FriendshipService instead of loading all users
      final friends = await FriendshipService.getFriends(widget.currentUser.uid);
      
      setState(() {
        _friends = friends;
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading friends: $e');
      setState(() => _isLoading = false);
    }
  }

  void _loadGroups() async {
    // Keep your existing group loading logic
    setState(() => _isLoading = true);

    final snapshot = await FirebaseFirestore.instance.collection('groups').get();

    final loadedGroups = snapshot.docs.map((doc) {
      final data = doc.data();
      return FriendGroup(
        id: doc.id,
        name: data['name'] ?? '',
        members: (data['members'] as List<dynamic>? ?? [])
            .map((uid) => UserProfile.empty()..uid = uid)
            .toList(),
        createdBy: data['createdBy'] ?? '',
        imageUrl: data['imageUrl'] ?? '',
      );
    }).toList();

    setState(() {
      _groups = loadedGroups;
      _isLoading = false;
    });
  }

  void _createNewGroup() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CreateGroupScreen(
          currentUser: widget.currentUser,
          friends: _friends,
        ),
      ),
    );
    _loadGroups();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text('Friends', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: Icon(Icons.bug_report),
            onPressed: _debugFriendRequests,
          ),
          IconButton(
            icon: const Icon(Icons.movie_filter),
            tooltip: 'View Matches',
            onPressed: widget.onShowMatches,
          ),
          IconButton(
            icon: const Icon(Icons.person_add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AddFriendScreen(currentUser: widget.currentUser),
                ),
              ).then((_) => _loadFriends());
            },
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFFE5A00D),
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: [
            Tab(text: 'FRIENDS (${_friends.length})'), // ✅ Show count
            Tab(text: 'REQUESTS'), // ✅ New tab for friend requests
            Tab(text: 'GROUPS'),
          ],
        ),
      ),
      floatingActionButton: _tabController.index == 2 // ✅ Updated index
          ? FloatingActionButton(
              onPressed: _createNewGroup,
              backgroundColor: const Color(0xFFE5A00D),
              child: const Icon(Icons.group_add, color: Colors.white),
            )
          : null,
      body: TabBarView(
        controller: _tabController,
        children: [
          // Friends tab
          _isLoading ? _loadingSpinner() : _friends.isEmpty ? _buildEmptyFriendsState() : _buildFriendsList(),
          
          // ✅ Friend requests tab
          _buildFriendRequestsTab(),
          
          // Groups tab
          _isLoading ? _loadingSpinner() : _groups.isEmpty ? _buildEmptyGroupsState() : _buildGroupsList(),
        ],
      ),
    );
  }

  // ✅ NEW: Friend requests tab
  Widget _buildFriendRequestsTab() {
    print("🔍 Building friend requests tab for: ${widget.currentUser.uid}");
    
    return StreamBuilder<List<Map<String, dynamic>>>(
      key: ValueKey(widget.currentUser.uid), // Force rebuild if user changes
      stream: FriendshipService.getPendingFriendRequests(widget.currentUser.uid),
      builder: (context, snapshot) {
        print("🔍 StreamBuilder state: ${snapshot.connectionState}");
        print("🔍 Has data: ${snapshot.hasData}");
        print("🔍 Data length: ${snapshot.data?.length ?? 0}");
        
        if (snapshot.connectionState == ConnectionState.waiting) {
          return _loadingSpinner();
        }

        if (snapshot.hasError) {
          print("❌ Stream error: ${snapshot.error}");
          return Center(
            child: Text(
              "Error loading requests: ${snapshot.error}",
              style: TextStyle(color: Colors.red),
            ),
          );
        }

        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return _buildEmptyState(
            icon: Icons.mail_outline,
            title: 'No friend requests',
            subtitle: 'Friend requests will appear here',
            buttonLabel: 'Find Friends',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AddFriendScreen(currentUser: widget.currentUser),
                ),
              );
            },
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: snapshot.data!.length,
          itemBuilder: (context, index) {
            final request = snapshot.data![index];
            return _buildRequestTile(request);
          },
        );
      },
    );
  }

  Widget _buildRequestTile(Map<String, dynamic> request) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F1F1F),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          // Avatar
          CircleAvatar(
            backgroundColor: Colors.blue.shade700,
            radius: 24,
            child: Text(
              request['fromUserName'][0].toUpperCase(),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 16),
          
          // Request info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  request['fromUserName'],
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  "wants to be friends",
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          
          // Action buttons
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextButton(
                onPressed: () => _declineRequest(request),
                child: const Text(
                  "Decline",
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () => _acceptRequest(request),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE5A00D),
                  minimumSize: const Size(60, 32),
                ),
                child: const Text(
                  "Accept",
                  style: TextStyle(color: Colors.black, fontSize: 12),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _acceptRequest(Map<String, dynamic> request) async {
    try {
      await FriendshipService.acceptFriendRequest(
        fromUserId: request['fromUserId'],
        toUserId: request['toUserId'],
      );
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${request['fromUserName']} is now your friend!'),
          backgroundColor: Colors.green,
        ),
      );
      
      _loadFriends(); // Refresh friends list
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to accept request: $e')),
      );
    }
  }

  void _declineRequest(Map<String, dynamic> request) async {
    try {
      await FriendshipService.declineFriendRequest(
        fromUserId: request['fromUserId'],
        toUserId: request['toUserId'],
      );
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Friend request declined')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to decline request: $e')),
      );
    }
  }

  Widget _loadingSpinner() => const Center(
    child: CircularProgressIndicator(color: Color(0xFFE5A00D)),
  );

  Widget _buildEmptyFriendsState() {
    return _buildEmptyState(
      icon: Icons.people_outline,
      title: 'No friends yet',
      subtitle: 'Add friends to match movies together',
      buttonLabel: 'Add Friends',
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AddFriendScreen(currentUser: widget.currentUser),
          ),
        ).then((_) => _loadFriends());
      },
    );
  }

  Widget _buildEmptyGroupsState() {
    return _buildEmptyState(
      icon: Icons.group_outlined,
      title: 'No groups yet',
      subtitle: 'Create groups to match movies together',
      buttonLabel: 'Create Group',
      onPressed: _createNewGroup,
    );
  }

  Widget _buildEmptyState({
    required IconData icon,
    required String title,
    required String subtitle,
    required String buttonLabel,
    required VoidCallback onPressed,
  }) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 70, color: Colors.white30),
          const SizedBox(height: 16),
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(subtitle, style: const TextStyle(color: Colors.white54)),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: onPressed,
            icon: const Icon(Icons.add, color: Colors.white),
            label: Text(buttonLabel, style: const TextStyle(color: Colors.white)),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFE5A00D),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFriendsList() {
    return RefreshIndicator( // ✅ Add pull to refresh
      onRefresh: _loadFriends,
      color: const Color(0xFFE5A00D),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _friends.length,
        itemBuilder: (context, index) {
          final friend = _friends[index];
          final sharedGenres = friend.preferredGenres.intersection(widget.currentUser.preferredGenres);
          final compatibility = widget.currentUser.preferredGenres.isEmpty || friend.preferredGenres.isEmpty
              ? 0
              : (sharedGenres.length / (widget.currentUser.preferredGenres.length + friend.preferredGenres.length - sharedGenres.length)) * 100;

          return FriendCard(
            friend: friend,
            compatibility: compatibility.toDouble(),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FriendProfileScreen(
                    currentUser: widget.currentUser,
                    friend: friend,
                    allMovies: widget.allMovies,
                  ),
                ),
              );
            },
            onMatchPressed: () {
              print("🟡 Friend match button pressed: ${friend.name}");
              widget.onMatchWithFriend?.call(friend);
            },
          );
        },
      ),
    );
  }

  Widget _buildGroupsList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _groups.length,
      itemBuilder: (context, index) {
        final group = _groups[index];
        return GroupCard(
          group: group,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => GroupDetailScreen(
                  group: group,
                  currentUser: widget.currentUser,
                  allMovies: widget.allMovies,
                ),
              ),
            );
          },
          onMatchPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => MatcherScreen(
                  allMovies: widget.allMovies,
                  currentUser: widget.currentUser,
                  availableFriends: group.members,
                ),
              ),
            );
          },
        );
      },
    );
  }
}