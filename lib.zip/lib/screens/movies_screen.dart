import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/user_profile.dart';
import '../movie.dart';
import '../utils/tmdb_api.dart';
import '../utils/enhanced_learning_engine.dart';
import '../utils/movie_loader.dart';
import 'movie_detail_screen.dart';
import 'dart:async';
import '../services/firestore_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:math';

class MoviesScreen extends StatefulWidget {
  final UserProfile? currentUser;
  final Function(String mode, {String? sessionId, bool resume})? onNavigateToMatcher;

  const MoviesScreen({
    super.key, 
    required this.currentUser,
    this.onNavigateToMatcher,
  });

  @override
  State<MoviesScreen> createState() => _MoviesScreenState();
}

class _MoviesScreenState extends State<MoviesScreen> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late TabController _tabController;
  final FirestoreService _firestoreService = FirestoreService();
  
  // Session-based data
  List<MovieSession> _activeSessions = [];
  List<MovieSession> _readyToWatchSessions = [];
  List<MovieSession> _archivedSessions = [];
  Map<String, List<Movie>> _sessionMatches = {};
  bool _isLoadingSessions = true;
  
  // Discovery Tab Variables
  List<Movie> _movieDatabase = [];
  List<Movie> _personalizedRecommendations = [];
  List<Movie> _trendingMovies = [];
  List<Movie> _becauseYouLiked = [];
  Map<String, List<Movie>> _genreDeepDives = {};
  bool _isLoadingDiscover = true;
  bool _isRefreshingDiscover = false;
  String? _selectedGenreForDeepDive;

  List<Movie> _getRecentSoloLikes() {
    if (widget.currentUser?.likedMovies.isEmpty ?? true) return [];
    
    final recentLikes = widget.currentUser!.likedMovies
        .toList()
        .reversed
        .take(10)
        .toList();
        
    return recentLikes;
  }
  
  // Quick swipe functionality
  Set<String> _quickLikedMovieIds = {};
  Set<String> _quickPassedMovieIds = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(_handleTabChange);
    
    _loadSessionData();
    _loadDiscoverContent();
    
    WidgetsBinding.instance.addObserver(this);
  }

  Future<void> _loadSessionData() async {
    if (!mounted || widget.currentUser == null) return;
    
    setState(() => _isLoadingSessions = true);
    
    try {
      final sessionsQuery = await FirebaseFirestore.instance
          .collection('movieSessions')
          .where('participantIds', arrayContains: widget.currentUser!.uid)
          .orderBy('createdAt', descending: true)
          .limit(50)
          .get();
      
      final now = DateTime.now();
      final sessions = <MovieSession>[];
      
      for (final doc in sessionsQuery.docs) {
        final session = MovieSession.fromFirestore(doc);
        sessions.add(session);
        
        if (session.matchedMovieIds.isNotEmpty) {
          final matches = <Movie>[];
          for (final movieId in session.matchedMovieIds) {
            try {
              final movie = _movieDatabase.firstWhere((m) => m.id == movieId);
              matches.add(movie);
            } catch (e) {
              // Movie not found in local database
            }
          }
          _sessionMatches[session.id] = matches;
        }
      }
      
      _activeSessions = sessions.where((s) => 
        s.status == SessionStatus.active || 
        s.status == SessionStatus.swiping
      ).toList();
      
      _readyToWatchSessions = sessions.where((s) => 
        s.status == SessionStatus.hasMatches &&
        now.difference(s.createdAt).inHours < 24
      ).toList();
      
      _archivedSessions = sessions.where((s) => 
        (s.status == SessionStatus.hasMatches && now.difference(s.createdAt).inHours >= 24) ||
        s.status == SessionStatus.completed ||
        s.status == SessionStatus.expired
      ).where((s) => now.difference(s.createdAt).inDays <= 30).toList();
      
    } catch (e) {
      print("❌ Error loading session data: $e");
    } finally {
      if (mounted) {
        setState(() => _isLoadingSessions = false);
      }
    }
  }

  void _handleTabChange() {
    if (_tabController.index == 0) {
      _loadSessionData();
    } else if (_tabController.index == 1 && _personalizedRecommendations.isEmpty) {
      _loadDiscoverContent();
    }
  }

  

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: const Color(0xFF121212),
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: const Color(0xFF1F1F1F),
          title: const Text("Movie Nights", style: TextStyle(fontWeight: FontWeight.bold)),
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: const Color(0xFFE5A00D),
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: const [
              Tab(text: "READY TO WATCH"),
              Tab(text: "DISCOVER"),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            _buildReadyToWatchTab(),
            _buildDiscoverTab(),
          ],
        ),
      ),
    );
  }

  Widget _buildReadyToWatchTab() {
  if (_isLoadingSessions) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: Color(0xFFE5A00D)),
          SizedBox(height: 16.h),
          Text(
            "Loading your movie sessions...",
            style: TextStyle(color: Colors.white70, fontSize: 16.sp),
          ),
        ],
      ),
    );
  }

  return RefreshIndicator(
    color: Color(0xFFE5A00D),
    backgroundColor: Color(0xFF1F1F1F),
    onRefresh: _loadSessionData,
    child: SingleChildScrollView(
      physics: AlwaysScrollableScrollPhysics(),
      child: Column(
        children: [
          // Header with quick start action
          _buildSessionsHeader(),
          
          // Ready to Pick Sessions (Priority #1)
          if (_readyToWatchSessions.isNotEmpty) 
            _buildReadyToPickSection(),
          
          // Active Sessions (Priority #2)  
          if (_activeSessions.isNotEmpty)
            _buildActiveSessionsSection(),
          
          // Your Movie Collection
          _buildCollectionSection(),
          
          // Archive (Collapsed by default)
          if (_archivedSessions.isNotEmpty)
            _buildRecentActivitySection(),
          
          // Show empty state only if NO sessions exist
          if (_readyToWatchSessions.isEmpty && _activeSessions.isEmpty && _archivedSessions.isEmpty)
            _buildCompleteEmptyState(),
          
          SizedBox(height: 32.h),
        ],
      ),
    ),
  );
}

Widget _buildSessionsHeader() {
  final totalActiveSessions = _readyToWatchSessions.length + _activeSessions.length;
  
  return Container(
    margin: EdgeInsets.all(16.w),
    padding: EdgeInsets.all(20.w),
    decoration: BoxDecoration(
      color: Color(0xFF1F1F1F),
      borderRadius: BorderRadius.circular(16.r),
      border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
    ),
    child: Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Your Movie Sessions",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 22.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 4.h),
              Text(
                totalActiveSessions > 0 
                    ? "$totalActiveSessions active sessions"
                    : "No active sessions",
                style: TextStyle(
                  color: totalActiveSessions > 0 ? Color(0xFFE5A00D) : Colors.white70,
                  fontSize: 14.sp,
                ),
              ),
            ],
          ),
        ),
        
        // Quick start button
        ElevatedButton.icon(
          onPressed: _showStartSessionDialog,
          icon: Icon(Icons.add, size: 18.sp),
          label: Text("New Session"),
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFFE5A00D),
            foregroundColor: Colors.black,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.r),
            ),
          ),
        ),
      ],
    ),
  );
}

Widget _buildReadyToPickSection() {
  return Container(
    margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 24.h),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header
        Container(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 12.h),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                decoration: BoxDecoration(
                  color: Color(0xFFE5A00D),
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.stars, color: Colors.black, size: 16.sp),
                    SizedBox(width: 4.w),
                    Text(
                      "READY TO PICK",
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 12.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 12.w),
              Text(
                "${_readyToWatchSessions.length} sessions ready",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        
        // Sessions with matches
        ..._readyToWatchSessions.map((session) {
          final matches = _sessionMatches[session.id] ?? [];
          if (matches.isEmpty) return SizedBox.shrink();
          
          return Container(
            margin: EdgeInsets.only(bottom: 16.h),
            child: _buildReadySessionCard(session, matches),
          );
        }).toList(),
      ],
    ),
  );
}

Widget _buildReadySessionCard(MovieSession session, List<Movie> matches) {
  final isSolo = session.participantIds.length == 1;
  final otherNames = session.participantNames
      .where((name) => name != widget.currentUser?.name)
      .join(', ');
  final timeAgo = _formatRelativeDate(session.createdAt);
  
  return Container(
    padding: EdgeInsets.all(20.w),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        colors: [
          Color(0xFFE5A00D).withValues(alpha: 0.1),
          Color(0xFF2A2A2A),
        ],
      ),
      borderRadius: BorderRadius.circular(16.r),
      border: Border.all(
        color: Color(0xFFE5A00D).withValues(alpha: 0.3),
        width: 1.w,
      ),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Session info header
        Row(
          children: [
            Container(
              padding: EdgeInsets.all(10.w),
              decoration: BoxDecoration(
                color: Color(0xFFE5A00D).withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: Icon(
                isSolo ? Icons.person : Icons.group,
                color: Color(0xFFE5A00D),
                size: 20.sp,
              ),
            ),
            
            SizedBox(width: 12.w),
            
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isSolo ? "Solo Session" : "With $otherNames",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    "Created $timeAgo • ${matches.length} matches",
                    style: TextStyle(
                      color: Color(0xFFE5A00D),
                      fontSize: 13.sp,
                    ),
                  ),
                ],
              ),
            ),
            
            if (!isSolo)
              GestureDetector(
                onTap: () => _openChat(session),
                child: Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    color: Colors.blue.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Icon(
                    Icons.chat_bubble_outline,
                    color: Colors.blue,
                    size: 18.sp,
                  ),
                ),
              ),
          ],
        ),
        
        SizedBox(height: 16.h),
        
        // Movie matches display
        Text(
          "Choose your movie:",
          style: TextStyle(
            color: Colors.white,
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        
        SizedBox(height: 12.h),
        
        // Horizontal scrollable movie list
        SizedBox(
          height: 200.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: matches.length,
            itemBuilder: (context, index) {
              return _buildMatchMovieCard(matches[index], session);
            },
          ),
        ),
        
        SizedBox(height: 16.h),
        
        // Action buttons
        Row(
          children: [
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                onPressed: () => _startMovieNight(session, matches),
                icon: Icon(Icons.movie_creation, size: 18.sp),
                label: Text("Pick & Watch"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFE5A00D),
                  foregroundColor: Colors.black,
                  padding: EdgeInsets.symmetric(vertical: 14.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                ),
              ),
            ),
            
            SizedBox(width: 12.w),
            
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _resumeSession(session),
                icon: Icon(Icons.add, size: 16.sp),
                label: Text("Add More"),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Color(0xFFE5A00D),
                  side: BorderSide(color: Color(0xFFE5A00D)),
                  padding: EdgeInsets.symmetric(vertical: 14.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    ),
  );
}

Widget _buildMatchMovieCard(Movie movie, MovieSession session) {
  return Container(
    width: 130.w,
    margin: EdgeInsets.only(right: 12.w),
    child: GestureDetector(
      onTap: () => _completeMovieNight(session, movie),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(
            color: Color(0xFFE5A00D).withValues(alpha: 0.3),
            width: 1.w,
          ),
        ),
        child: Column(
          children: [
            // Movie poster
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.vertical(top: Radius.circular(12.r)),
                child: Stack(
                  children: [
                    Image.network(
                      movie.posterUrl,
                      fit: BoxFit.cover,
                      width: double.infinity,
                      errorBuilder: (_, __, ___) => Container(
                        color: Colors.grey[800],
                        child: Icon(Icons.movie, color: Colors.white30),
                      ),
                    ),
                    // Rating overlay
                    if (movie.rating != null)
                      Positioned(
                        top: 8.h,
                        right: 8.w,
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 3.h),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.7),
                            borderRadius: BorderRadius.circular(6.r),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.star, color: Color(0xFFE5A00D), size: 12.sp),
                              SizedBox(width: 2.w),
                              Text(
                                movie.rating!.toStringAsFixed(1),
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    // Select overlay on hover/press
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.0),
                          borderRadius: BorderRadius.vertical(top: Radius.circular(12.r)),
                        ),
                        child: Center(
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                            decoration: BoxDecoration(
                              color: Color(0xFFE5A00D),
                              borderRadius: BorderRadius.circular(20.r),
                            ),
                            child: Text(
                              "SELECT",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 10.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            // Movie info
            Container(
              padding: EdgeInsets.all(12.w),
              decoration: BoxDecoration(
                color: Color(0xFF1F1F1F),
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(12.r)),
              ),
              child: Column(
                children: [
                  Text(
                    movie.title,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13.sp,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 4.h),
                  if (movie.genres.isNotEmpty)
                    Text(
                      movie.genres.take(2).join(' • '),
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 10.sp,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

Widget _buildActiveSessionsSection() {
  return Container(
    margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 24.h),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header
        Container(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 12.h),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 8.w,
                      height: 8.h,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(width: 6.w),
                    Text(
                      "ACTIVE",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 12.w),
              Text(
                "${_activeSessions.length} sessions in progress",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        
        // Active sessions
        ..._activeSessions.map((session) {
          return Container(
            margin: EdgeInsets.only(bottom: 12.h),
            child: _buildActiveSessionCard(session),
          );
        }).toList(),
      ],
    ),
  );
}

Widget _buildActiveSessionCard(MovieSession session) {
  final isSolo = session.participantIds.length == 1;
  final matchCount = _sessionMatches[session.id]?.length ?? 0;
  final otherNames = session.participantNames
      .where((name) => name != widget.currentUser?.name)
      .join(', ');
  final timeAgo = _formatRelativeDate(session.createdAt);
  
  return Container(
    padding: EdgeInsets.all(16.w),
    decoration: BoxDecoration(
      color: Color(0xFF1F1F1F),
      borderRadius: BorderRadius.circular(16.r),
      border: Border.all(
        color: Colors.blue.withValues(alpha: 0.3),
        width: 1.w,
      ),
    ),
    child: Row(
      children: [
        // Session indicator
        Container(
          padding: EdgeInsets.all(12.w),
          decoration: BoxDecoration(
            color: Colors.blue.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(12.r),
          ),
          child: Icon(
            isSolo ? Icons.person : Icons.group,
            color: Colors.blue,
            size: 20.sp,
          ),
        ),
        
        SizedBox(width: 16.w),
        
        // Session info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                isSolo ? "Solo Session" : "With $otherNames",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                "Started $timeAgo${matchCount > 0 ? ' • $matchCount matches' : ''}",
                style: TextStyle(
                  color: matchCount > 0 ? Colors.blue : Colors.white70,
                  fontSize: 12.sp,
                ),
              ),
            ],
          ),
        ),
        
        // Action buttons
        Row(
          children: [
            if (!isSolo) ...[
              GestureDetector(
                onTap: () => _openChat(session),
                child: Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Icon(
                    Icons.chat,
                    color: Colors.white70,
                    size: 16.sp,
                  ),
                ),
              ),
              SizedBox(width: 8.w),
            ],
            
            ElevatedButton(
              onPressed: () => _resumeSession(session),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                minimumSize: Size(80.w, 36.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18.r),
                ),
              ),
              child: Text(
                "Continue",
                style: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ],
    ),
  );
}

Widget _buildCollectionSection() {
  final recentLikes = _getRecentSoloLikes();
  
  return Container(
    margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 24.h),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header
        Container(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 12.h),
          child: Row(
            children: [
              Icon(Icons.favorite, color: Colors.red, size: 20.sp),
              SizedBox(width: 8.w),
              Text(
                "Your Collection",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Spacer(),
              if (recentLikes.isNotEmpty)
                Text(
                  "${recentLikes.length} movies",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14.sp,
                  ),
                ),
            ],
          ),
        ),
        
        if (recentLikes.isEmpty)
          Container(
            padding: EdgeInsets.all(24.w),
            decoration: BoxDecoration(
              color: Color(0xFF1F1F1F),
              borderRadius: BorderRadius.circular(16.r),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.1),
                width: 1.w,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.movie_outlined,
                  size: 40.sp,
                  color: Colors.white30,
                ),
                SizedBox(width: 16.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "No liked movies yet",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "Start swiping to build your collection",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 14.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )
        else
          SizedBox(
            height: 140.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: recentLikes.length,
              itemBuilder: (context, index) {
                return _buildCollectionMovieCard(recentLikes[index]);
              },
            ),
          ),
      ],
    ),
  );
}

Widget _buildCollectionMovieCard(Movie movie) {
  return Container(
    width: 90.w,
    margin: EdgeInsets.only(right: 12.w),
    child: GestureDetector(
      onTap: () => _watchSoloMovie(movie),
      child: Column(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12.r),
              child: Stack(
                children: [
                  Image.network(
                    movie.posterUrl,
                    fit: BoxFit.cover,
                    width: double.infinity,
                    errorBuilder: (_, __, ___) => Container(
                      color: Colors.grey[800],
                      child: Icon(Icons.movie, color: Colors.white30, size: 20.sp),
                    ),
                  ),
                  Positioned(
                    top: 4.h,
                    right: 4.w,
                    child: Container(
                      padding: EdgeInsets.all(4.w),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.favorite,
                        color: Colors.white,
                        size: 12.sp,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 6.h),
          Text(
            movie.title,
            style: TextStyle(
              color: Colors.white,
              fontSize: 12.sp,
              fontWeight: FontWeight.w500,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    ),
  );
}

Widget _buildRecentActivitySection() {
  return Container(
    margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 0),
    child: ExpansionTile(
      leading: Icon(Icons.history, color: Colors.white70, size: 20.sp),
      title: Text(
        "Recent Activity",
        style: TextStyle(
          color: Colors.white,
          fontSize: 16.sp,
          fontWeight: FontWeight.bold,
        ),
      ),
      subtitle: Text(
        "${_archivedSessions.length} completed sessions",
        style: TextStyle(
          color: Colors.white70,
          fontSize: 12.sp,
        ),
      ),
      children: _archivedSessions.take(5).map((session) {
        return _buildArchiveListItem(session);
      }).toList(),
    ),
  );
}

Widget _buildArchiveListItem(MovieSession session) {
  final isCompleted = session.status == SessionStatus.completed;
  final timeAgo = _formatRelativeDate(session.createdAt);
  
  return ListTile(
    leading: Icon(
      isCompleted ? Icons.check_circle : Icons.schedule,
      color: isCompleted ? Colors.green : Colors.orange,
      size: 20.sp,
    ),
    title: Text(
      isCompleted 
          ? session.chosenMovie?.title ?? "Movie Night"
          : "Session with ${session.participantNames.where((name) => name != widget.currentUser?.name).join(', ')}",
      style: TextStyle(
        color: Colors.white,
        fontSize: 14.sp,
      ),
    ),
    subtitle: Text(
      timeAgo,
      style: TextStyle(
        color: Colors.white70,
        fontSize: 12.sp,
      ),
    ),
    dense: true,
  );
}

Widget _buildCompleteEmptyState() {
  return Container(
    margin: EdgeInsets.all(32.w),
    padding: EdgeInsets.all(32.w),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color(0xFFE5A00D).withValues(alpha: 0.1),
          Colors.purple.withValues(alpha: 0.05),
        ],
      ),
      borderRadius: BorderRadius.circular(20.r),
      border: Border.all(
        color: Color(0xFFE5A00D).withValues(alpha: 0.3),
        width: 1.w,
      ),
    ),
    child: Column(
      children: [
        Icon(
          Icons.movie_creation,
          size: 64.sp,
          color: Color(0xFFE5A00D),
        ),
        
        SizedBox(height: 20.h),
        
        Text(
          "No Movie Sessions Yet",
          style: TextStyle(
            color: Colors.white,
            fontSize: 24.sp,
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
        
        SizedBox(height: 8.h),
        
        Text(
          "Start your first session to find movies with friends or solo",
          style: TextStyle(
            color: Colors.white70,
            fontSize: 16.sp,
          ),
          textAlign: TextAlign.center,
        ),
        
        SizedBox(height: 24.h),
        
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _startMatching('solo'),
                icon: Icon(Icons.person, size: 18.sp),
                label: Text("Solo Session"),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Color(0xFFE5A00D),
                  side: BorderSide(color: Color(0xFFE5A00D)),
                  padding: EdgeInsets.symmetric(vertical: 14.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                ),
              ),
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () => _startMatching('friend'),
                icon: Icon(Icons.people, size: 18.sp),
                label: Text("With Friends"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFE5A00D),
                  foregroundColor: Colors.black,
                  padding: EdgeInsets.symmetric(vertical: 14.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    ),
  );
}


  // Add this method after the other dialog methods
  void _showStartSessionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1F1F1F),
        title: Text(
          "Start New Session",
          style: TextStyle(color: Colors.white, fontSize: 18.sp),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildStartOption(
              icon: Icons.person,
              title: "Solo Session",
              subtitle: "Find movies for yourself",
              onTap: () {
                Navigator.pop(context);
                _startMatching('solo');
              },
            ),
            SizedBox(height: 12.h),
            _buildStartOption(
              icon: Icons.people,
              title: "With Friends",
              subtitle: "Match together with friends",
              onTap: () {
                Navigator.pop(context);
                _startMatching('friend');
              },
            ),
            SizedBox(height: 12.h),
            _buildStartOption(
              icon: Icons.groups,
              title: "Group Session",
              subtitle: "Multiple friends at once",
              onTap: () {
                Navigator.pop(context);
                _startMatching('group');
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStartOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(16.w),
        decoration: BoxDecoration(
          color: Color(0xFF2A2A2A),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: Color(0xFFE5A00D).withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: Color(0xFFE5A00D), size: 24.sp),
            SizedBox(width: 16.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 14.sp,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: Color(0xFFE5A00D),
              size: 16.sp,
            ),
          ],
        ),
      ),
    );
  }

  // Action Methods
  void _resumeSession(MovieSession session) {
    String mode;
    if (session.participantIds.length == 1) {
      mode = 'solo';
    } else if (session.participantIds.length == 2) {
      mode = 'friend';
    } else {
      mode = 'group';
    }
    
    _navigateToMatcher(mode, sessionId: session.id, resume: true);
  }

  void _startMovieNight(MovieSession session, List<Movie> matches) {
    _showMoviePickerDialog(session, matches);
  }

  void _openChat(MovieSession session) {
  final otherParticipants = session.participantNames
      .where((name) => name != widget.currentUser?.name)
      .toList();
  
  if (otherParticipants.length == 1) {
    Navigator.pushNamed(
      context,
      '/chat',
      arguments: {
        'friendName': otherParticipants.first,
        'sessionId': session.id,
      },
    );
  } else {
    Navigator.pushNamed(
      context,
      '/group-chat',
      arguments: {
        'sessionId': session.id,
        'groupName': 'Movie Night Group',
      },
    );
  }
}


  void _navigateToMatcher(String mode, {String? sessionId, bool resume = false}) {
    if (widget.onNavigateToMatcher != null) {
      widget.onNavigateToMatcher!(mode, sessionId: sessionId, resume: resume);
    } else {
      print("❌ No navigation callback provided");
    }
  }

  void _startMatching(String mode) {
    print("🎯 Starting $mode matching...");
    
    if (widget.onNavigateToMatcher != null) {
      widget.onNavigateToMatcher!(mode);
    } else {
      print("❌ No navigation callback provided");
    }
  }

  void _watchSoloMovie(Movie movie) {
    showMovieDetails(
      context: context,
      movie: movie,
      currentUser: widget.currentUser!,
      isInFavorites: true,
      onRemoveFromFavorites: (Movie movie) {
        setState(() {
          widget.currentUser!.likedMovieIds.remove(movie.id);
          widget.currentUser!.likedMovies.removeWhere((m) => m.id == movie.id);
        });
        
        _firestoreService.updateUserProfile(widget.currentUser!);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${movie.title} removed from likes'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 2),
          ),
        );
      },
    );
  }

  void _showMoviePickerDialog(MovieSession session, List<Movie> matches) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1F1F1F),
        title: Text(
          "Pick Tonight's Movie",
          style: TextStyle(color: Colors.white, fontSize: 18.sp),
        ),
        content: SizedBox(
          width: double.maxFinite,
          height: 300.h,
          child: GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.7,
              crossAxisSpacing: 12.w,
              mainAxisSpacing: 12.h,
            ),
            itemCount: matches.length,
            itemBuilder: (context, index) {
              final movie = matches[index];
              return GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                  _completeMovieNight(session, movie);
                },
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8.r),
                    border: Border.all(color: Color(0xFFE5A00D).withValues(alpha: 0.3)),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8.r),
                    child: Column(
                      children: [
                        Expanded(
                          child: Image.network(
                            movie.posterUrl,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            errorBuilder: (_, __, ___) => Container(
                              color: Colors.grey[800],
                              child: Icon(Icons.movie, color: Colors.white30),
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.all(8.w),
                          color: Color(0xFF2A2A2A),
                          child: Text(
                            movie.title,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel",
              style: TextStyle(color: Colors.white70),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _completeMovieNight(MovieSession session, Movie chosenMovie) async {
    try {
      await FirebaseFirestore.instance
          .collection('movieSessions')
          .doc(session.id)
          .update({
        'status': 'completed',
        'chosenMovieId': chosenMovie.id,
        'chosenMovieTitle': chosenMovie.title,
        'completedAt': DateTime.now(),
      });

      await _loadSessionData();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Great choice! Enjoy "${chosenMovie.title}"'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      print("❌ Error completing movie night: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error completing movie night'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  String _formatRelativeDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays == 0) {
      if (difference.inHours == 0) {
        return '${difference.inMinutes}m ago';
      }
      return '${difference.inHours}h ago';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }

  // DISCOVERY TAB - Keep all your existing methods
  Widget _buildDiscoverTab() {
    if (_isLoadingDiscover) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Color(0xFFE5A00D)),
            SizedBox(height: 16.h),
            Text(
              "Discovering movies for you...",
              style: TextStyle(color: Colors.white70, fontSize: 16.sp),
            ),
          ],
        ),
      );
    }
    
    return RefreshIndicator(
      color: Color(0xFFE5A00D),
      backgroundColor: Color(0xFF1F1F1F),
      onRefresh: () async {
        setState(() => _isRefreshingDiscover = true);
        await _loadDiscoverContent();
        setState(() => _isRefreshingDiscover = false);
      },
      child: SingleChildScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_isRefreshingDiscover)
              Padding(
                padding: EdgeInsets.symmetric(vertical: 24.h),
                child: Center(
                  child: CircularProgressIndicator(color: Color(0xFFE5A00D)),
                ),
              ),
            if (_personalizedRecommendations.isNotEmpty)
              _buildSection(
                title: "Perfect For You",
                subtitle: "Based on your unique taste",
                icon: Icons.auto_awesome,
                movies: _personalizedRecommendations,
                showQuickActions: true,
              ),
            if (_becauseYouLiked.length > 1)
              _buildBecauseYouLikedSection(),
            
            if (_trendingMovies.isNotEmpty)
              _buildSection(
                title: "Trending Now",
                subtitle: "Popular movies this week",
                icon: Icons.trending_up,
                movies: _trendingMovies,
                showQuickActions: true,
              ),
            
            ..._genreDeepDives.entries.map((entry) => 
              _buildSection(
                title: "More ${entry.key} Movies",
                subtitle: "Explore your favorite genre",
                icon: Icons.category,
                movies: entry.value,
                showQuickActions: true,
              ),
            ).toList(),
            
            _buildDiscoveryModeSection(),
            
            SizedBox(height: 32.h),
          ],
        ),
      ),
    );
  }

  // [Keep all your existing discovery methods here - _loadDiscoverContent, _buildSection, etc.]
  Future<void> _loadDiscoverContent() async {
    if (!mounted) return;
    
    setState(() => _isLoadingDiscover = true);
    
    try {
      _movieDatabase = await MovieDatabaseLoader.loadMovieDatabase();
      
      await Future.wait([
        _loadPersonalizedRecommendations(),
        _loadTrendingMovies(),
        _loadBecauseYouLiked(),
        _loadGenreDeepDives(),
      ]);
    } catch (e) {
      print("❌ Error loading discover content: $e");
    } finally {
      if (mounted) {
        setState(() => _isLoadingDiscover = false);
      }
    }
  }

  Widget _buildSection({
    required String title,
    required String subtitle,
    required IconData icon,
    required List<Movie> movies,
    bool showQuickActions = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(16.w, 24.h, 16.w, 12.h),
          child: Row(
            children: [
              Icon(icon, color: Color(0xFFE5A00D), size: 24.sp),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (subtitle.isNotEmpty)
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 14.sp,
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        SizedBox(
          height: showQuickActions ? 280.h : 220.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            itemCount: movies.length,
            itemBuilder: (context, index) {
              final movie = movies[index];
              return _buildDiscoveryCard(movie, showQuickActions);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildBecauseYouLikedSection() {
    final referenceMovie = _becauseYouLiked.first;
    final similarMovies = _becauseYouLiked.skip(1).toList();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(16.w, 24.h, 16.w, 12.h),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(6.r),
                child: Image.network(
                  referenceMovie.posterUrl,
                  width: 40.w,
                  height: 60.h,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    width: 40.w,
                    height: 60.h,
                    color: Colors.grey[800],
                    child: Icon(Icons.movie, size: 20.sp, color: Colors.white30),
                  ),
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Because you liked",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14.sp,
                      ),
                    ),
                    Text(
                      referenceMovie.title,
                      style: TextStyle(
                        color: Color(0xFFE5A00D),
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        SizedBox(
          height: 280.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            itemCount: similarMovies.length,
            itemBuilder: (context, index) {
              return _buildDiscoveryCard(similarMovies[index], true);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDiscoveryModeSection() {
    return Container(
      margin: EdgeInsets.fromLTRB(16.w, 24.h, 16.w, 0),
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xFF1F1F1F),
            Color(0xFF2A2A2A),
          ],
        ),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: Color(0xFFE5A00D).withValues(alpha: 0.3),
          width: 1.w,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.explore, color: Color(0xFFE5A00D), size: 24.sp),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Discovery Mode",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "Find movies outside your comfort zone",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14.sp,
                      ),
                    ),
                  ],
                ),
              ),
              Switch(
                value: widget.currentUser?.discoveryModeEnabled ?? false,
                onChanged: (value) {
                  setState(() {
                    widget.currentUser?.discoveryModeEnabled = value;
                  });
                  _firestoreService.updateUserProfile(widget.currentUser!);
                  
                  if (value) {
                    _loadDiscoverContent();
                  }
                },
                activeColor: Color(0xFFE5A00D),
              ),
            ],
          ),
          
          if (widget.currentUser?.genresToExplore.isNotEmpty ?? false) ...[
            SizedBox(height: 16.h),
            Text(
              "Unexplored genres:",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 14.sp,
              ),
            ),
            SizedBox(height: 8.h),
            Wrap(
              spacing: 8.w,
              runSpacing: 8.h,
              children: widget.currentUser!.genresToExplore.take(5).map((genre) {
                final bool isSelected = _selectedGenreForDeepDive == genre;

                return GestureDetector(
                  onTap: () {
                    setState(() => _selectedGenreForDeepDive = genre);
                    _loadGenreDeepDive(genre);
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? Color(0xFFE5A00D)
                          : Color(0xFFE5A00D).withAlpha(40),
                      borderRadius: BorderRadius.circular(20.r),
                      border: Border.all(
                        color: isSelected
                            ? Color(0xFFE5A00D)
                            : Color(0xFFE5A00D).withAlpha(120),
                        width: 1.w,
                      ),
                    ),
                    child: Text(
                      genre,
                      style: TextStyle(
                        color: isSelected ? Colors.black : Color(0xFFE5A00D),
                        fontSize: 14.sp,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _loadGenreDeepDive(String genre) async {
    final genreMovies = MovieDatabaseLoader.getMoviesByGenres(
      _movieDatabase,
      [genre],
      limit: 20,
    );
    
    if (genreMovies.isNotEmpty) {
      setState(() {
        _genreDeepDives[genre] = genreMovies;
      });
    }
  }

  void _showMovieDetails(Movie movie) {
    final isInFavorites = widget.currentUser?.likedMovieIds.contains(movie.id) ?? false;
    
    showMovieDetails(
      context: context,
      movie: movie,
      currentUser: widget.currentUser!,
      isInFavorites: isInFavorites,
      onAddToFavorites: !isInFavorites ? (Movie movie) {
        setState(() {
          widget.currentUser!.likedMovieIds.add(movie.id);
          widget.currentUser!.likedMovies.add(movie);
        });
        
        EnhancedLearningEngine.learnFromLikedMovie(widget.currentUser!, movie);
        _firestoreService.updateUserProfile(widget.currentUser!);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${movie.title} added to likes'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
        
        _loadPersonalizedRecommendations();
      } : null,
      onRemoveFromFavorites: isInFavorites ? (Movie movie) {
        setState(() {
          widget.currentUser!.likedMovieIds.remove(movie.id);
          widget.currentUser!.likedMovies.removeWhere((m) => m.id == movie.id);
        });
        
        _firestoreService.updateUserProfile(widget.currentUser!);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${movie.title} removed from likes'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 2),
          ),
        );
      } : null,
    );
  }

  Future<void> _loadPersonalizedRecommendations() async {
    if (widget.currentUser == null || _movieDatabase.isEmpty) return;
    
    try {
      final seenMovieIds = <String>{
        ...widget.currentUser!.likedMovieIds,
        ...widget.currentUser!.passedMovieIds,
        ..._quickLikedMovieIds,
        ..._quickPassedMovieIds,
      };
      
      final recommendations = await EnhancedLearningEngine.generatePersonalizedSession(
        user: widget.currentUser!,
        movieDatabase: _movieDatabase,
        seenMovieIds: seenMovieIds,
        sessionSize: 20,
      );
      
      if (mounted) {
        setState(() {
          _personalizedRecommendations = recommendations;
        });
      }
    } catch (e) {
      print("❌ Error loading personalized recommendations: $e");
    }
  }

  Future<void> _loadTrendingMovies() async {
    try {
      final trending = await TMDBApi.getPopularMovies();
      if (mounted) {
        setState(() {
          _trendingMovies = trending.take(20).toList();
        });
      }
    } catch (e) {
      print("❌ Error loading trending movies: $e");
    }
  }

  Future<void> _loadBecauseYouLiked() async {
    if (widget.currentUser == null || widget.currentUser!.likedMovies.isEmpty) return;
    
    try {
      final recentLikes = widget.currentUser!.likedMovies.toList();
      if (recentLikes.isEmpty) return;
      
      recentLikes.shuffle();
      final referenceMovie = recentLikes.first;
      
      final similarMovies = _movieDatabase.where((movie) {
        if (movie.id == referenceMovie.id) return false;
        if (widget.currentUser!.likedMovieIds.contains(movie.id)) return false;
        
        final sharedGenres = movie.genres.toSet().intersection(referenceMovie.genres.toSet());
        final sharedVibes = movie.tags.toSet().intersection(referenceMovie.tags.toSet());
        
        return sharedGenres.isNotEmpty || sharedVibes.isNotEmpty;
      }).toList();
      
      similarMovies.sort((a, b) {
        final aScore = _calculateSimilarityScore(a, referenceMovie);
        final bScore = _calculateSimilarityScore(b, referenceMovie);
        return bScore.compareTo(aScore);
      });
      
      if (mounted) {
        setState(() {
          _becauseYouLiked = similarMovies.take(15).toList();
          if (_becauseYouLiked.isNotEmpty) {
            _becauseYouLiked.insert(0, referenceMovie);
          }
        });
      }
    } catch (e) {
      print("❌ Error loading similar movies: $e");
    }
  }

  double _calculateSimilarityScore(Movie movie1, Movie movie2) {
    double score = 0;
    
    final sharedGenres = movie1.genres.toSet().intersection(movie2.genres.toSet());
    score += sharedGenres.length * 3.0;
    
    final sharedVibes = movie1.tags.toSet().intersection(movie2.tags.toSet());
    score += sharedVibes.length * 2.0;
    
    if (movie1.runtime != null && movie2.runtime != null) {
      final runtimeDiff = (movie1.runtime! - movie2.runtime!).abs();
      if (runtimeDiff < 30) score += 1.0;
    }
    
    if (movie1.rating != null && movie2.rating != null) {
      final ratingDiff = (movie1.rating! - movie2.rating!).abs();
      if (ratingDiff < 1.0) score += 1.0;
    }
    
    return score;
  }

  Future<void> _loadGenreDeepDives() async {
    if (widget.currentUser == null) return;
    
    try {
      final topGenres = widget.currentUser!.genreScores.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));
      
      for (int i = 0; i < min(3, topGenres.length); i++) {
        final genre = topGenres[i].key;
        final genreMovies = MovieDatabaseLoader.getMoviesByGenres(
          _movieDatabase,
          [genre],
          limit: 20,
        ).where((movie) => !widget.currentUser!.likedMovieIds.contains(movie.id)).toList();
        
        if (genreMovies.isNotEmpty) {
          _genreDeepDives[genre] = genreMovies;
        }
      }
      
      if (mounted) setState(() {});
    } catch (e) {
      print("❌ Error loading genre deep dives: $e");
    }
  }

  Widget _buildDiscoveryCard(Movie movie, bool showQuickActions) {
    final isLiked = widget.currentUser?.likedMovieIds.contains(movie.id) ?? false;
    final isPassed = _quickPassedMovieIds.contains(movie.id) || 
                     (widget.currentUser?.passedMovieIds.contains(movie.id) ?? false);
    
    if (isPassed) return SizedBox.shrink();
    
    return Container(
      width: 140.w,
      margin: EdgeInsets.only(right: 12.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              GestureDetector(
                onTap: () => _showMovieDetails(movie),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12.r),
                  child: Container(
                    height: showQuickActions ? 180.h : 200.h,
                    decoration: BoxDecoration(color: Colors.grey[800]),
                    child: Image.network(
                      movie.posterUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Center(
                        child: Icon(Icons.movie, color: Colors.white30, size: 40.sp),
                      ),
                    ),
                  ),
                ),
              ),

              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  height: 40.h,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withValues(alpha: 0.6),
                      ],
                    ),
                    borderRadius: BorderRadius.vertical(bottom: Radius.circular(12.r)),
                  ),
                ),
              ),

              if (movie.rating != null)
                Positioned(
                  top: 8.h,
                  right: 8.w,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.7),
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star, color: Color(0xFFE5A00D), size: 14.sp),
                        SizedBox(width: 2.w),
                        Text(
                          movie.rating!.toStringAsFixed(1),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              if (isLiked)
                Positioned(
                  top: 8.h,
                  left: 8.w,
                  child: Container(
                    padding: EdgeInsets.all(6.w),
                    decoration: BoxDecoration(
                      color: Colors.green,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.favorite, color: Colors.white, size: 16.sp),
                  ),
                ),
            ],
          ),

          SizedBox(height: 8.h),

          Text(
            movie.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white,
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed && _tabController.index == 0) {
      _loadSessionData();
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }
}

// Session data models (keep these the same)
class MovieSession {
  final String id;
  final List<String> participantIds;
  final List<String> participantNames;
  final DateTime createdAt;
  final SessionStatus status;
  final List<String> matchedMovieIds;
  final Movie? chosenMovie;
  final DateTime? completedAt;

  MovieSession({
    required this.id,
    required this.participantIds,
    required this.participantNames,
    required this.createdAt,
    required this.status,
    required this.matchedMovieIds,
    this.chosenMovie,
    this.completedAt,
  });

  factory MovieSession.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return MovieSession(
      id: doc.id,
      participantIds: List<String>.from(data['participantIds'] ?? []),
      participantNames: List<String>.from(data['participantNames'] ?? []),
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      status: SessionStatus.values.firstWhere(
        (e) => e.toString().split('.').last == data['status'],
        orElse: () => SessionStatus.active,
      ),
      matchedMovieIds: List<String>.from(data['matchedMovieIds'] ?? []),
      chosenMovie: data['chosenMovieTitle'] != null 
          ? Movie(
              id: data['chosenMovieId'] ?? '',
              title: data['chosenMovieTitle'] ?? '',
              posterUrl: '',
              overview: '',
              cast: [],
              genres: [],
              tags: [],
            )
          : null,
      completedAt: data['completedAt'] != null 
          ? (data['completedAt'] as Timestamp).toDate()
          : null,
    );
  }
}

enum SessionStatus {
  active,
  swiping,
  hasMatches,
  completed,
  expired,
}