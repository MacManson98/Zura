import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/user_profile.dart';
import '../movie.dart';
import '../models/session_models.dart';
import '../services/session_service.dart';
import 'movie_detail_screen.dart';
import 'package:collection/collection.dart';

class NotificationsScreen extends StatefulWidget {
  final UserProfile currentUser;
  final List<Movie> allMovies;
  final Function(SwipeSession session)? onSessionJoined; // Optional callback for joining sessions

  const NotificationsScreen({
    super.key,
    required this.currentUser,
    required this.allMovies,
    this.onSessionJoined,
  });

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<Map<String, dynamic>> _notifications = [];

  @override
  void initState() {
    super.initState();
    _loadNotifications();
  }

  Future<void> _loadNotifications() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.currentUser.uid)
        .collection('notifications')
        .orderBy('timestamp', descending: true)
        .get();

    setState(() {
      _notifications = snapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'title': data['title'] ?? '',
          'message': data['message'] ?? '',
          'movieId': data['movieId'],
          'timestamp': data['timestamp'],
          'read': data['read'] ?? false,
          'type': data['type'] ?? 'general', // Add type field
        };
      }).toList();
    });

    // Mark all as read
    for (final doc in snapshot.docs) {
      if (!(doc.data()['read'] ?? false)) {
        doc.reference.update({'read': true});
      }
    }
  }

  Future<void> _openMovieDetails(String movieId) async {
    final movie = widget.allMovies.firstWhereOrNull((m) => m.id == movieId);

    if (movie == null) {
      print("⚠️ Movie not found.");
      return;
    }

    showMovieDetails(
      context: context,
      movie: movie,
      currentUser: widget.currentUser,
    );
  }

  Widget _buildSessionInvitationCard(Map<String, dynamic> invitation) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF4A90E2).withValues(alpha: 0.9),
            const Color(0xFF357ABD).withValues(alpha: 0.9),
          ],
        ),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
          width: 1.w,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with session theme
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8.r),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE5A00D).withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Icon(
                    Icons.people,
                    color: const Color(0xFFE5A00D),
                    size: 20.sp,
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "${invitation['fromUserName']} invited you",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "to swipe movies together",
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.8),
                          fontSize: 14.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            
            SizedBox(height: 16.h),
            
            // Action buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _declineInvitation(
                      invitation['id'], 
                      invitation['sessionId'],
                    ),
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: Colors.white.withValues(alpha: 0.3), width: 1.w),
                      minimumSize: Size(0, 44.h),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
                    ),
                    child: Text(
                      "Decline",
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.8),
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _acceptInvitation(invitation),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE5A00D),
                      minimumSize: Size(0, 44.h),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
                    ),
                    child: Text(
                      "Accept",
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 14.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRegularNotification(Map<String, dynamic> note) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 4.h),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
        tileColor: const Color(0xFF1F1F1F),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
        leading: Container(
          padding: EdgeInsets.all(8.r),
          decoration: BoxDecoration(
            color: const Color(0xFFE5A00D).withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8.r),
          ),
          child: Icon(
            note['read'] ? Icons.notifications : Icons.notifications_active,
            color: const Color(0xFFE5A00D),
            size: 20.sp,
          ),
        ),
        title: Text(
          note['title'],
          style: TextStyle(
            color: Colors.white,
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Text(
          note['message'],
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 14.sp,
          ),
        ),
        trailing: note['movieId'] != null
            ? Icon(
                Icons.chevron_right,
                color: const Color(0xFFE5A00D),
                size: 20.sp,
              )
            : null,
        onTap: note['movieId'] != null
            ? () => _openMovieDetails(note['movieId'])
            : null,
      ),
    );
  }

  Future<void> _acceptInvitation(Map<String, dynamic> invitation) async {
    try {
      final session = await SessionService.acceptInvitation(
        invitation['sessionId'],
        widget.currentUser.name,
      );
      
      if (!mounted) return;
      
      if (session != null) {
        // If callback provided, use it to join session
        if (widget.onSessionJoined != null) {
          widget.onSessionJoined!(session);
          
          // Navigate back or to matcher
          Navigator.of(context).pop();
        }
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Successfully joined session!'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Session no longer available'),
            backgroundColor: Colors.orange,
            duration: Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      print("❌ Error accepting invitation: $e");
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to join session: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  Future<void> _declineInvitation(String invitationId, String? sessionId) async {
    try {
      await SessionService.declineInvitation(invitationId, sessionId);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Invitation declined'),
            backgroundColor: Colors.grey,
            duration: Duration(seconds: 2),
          ),
        );
      }
      
      print("✅ Invitation declined successfully");
    } catch (e) {
      print("❌ Error declining invitation: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Notifications',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20.sp,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: SessionService.watchPendingInvitations(),
        builder: (context, invitationSnapshot) {
          final hasInvitations = invitationSnapshot.hasData && invitationSnapshot.data!.isNotEmpty;
          final invitations = invitationSnapshot.data ?? [];
          
          // Combine invitations and regular notifications
          final hasAnyNotifications = hasInvitations || _notifications.isNotEmpty;
          
          if (!hasAnyNotifications) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.notifications_off_outlined,
                    size: 80.sp,
                    color: Colors.grey[600],
                  ),
                  SizedBox(height: 16.h),
                  Text(
                    "You're all caught up!",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    "No new notifications",
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 16.sp,
                    ),
                  ),
                ],
              ),
            );
          }
          
          return SingleChildScrollView(
            padding: EdgeInsets.symmetric(vertical: 16.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Session invitations section
                if (hasInvitations) ...[
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                    child: Text(
                      "Session Invitations",
                      style: TextStyle(
                        color: const Color(0xFFE5A00D),
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  ...invitations.map((invitation) => _buildSessionInvitationCard(invitation)),
                  SizedBox(height: 16.h),
                ],
                
                // Regular notifications section
                if (_notifications.isNotEmpty) ...[
                  if (hasInvitations)
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                      child: Text(
                        "Other Notifications",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ..._notifications.map((note) => _buildRegularNotification(note)),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}