import 'package:flutter/material.dart';
import 'onboarding_swipe_screen.dart';
import '../models/user_profile.dart';
import '../utils/user_profile_storage.dart';
import '../main_navigation.dart';
import '../movie.dart';

class WelcomeScreen extends StatefulWidget {
  final UserProfile profile;
  final List<Movie> movies;

  const WelcomeScreen({
    super.key,
    required this.profile,
    required this.movies,
  });

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  void initState() {
    super.initState();

    if (widget.profile.hasCompletedOnboarding) {
      Future.microtask(() {
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => MainNavigation(
                profile: widget.profile,
                movies: widget.movies,
              ),
            ),
          );
        }
      });
    }
  }
  

  void _skipAndContinue(BuildContext context) {
    // Use existing profile but mark onboarding as complete
    final profile = widget.profile.copyWith(hasCompletedOnboarding: true);
    UserProfileStorage.saveProfile(profile);

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => MainNavigation(profile: profile, movies: widget.movies),
      ),
    );
  }

  void _startOnboarding(BuildContext context) {
    // ✅ FIX: Use existing profile instead of creating empty one
    print('🔍 Starting onboarding with profile name: "${widget.profile.name}"');
    
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => OnboardingSwipeScreen(
          profile: widget.profile, // ✅ Use existing profile with correct name
          movies: widget.movies,   // ✅ Use existing movies
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              const Text(
                "Welcome to QueueTogether 🍿",
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              const SizedBox(height: 16),
              const Text(
                "We'll help you and your friends decide what to watch – faster, smarter, and together.",
                style: TextStyle(fontSize: 16, color: Colors.white70),
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: () => _startOnboarding(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                ),
                child: const Text("Get Started"),
              ),
              TextButton(
                onPressed: () => _skipAndContinue(context),
                child: const Text("Skip for now", style: TextStyle(color: Colors.white54)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}