import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'auth_gate.dart';
import 'services/session_service.dart'; // Add this import

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await FirebaseAuth.instance.signOut();
  // await FirebaseAuth.instance.signOut();

  runApp(ScreenUtilInit(
    designSize: const Size(360, 690),
    minTextAdapt: true,
    splitScreenMode: true,
    builder: (context, child) => const MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    
    // Perform cleanup when app starts
    _performStartupCleanup();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    
    // Perform cleanup when app comes to foreground
    if (state == AppLifecycleState.resumed) {
      _performStartupCleanup();
    }
  }

  Future<void> _performStartupCleanup() async {
    try {
      // Only run cleanup occasionally (not every app start)
      final prefs = await SharedPreferences.getInstance();
      final lastCleanup = prefs.getInt('last_cleanup') ?? 0;
      final now = DateTime.now().millisecondsSinceEpoch;
      
      // Run cleanup every 6 hours (6 * 60 * 60 * 1000 milliseconds)
      if (now - lastCleanup > 6 * 60 * 60 * 1000) {
        print("🧹 Starting database cleanup...");
        await SessionService.performMaintenanceCleanup();
        await prefs.setInt('last_cleanup', now);
        print("✅ Database cleanup completed");
      }
    } catch (e) {
      print("Note: Cleanup failed, but app continues normally: $e");
      // Don't show error to user - cleanup failing shouldn't affect app functionality
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QueueTogether',
      theme: ThemeData.dark(),
      home: const AuthGate(),
    );
  }
}