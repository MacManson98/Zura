import '/movie.dart';
import '../utils/completed_session.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/user_service.dart';
import '../utils/user_profile_storage.dart';

class MovieLike {
  final String movieId;
  final DateTime likedAt;
  final String sessionType; // "solo", "friend", "group"
  
  MovieLike({
    required this.movieId, 
    required this.likedAt, 
    required this.sessionType
  });
  
  factory MovieLike.fromJson(Map<String, dynamic> json) {
    return MovieLike(
      movieId: json['movieId'],
      likedAt: DateTime.parse(json['likedAt']),
      sessionType: json['sessionType'] ?? 'solo',
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'movieId': movieId,
      'likedAt': likedAt.toIso8601String(),
      'sessionType': sessionType,
    };
  }
}

class UserProfile {
  String uid;
  String name;
  Set<String> preferredGenres;
  Set<String> preferredVibes;
  Set<String> blockedGenres;
  Set<String> blockedAttributes;
  Set<Movie> likedMovies;
  Set<Movie> matchedMovies;
  Set<String> matchedMovieIds;
  Set<String> likedMovieIds;
  Set<String> favouriteMovieIds;
  List<CompletedSession> sessionHistory;
  
  // ✅ SIMPLIFIED: Only essential learning data
  Map<String, double> genreScores;        // Max 15 core genres
  Map<String, double> vibeScores;         // Max 12 core vibes
  List<String> recentLikedMovieIds;       // Last 30 movies
  
  List<Map<String, dynamic>> matchHistory;
  final List<String> friendIds;
  List<MovieLike> recentLikes;
  DateTime lastActivityDate;
  Set<String> passedMovieIds;
  bool hasSeenMatcher = false;
  final List<String> groupIds;

  UserProfile({
    required this.uid,
    this.name = '',
    this.friendIds = const [],
    this.groupIds = const [],
    required this.preferredGenres,
    required this.preferredVibes,
    required this.blockedGenres,
    required this.blockedAttributes,
    required this.likedMovies,
    required this.matchedMovies,
    required this.matchedMovieIds,
    required this.likedMovieIds,
    required this.favouriteMovieIds,
    required this.matchHistory,
    this.hasSeenMatcher = false,
    Map<String, double>? genreScores,
    Map<String, double>? vibeScores,
    List<String>? recentLikedMovieIds,
    DateTime? lastActivityDate,
    Set<String>? passedMovieIds,
    List<MovieLike>? recentLikes,
    this.sessionHistory = const [],
    })  : genreScores = genreScores ?? {},
        vibeScores = vibeScores ?? {},
        recentLikedMovieIds = recentLikedMovieIds ?? [],
        lastActivityDate = lastActivityDate ?? DateTime.now(),
        passedMovieIds = passedMovieIds ?? {},
        recentLikes = recentLikes ?? [];

      void addCompletedSession(CompletedSession session) {
          sessionHistory.insert(0, session); // Add to beginning for reverse chronological order
          
          // Keep only last 50 sessions to prevent unlimited growth
          if (sessionHistory.length > 50) {
            sessionHistory = sessionHistory.take(50).toList();
          }
        }

        // Get recent solo sessions
        List<CompletedSession> get recentSoloSessions {
          return sessionHistory
              .where((session) => session.type == SessionType.solo)
              .take(10)
              .toList();
        }

        // Get recent collaborative sessions
        List<CompletedSession> get recentCollaborativeSessions {
          return sessionHistory
              .where((session) => session.type != SessionType.solo)
              .take(10)
              .toList();
        }

        // Get sessions from last 7 days
        List<CompletedSession> get recentSessions {
          final weekAgo = DateTime.now().subtract(const Duration(days: 7));
          return sessionHistory
              .where((session) => session.startTime.isAfter(weekAgo))
              .toList();
        }

        // Session statistics
        int get totalSessions => sessionHistory.length;
        
        int get totalMatches => sessionHistory
            .map((session) => session.matchedMovieIds.length)
            .fold(0, (sum, matches) => sum + matches);
        
        int get totalLikedFromSessions => sessionHistory
            .map((session) => session.likedMovieIds.length)
            .fold(0, (sum, likes) => sum + likes);

  Future<List<CompletedSession>> loadCollaborativeSessions(String userId) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('swipeSessions')
        .where('hostId', isEqualTo: userId)
        .where('status', isEqualTo: 'completed')
        .get();

    return snapshot.docs.map((doc) {
      return CompletedSession.fromFirestore(doc.id, doc.data());
    }).toList();
  }

  factory UserProfile.empty() {
    return UserProfile(
      uid: '',
      name: '',
      friendIds: const [],
      groupIds: const [],
      preferredGenres: {},
      preferredVibes: {},
      blockedGenres: {},
      blockedAttributes: {},
      likedMovies: {},
      matchedMovies: {},
      matchedMovieIds: {},
      likedMovieIds: {},
      favouriteMovieIds: {},
      genreScores: {},
      vibeScores: {},
      matchHistory: [],
      recentLikedMovieIds: [],
      passedMovieIds: {},
      recentLikes: [],
    );
  }

  UserProfile copyWith({
    String? uid,
    String? name,
    List<String>? friendIds,
    List<String>? groupIds,
    Set<String>? preferredGenres,
    Set<String>? preferredVibes,
    Set<String>? blockedGenres,
    Set<String>? blockedAttributes,
    Set<Movie>? likedMovies,
    Set<Movie>? matchedMovies,
    Set<String>? matchedMovieIds,
    Set<String>? likedMovieIds,
    Set<String>? favouriteMovieIds,
    Map<String, double>? genreScores,
    Map<String, double>? vibeScores,
    List<Map<String, dynamic>>? matchHistory,
    bool? hasSeenMatcher,
    List<String>? recentLikedMovieIds,
    DateTime? lastActivityDate,
    Set<String>? passedMovieIds,
    List<MovieLike>? recentLikes,
    List<CompletedSession>? sessionHistory,
  }) {
    return UserProfile(
      uid: uid ?? this.uid,
      name: name ?? this.name,
      friendIds: friendIds ?? this.friendIds,
      groupIds: groupIds ?? this.groupIds,
      preferredGenres: preferredGenres ?? this.preferredGenres,
      preferredVibes: preferredVibes ?? this.preferredVibes,
      blockedGenres: blockedGenres ?? this.blockedGenres,
      blockedAttributes: blockedAttributes ?? this.blockedAttributes,
      likedMovies: likedMovies ?? this.likedMovies,
      matchedMovies: matchedMovies ?? this.matchedMovies,
      matchedMovieIds: matchedMovieIds ?? this.matchedMovieIds,
      likedMovieIds: likedMovieIds ?? this.likedMovieIds,
      favouriteMovieIds: favouriteMovieIds ?? this.favouriteMovieIds,
      genreScores: genreScores ?? this.genreScores,
      vibeScores: vibeScores ?? this.vibeScores,
      matchHistory: matchHistory ?? this.matchHistory,
      hasSeenMatcher: hasSeenMatcher ?? this.hasSeenMatcher,
      recentLikedMovieIds: recentLikedMovieIds ?? this.recentLikedMovieIds,
      lastActivityDate: lastActivityDate ?? this.lastActivityDate,
      passedMovieIds: passedMovieIds ?? this.passedMovieIds,
      recentLikes: recentLikes ?? this.recentLikes,
      sessionHistory: sessionHistory ?? this.sessionHistory,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'uid': uid,
      'name': name,
      'friendIds': friendIds,
      'groupIds': groupIds,
      'preferredGenres': preferredGenres.toList(),
      'preferredVibes': preferredVibes.toList(),
      'blockedGenres': blockedGenres.toList(),
      'blockedAttributes': blockedAttributes.toList(),
      'likedMovieIds': likedMovieIds.toList(),
      'favouriteMovieIds': favouriteMovieIds.toList(),
      'matchedMovieIds': matchedMovieIds.toList(),
      'genreScores': genreScores,
      'vibeScores': vibeScores,
      'matchHistory': matchHistory,
      'hasSeenMatcher': hasSeenMatcher,
      'recentLikedMovieIds': recentLikedMovieIds,
      'lastActivityDate': lastActivityDate.toIso8601String(),
      'passedMovieIds': passedMovieIds.toList(),
      'recentLikes': recentLikes.map((like) => like.toJson()).toList(),
      'sessionHistory': sessionHistory.map((session) => session.toJson()).toList(),
    };
  }

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      uid: json['uid'] ?? '',
      name: json['name'] ?? '',
      friendIds: List<String>.from(json['friendIds'] ?? []),
      groupIds: List<String>.from(json['groupIds'] ??[]),
      preferredGenres: Set<String>.from(json['preferredGenres'] ?? []),
      preferredVibes: Set<String>.from(json['preferredVibes'] ?? []),
      blockedGenres: Set<String>.from(json['blockedGenres'] ?? []),
      blockedAttributes: Set<String>.from(json['blockedAttributes'] ?? []),
      likedMovieIds: Set<String>.from(json['likedMovieIds'] ?? []),
      favouriteMovieIds: Set<String>.from(json['favouriteMovieIds'] ?? []),
      matchedMovieIds: Set<String>.from(json['matchedMovieIds'] ?? []),
      matchedMovies: {},
      likedMovies: {},
      genreScores: Map<String, double>.from(json['genreScores'] ?? {}),
      vibeScores: Map<String, double>.from(json['vibeScores'] ?? {}),
      matchHistory: (json['matchHistory'] as List<dynamic>? ?? [])
          .map((entry) => Map<String, dynamic>.from(entry))
          .toList(),
      hasSeenMatcher: json['hasSeenMatcher'] ?? false,
      recentLikedMovieIds: List<String>.from(json['recentLikedMovieIds'] ?? []),
      lastActivityDate: json['lastActivityDate'] != null 
          ? DateTime.parse(json['lastActivityDate'])
          : DateTime.now(),
      passedMovieIds: Set<String>.from(json['passedMovieIds'] ?? []),
      recentLikes: (json['recentLikes'] as List<dynamic>?)
        ?.map((item) => MovieLike.fromJson(item as Map<String, dynamic>))
        .toList() ?? [],
            sessionHistory: (json['sessionHistory'] as List<dynamic>?)
          ?.map((sessionJson) => CompletedSession.fromJson(sessionJson))
          .toList() ?? [],
    );
  }

  // Helper methods

  bool isMemberOfGroup(String groupId) => groupIds.contains(groupId);
  int get groupCount => groupIds.length;
  bool get hasGroups => groupIds.isNotEmpty;

  // Add/remove group methods
  UserProfile addToGroup(String groupId) {
    if (groupIds.contains(groupId)) return this;
    return copyWith(groupIds: [...groupIds, groupId]);
  }

  UserProfile removeFromGroup(String groupId) {
    final newGroupIds = groupIds.where((id) => id != groupId).toList();
    return copyWith(groupIds: newGroupIds);
  }
  
  bool isFriendsWith(String userId) => friendIds.contains(userId);
  int get friendCount => friendIds.length;
  bool get hasFriends => friendIds.isNotEmpty;

  void removeDuplicateSessions() {
    final seen = <String>{};
    final uniqueSessions = <CompletedSession>[];
    
    for (final session in sessionHistory) {
      if (!seen.contains(session.id)) {
        seen.add(session.id);
        uniqueSessions.add(session);
      }
    }
    
    if (uniqueSessions.length != sessionHistory.length) {
      print("🧹 Cleaned up ${sessionHistory.length - uniqueSessions.length} duplicate sessions");
      sessionHistory = uniqueSessions;
    }
  }

  // 🆕 Method 2: Get all sessions for display (combines local solo + firestore collaborative)
  Future<List<CompletedSession>> getAllSessionsForDisplay() async {
    final soloSessions = sessionHistory
        .where((session) => session.type == SessionType.solo)
        .toList();
    
    try {
      final uid = this.uid;
      final userService = UserService(); // You'll need to import this
      final collaborativeSessions = await userService.loadCollaborativeSessionsForDisplay(uid);
      
      // Combine and sort by date
      final allSessions = [...soloSessions, ...collaborativeSessions];
      allSessions.sort((a, b) => b.startTime.compareTo(a.startTime));
      
      return allSessions;
    } catch (e) {
      print("Error loading collaborative sessions: $e");
      return soloSessions; // Fallback to solo sessions only
    }
  }

  // 🆕 Method 3: Delete session from appropriate storage
  Future<void> deleteSession(CompletedSession session) async {
    if (session.type == SessionType.solo) {
      // Remove from local storage
      sessionHistory.removeWhere((s) => s.id == session.id);
      await UserProfileStorage.saveProfile(this);
    } else {
      // Remove from Firestore
      try {
        await FirebaseFirestore.instance
            .collection('swipeSessions')
            .doc(session.id)
            .delete();
      } catch (e) {
        print("Error deleting collaborative session: $e");
      }
    }
  }
}
