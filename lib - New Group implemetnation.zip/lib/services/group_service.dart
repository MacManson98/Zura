// File: lib/services/group_service.dart
// Service for the enhanced FriendGroup (single class approach)

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/friend_group.dart';
import '../models/user_profile.dart';
import '../utils/user_profile_storage.dart';

class GroupService {
  static final GroupService _instance = GroupService._internal();
  factory GroupService() => _instance;
  GroupService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  CollectionReference get _groupsCollection => _firestore.collection('groups');

  // ============================================================================
  // CREATE
  // ============================================================================

  Future<FriendGroup> createGroup({
    required String name,
    required String description,
    required List<UserProfile> members,
    String imageUrl = '',
    bool isPrivate = false,
    bool notificationsEnabled = true,
  }) async {
    final currentUser = _auth.currentUser;
    if (currentUser == null) {
      throw Exception('User must be logged in to create a group');
    }

    // Create the group
    final group = FriendGroup.create(
      name: name,
      createdBy: currentUser.displayName ?? 'Unknown',
      creatorId: currentUser.uid,
      members: members,
      description: description,
      imageUrl: imageUrl,
      isPrivate: isPrivate,
      notificationsEnabled: notificationsEnabled,
    );

    try {
      // Save to Firestore
      final docRef = await _groupsCollection.add(group.toFirestore());
      
      // Return group with Firestore ID
      final savedGroup = group.copyWith(id: docRef.id);

      // Update members' profiles
      await _addGroupToMembers(savedGroup.id, savedGroup.memberIds);

      return savedGroup;
    } catch (e) {
      throw Exception('Failed to create group: $e');
    }
  }

  // ============================================================================
  // READ
  // ============================================================================

  Future<FriendGroup?> getGroupById(String groupId) async {
    try {
      final doc = await _groupsCollection.doc(groupId).get();
      if (!doc.exists || doc.data() == null) return null;

      final data = doc.data() as Map<String, dynamic>;
      final memberIds = List<String>.from(data['memberIds'] ?? []);
      
      // Load member profiles (you'll need to implement this based on your user system)
      final memberProfiles = await _loadMemberProfiles(memberIds);
      
      return FriendGroup.fromFirestore(doc.id, data, memberProfiles);
    } catch (e) {
      print('Error getting group: $e');
      return null;
    }
  }

  Future<List<FriendGroup>> getUserGroups(String userId) async {
    try {
      final querySnapshot = await _groupsCollection
          .where('memberIds', arrayContains: userId)
          .orderBy('lastActivityDate', descending: true)
          .get();

      final groups = <FriendGroup>[];
      
      for (final doc in querySnapshot.docs) {
        final data = doc.data() as Map<String, dynamic>;
        final memberIds = List<String>.from(data['memberIds'] ?? []);
        final memberProfiles = await _loadMemberProfiles(memberIds);
        
        groups.add(FriendGroup.fromFirestore(doc.id, data, memberProfiles));
      }

      return groups;
    } catch (e) {
      print('Error getting user groups: $e');
      return [];
    }
  }

  // ============================================================================
  // UPDATE
  // ============================================================================

  Future<FriendGroup?> updateGroup(FriendGroup group) async {
    try {
      await _groupsCollection.doc(group.id).update(group.toFirestore());
      return group;
    } catch (e) {
      print('Error updating group: $e');
      return null;
    }
  }

  Future<FriendGroup?> updateGroupActivity({
    required String groupId,
    int addSessions = 0,
    int addMatches = 0,
    DateTime? sessionDate,
  }) async {
    try {
      final group = await getGroupById(groupId);
      if (group == null) return null;

      final updatedGroup = group.updateActivity(
        addSessions: addSessions,
        addMatches: addMatches,
        sessionDate: sessionDate,
      );

      await updateGroup(updatedGroup);
      return updatedGroup;
    } catch (e) {
      print('Error updating group activity: $e');
      return null;
    }
  }

  // ============================================================================
  // DELETE
  // ============================================================================

  Future<bool> deleteGroup(String groupId, String userId) async {
    try {
      final group = await getGroupById(groupId);
      if (group == null) return false;

      if (group.creatorId != userId) {
        throw Exception('Only the group creator can delete the group');
      }

      await _removeGroupFromMembers(groupId, group.memberIds);
      await _groupsCollection.doc(groupId).delete();

      return true;
    } catch (e) {
      print('Error deleting group: $e');
      return false;
    }
  }

  Future<bool> leaveGroup(String groupId, String userId) async {
    try {
      final group = await getGroupById(groupId);
      if (group == null) return false;

      if (group.creatorId == userId) {
        throw Exception('Group creator cannot leave the group. Delete the group instead.');
      }

      final updatedGroup = group.removeMember(userId);
      await updateGroup(updatedGroup);
      await _removeGroupFromMembers(groupId, [userId]);

      return true;
    } catch (e) {
      print('Error leaving group: $e');
      return false;
    }
  }

  // ============================================================================
  // HELPER METHODS
  // ============================================================================

  Future<List<UserProfile>> _loadMemberProfiles(List<String> memberIds) async {
    final profiles = <UserProfile>[];
    
    // TODO: Implement based on your user system
    // For now, return empty profiles with just UIDs
    for (final memberId in memberIds) {
      profiles.add(UserProfile(
        uid: memberId,
        name: 'User $memberId', // You'd load real names
        preferredGenres: {},
        preferredVibes: {},
        blockedGenres: {},
        blockedAttributes: {},
        likedMovies: {},
        matchedMovies: {},
        matchedMovieIds: {},
        likedMovieIds: {},
        favouriteMovieIds: {},
        matchHistory: [],
      ));
    }
    
    return profiles;
  }

  Future<void> _addGroupToMembers(String groupId, List<String> memberIds) async {
    for (final memberId in memberIds) {
      try {
        final userProfile = await UserProfileStorage.loadProfile();
        if (userProfile.uid == memberId) {
          final updatedProfile = userProfile.addToGroup(groupId);
          await UserProfileStorage.saveProfile(updatedProfile);
        }
      } catch (e) {
        print('Error adding group to member $memberId: $e');
      }
    }
  }

  Future<void> _removeGroupFromMembers(String groupId, List<String> memberIds) async {
    for (final memberId in memberIds) {
      try {
        final userProfile = await UserProfileStorage.loadProfile();
        if (userProfile.uid == memberId) {
          final updatedProfile = userProfile.removeFromGroup(groupId);
          await UserProfileStorage.saveProfile(updatedProfile);
        }
      } catch (e) {
        print('Error removing group from member $memberId: $e');
      }
    }
  }

    /// Sync user's groups from Firebase (call on login/app start)
  Future<void> syncUserGroupsFromFirebase(String userId) async {
    try {
      // Query Firebase for groups where user is a member
      final querySnapshot = await _groupsCollection
          .where('memberIds', arrayContains: userId)
          .get();

      // Extract group IDs
      final groupIds = querySnapshot.docs.map((doc) => doc.id).toList();
      
      // Update local user profile with synced group IDs
      final userProfile = await UserProfileStorage.loadProfile();
      final updatedProfile = userProfile.copyWith(groupIds: groupIds);
      await UserProfileStorage.saveProfile(updatedProfile);
      print('✅ Synced ${groupIds.length} groups from Firebase');
        } catch (e) {
      print('Error syncing groups: $e');
    }
  }
}

// Usage: Call this once when user logs in or app starts
void initializeApp() async {
  final groupService = GroupService();
  final currentUser = FirebaseAuth.instance.currentUser;
  
  if (currentUser != null) {
    // This one call rebuilds the user's group list from Firebase
    await groupService.syncUserGroupsFromFirebase(currentUser.uid);
  }
}