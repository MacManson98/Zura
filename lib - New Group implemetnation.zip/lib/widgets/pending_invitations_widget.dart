// File: lib/widgets/pending_invitations_widget.dart

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/session_models.dart';
import '../services/session_service.dart';
import '../models/user_profile.dart';
import '../utils/debug_loader.dart';

class PendingInvitationsWidget extends StatelessWidget {
  final Function(SwipeSession session) onSessionJoined;
  final UserProfile currentUser; // ✅ Add currentUser parameter

  const PendingInvitationsWidget({
    super.key,
    required this.onSessionJoined,
    required this.currentUser, // ✅ Required parameter
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: SessionService.watchPendingInvitations(),
      builder: (context, snapshot) {
        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const SizedBox.shrink();
        }

        return Container(
          margin: EdgeInsets.all(16.r),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Pending Invitations",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 12.h),
              
              ...snapshot.data!.map((invitation) => 
                _buildInvitationCard(context, invitation)
              ).toList(),
            ],
          ),
        );
      },
    );
  }

  Widget _buildInvitationCard(BuildContext context, Map<String, dynamic> invitation) {
    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        color: const Color(0xFF1F1F1F),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: const Color(0xFFE5A00D)),
      ),
      child: Row(
        children: [
          Icon(
            Icons.people,
            color: const Color(0xFFE5A00D),
            size: 24.sp,
          ),
          SizedBox(width: 12.w),
          
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "${invitation['fromUserName']} invited you to swipe together!",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  "Swipe session invitation",
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 12.sp,
                  ),
                ),
              ],
            ),
          ),
          
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextButton(
                onPressed: () => _declineInvitation(invitation['id']),
                child: Text(
                  "Decline",
                  style: TextStyle(color: Colors.grey[400], fontSize: 12.sp),
                ),
              ),
              SizedBox(width: 8.w),
              ElevatedButton(
                onPressed: () => _acceptInvitation(context, invitation),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE5A00D),
                  minimumSize: Size(60.w, 32.h),
                ),
                child: Text(
                  "Accept",
                  style: TextStyle(color: Colors.black, fontSize: 12.sp),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _acceptInvitation(BuildContext context, Map<String, dynamic> invitation) async {
    try {
      final session = await SessionService.acceptInvitation(
        invitation['sessionId'],
        currentUser.name, // ✅ Use currentUser parameter
      );
      
      if (session != null) {
        onSessionJoined(session);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Session no longer available')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to join session: $e')),
      );
    }
  }

  Future<void> _declineInvitation(String invitationId) async {
    try {
      // Implement decline invitation logic
      DebugLogger.log("Declining invitation: $invitationId");
      // You can add actual decline logic here if needed
    } catch (e) {
      DebugLogger.log("Error declining invitation: $e");
    }
  }
}