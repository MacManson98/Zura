// File: lib/screens/groups_screen.dart
// Clean version using only FriendGroup

import 'package:flutter/material.dart';
import '../models/friend_group.dart';
import '../models/user_profile.dart';
import '../services/group_service.dart';
import 'create_group_screen.dart';
import 'group_detail_screen.dart';
import '../movie.dart';

class GroupsScreen extends StatefulWidget {
  final UserProfile currentUser;
  final List<UserProfile> friends;
  final List<Movie> allMovies;

  const GroupsScreen({
    super.key,
    required this.currentUser,
    required this.friends,
    required this.allMovies,
  });

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> with TickerProviderStateMixin {
  late TabController _tabController;
  final GroupService _groupService = GroupService();
  
  List<FriendGroup> _myGroups = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadMyGroups();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadMyGroups() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final groups = await _groupService.getUserGroups(widget.currentUser.uid);
      setState(() {
        _myGroups = groups;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error loading groups: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _leaveGroup(FriendGroup group) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text('Leave Group', style: TextStyle(color: Colors.white)),
        content: Text(
          'Are you sure you want to leave "${group.name}"?',
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Leave', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await _groupService.leaveGroup(group.id, widget.currentUser.uid);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Left ${group.name}'),
            backgroundColor: Colors.orange,
          ),
        );
        _loadMyGroups();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to leave group: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _deleteGroup(FriendGroup group) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text('Delete Group', style: TextStyle(color: Colors.white)),
        content: Text(
          'Are you sure you want to delete "${group.name}"? This action cannot be undone.',
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await _groupService.deleteGroup(group.id, widget.currentUser.uid);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Deleted ${group.name}'),
            backgroundColor: Colors.red,
          ),
        );
        _loadMyGroups();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to delete group: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _navigateToCreateGroup() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CreateGroupScreen(
          currentUser: widget.currentUser,
          friends: widget.friends,
        ),
      ),
    );

    if (result == true) {
      _loadMyGroups();
    }
  }

  void _navigateToGroupDetail(FriendGroup group) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => GroupDetailScreen(
          group: group, // Now we can pass FriendGroup directly!
          currentUser: widget.currentUser,
          allMovies: widget.allMovies,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text('Groups'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFFE5A00D),
          labelColor: const Color(0xFFE5A00D),
          unselectedLabelColor: Colors.white60,
          tabs: const [
            Tab(text: 'My Groups'),
            Tab(text: 'Discover'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildMyGroupsTab(),
          _buildDiscoverTab(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToCreateGroup,
        backgroundColor: const Color(0xFFE5A00D),
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _buildMyGroupsTab() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFFE5A00D)),
      );
    }

    if (_myGroups.isEmpty) {
      return _buildEmptyMyGroups();
    }

    return RefreshIndicator(
      onRefresh: _loadMyGroups,
      color: const Color(0xFFE5A00D),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _myGroups.length,
        itemBuilder: (context, index) {
          final group = _myGroups[index];
          return _buildGroupCard(group);
        },
      ),
    );
  }

  Widget _buildDiscoverTab() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.search, size: 64, color: Colors.white24),
          SizedBox(height: 16),
          Text(
            'Discover Groups',
            style: TextStyle(
              color: Colors.white54,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Coming soon: Find public groups to join',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white38),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyMyGroups() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: const Color(0xFF1F1F1F),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.group_add,
                size: 64,
                color: Color(0xFFE5A00D),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'No Groups Yet',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Create your first group to start matching movies with friends!',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white60,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: _navigateToCreateGroup,
              icon: const Icon(Icons.add, color: Colors.white),
              label: const Text(
                'Create Group',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGroupCard(FriendGroup group) {
    final isCreator = group.isCreatedBy(widget.currentUser.uid);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: const Color(0xFF1F1F1F),
      child: InkWell(
        onTap: () => _navigateToGroupDetail(group),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  // Group avatar
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.grey[800],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: group.imageUrl.isNotEmpty
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.network(
                              group.imageUrl,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return const Icon(Icons.group, color: Colors.white54);
                              },
                            ),
                          )
                        : const Icon(Icons.group, color: Colors.white54),
                  ),
                  const SizedBox(width: 16),
                  
                  // Group info
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                group.name,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (group.isPrivate)
                              const Icon(Icons.lock, color: Colors.white54, size: 16),
                          ],
                        ),
                        const SizedBox(height: 4),
                        if (group.description.isNotEmpty)
                          Text(
                            group.description,
                            style: const TextStyle(color: Colors.white70, fontSize: 14),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const Icon(Icons.people, size: 16, color: Colors.white54),
                            const SizedBox(width: 4),
                            Text(
                              '${group.memberCount} member${group.memberCount != 1 ? 's' : ''}',
                              style: const TextStyle(color: Colors.white54, fontSize: 12),
                            ),
                            const SizedBox(width: 16),
                            const Icon(Icons.movie, size: 16, color: Colors.white54),
                            const SizedBox(width: 4),
                            Text(
                              '${group.totalSessions} session${group.totalSessions != 1 ? 's' : ''}',
                              style: const TextStyle(color: Colors.white54, fontSize: 12),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  
                  // Action menu
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.more_vert, color: Colors.white54),
                    itemBuilder: (context) => [
                      if (isCreator)
                        const PopupMenuItem(
                          value: 'edit',
                          child: Row(
                            children: [
                              Icon(Icons.edit, size: 18),
                              SizedBox(width: 8),
                              Text('Edit Group'),
                            ],
                          ),
                        ),
                      PopupMenuItem(
                        value: isCreator ? 'delete' : 'leave',
                        child: Row(
                          children: [
                            Icon(
                              isCreator ? Icons.delete : Icons.exit_to_app,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Text(isCreator ? 'Delete Group' : 'Leave Group'),
                          ],
                        ),
                      ),
                    ],
                    onSelected: (value) {
                      if (value == 'edit') {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Edit functionality coming soon')),
                        );
                      } else if (value == 'delete') {
                        _deleteGroup(group);
                      } else if (value == 'leave') {
                        _leaveGroup(group);
                      }
                    },
                  ),
                ],
              ),
              
              // Creator badge
              if (isCreator)
                Container(
                  margin: const EdgeInsets.only(top: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE5A00D).withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.star, size: 14, color: Color(0xFFE5A00D)),
                      SizedBox(width: 4),
                      Text(
                        'Created by you',
                        style: TextStyle(color: Color(0xFFE5A00D), fontSize: 12),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}