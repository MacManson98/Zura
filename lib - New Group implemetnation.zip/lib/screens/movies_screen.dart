// File: lib/screens/movies_screen.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/user_profile.dart';
import '../movie.dart';
import '../utils/completed_session.dart';
import '../utils/debug_loader.dart';
import '../screens/session_detail_screen.dart';
import 'package:glassmorphism/glassmorphism.dart';
import '../utils/unified_session_manager.dart';
import '../utils/session_manager.dart';
import '../utils/movie_loader.dart';
import 'dart:async';

enum ViewMode { today, solo, friends, groups }

class MoviesScreen extends StatefulWidget {
  final UserProfile? currentUser;
  final Function(String mode, {String? sessionId, bool resume})? onNavigateToMatcher;

  const MoviesScreen({
    super.key,
    required this.currentUser,
    this.onNavigateToMatcher,
    required bool focusReadyToWatch,
  });

  @override
  State<MoviesScreen> createState() => _MoviesScreenState();
}

class _MoviesScreenState extends State<MoviesScreen>
    with TickerProviderStateMixin {

  ViewMode _currentView = ViewMode.today;
  AnimationController? _fabController;
  AnimationController? _heroController;
  Animation<double>? _heroAnimation;
  bool _isRefreshing = false;
  
  // Variables for the auto-refresh functionality
  List<CompletedSession> _allDisplaySessions = [];
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _fabController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _heroController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _heroAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _heroController!, curve: Curves.easeOutCubic),
    );
    
    _heroController!.forward();

    // Simple periodic refresh
    _startRefreshTimer();
    
    // Load sessions initially
    _loadSessionHistory();
  }

  Future<void> _loadMatchedMoviesFromSessions(List<CompletedSession> sessions) async {
    try {
      // Get all movie IDs from all sessions
      final Set<String> allMovieIds = {};
      
      for (final session in sessions) {
        allMovieIds.addAll(session.matchedMovieIds);
        allMovieIds.addAll(session.likedMovieIds);
      }
      
      if (allMovieIds.isEmpty) {
        DebugLogger.log("📝 No movie IDs found in sessions");
        return;
      }
      
      DebugLogger.log("🔍 Found ${allMovieIds.length} unique movie IDs across all sessions");
      
      // Try to find movies in existing collections first
      final List<Movie> foundMovies = [];
      final Set<String> missingMovieIds = {};
      
      for (final movieId in allMovieIds) {
        Movie? foundMovie;
        
        // Try likedMovies first
        try {
          foundMovie = widget.currentUser!.likedMovies.firstWhere(
            (movie) => movie.id == movieId,
          );
          DebugLogger.log("✅ Found movie in likedMovies: ${foundMovie.title}");
        } catch (e) {
          // Try matchedMovies
          try {
            foundMovie = widget.currentUser!.matchedMovies.firstWhere(
              (movie) => movie.id == movieId,
            );
            DebugLogger.log("✅ Found movie in matchedMovies: ${foundMovie.title}");
          } catch (e) {
            // Movie not found in either collection
            missingMovieIds.add(movieId);
            DebugLogger.log("⚠️ Movie ID $movieId not found in user collections");
          }
        }
        
        if (foundMovie != null) {
          foundMovies.add(foundMovie);
        }
      }
      
      // Load missing movies from database if needed
      if (missingMovieIds.isNotEmpty) {
        DebugLogger.log("🔄 Loading ${missingMovieIds.length} missing movies from database...");
        await _loadMissingMoviesFromDatabase(missingMovieIds, foundMovies);
      }
      
      // Update the user's movie collections
      if (mounted) {
        setState(() {
          // Add any new movies to both collections to ensure they're available
          for (final movie in foundMovies) {
            // Add to likedMovies if not already there
            if (!widget.currentUser!.likedMovies.any((m) => m.id == movie.id)) {
              widget.currentUser!.likedMovies.add(movie);
            }
            // Add to matchedMovies if not already there
            if (!widget.currentUser!.matchedMovies.any((m) => m.id == movie.id)) {
              widget.currentUser!.matchedMovies.add(movie);
            }
          }
        });
        
        DebugLogger.log("✅ Updated movie collections: ${foundMovies.length} movies total");
      }
      
    } catch (e) {
      DebugLogger.log("❌ Error loading movies from sessions: $e");
    }
  }

  Future<void> _loadMissingMoviesFromDatabase(Set<String> missingMovieIds, List<Movie> foundMovies) async {
    try {
      // Load the movie database
      final movieDatabase = await MovieDatabaseLoader.loadMovieDatabase();
      
      for (final movieId in missingMovieIds) {
        try {
          final movie = movieDatabase.firstWhere((m) => m.id == movieId);
          foundMovies.add(movie);
          DebugLogger.log("✅ Loaded missing movie from database: ${movie.title}");
        } catch (e) {
          DebugLogger.log("⚠️ Movie ID $movieId not found in movie database - skipping");
          // Just skip missing movies rather than creating placeholders
          // This prevents constructor errors and the UI will handle empty movie lists gracefully
        }
      }
    } catch (e) {
      DebugLogger.log("❌ Error loading movie database: $e");
      // Don't create any placeholders - just let the missing movies remain missing
    }
  }

  @override
  void dispose() {
    // Cancel timer
    _refreshTimer?.cancel();
    _fabController?.dispose();
    _heroController?.dispose();
    super.dispose();
  }

  void _startRefreshTimer() {
    _refreshTimer = Timer.periodic(Duration(seconds: 15), (timer) {
      if (mounted && !_isRefreshing) {
        DebugLogger.log("🔄 Periodic refresh");
        _loadSessionHistory();
      }
    });
  }

  // Manual refresh method for pull-to-refresh
  Future<void> refreshSessions() async {
    DebugLogger.log("🔄 Manual refresh triggered");
    await _loadSessionHistory();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.currentUser == null) {
      return _buildNoUserState();
    }

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: Stack(
        children: [
          // Subtle gradient background
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF1F1F1F),
                  Color(0xFF161616),
                  Color(0xFF121212),
                ],
              ),
            ),
          ),
          
          // Wrap main content in RefreshIndicator
          RefreshIndicator(
            onRefresh: _refreshSessions,
            backgroundColor: Color(0xFF1F1F1F),
            color: Color(0xFFE5A00D),
            strokeWidth: 3.0,
            displacement: 40.0,
            child: CustomScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              slivers: [
                _buildAnimatedHeader(),
                _buildViewToggle(),
                _buildCurrentView(),
                SliverToBoxAdapter(
                  child: SizedBox(height: 100.h),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Dedicated refresh method with user feedback
  Future<void> _refreshSessions() async {
    if (_isRefreshing) return;
    
    try {
      DebugLogger.log("🔄 Pull-to-refresh triggered");
      
      // Show immediate feedback
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                SizedBox(
                  width: 16.w,
                  height: 16.h,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                ),
                SizedBox(width: 12.w),
                Text('Refreshing sessions...'),
              ],
            ),
            backgroundColor: Color(0xFF1F1F1F),
            behavior: SnackBarBehavior.floating,
            duration: Duration(milliseconds: 1500),
          ),
        );
      }
      
      // Perform the actual refresh
      await _loadSessionHistory();
      
      // Success feedback
      if (mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 16.sp),
                SizedBox(width: 8.w),
                Text('Sessions updated!'),
              ],
            ),
            backgroundColor: Color(0xFF1F1F1F),
            behavior: SnackBarBehavior.floating,
            duration: Duration(milliseconds: 1000),
          ),
        );
      }
      
    } catch (e) {
      // Error feedback
      DebugLogger.log("❌ Error during pull-to-refresh: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.error, color: Colors.red, size: 16.sp),
                SizedBox(width: 8.w),
                Text('Refresh failed - try again'),
              ],
            ),
            backgroundColor: Colors.red.withValues(alpha: 0.1),
            behavior: SnackBarBehavior.floating,
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  Widget _buildAnimatedHeader() {
    final stats = _getQuickStats();
    
    return SliverToBoxAdapter(
      child: _heroAnimation != null ? AnimatedBuilder(
        animation: _heroAnimation!,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(0, 50 * (1 - _heroAnimation!.value)),
            child: Opacity(
              opacity: _heroAnimation!.value,
              child: Container(
                height: 150.h,
                margin: EdgeInsets.fromLTRB(20.w, 80.h, 20.w, 20.h),
                child: Stack(
                  children: [
                    // Hero background card
                    GlassmorphicContainer(
                      width: double.infinity,
                      height: double.infinity,
                      borderRadius: 24,
                      blur: 20,
                      alignment: Alignment.center,
                      border: 2,
                      linearGradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Colors.white.withValues(alpha: 0.08),
                          Colors.white.withValues(alpha: 0.04),
                          Colors.white.withValues(alpha: 0.02),
                        ],
                      ),
                      borderGradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Colors.white.withValues(alpha: 0.2),
                          Colors.white.withValues(alpha: 0.1),
                        ],
                      ),
                      child: Container(),
                    ),
                    
                    // Content overlay
                    Padding(
                      padding: EdgeInsets.all(24.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Title row
                          Row(
                            children: [
                              Container(
                                padding: EdgeInsets.all(12.w),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [Color(0xFFE5A00D), Color(0xFFFF6B35)],
                                  ),
                                  borderRadius: BorderRadius.circular(16.r),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0xFFE5A00D).withValues(alpha: 0.3),
                                      blurRadius: 12.r,
                                      spreadRadius: 2.r,
                                    ),
                                  ],
                                ),
                                child: Icon(
                                  Icons.movie_filter,
                                  color: Colors.white,
                                  size: 24.sp,
                                ),
                              ),
                              SizedBox(width: 16.w),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _getHeaderTitle(),
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 24.sp,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                    Text(
                                      "${widget.currentUser!.name}'s Movie Journey",
                                      style: TextStyle(
                                        color: Colors.white70,
                                        fontSize: 14.sp,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              
                              // Integrated notification button
                              GestureDetector(
                                onTap: () => _showNotifications(),
                                child: Container(
                                  padding: EdgeInsets.all(10.w),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withValues(alpha: 0.1),
                                    borderRadius: BorderRadius.circular(12.r),
                                    border: Border.all(
                                      color: Colors.white.withValues(alpha: 0.2),
                                      width: 1.w,
                                    ),
                                  ),
                                  child: Stack(
                                    children: [
                                      Icon(
                                        Icons.notifications_outlined,
                                        color: Colors.white70,
                                        size: 20.sp,
                                      ),
                                      // Notification dot if there are notifications
                                      if (_hasUnreadNotifications())
                                        Positioned(
                                          top: 0,
                                          right: 0,
                                          child: Container(
                                            width: 8.w,
                                            height: 8.h,
                                            decoration: BoxDecoration(
                                              color: Colors.red,
                                              shape: BoxShape.circle,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          
                          Spacer(),
                          
                          // Quick stats grid
                          Row(
                            children: [
                              _buildQuickStatBubble(
                                stats['total'].toString(),
                                'Sessions',
                                Color(0xFFE5A00D),
                              ),
                              SizedBox(width: 12.w),
                              _buildQuickStatBubble(
                                stats['streak'].toString(),
                                'Day Streak',
                                Colors.green,
                              ),
                              SizedBox(width: 12.w),
                              _buildQuickStatBubble(
                                stats['matches'].toString(),
                                'Matches',
                                Colors.purple,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ) : Container(
        height: 200.h,
        margin: EdgeInsets.fromLTRB(20.w, 60.h, 20.w, 20.h),
        child: Stack(
          children: [
            // Hero background card
            GlassmorphicContainer(
              width: double.infinity,
              height: double.infinity,
              borderRadius: 24,
              blur: 20,
              alignment: Alignment.center,
              border: 2,
              linearGradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.white.withValues(alpha: 0.08),
                  Colors.white.withValues(alpha: 0.04),
                  Colors.white.withValues(alpha: 0.02),
                ],
              ),
              borderGradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.white.withValues(alpha: 0.2),
                  Colors.white.withValues(alpha: 0.1),
                ],
              ),
              child: Container(),
            ),
            
            // Content overlay
            Padding(
              padding: EdgeInsets.all(24.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title row
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(12.w),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(16.r),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.2),
                            width: 1.w,
                          ),
                        ),
                        child: Icon(
                          Icons.movie_filter,
                          color: Colors.white,
                          size: 24.sp,
                        ),
                      ),
                      SizedBox(width: 16.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _getHeaderTitle(),
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24.sp,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                              ),
                            ),
                            Text(
                              "${widget.currentUser!.name}'s Movie Journey",
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 14.sp,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Integrated notification button
                      GestureDetector(
                        onTap: () => _showNotifications(),
                        child: Container(
                          padding: EdgeInsets.all(10.w),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(12.r),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.2),
                              width: 1.w,
                            ),
                          ),
                          child: Stack(
                            children: [
                              Icon(
                                Icons.notifications_outlined,
                                color: Colors.white70,
                                size: 20.sp,
                              ),
                              // Notification dot if there are notifications
                              if (_hasUnreadNotifications())
                                Positioned(
                                  top: 0,
                                  right: 0,
                                  child: Container(
                                    width: 8.w,
                                    height: 8.h,
                                    decoration: BoxDecoration(
                                      color: Colors.red,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  
                  Spacer(),
                  
                  // Quick stats grid
                  Row(
                    children: [
                      _buildQuickStatBubble(
                        stats['total'].toString(),
                        'Sessions',
                        Colors.white,
                      ),
                      SizedBox(width: 12.w),
                      _buildQuickStatBubble(
                        stats['streak'].toString(),
                        'Day Streak',
                        Colors.white70,
                      ),
                      SizedBox(width: 12.w),
                      _buildQuickStatBubble(
                        stats['matches'].toString(),
                        'Matches',
                        Colors.white60,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickStatBubble(String value, String label, Color color) {
    return Expanded(
      child: GlassmorphicContainer(
        width: double.infinity,
        height: 60.h,
        borderRadius: 16,
        blur: 10,
        alignment: Alignment.center,
        border: 1,
        linearGradient: LinearGradient(
          colors: [
            Colors.white.withValues(alpha: 0.08),
            Colors.white.withValues(alpha: 0.04),
          ],
        ),
        borderGradient: LinearGradient(
          colors: [
            Colors.white.withValues(alpha: 0.2),
            Colors.white.withValues(alpha: 0.1),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: Colors.white54,
                fontSize: 10.sp,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildViewToggle() {
    return SliverToBoxAdapter(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
        child: GlassmorphicContainer(
          width: double.infinity,
          height: 60.h,
          borderRadius: 30,
          blur: 10,
          alignment: Alignment.center,
          border: 1,
          linearGradient: LinearGradient(
            colors: [
              Colors.white.withValues(alpha: 0.1),
              Colors.white.withValues(alpha: 0.05),
            ],
          ),
          borderGradient: LinearGradient(
            colors: [
              Colors.white.withValues(alpha: 0.3),
              Colors.white.withValues(alpha: 0.1),
            ],
          ),
          child: Row(
            children: ViewMode.values.map((mode) {
              final isSelected = _currentView == mode;
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _currentView = mode),
                  child: Container(
                    height: double.infinity,
                    margin: EdgeInsets.all(6.w),
                    decoration: BoxDecoration(
                      gradient: isSelected 
                          ? LinearGradient(
                              colors: [Color(0xFFE5A00D), Colors.orange.shade600],
                            )
                          : null,
                      borderRadius: BorderRadius.circular(24.r),
                      boxShadow: isSelected 
                          ? [
                              BoxShadow(
                                color: Color(0xFFE5A00D).withValues(alpha: 0.3),
                                blurRadius: 8.r,
                                spreadRadius: 1.r,
                              ),
                            ]
                          : null,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _getViewModeIcon(mode),
                          color: isSelected ? Colors.white : Colors.white60,
                          size: 20.sp,
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          _getViewModeLabel(mode),
                          style: TextStyle(
                            color: isSelected ? Colors.white : Colors.white60,
                            fontSize: 10.sp,
                            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  Widget _buildCurrentView() {
    switch (_currentView) {
      case ViewMode.today:
        return _buildTodayView();
      case ViewMode.solo:
        return _buildSoloView();
      case ViewMode.friends:
        return _buildFriendsView();
      case ViewMode.groups:
        return _buildGroupsView();
    }
  }

  Widget _buildTodayView() {
    final now = DateTime.now();
    final todayStart = DateTime(now.year, now.month, now.day);
    
    // Get all sessions from today
    final todaySessions = _allDisplaySessions.where((session) {
      return session.startTime.isAfter(todayStart) || 
             session.startTime.isAtSameMomentAs(todayStart);
    }).toList();
    
    if (todaySessions.isEmpty) {
      return SliverToBoxAdapter(child: _buildTodayEmptyState());
    }

    // Group sessions by type
    final soloSessions = todaySessions.where((s) => s.type == SessionType.solo).toList();
    final groupSessions = todaySessions.where((s) => s.type != SessionType.solo).toList();
    
    // Group collaborative sessions by participants
    final sessionsByPartner = <String, List<CompletedSession>>{};
    for (final session in groupSessions) {
      final key = session.getOtherParticipantsDisplay(widget.currentUser!.name);
      sessionsByPartner[key] = [...(sessionsByPartner[key] ?? []), session];
    }

    List<Widget> children = [];

    // Solo sessions section
    if (soloSessions.isNotEmpty) {
      children.add(_buildSectionHeaderWidget("Your Solo Sessions", soloSessions.length, Icons.person, Color(0xFFE5A00D)));
      for (int i = 0; i < soloSessions.length; i++) {
        final session = soloSessions[i];
        final isActiveSession = session.id.startsWith("active_");
        children.add(Container(
          margin: EdgeInsets.fromLTRB(20.w, 4.h, 20.w, 8.h),
          child: _buildSessionFeedCard(session, i, isActive: isActiveSession),
        ));
      }
      children.add(SizedBox(height: 20.h));
    }

    // Friend/Group sessions sections
    for (final entry in sessionsByPartner.entries) {
      final partnerName = entry.key;
      final sessions = entry.value;
      
      children.add(_buildSectionHeaderWidget(
        sessions.length == 1 && sessions.first.participantNames.length == 2 
            ? "Your Session with $partnerName"
            : "Your Sessions with $partnerName",
        sessions.length,
        sessions.first.participantNames.length > 2 ? Icons.groups : Icons.people,
        Colors.blue,
      ));
      
      for (int i = 0; i < sessions.length; i++) {
        final session = sessions[i];
        final isActiveSession = session.id.startsWith("active_");
        children.add(Container(
          margin: EdgeInsets.fromLTRB(20.w, 4.h, 20.w, 8.h),
          child: _buildSessionFeedCard(session, i, isActive: isActiveSession),
        ));
      }
      children.add(SizedBox(height: 20.h));
    }

    return SliverList(
      delegate: SliverChildListDelegate(children),
    );
  }

  Widget _buildSectionHeaderWidget(String title, int count, IconData icon, Color color) {
    return Container(
      margin: EdgeInsets.fromLTRB(20.w, 8.h, 20.w, 12.h),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(10.r),
            ),
            child: Icon(icon, color: color, size: 18.sp),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 16.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Text(
              count.toString(),
              style: TextStyle(
                color: color,
                fontSize: 12.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSoloView() {
    // Show all solo sessions (from all time)
    final soloSessions = _allDisplaySessions
        .where((s) => s.type == SessionType.solo)
        .toList();
    
    if (soloSessions.isEmpty) {
      return SliverToBoxAdapter(child: _buildSoloEmptyState());
    }

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) {
          final session = soloSessions[index];
          final isActiveSession = session.id.startsWith("active_");
          
          return Container(
            margin: EdgeInsets.fromLTRB(20.w, 8.h, 20.w, 8.h),
            child: _buildSessionFeedCard(session, index, isActive: isActiveSession),
          );
        },
        childCount: soloSessions.length,
      ),
    );
  }

  Widget _buildFriendsView() {
    // Show all collaborative sessions (from all time)
    final collaborativeSessions = _allDisplaySessions
        .where((s) => s.type != SessionType.solo && 
                      s.participantNames.length == 2)
        .toList();
    
    if (collaborativeSessions.isEmpty) {
      return SliverToBoxAdapter(child: _buildFriendsEmptyState());
    }
    
    // Group by participants for better organization
    final sessionsByPartner = <String, List<CompletedSession>>{};
    
    for (final session in collaborativeSessions) {
      final otherParticipants = session.getOtherParticipantNames(widget.currentUser!.name);
      for (final participant in otherParticipants) {
        sessionsByPartner[participant] = [...(sessionsByPartner[participant] ?? []), session];
      }
    }
    
    final sortedPartners = sessionsByPartner.entries.toList()
      ..sort((a, b) => b.value.length.compareTo(a.value.length)); // Sort by session count

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) {
          final entry = sortedPartners[index];
          final partnerName = entry.key;
          final partnerSessions = entry.value;
          final latestSession = partnerSessions.first;
          
          return Container(
            margin: EdgeInsets.fromLTRB(20.w, 8.h, 20.w, 8.h),
            child: _buildSocialPartnerCard(partnerName, partnerSessions, latestSession, index),
          );
        },
        childCount: sortedPartners.length,
      ),
    );
  }

  Widget _buildGroupsView() {
    // Show only group sessions (3+ participants)
    final groupSessions = _allDisplaySessions
        .where((s) => s.type != SessionType.solo && 
                    s.participantNames.length >= 3) // 3+ total people (2+ other participants)
        .toList();
    
    if (groupSessions.isEmpty) {
      return SliverToBoxAdapter(child: _buildGroupsEmptyState());
    }
    
    // Group by participants for better organization
    final sessionsByGroup = <String, List<CompletedSession>>{};
    
    for (final session in groupSessions) {
      final groupKey = session.getOtherParticipantsDisplay(widget.currentUser!.name);
      sessionsByGroup[groupKey] = [...(sessionsByGroup[groupKey] ?? []), session];
    }
    
    final sortedGroups = sessionsByGroup.entries.toList()
      ..sort((a, b) => b.value.length.compareTo(a.value.length));

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) {
          final entry = sortedGroups[index];
          final groupName = entry.key;
          final groupSessions = entry.value;
          final latestSession = groupSessions.first;
          
          return Container(
            margin: EdgeInsets.fromLTRB(20.w, 8.h, 20.w, 8.h),
            child: _buildGroupPartnerCard(groupName, groupSessions, latestSession, index),
          );
        },
        childCount: sortedGroups.length,
      ),
    );
  }

  void _showPartnerSessionsDetail(String partnerName, List<CompletedSession> sessions) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        padding: EdgeInsets.all(20.w),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1F1F1F),
              Color(0xFF121212),
            ],
          ),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
        ),
        child: Column(
          children: [
            // Handle bar
            Container(
              width: 40.w,
              height: 4.h,
              decoration: BoxDecoration(
                color: Colors.white30,
                borderRadius: BorderRadius.circular(2.r),
              ),
            ),
            
            SizedBox(height: 20.h),
            
            // Header
            Row(
              children: [
                Container(
                  width: 40.w,
                  height: 40.h,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.purple, Colors.blue],
                    ),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      partnerName.isNotEmpty ? partnerName[0].toUpperCase() : "?",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                
                SizedBox(width: 12.w),
                
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Sessions with $partnerName",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "${sessions.length} ${sessions.length == 1 ? 'session' : 'sessions'}",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            
            SizedBox(height: 20.h),
            
            // Sessions list
            Expanded(
              child: ListView.builder(
                itemCount: sessions.length,
                itemBuilder: (context, index) {
                  final session = sessions[index];
                  final movieCount = session.matchedMovieIds.length;
                  
                  return Container(
                    margin: EdgeInsets.only(bottom: 12.h),
                    child: GestureDetector(
                      onTap: () => _openSessionDetail(session),
                      child: Container(
                        padding: EdgeInsets.all(16.w),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.05),
                          borderRadius: BorderRadius.circular(12.r),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.1),
                            width: 1.w,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: EdgeInsets.all(8.w),
                              decoration: BoxDecoration(
                                color: Colors.purple.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(8.r),
                              ),
                              child: Icon(
                                Icons.people,
                                color: Colors.purple,
                                size: 16.sp,
                              ),
                            ),
                            
                            SizedBox(width: 12.w),
                            
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _generateMeaningfulTitle(session),
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 2.h),
                                  Text(
                                    _formatRelativeDate(session.startTime),
                                    style: TextStyle(
                                      color: Colors.white60,
                                      fontSize: 12.sp,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                              decoration: BoxDecoration(
                                color: Colors.purple.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(8.r),
                              ),
                              child: Text(
                                "$movieCount ${movieCount == 1 ? 'match' : 'matches'}",
                                style: TextStyle(
                                  color: Colors.purple,
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showGroupSessionsDetail(String groupName, List<CompletedSession> sessions) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        padding: EdgeInsets.all(20.w),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1F1F1F),
              Color(0xFF121212),
            ],
          ),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
        ),
        child: Column(
          children: [
            // Handle bar
            Container(
              width: 40.w,
              height: 4.h,
              decoration: BoxDecoration(
                color: Colors.white30,
                borderRadius: BorderRadius.circular(2.r),
              ),
            ),
            
            SizedBox(height: 20.h),
            
            // Header
            Row(
              children: [
                Container(
                  width: 40.w,
                  height: 40.h,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.purple, Colors.pink],
                    ),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.groups,
                    color: Colors.white,
                    size: 20.sp,
                  ),
                ),
                
                SizedBox(width: 12.w),
                
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Group Sessions",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "${sessions.length} ${sessions.length == 1 ? 'session' : 'sessions'} with $groupName",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            
            SizedBox(height: 20.h),
            
            // Sessions list
            Expanded(
              child: ListView.builder(
                itemCount: sessions.length,
                itemBuilder: (context, index) {
                  final session = sessions[index];
                  final movieCount = session.matchedMovieIds.length;
                  
                  return Container(
                    margin: EdgeInsets.only(bottom: 12.h),
                    child: GestureDetector(
                      onTap: () => _openSessionDetail(session),
                      child: Container(
                        padding: EdgeInsets.all(16.w),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.05),
                          borderRadius: BorderRadius.circular(12.r),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.1),
                            width: 1.w,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: EdgeInsets.all(8.w),
                              decoration: BoxDecoration(
                                color: Colors.purple.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(8.r),
                              ),
                              child: Icon(
                                Icons.groups,
                                color: Colors.purple,
                                size: 16.sp,
                              ),
                            ),
                            
                            SizedBox(width: 12.w),
                            
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _generateMeaningfulTitle(session),
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 2.h),
                                  Text(
                                    _formatRelativeDate(session.startTime),
                                    style: TextStyle(
                                      color: Colors.white60,
                                      fontSize: 12.sp,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                              decoration: BoxDecoration(
                                color: Colors.purple.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(8.r),
                              ),
                              child: Text(
                                "$movieCount ${movieCount == 1 ? 'match' : 'matches'}",
                                style: TextStyle(
                                  color: Colors.purple,
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSessionFeedCard(CompletedSession session, int index, {bool isActive = false}) {
    final isSolo = session.type == SessionType.solo;
    late final List<String> relevantMovieIds;

    if (isSolo) {
      relevantMovieIds = widget.currentUser!.recentLikes
        .where((like) =>
          like.likedAt.isAfter(session.startTime) &&
          like.likedAt.isBefore(session.endTime))
        .map((like) => like.movieId)
        .toList();
    } else {
      relevantMovieIds = session.matchedMovieIds;
    }

    final movieCount = relevantMovieIds.length;
    final previewMovies = relevantMovieIds.take(4).map((movieId) {
      return widget.currentUser!.likedMovies.firstWhere(
        (m) => m.id == movieId,
        orElse: () => Movie.empty(),
      );
    }).where((movie) => movie.id.isNotEmpty).toList();

    return GestureDetector(
      // Long press for delete menu
      onLongPress: () => _showSessionMenu(session),
      onTap: () => _openSessionDetail(session),
      child: TweenAnimationBuilder<double>(
        duration: Duration(milliseconds: 600 + (index * 100)),
        tween: Tween(begin: 0.0, end: 1.0),
        builder: (context, value, child) {
          return Transform.translate(
            offset: Offset(50 * (1 - value), 0),
            child: Opacity(
              opacity: value,
              child: GlassmorphicContainer(
                width: double.infinity,
                height: movieCount > 0 ? 140.h : 100.h,
                borderRadius: 20,
                blur: 15,
                alignment: Alignment.centerLeft,
                border: 2,
                linearGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: isActive
                      ? [
                          Colors.green.withValues(alpha: 0.2),
                          Colors.blue.withValues(alpha: 0.15),
                          Colors.white.withValues(alpha: 0.05),
                        ]
                      : isSolo
                          ? [
                              Color(0xFFE5A00D).withValues(alpha: 0.15),
                              Colors.orange.withValues(alpha: 0.1),
                              Colors.white.withValues(alpha: 0.05),
                            ]
                          : [
                              Colors.blue.withValues(alpha: 0.15),
                              Colors.purple.withValues(alpha: 0.1),
                              Colors.white.withValues(alpha: 0.05),
                            ],
                ),
                borderGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    (isActive 
                        ? Colors.green 
                        : isSolo 
                            ? Color(0xFFE5A00D) 
                            : Colors.blue).withValues(alpha: 0.6),
                    Colors.white.withValues(alpha: 0.2),
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.all(20.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Clear visual hierarchy
                      Row(
                        children: [
                          // Session type icon with better visibility
                          Container(
                            padding: EdgeInsets.all(10.w),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: isActive 
                                    ? [Colors.green, Colors.green.shade600]
                                    : isSolo 
                                        ? [Color(0xFFE5A00D), Colors.orange]
                                        : [Colors.blue, Colors.blue.shade600],
                              ),
                              borderRadius: BorderRadius.circular(12.r),
                              boxShadow: [
                                BoxShadow(
                                  color: (isActive ? Colors.green : isSolo ? Color(0xFFE5A00D) : Colors.blue)
                                      .withValues(alpha: 0.3),
                                  blurRadius: 8.r,
                                  spreadRadius: 1.r,
                                ),
                              ],
                            ),
                            child: Icon(
                              isActive 
                                  ? Icons.play_circle_filled 
                                  : isSolo 
                                      ? Icons.person 
                                      : Icons.people,
                              color: Colors.white,
                              size: 16.sp,
                            ),
                          ),
                          
                          SizedBox(width: 16.w),
                          
                          // Better hierarchy
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Better title with meaningful names
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        isActive 
                                            ? "Current Session" 
                                            : _generateMeaningfulTitle(session),
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 16.sp,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 0.3,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                    ),
                                    if (isActive) ...[
                                      Container(
                                        padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 2.h),
                                        decoration: BoxDecoration(
                                          color: Colors.green,
                                          borderRadius: BorderRadius.circular(8.r),
                                        ),
                                        child: Text(
                                          "LIVE",
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 10.sp,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                                
                                SizedBox(height: 4.h),
                                
                                // Single time display, better participant info
                                Row(
                                  children: [
                                    Icon(
                                      Icons.access_time,
                                      size: 12.sp,
                                      color: Colors.white60,
                                    ),
                                    SizedBox(width: 4.w),
                                    Text(
                                      isActive 
                                          ? "In progress..." 
                                          : _formatRelativeDate(session.startTime),
                                      style: TextStyle(
                                        color: Colors.white70,
                                        fontSize: 12.sp,
                                      ),
                                    ),
                                    if (!isSolo && session.participantNames.isNotEmpty) ...[
                                      SizedBox(width: 12.w),
                                      Icon(
                                        Icons.people_outline,
                                        size: 12.sp,
                                        color: Colors.white60,
                                      ),
                                      SizedBox(width: 4.w),
                                      Expanded(
                                        child: Text(
                                          session.getOtherParticipantsDisplay(widget.currentUser!.name),
                                          style: TextStyle(
                                            color: Colors.blue.shade300,
                                            fontSize: 12.sp,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ],
                            ),
                          ),
                          
                          // Clear action buttons
                          Column(
                            children: [
                              // Movie count badge
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: isActive 
                                        ? [Colors.green, Colors.green.shade600]
                                        : isSolo 
                                            ? [Color(0xFFE5A00D), Colors.orange]
                                            : [Colors.blue, Colors.blue.shade600],
                                  ),
                                  borderRadius: BorderRadius.circular(12.r),
                                ),
                                child: Text(
                                  "$movieCount ${movieCount == 1 ? 'pick' : 'picks'}",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11.sp,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              
                              SizedBox(height: 8.h),
                              
                              // Action button (Resume/View)
                              GestureDetector(
                                onTap: isActive 
                                    ? () => _resumeSession(session)
                                    : () => _openSessionDetail(session),
                                child: Container(
                                  padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withValues(alpha: 0.15),
                                    borderRadius: BorderRadius.circular(8.r),
                                    border: Border.all(
                                      color: Colors.white.withValues(alpha: 0.3),
                                      width: 1.w,
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        isActive ? Icons.play_arrow : Icons.arrow_forward,
                                        size: 12.sp,
                                        color: Colors.white,
                                      ),
                                      SizedBox(width: 2.w),
                                      Text(
                                        isActive ? "Resume" : "View",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 10.sp,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      
                      // Movie posters preview (only if movies exist)
                      if (movieCount > 0 && previewMovies.isNotEmpty) ...[
                        SizedBox(height: 12.h),
                        SizedBox(
                          height: 50.h,
                          child: Stack(
                            children: [
                              ...previewMovies.take(3).toList().asMap().entries.map((entry) {
                                final index = entry.key;
                                final movie = entry.value;
                                return Positioned(
                                  left: index * 35.w,
                                  child: Container(
                                    width: 40.w,
                                    height: 50.h,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8.r),
                                      border: Border.all(
                                        color: Colors.white.withValues(alpha: 0.3),
                                        width: 1.w,
                                      ),
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(7.r),
                                      child: Image.network(
                                        movie.posterUrl,
                                        fit: BoxFit.cover,
                                        errorBuilder: (_, __, ___) => Container(
                                          color: Colors.grey[800],
                                          child: Icon(
                                            Icons.movie,
                                            size: 16.sp,
                                            color: Colors.white30,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              }).toList(),
                              if (movieCount > 3)
                                Positioned(
                                  left: 3 * 35.w,
                                  child: Container(
                                    width: 40.w,
                                    height: 50.h,
                                    decoration: BoxDecoration(
                                      color: Colors.black54,
                                      borderRadius: BorderRadius.circular(8.r),
                                      border: Border.all(
                                        color: Colors.white.withValues(alpha: 0.3),
                                        width: 1.w,
                                      ),
                                    ),
                                    child: Center(
                                      child: Text(
                                        "+${movieCount - 3}",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 10.sp,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // Session context menu (replaces prominent delete button)
  void _showSessionMenu(CompletedSession session) {
    final isActive = session.id.startsWith("active_");
    
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.all(20.w),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1F1F1F),
              Color(0xFF121212),
            ],
          ),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle bar
            Container(
              width: 40.w,
              height: 4.h,
              decoration: BoxDecoration(
                color: Colors.white30,
                borderRadius: BorderRadius.circular(2.r),
              ),
            ),
            
            SizedBox(height: 20.h),
            
            Text(
              isActive ? "Active Session" : _generateMeaningfulTitle(session),
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            
            SizedBox(height: 20.h),
            
            // Menu options
            if (isActive) ...[
              _buildMenuOption(
                icon: Icons.play_arrow,
                title: "Resume Session",
                subtitle: "Continue where you left off",
                color: Colors.green,
                onTap: () {
                  Navigator.pop(context);
                  _resumeSession(session);
                },
              ),
              SizedBox(height: 12.h),
            ] else ...[
              _buildMenuOption(
                icon: Icons.visibility,
                title: "View Details",
                subtitle: "See full session summary",
                color: Colors.blue,
                onTap: () {
                  Navigator.pop(context);
                  _openSessionDetail(session);
                },
              ),
              SizedBox(height: 12.h),
            ],
            
            _buildMenuOption(
              icon: Icons.delete,
              title: "Delete Session",
              subtitle: isActive ? "End and delete this session" : "Remove from history",
              color: Colors.red,
              isDestructive: true,
              onTap: () {
                Navigator.pop(context);
                _deleteSession(session);
              },
            ),
            
            SizedBox(height: 20.h),
            
            // Cancel button
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 15.h),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12.r),
                ),
                child: Text(
                  "Cancel",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(16.w),
        decoration: BoxDecoration(
          color: isDestructive 
              ? Colors.red.withValues(alpha: 0.1)
              : Colors.white.withValues(alpha: 0.05),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(
            color: isDestructive 
                ? Colors.red.withValues(alpha: 0.3)
                : Colors.white.withValues(alpha: 0.1),
            width: 1.w,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(10.w),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(10.r),
              ),
              child: Icon(icon, color: color, size: 20.sp),
            ),
            
            SizedBox(width: 16.w),
            
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: isDestructive ? Colors.red : Colors.white,
                      fontSize: 15.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: isDestructive ? Colors.red.shade300 : Colors.white60,
                      fontSize: 12.sp,
                    ),
                  ),
                ],
              ),
            ),
            
            Icon(
              Icons.arrow_forward_ios,
              color: isDestructive ? Colors.red : Colors.white30,
              size: 14.sp,
            ),
          ],
        ),
      ),
    );
  }

  // Generate meaningful session titles
  String _generateMeaningfulTitle(CompletedSession session) {
    final isSolo = session.type == SessionType.solo;
    final movieCount = isSolo ? session.likedMovieIds.length : session.matchedMovieIds.length;
    final timeOfDay = session.startTime.hour;
    
    if (movieCount == 0) {
      return isSolo ? "Quick Browse" : "Group Session";
    }
    
    // Better titles based on context
    if (isSolo) {
      if (timeOfDay >= 18) {
        if (movieCount == 1) return "Evening Pick";
        if (movieCount <= 3) return "Night Browsing";
        return "Late Night Hunt";
      } else if (timeOfDay >= 12) {
        if (movieCount == 1) return "Afternoon Find";
        if (movieCount <= 3) return "Midday Picks";
        return "Afternoon Session";
      } else {
        if (movieCount == 1) return "Morning Discovery";
        if (movieCount <= 3) return "Morning Picks";
        return "Early Session";
      }
    } else {
      if (movieCount == 1) return "Perfect Match";
      if (movieCount <= 3) return "Group Consensus";
      if (movieCount <= 7) return "Movie Night Planning";
      return "Epic Group Session";
    }
  }

  // Resume session functionality
  void _resumeSession(CompletedSession session) {
    final isActive = session.id.startsWith("active_");
    
    if (isActive) {
      // Resume the current session
      if (widget.onNavigateToMatcher != null) {
        final sessionType = session.type == SessionType.solo ? 'solo' : 'friend';
        widget.onNavigateToMatcher!(sessionType, resume: true);
      }
    } else {
      // Show option to start a similar session
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          backgroundColor: const Color(0xFF1F1F1F),
          title: Text(
            "Start Similar Session?",
            style: TextStyle(color: Colors.white, fontSize: 18.sp),
          ),
          content: Text(
            "This session is already completed. Would you like to start a new ${session.type == SessionType.solo ? 'solo' : 'group'} session?",
            style: TextStyle(color: Colors.white70, fontSize: 14.sp),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                "Cancel",
                style: TextStyle(color: Colors.grey[400]),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _startMatching(session.type == SessionType.solo ? 'solo' : 'friend');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFFE5A00D),
                foregroundColor: Colors.black,
              ),
              child: Text("Start New"),
            ),
          ],
        ),
      );
    }
  }

  void _deleteSession(CompletedSession session) async {
    final isActive = session.id.startsWith("active_");
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          isActive ? "Delete Active Session?" : "Delete Session?",
          style: TextStyle(color: Colors.white, fontSize: 18.sp),
        ),
        content: Text(
          isActive 
              ? "This will end and permanently delete your current session. This action cannot be undone."
              : "This will permanently delete this session from your history. This action cannot be undone.",
          style: TextStyle(color: Colors.white70, fontSize: 14.sp),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              "Cancel",
              style: TextStyle(color: Colors.grey[400]),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.of(context).pop();
              await _performSessionDeletion(session, isActive);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: Text("Delete"),
          ),
        ],
      ),
    );
  }

  Future<void> _performSessionDeletion(CompletedSession session, bool isActive) async {
    try {
      if (isActive) {
        // Handle active session deletion
        SessionManager.endSession();
        DebugLogger.log("✅ Active session ended without saving");
      } else {
        // Use unified session manager for proper deletion
        await UnifiedSessionManager.deleteSessionProperly(
          session: session,
          userProfile: widget.currentUser!,
        );
      }

      // Refresh the session list using the unified loader
      await _loadSessionHistory();

      // Show success message
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(isActive ? 'Active session deleted' : 'Session deleted'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
      }

    } catch (e) {
      DebugLogger.log("❌ Error deleting session: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to delete session: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  Future<List<CompletedSession>> fetchSwipeSessions(String userId) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('swipeSessions')
        .where('participantIds', arrayContains: userId)
        .orderBy('createdAt', descending: true)
        .get();

    return snapshot.docs.map((doc) {
    return CompletedSession.fromFirestore(doc.id, doc.data());
  }).toList();
  }

  Future<void> _loadSessionHistory() async {
    if (widget.currentUser == null || _isRefreshing) return;
    
    try {
      _isRefreshing = true;
      
      // Load all sessions using unified manager (already includes active sessions properly)
      final allSessions = await UnifiedSessionManager.getAllSessionsForDisplay(widget.currentUser!);
      
      if (mounted) {
        setState(() {
          // Use the sessions directly from UnifiedSessionManager (includes active sessions properly)
          _allDisplaySessions = allSessions;
          
          // Keep only solo sessions in the user profile (for local storage)
          widget.currentUser!.sessionHistory = allSessions
              .where((s) => s.type == SessionType.solo && !s.id.startsWith("active_"))
              .toList();
        });
        
        DebugLogger.log("✅ Loaded ${allSessions.length} sessions (including active sessions)");
        
        // Load matched movies from sessions
        await _loadMatchedMoviesFromSessions(allSessions);
      }
      
    } catch (e) {
      DebugLogger.log("❌ Error loading session history: $e");
    } finally {
      _isRefreshing = false;
    }
  }

  Widget _buildTodayEmptyState() {
    return Container(
      margin: EdgeInsets.all(40.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(24.w),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.blue.withValues(alpha: 0.2),
                  Colors.purple.withValues(alpha: 0.1),
                ],
              ),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.today,
              size: 48.sp,
              color: Colors.blue,
            ),
          ),
          
          SizedBox(height: 24.h),
          
          Text(
            "No Sessions Today",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 8.h),
          
          Text(
            "Start a movie session to discover something great",
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14.sp,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 24.h),
          
          GestureDetector(
            onTap: () => _startMatching('solo'),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFFE5A00D), Colors.orange.shade600],
                ),
                borderRadius: BorderRadius.circular(20.r),
              ),
              child: Text(
                "Start Session",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSoloEmptyState() {
    return Container(
      margin: EdgeInsets.all(40.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(24.w),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFFE5A00D).withValues(alpha: 0.2),
                  Colors.orange.withValues(alpha: 0.1),
                ],
              ),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.person,
              size: 48.sp,
              color: Color(0xFFE5A00D),
            ),
          ),
          
          SizedBox(height: 24.h),
          
          Text(
            "No Solo Sessions Yet",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 8.h),
          
          Text(
            "Start a solo session to discover movies on your own",
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14.sp,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 24.h),
          
          GestureDetector(
            onTap: () => _startMatching('solo'),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFFE5A00D), Colors.orange.shade600],
                ),
                borderRadius: BorderRadius.circular(20.r),
              ),
              child: Text(
                "Start Solo Session",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFriendsEmptyState() {
    return Container(
      margin: EdgeInsets.all(40.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(24.w),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.blue.withValues(alpha: 0.2),
                  Colors.purple.withValues(alpha: 0.1),
                ],
              ),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.people_outline,
              size: 48.sp,
              color: Colors.blue,
            ),
          ),
          
          SizedBox(height: 24.h),
          
          Text(
            "No Friend Sessions Yet",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 8.h),
          
          Text(
            "Start a session with friends to see your social movie history",
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14.sp,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 24.h),
          
          GestureDetector(
            onTap: () => _startMatching('friend'),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue, Colors.blue.shade600],
                ),
                borderRadius: BorderRadius.circular(20.r),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.people, size: 16.sp, color: Colors.white),
                  SizedBox(width: 8.w),
                  Text(
                    "Start Friend Session",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGroupsEmptyState() {
    return Container(
      margin: EdgeInsets.all(40.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(24.w),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.purple.withValues(alpha: 0.2),
                  Colors.blue.withValues(alpha: 0.1),
                ],
              ),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.groups,
              size: 48.sp,
              color: Colors.purple,
            ),
          ),
          
          SizedBox(height: 24.h),
          
          Text(
            "No Group Sessions Yet",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 8.h),
          
          Text(
            "Start a group session with multiple friends to see your group movie history",
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14.sp,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 24.h),
          
          GestureDetector(
            onTap: () => _startMatching('group'), // This will allow group creation
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.purple, Colors.purple.shade600],
                ),
                borderRadius: BorderRadius.circular(20.r),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.groups, size: 16.sp, color: Colors.white),
                  SizedBox(width: 8.w),
                  Text(
                    "Start Group Session",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSocialPartnerCard(String partnerName, List<CompletedSession> sessions, CompletedSession latestSession, int index) {
    final totalMatches = sessions.fold(0, (sum, s) => sum + s.matchedMovieIds.length);
    final sessionCount = sessions.length;
    
    return GestureDetector(
      onTap: () => _showPartnerSessionsDetail(partnerName, sessions),
      child: TweenAnimationBuilder<double>(
        duration: Duration(milliseconds: 600 + (index * 100)),
        tween: Tween(begin: 0.0, end: 1.0),
        builder: (context, value, child) {
          return Transform.translate(
            offset: Offset(50 * (1 - value), 0),
            child: Opacity(
              opacity: value,
              child: GlassmorphicContainer(
                width: double.infinity,
                height: 120.h,
                borderRadius: 20,
                blur: 15,
                alignment: Alignment.centerLeft,
                border: 2,
                linearGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.purple.withValues(alpha: 0.15),
                    Colors.blue.withValues(alpha: 0.1),
                    Colors.white.withValues(alpha: 0.05),
                  ],
                ),
                borderGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.purple.withValues(alpha: 0.6),
                    Colors.white.withValues(alpha: 0.2),
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.all(20.w),
                  child: Row(
                    children: [
                      // Partner avatar/icon
                      Container(
                        width: 50.w,
                        height: 50.h,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.purple, Colors.blue],
                          ),
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: Text(
                            partnerName.isNotEmpty ? partnerName[0].toUpperCase() : "?",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20.sp,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      
                      SizedBox(width: 16.w),
                      
                      // Partner info
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              partnerName,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16.sp,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            
                            SizedBox(height: 4.h),
                            
                            Row(
                              children: [
                                Icon(
                                  Icons.movie_filter,
                                  size: 12.sp,
                                  color: Colors.purple.shade300,
                                ),
                                SizedBox(width: 4.w),
                                Text(
                                  "$sessionCount ${sessionCount == 1 ? 'session' : 'sessions'}",
                                  style: TextStyle(
                                    color: Colors.purple.shade300,
                                    fontSize: 12.sp,
                                  ),
                                ),
                                SizedBox(width: 12.w),
                                Icon(
                                  Icons.favorite,
                                  size: 12.sp,
                                  color: Colors.purple.shade300,
                                ),
                                SizedBox(width: 4.w),
                                Text(
                                  "$totalMatches ${totalMatches == 1 ? 'match' : 'matches'}",
                                  style: TextStyle(
                                    color: Colors.purple.shade300,
                                    fontSize: 12.sp,
                                  ),
                                ),
                              ],
                            ),
                            
                            SizedBox(height: 4.h),
                            
                            Text(
                              "Latest: ${_formatRelativeDate(latestSession.startTime)}",
                              style: TextStyle(
                                color: Colors.white60,
                                fontSize: 11.sp,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Arrow indicator
                      Container(
                        padding: EdgeInsets.all(8.w),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8.r),
                        ),
                        child: Icon(
                          Icons.arrow_forward_ios,
                          color: Colors.white60,
                          size: 14.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildGroupPartnerCard(String groupName, List<CompletedSession> sessions, CompletedSession latestSession, int index) {
    final totalMatches = sessions.fold(0, (sum, s) => sum + s.matchedMovieIds.length);
    final sessionCount = sessions.length;
    
    return GestureDetector(
      onTap: () => _showGroupSessionsDetail(groupName, sessions),
      child: TweenAnimationBuilder<double>(
        duration: Duration(milliseconds: 600 + (index * 100)),
        tween: Tween(begin: 0.0, end: 1.0),
        builder: (context, value, child) {
          return Transform.translate(
            offset: Offset(50 * (1 - value), 0),
            child: Opacity(
              opacity: value,
              child: GlassmorphicContainer(
                width: double.infinity,
                height: 120.h,
                borderRadius: 20,
                blur: 15,
                alignment: Alignment.centerLeft,
                border: 2,
                linearGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.purple.withValues(alpha: 0.15),
                    Colors.pink.withValues(alpha: 0.1),
                    Colors.white.withValues(alpha: 0.05),
                  ],
                ),
                borderGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.purple.withValues(alpha: 0.6),
                    Colors.white.withValues(alpha: 0.2),
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.all(20.w),
                  child: Row(
                    children: [
                      // Group avatar/icon
                      Container(
                        width: 50.w,
                        height: 50.h,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.purple, Colors.pink],
                          ),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.groups,
                          color: Colors.white,
                          size: 24.sp,
                        ),
                      ),
                      
                      SizedBox(width: 16.w),
                      
                      // Group info
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              groupName,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16.sp,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            
                            SizedBox(height: 4.h),
                            
                            Row(
                              children: [
                                Icon(
                                  Icons.movie_filter,
                                  size: 12.sp,
                                  color: Colors.purple.shade300,
                                ),
                                SizedBox(width: 4.w),
                                Text(
                                  "$sessionCount ${sessionCount == 1 ? 'session' : 'sessions'}",
                                  style: TextStyle(
                                    color: Colors.purple.shade300,
                                    fontSize: 12.sp,
                                  ),
                                ),
                                SizedBox(width: 12.w),
                                Icon(
                                  Icons.favorite,
                                  size: 12.sp,
                                  color: Colors.purple.shade300,
                                ),
                                SizedBox(width: 4.w),
                                Text(
                                  "$totalMatches ${totalMatches == 1 ? 'match' : 'matches'}",
                                  style: TextStyle(
                                    color: Colors.purple.shade300,
                                    fontSize: 12.sp,
                                  ),
                                ),
                              ],
                            ),
                            
                            SizedBox(height: 4.h),
                            
                            Text(
                              "Latest: ${_formatRelativeDate(latestSession.startTime)}",
                              style: TextStyle(
                                color: Colors.white60,
                                fontSize: 11.sp,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Arrow indicator
                      Container(
                        padding: EdgeInsets.all(8.w),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8.r),
                        ),
                        child: Icon(
                          Icons.arrow_forward_ios,
                          color: Colors.white60,
                          size: 14.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildNoUserState() {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.person_off, size: 64.sp, color: Colors.white30),
            SizedBox(height: 16.h),
            Text(
              "Profile Required",
              style: TextStyle(color: Colors.white, fontSize: 20.sp, fontWeight: FontWeight.bold),
            ),
            Text(
              "Please set up your profile first",
              style: TextStyle(color: Colors.white70, fontSize: 14.sp),
            ),
          ],
        ),
      ),
    );
  }

  // Helper methods
  IconData _getViewModeIcon(ViewMode mode) {
    switch (mode) {
      case ViewMode.today:
        return Icons.today;
      case ViewMode.solo:
        return Icons.person;
      case ViewMode.friends:
        return Icons.people;
      case ViewMode.groups:
        return Icons.groups;
    }
  }

  String _getViewModeLabel(ViewMode mode) {
    switch (mode) {
      case ViewMode.today:
        return "Today";
      case ViewMode.solo:
        return "Solo";
      case ViewMode.friends:
        return "Friends";
      case ViewMode.groups:
        return "Groups";
    }
  }

  String _getHeaderTitle() {
    switch (_currentView) {
      case ViewMode.today:
        return "Today's Sessions";
      case ViewMode.solo:
        return "Solo Sessions";
      case ViewMode.friends:
        return "Friend Sesions";
      case ViewMode.groups:
        return "Group Sessions";
    }
  }

  Map<String, dynamic> _getQuickStats() {
    final sessions = _allDisplaySessions;
    
    int totalSessions = sessions.length;
    int totalMatches = sessions.fold(0, (sum, s) => sum + s.matchedMovieIds.length);
    
    if (SessionManager.hasActiveSession && SessionManager.currentSession != null) {
      final activeSession = SessionManager.currentSession!;
      totalSessions += 1;
      totalMatches += activeSession.matchedMovieIds.length;
    }
    
    return {
      'total': totalSessions,
      'streak': _calculateStreak(),
      'matches': totalMatches,
    };
  }

  int _calculateStreak() {
    final sessions = _allDisplaySessions;
    if (sessions.isEmpty) return 0;
    
    final sortedSessions = sessions.toList()
      ..sort((a, b) => b.startTime.compareTo(a.startTime));
    
    int streak = 0;
    DateTime? lastDate;
    
    for (final session in sortedSessions) {
      final sessionDate = DateTime(
        session.startTime.year,
        session.startTime.month,
        session.startTime.day,
      );
      
      if (lastDate == null) {
        lastDate = sessionDate;
        streak = 1;
      } else {
        final daysDiff = lastDate.difference(sessionDate).inDays;
        if (daysDiff == 1) {
          streak++;
          lastDate = sessionDate;
        } else {
          break;
        }
      }
    }
    
    return streak;
  }

  void _openSessionDetail(CompletedSession session) {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => SessionDetailScreen(
          session: session,
          currentUser: widget.currentUser!,
          onStartNewSession: () {
            Navigator.pop(context);
            _startMatching(session.type == SessionType.solo ? 'solo' : 'friend');
          },
        ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: animation.drive(
              Tween(begin: const Offset(1.0, 0.0), end: Offset.zero)
                  .chain(CurveTween(curve: Curves.easeInOut)),
            ),
            child: child,
          );
        },
      ),
    );
  }

  void _startMatching(String mode) {
    DebugLogger.log("🎯 Starting $mode matching...");
    
    if (widget.onNavigateToMatcher != null) {
      widget.onNavigateToMatcher!(mode);
    } else {
      DebugLogger.log("❌ No navigation callback provided");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Unable to start matching session'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  void _showNotifications() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Notifications - Coming soon!'),
        backgroundColor: Color(0xFF1A1A2E),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  bool _hasUnreadNotifications() {
    return false;
  }

  String _formatRelativeDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays == 0) {
      if (difference.inHours == 0) {
        return '${difference.inMinutes}m ago';
      }
      return '${difference.inHours}h ago';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
}