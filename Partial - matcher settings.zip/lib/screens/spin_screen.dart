// File: lib/screens/spin_screen.dart

import 'package:flutter/material.dart';
import '../movie.dart';
import '../widgets/quick_pick_widget.dart';

class SpinScreen extends StatelessWidget {
  final List<Movie> likedMovies;
  final Set<String> passedMovies;

  const SpinScreen({
    super.key,
    required this.likedMovies,
    required this.passedMovies,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text('Quick Pick'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              children: [
                const Text(
                  'Can\'t decide what to watch?',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Let Quick Pick choose a movie for your group!',
                  style: TextStyle(color: Colors.white70),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),
                QuickPickWidget(
                  matchedMovies: likedMovies,
                  onMovieSelected: (movie) {
                    // Show a snackbar with the picked movie
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Tonight's movie: ${movie.title}"),
                        backgroundColor: const Color(0xFFE5A00D),
                        duration: const Duration(seconds: 4),
                        action: SnackBarAction(
                          label: 'Details',
                          textColor: Colors.black,
                          onPressed: () {
                            // Show movie details
                            _showMovieDetails(context, movie);
                          },
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  
  void _showMovieDetails(BuildContext context, Movie movie) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          movie.title,
          style: const TextStyle(color: Colors.white),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  movie.posterUrl,
                  height: 200,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      height: 200,
                      color: Colors.grey[800],
                      child: const Center(
                        child: Icon(
                          Icons.movie,
                          color: Colors.white24,
                          size: 64,
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
              Text(
                movie.overview,
                style: const TextStyle(color: Colors.white70),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Close',
              style: TextStyle(color: Color(0xFFE5A00D)),
            ),
          ),
        ],
      ),
    );
  }
}