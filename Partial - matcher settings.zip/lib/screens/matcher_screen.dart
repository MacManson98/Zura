import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../movie.dart';
import '../utils/enhanced_learning_engine.dart'; // 🆕 NEW
import '../utils/movie_loader.dart'; // 🆕 NEW
import '../models/user_profile.dart';
import '../utils/user_profile_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/session_invitation_widget.dart';
import '../screens/match_celebration_screen.dart';
import 'movie_detail_screen.dart';
import '../utils/tmdb_api.dart';
import '../utils/mood_based_learning_engine.dart';
import '../models/session_models.dart';
import '../services/session_service.dart';
import '../main_navigation.dart';
import '../screens/matcher_settings_screen.dart';
// Define matching modes
enum MatchingMode { 
  solo,
  friend,
  group,
}

class MatcherScreen extends StatefulWidget {
  final List<Movie> allMovies;
  final UserProfile currentUser;
  final List<UserProfile> availableFriends;
  final bool showTutorial;
  final UserProfile? selectedFriend;
  final MatchingMode mode;

  const MatcherScreen({
    super.key,
    required this.allMovies,
    required this.currentUser,
    required this.availableFriends,
    this.showTutorial = false,
    this.selectedFriend,
    this.mode = MatchingMode.solo,
  });

  @override
  State<MatcherScreen> createState() => _MatcherScreenState();
}

class _MatcherScreenState extends State<MatcherScreen> {
  late List<Movie> sessionPool = [];
  final Set<String> currentUserLikes = {};
  MatchingMode currentMode = MatchingMode.solo;
  UserProfile? selectedFriend; // Track the currently selected friend
  List<UserProfile> selectedGroup = [];
  final Map<String, Set<String>> groupLikes = {};
  bool _showTutorial = true; // Set to false after user completes tutorial
  int _tutorialPage = 0;
  final PageController _tutorialPageController = PageController();
  late List<Movie> movieDatabase = [];
  final Set<String> currentSessionMovieIds = {};
  bool _isLoadingSession = false;
  late List<Movie> _basePool = []; // Original pool
  late List<Movie> _dynamicPool = []; // Current dynamic pool
  int _swipeCount = 0;
  bool _isRefreshingPool = false;
  SessionContext? currentSessionContext;
  List<CurrentMood> selectedMoods = [];
  bool _showMatcherSettings = false;  // Replace _showMoodSelectionModal
  SessionSettings? currentSessionSettings;
  bool _isReadyToSwipe = false;
  SwipeSession? currentSession;
  StreamSubscription<SwipeSession>? sessionSubscription;
  bool isWaitingForFriend = false;
  bool isInCollaborativeMode = false;
  Set<String> sessionPassedMovieIds = {};  
  
  
  
      @override
    void initState() {
      super.initState();
      
      // Register callback for direct session joining
      MainNavigation.setSessionCallback(_startCollaborativeSession);
      
      EnhancedLearningEngine.resetSessionTracking();
      currentMode = widget.mode;
      selectedFriend = widget.selectedFriend;
      _initializeApp();
      _checkTutorialSeen(widget.showTutorial);
    }

    // NEW: Show mood picker modal
    void _showMatcherSettingsScreen() {
      setState(() {
        _showMatcherSettings = true;
      });
    }

    // NEW: Reset to selection state
    void _resetToSelection() {
      setState(() {
        _isReadyToSwipe = false;
        selectedMoods.clear();
        currentSessionContext = null;
        currentSessionSettings = null;
        sessionPool.clear();
        sessionPassedMovieIds.clear(); 
      });
    }

  bool _canChooseMood() {
    switch (currentMode) {
      case MatchingMode.solo:
        return true;
      case MatchingMode.friend:
        return selectedFriend != null;
      case MatchingMode.group:
        return selectedGroup.isNotEmpty;
    }
  }

  @override
  void didUpdateWidget(MatcherScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    
    // Check if the mode parameter has changed
    if (oldWidget.mode != widget.mode) {
      print("🔄 Mode changed from ${oldWidget.mode} to ${widget.mode}");
      
      setState(() {
        currentMode = widget.mode;
        
        // Reset session state when mode changes
        _resetToSelection();
        
        // Clear selections when switching away from those modes
        if (currentMode != MatchingMode.friend) {
          selectedFriend = null;
        }
        if (currentMode != MatchingMode.group) {
          selectedGroup.clear();
          groupLikes.clear();
        }
      });
      
      // Regenerate session if needed
      if (currentMode == MatchingMode.solo) {
        _initializeApp();
      }
    }
    
    // Check if selectedFriend parameter has changed
    if (oldWidget.selectedFriend != widget.selectedFriend) {
      print("🔄 Selected friend changed from ${oldWidget.selectedFriend?.name} to ${widget.selectedFriend?.name}");
      
      setState(() {
        selectedFriend = widget.selectedFriend;
      });
    }
  }

  void debugMoviePool() {
    print("🔍 DEBUG: Current movie pool:");
    print("   Total movies: ${sessionPool.length}");
    
    if (sessionPool.isNotEmpty) {
      print("   First 5 movies:");
      for (int i = 0; i < sessionPool.length && i < 5; i++) {
        print("      ${i + 1}. ${sessionPool[i].title} (ID: ${sessionPool[i].id})");
      }
    }
    
    if (currentSession != null) {
      print("   Firestore has ${currentSession!.moviePool.length} movie IDs");
      if (currentSession!.moviePool.isNotEmpty) {
        print("   First 3 Firestore IDs: ${currentSession!.moviePool.take(3).join(', ')}");
      }
    }
  }

  Future<void> _initializeApp() async {
    setState(() => _isLoadingSession = true);
    
    try {
      // Load movie database
      movieDatabase = await MovieDatabaseLoader.loadMovieDatabase();
      
      // Check if we should show the "Learning your taste..." banner
      if (!widget.currentUser.hasSeenMatcher) {
        widget.currentUser.hasSeenMatcher = true;
        await UserProfileStorage.saveProfile(widget.currentUser);
      }

      // Don't generate any movies automatically - wait for user to choose mood
      print("✅ App initialized - waiting for mood selection");
          
    } catch (e) {
      print("❌ Error initializing app: $e");
    } finally {
      setState(() => _isLoadingSession = false);
    }
  }
    Widget _buildSmartBanner() {
      if (_showMatcherSettings) {
        return const SizedBox.shrink();
      }
      
      // Show mood banner for mood-based sessions OR collaborative sessions
      if (selectedMoods.isNotEmpty) {
        return _buildMoodBanner();
      }
      
      return const SizedBox.shrink();
    }

  Widget _buildMoodBanner() {
    String moodText;
    String moodEmoji;
    
    if (selectedMoods.length == 1) {
      moodText = "${selectedMoods.first.displayName} vibes";
      moodEmoji = selectedMoods.first.emoji;
    } else {
      moodText = "Blended vibes: ${selectedMoods.map((m) => m.displayName).take(2).join(' + ')}${selectedMoods.length > 2 ? ' +${selectedMoods.length - 2}' : ''}";
      moodEmoji = selectedMoods.take(3).map((m) => m.emoji).join();
    }

    // 🆕 NEW: Add settings summary for collaborative sessions
    String? settingsText;
    if (isInCollaborativeMode && currentSessionSettings != null) {
      final parts = <String>[];
      
      if (currentSessionSettings!.streamingPreferences.ownedServices.isNotEmpty) {
        parts.add("${currentSessionSettings!.streamingPreferences.ownedServices.length} services");
      }
      
      if (currentSessionSettings!.additionalGenres.isNotEmpty) {
        parts.add("${currentSessionSettings!.additionalGenres.length} genres");
      }
      
      if (parts.isNotEmpty) {
        settingsText = parts.join(" • ");
      }
    }
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 6.h),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isInCollaborativeMode 
              ? [
                  const Color(0xFF4A90E2).withValues(alpha: 0.9),
                  const Color(0xFF357ABD).withValues(alpha: 0.9),
                ]
              : [
                  const Color(0xFF4A90E2).withValues(alpha: 0.8),
                  const Color(0xFF357ABD).withValues(alpha: 0.8),
                ],
        ),
        borderRadius: BorderRadius.circular(12.r),
        boxShadow: [
          BoxShadow(
            color: (isInCollaborativeMode ? const Color(0xFF4A90E2) : const Color(0xFF4A90E2)).withValues(alpha: 0.3),
            blurRadius: 4.r,
            offset: Offset(0, 1.h),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(12.r),
        child: Row(
          children: [
            // Mood emoji
            Container(
              padding: EdgeInsets.all(6.r),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8.r),
              ),
              child: Text(
                moodEmoji,
                style: TextStyle(fontSize: 18.sp),
              ),
            ),
            SizedBox(width: 10.w),
            
            // Mood and settings text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    moodText,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13.sp,
                      fontWeight: FontWeight.bold,
                      height: 1.2,
                    ),
                  ),
                  if (settingsText != null) ...[
                    Text(
                      settingsText,
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.8),
                        fontSize: 10.sp,
                        height: 1.2,
                      ),
                    ),
                  ] else ...[
                    Text(
                      isInCollaborativeMode ? "Collaborative session active" : "Finding perfect movies",
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.85),
                        fontSize: 11.sp,
                        height: 1.2,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            
            // Action buttons (your existing button logic)
            if (isInCollaborativeMode) ...[
              // Change Settings button
              GestureDetector(
                onTap: _requestMoodChange,
                child: Container(
                  padding: EdgeInsets.all(6.r),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white.withValues(alpha: 0.6), width: 1.w),
                    borderRadius: BorderRadius.circular(6.r),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.tune, color: Colors.white, size: 14.sp),
                      SizedBox(width: 4.w),
                      Text(
                        currentSession?.hostId == widget.currentUser.uid ? "Settings" : "Request",
                        style: TextStyle(color: Colors.white, fontSize: 10.sp),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(width: 8.w),
              
              // End Session button
              GestureDetector(
                onTap: _cancelSessionForBoth,
                child: Container(
                  padding: EdgeInsets.all(6.r),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.red.withValues(alpha: 0.8), width: 1.w),
                    borderRadius: BorderRadius.circular(6.r),
                  ),
                  child: Icon(
                    Icons.close,
                    color: Colors.red.withValues(alpha: 0.9),
                    size: 16.sp,
                  ),
                ),
              ),
            ] else ...[
              // Solo mode - refresh button
              GestureDetector(
                onTap: () {
                  setState(() {
                    _showMatcherSettings = true;
                    selectedMoods.clear();
                    currentSessionContext = null;
                  });
                },
                child: Container(
                  padding: EdgeInsets.all(6.r),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white.withValues(alpha: 0.6), width: 1.w),
                    borderRadius: BorderRadius.circular(6.r),
                  ),
                  child: Icon(
                    Icons.refresh,
                    color: Colors.white,
                    size: 16.sp,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }


    /// 🆕 NEW: Loading state for when generating sessions
    Widget _buildLoadingState() {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(color: Color(0xFFE5A00D)),
            SizedBox(height: 16.h),
            Text(
              "Generating personalized recommendations...",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16.sp,
              ),
            ),
          ],
        ),
      );
    }

    /// 🆕 NEW: Print learning insights for debugging
    void _printLearningInsights() {
      final insights = EnhancedLearningEngine.analyzeTasteProfile(widget.currentUser);
      print("🧠 Learning Insights:");
      print("   Movies Liked: ${insights['totalMoviesLiked']}");
      print("   Diversity Score: ${insights['diversityScore']}");
      print("   Exploration: ${insights['explorationTrend']}");
      
      if ((insights['topGenres'] as List).isNotEmpty) {
        print("   Top Genres: ${(insights['topGenres'] as List).take(3).map((g) => g['name']).join(', ')}");
      }
      if ((insights['topVibes'] as List).isNotEmpty) {
        print("   Top Vibes: ${(insights['topVibes'] as List).take(3).map((v) => v['name']).join(', ')}");
      }
    }

  // 🆕 ADD THIS NEW METHOD
  Future<void> _generatePersonalizedSession() async {
    if (movieDatabase.isEmpty) {
      print("⚠️ No movie database loaded, using sample movies");
      return;
    }
    
    final seenMovieIds = <String>{
      ...widget.currentUser.likedMovieIds,
      ...widget.currentUser.passedMovieIds,
      ...currentSessionMovieIds,
    };
    
    if (currentMode == MatchingMode.solo) {
      // Generate initial pool
      _basePool = await EnhancedLearningEngine.generatePersonalizedSession(
        user: widget.currentUser,
        movieDatabase: movieDatabase,
        seenMovieIds: seenMovieIds,
        sessionSize: 50,
      );
      
      // Start with first 20 movies
      _dynamicPool = _basePool.take(20).toList();
      sessionPool = List.from(_dynamicPool);
      
    } else {
      // Your existing logic for friend/group modes
      if (movieDatabase.isNotEmpty) {
        sessionPool = movieDatabase.take(50).toList();
        if (isInCollaborativeMode && currentSession != null) {
          sessionPool.shuffle(Random(currentSession!.sessionId.hashCode));
        } else {
          sessionPool.shuffle(); // Normal random shuffle
        }
      }
    }
    
    currentSessionMovieIds.clear();
    currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
    
    print("🎬 Generated session: ${sessionPool.length} movies for ${currentMode.name} mode");
  }
  

  Future<void> _checkTutorialSeen(bool forceShow) async {
    final prefs = await SharedPreferences.getInstance();
    final tutorialSeen = prefs.getBool('tutorial_seen') ?? false;
    setState(() {
      _showTutorial = forceShow || !tutorialSeen;
    });
  }


  Future<void> _markTutorialSeen() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('tutorial_seen', true);
  }

  void likeMovie(Movie movie) async {
    // 🆕 Track with timestamp and session type
    final sessionType = currentMode == MatchingMode.solo 
        ? "solo" 
        : currentMode == MatchingMode.friend 
            ? "friend" 
            : "group";
            
    widget.currentUser.recentLikes.add(MovieLike(
      movieId: movie.id,
      likedAt: DateTime.now(),
      sessionType: sessionType,
    ));
    
    // Keep only last 50 likes to prevent unlimited growth
    if (widget.currentUser.recentLikes.length > 50) {
      widget.currentUser.recentLikes.removeRange(
        0, 
        widget.currentUser.recentLikes.length - 50
      );
    }
    
    // 🆕 Apply enhanced learning (your existing code)
    EnhancedLearningEngine.learnFromLikedMovie(widget.currentUser, movie);
    
    setState(() {
      widget.currentUser.likedMovies.add(movie);
      widget.currentUser.likedMovieIds.add(movie.id);
    });

    try {
      await UserProfileStorage.saveProfile(widget.currentUser);
    } catch (e) {
      print("⚠️ Error saving user profile: $e");
    }

    // Match logic (your existing code)
    if (currentMode == MatchingMode.friend &&
        selectedFriend?.likedMovieIds.contains(movie.id) == true) {
      _showMatchDialog(movie);
    }

    if (currentMode == MatchingMode.group) {
      groupLikes[widget.currentUser.name]?.add(movie.title);
      final everyone = [widget.currentUser.name, ...selectedGroup.map((f) => f.name)];
      final allLiked = everyone.every((name) => groupLikes[name]?.contains(movie.title) == true);
      if (allLiked) _showMatchDialog(movie);
    }

    _printLearningInsights();
  }

   void passMovie(Movie movie) {
    // For mood sessions, this is just "not in mood tonight" - very light learning
    if (currentSessionContext != null) {
      // Already handled in _onSwipe via MoodBasedLearningEngine.learnFromMoodInteraction
      print("👎 Not in mood for: ${movie.title} (light learning applied)");
    } else {
      // For Perfect For Me/Us sessions, apply enhanced learning
      EnhancedLearningEngine.learnFromPassedMovie(widget.currentUser, movie);
      print("👎 Passed on: ${movie.title}");
    }
    
    // Save profile
    UserProfileStorage.saveProfile(widget.currentUser);
  }

  void _showMatchDialog(Movie movie) {
    // Navigate to the new match celebration screen
    Navigator.push(
      context,
      PageRouteBuilder(
        opaque: false,
        barrierDismissible: false,
        pageBuilder: (context, animation, secondaryAnimation) {
          return MatchCelebrationScreen(  // ✅ FIXED: Use new screen
            movie: movie,
            currentUser: widget.currentUser,
            matchedName: selectedFriend?.name,
            allMatchedUsers: currentMode == MatchingMode.group 
                ? selectedGroup.map((f) => f.uid).toList()
                : null,
            onContinueSearching: () {
              // User wants to keep swiping - no special action needed
              print("🔄 User wants to continue searching");
            },
          );
        },
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(
            opacity: animation,
            child: child,
          );
        },
      ),
    );
  }

  bool _onSwipe(int previousIndex, int? currentIndex, CardSwiperDirection direction) {
    if (isInCollaborativeMode && currentSession != null) {
      return _onCollaborativeSwipe(previousIndex, currentIndex, direction);
    }
    
    if (previousIndex >= sessionPool.length) return false;
    
    final movie = sessionPool[previousIndex];
    _swipeCount++;
    print("🔢 Swipe count: $_swipeCount");
    
    final isLike = direction == CardSwiperDirection.right;
    
    // All sessions are now mood-based (light learning)
    if (currentSessionContext != null) {
      // Light mood learning that only affects user profile
      MoodBasedLearningEngine.learnFromMoodInteraction(
        widget.currentUser, 
        movie, 
        currentSessionContext!, 
        isLike
      );
      
      if (isLike) {
        likeMovie(movie);
      } else {
        passMovie(movie);
        // Track passed movies to avoid showing again this session
        sessionPassedMovieIds.add(movie.id);
      }
    }
    
    // Check for matches
    if (currentMode == MatchingMode.friend && isLike) {
      _checkForFriendMatch(movie);
    } else if (currentMode == MatchingMode.group && isLike) {
      _checkForGroupMatch(movie, isLike);
    }
    
    return true;
  }

  void _checkForFriendMatch(Movie movie) {
    if (selectedFriend?.likedMovieIds.contains(movie.id) == true) {
      _showMatchDialog(movie);
    }
  }

  void _checkForGroupMatch(Movie movie, bool isLike) {
    if (!isLike) return;
    
    // For now, just check friend mode - group mode matching logic can be expanded later
    if (currentMode == MatchingMode.friend && selectedFriend?.likedMovieIds.contains(movie.id) == true) {
      _showMatchDialog(movie);
    }
    
    // TODO: Implement group matching logic where ALL members need to like the same movie
    if (currentMode == MatchingMode.group) {
      // This is where we'd implement the "everyone likes it = match" logic
      // For now, just use the existing group logic
      groupLikes[widget.currentUser.name]?.add(movie.title);
      final everyone = [widget.currentUser.name, ...selectedGroup.map((f) => f.name)];
      final allLiked = everyone.every((name) => groupLikes[name]?.contains(movie.title) == true);
      if (allLiked) _showMatchDialog(movie);
    }
  }

  // Add visual indicator for pool refresh
  Widget _buildPoolRefreshIndicator() {
    if (!_isRefreshingPool) return const SizedBox.shrink();
    
    return Positioned(
      top: 100.h,
      right: 16.w,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
        decoration: BoxDecoration(
          color: const Color(0xFFE5A00D),
          borderRadius: BorderRadius.circular(20.r),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 12.w,
              height: 12.w,
              child: CircularProgressIndicator(
                strokeWidth: 2.w,
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            ),
            SizedBox(width: 8.w),
            Text(
              'Finding new picks...',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Handle mode change
  void _switchMode(MatchingMode mode) {
  setState(() {
    currentMode = mode;
    _resetToSelection(); // Reset session when switching modes
    
    // Clear selections when switching away from those modes
    if (mode != MatchingMode.friend) {
      selectedFriend = null;
    }
    if (mode != MatchingMode.group) {
      selectedGroup.clear();
      groupLikes.clear();
    }
  });
}

  // Add method to select a friend
  void _selectFriend(UserProfile friend) {
    setState(() {
      selectedFriend = friend;
      currentMode = MatchingMode.friend;
      _generatePersonalizedSession();
    });
  }

  // ADD this new method for generating collaborative sessions with settings:
  Future<void> _generateCollaborativeSessionWithSettings(SessionSettings settings) async {
    if (currentSession == null) return;
    
    final seenMovieIds = <String>{
      ...widget.currentUser.likedMovieIds,
      ...widget.currentUser.passedMovieIds,
      ...currentSessionMovieIds,
    };
    
    List<Movie> collaborativePool = [];
    
    try {
      if (settings.selectedMood != null) {
        // Generate mood-based session with streaming and genre filters
        final context = SessionContext(
          moods: settings.selectedMood!,
          groupMemberIds: currentSession!.participantIds,
        );
        
        collaborativePool = await MoodBasedLearningEngine.generateMoodBasedSession(
          user: widget.currentUser,
          movieDatabase: movieDatabase,
          sessionContext: context,
          seenMovieIds: seenMovieIds,
          sessionPassedMovieIds: sessionPassedMovieIds,
          sessionSize: 30,
          streamingPreferences: settings.streamingPreferences, // 🆕 Pass streaming prefs
          additionalGenres: settings.additionalGenres,         // 🆕 Pass additional genres
        );
      } else {
        // No mood - filter by streaming and genres only
        collaborativePool = await _generateFilteredSession(settings, seenMovieIds);
      }
      
      // Apply consistent seed for all participants
      final seed = currentSession!.sessionId.hashCode;
      collaborativePool.shuffle(Random(seed));
      
      // Update session with new movie pool
      final movieIds = collaborativePool.map((m) => m.id).toList();
      await SessionService.addMoviesToSession(currentSession!.sessionId, movieIds);
      
      // Update local state
      setState(() {
        sessionPool = List.from(collaborativePool);
        currentSessionMovieIds.clear();
        currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
        _isReadyToSwipe = true;
      });
      
      print("🎬 Generated ${sessionPool.length} movies with collaborative settings");
      
    } catch (e) {
      print("❌ Error generating collaborative session: $e");
      // Fallback to basic session
      await _generateCollaborativeSession();
    }
  }

  // ADD this new method for filtered sessions without mood:
  Future<List<Movie>> _generateFilteredSession(SessionSettings settings, Set<String> seenMovieIds) async {
    final filteredMovies = <Movie>[];
    
    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!MoodBasedLearningEngine.meetsQualityThreshold(movie)) continue;
      if (!MoodBasedLearningEngine.isSfwMovie(movie)) continue;
      
      // Apply streaming filter if specified
      if (settings.streamingPreferences.ownedServices.isNotEmpty || settings.streamingPreferences.willingToRent) {
        if (!settings.streamingPreferences.canWatchMovie(movie)) continue;
      }
      
      // Apply genre filter if specified
      if (settings.additionalGenres.isNotEmpty) {
        final hasGenreMatch = movie.genres.any((g) => settings.additionalGenres.contains(g));
        if (!hasGenreMatch) continue;
      }
      
      filteredMovies.add(movie);
    }
    
    // If too few movies, fall back to all movies
    if (filteredMovies.length < 10) {
      print("⚠️ Filter too restrictive, falling back to all movies");
      return movieDatabase.where((movie) => 
        !seenMovieIds.contains(movie.id) && 
        MoodBasedLearningEngine.meetsQualityThreshold(movie)
      ).toList();
    }
    
    return filteredMovies;
  }


  @override
  Widget build(BuildContext context) {
    print("🔍 DEBUG: Building matcher_screen");
    print("   isInCollaborativeMode: $isInCollaborativeMode");
    print("   isWaitingForFriend: $isWaitingForFriend");
    print("   _showMatcherSettings: $_showMatcherSettings");
    print("   _isReadyToSwipe: $_isReadyToSwipe");
    print("   currentMode: $currentMode");
    print("   mounted: $mounted");
    
    // Show matcher settings screen if requested
    if (_showMatcherSettings) {
      print("🔍 DEBUG: Returning matcher settings screen");
      return Scaffold(
        backgroundColor: const Color(0xFF121212),
        body: SafeArea(
          child: Stack(
            children: [
              // Your existing MatcherSettingsScreen code...
              MatcherSettingsScreen(
                hostUser: widget.currentUser,
                selectedFriends: currentMode == MatchingMode.group
                    ? selectedGroup
                    : currentMode == MatchingMode.friend && selectedFriend != null
                        ? [selectedFriend!]
                        : [],
                onSessionCreated: (SwipeSession session) {
                  print("🎉 Session created in matcher_screen: ${session.sessionId}");
                  _startCollaborativeSession(session);
                  setState(() {
                    _showMatcherSettings = false;
                  });
                },
              ),
              // Your existing cancel button...
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text(
          _getAppBarTitle(),
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20.sp,
          ),
        ),
        actions: [],
      ),
      body: Container(
        color: Colors.purple.withValues(alpha: 0.1), // 🔍 DEBUG: Body container
        child: Stack(
          children: [
            Column(
              children: [
                // Mode selection (always visible)
                Container(
                  color: Colors.yellow.withValues(alpha: 0.1), // 🔍 DEBUG: Mode buttons
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 7.w, vertical: 10.h),
                    child: Row(
                      children: [
                        Expanded(
                          child: _buildModeButton(
                            "Solo Mode", 
                            Icons.person,
                            currentMode == MatchingMode.solo,
                            () => _switchMode(MatchingMode.solo),
                          ),
                        ),
                        SizedBox(width: 5.w),
                        Expanded(
                          child: _buildModeButton(
                            "Friend Mode",
                            Icons.people,
                            currentMode == MatchingMode.friend,
                            () => _switchMode(MatchingMode.friend),
                          ),
                        ),
                        SizedBox(width: 5.w),
                        Expanded(
                          child: _buildModeButton(
                            "Group Mode",
                            Icons.groups,
                            currentMode == MatchingMode.group,
                            () => _switchMode(MatchingMode.group),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                
                // Collaborative header
                Container(
                  color: Colors.orange.withValues(alpha: 0.1), // 🔍 DEBUG: Collaborative header
                  child: _buildCollaborativeHeader(),
                ),
                
                // Session controls (when not ready to swipe)
                if (!_isReadyToSwipe) 
                  Container(
                    color: Colors.cyan.withValues(alpha: 0.1), // 🔍 DEBUG: Session controls
                    child: _buildSessionControls(),
                  ),

                // Smart banner and indicators (when ready to swipe)
                if (_isReadyToSwipe) 
                  Container(
                    color: Colors.pink.withValues(alpha: 0.1), // 🔍 DEBUG: Smart banner
                    child: _buildSmartBanner(),
                  ),

                // Main content - THIS IS THE CRITICAL PART
                Expanded(
                  child: Container(
                    color: Colors.green.withValues(alpha: 0.2), // 🔍 DEBUG: Main content container
                    child: Builder(
                      builder: (context) {
                        print("🔍 DEBUG: Main content builder executing");
                        print("   _isLoadingSession: $_isLoadingSession");
                        print("   _isReadyToSwipe: $_isReadyToSwipe");
                        print("   isInCollaborativeMode: $isInCollaborativeMode");
                        
                        if (_isLoadingSession) {
                          print("🔍 DEBUG: Returning _buildLoadingState");
                          return Container(
                            color: Colors.blue.withValues(alpha: 0.3),
                            child: _buildLoadingState(),
                          );
                        } else if (_isReadyToSwipe) {
                          print("🔍 DEBUG: Returning _buildMainContent");
                          return Container(
                            color: Colors.indigo.withValues(alpha: 0.3),
                            child: _buildMainContent(),
                          );
                        } else {
                          print("🔍 DEBUG: Returning _buildWelcomeScreen");
                          return Container(
                            color: Colors.red.withValues(alpha: 0.3), // 🔍 DEBUG: Welcome screen
                            child: _buildWelcomeScreen(),
                          );
                        }
                      },
                    ),
                  ),
                ),
              ],
            ),
            if (_isReadyToSwipe) _buildPoolRefreshIndicator(),
            _buildTutorialOverlay(),
          ],
        ),
      ),
    );
  }
  
  
  
  String _getAppBarTitle() {
    if (isInCollaborativeMode && currentSession != null) {
      final friendNames = currentSession!.participantNames
          .where((name) => name != widget.currentUser.name)
          .toList();
      
      if (friendNames.isNotEmpty) {
        if (friendNames.length == 1) {
          return "Swiping with ${friendNames.first}";
        } else {
          return "Swiping with ${friendNames.join(", ")}";
        }
      } else {
        return "Collaborative Session";
      }
    }
    
    switch (currentMode) {
      case MatchingMode.solo:
        return "Find Your Movies";
      case MatchingMode.friend:
        return selectedFriend != null 
            ? "Swiping with ${selectedFriend!.name}"
            : "Friend Mode";
      case MatchingMode.group:
        if (selectedGroup.isNotEmpty) {
          if (selectedGroup.length == 1) {
            return "Swiping with ${selectedGroup.first.name}";
          } else {
            return "Group of ${selectedGroup.length + 1}";
          }
        } else {
          return "Group Mode";
        }
    }
  }

Widget _buildSessionControls() {
  // Don't show session controls if we're in collaborative mode
  if (isInCollaborativeMode) {
    return const SizedBox.shrink();
  }
  
  return Container(
    margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
    child: Column(
      children: [
        // All Modes: Just show mood selection
        SizedBox(
          width: double.infinity,
          height: 56.h,
          child: ElevatedButton.icon(
            onPressed: _canChooseMood() ? _showMatcherSettingsScreen : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: _canChooseMood() ? const Color(0xFFE5A00D) : Colors.grey[700],
              disabledBackgroundColor: Colors.grey[700],
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16.r),
              ),
            ),
            icon: Icon(
              Icons.mood,
              color: _canChooseMood() ? Colors.black : Colors.grey[400],
              size: 24.sp,
            ),
            label: Text(
              _getMoodButtonText(),
              style: TextStyle(
                color: _canChooseMood() ? Colors.black : Colors.grey[400],
                fontSize: 16.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        
        // Friend Mode: Show selected friend info
        if (currentMode == MatchingMode.friend && selectedFriend != null) ...[
          SizedBox(height: 16.h),
          Container(
            padding: EdgeInsets.all(16.r),
            decoration: BoxDecoration(
              color: const Color(0xFF2A2A2A),
              borderRadius: BorderRadius.circular(12.r),
              border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.3)),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: const Color(0xFFE5A00D),
                  child: Text(selectedFriend!.name[0].toUpperCase()),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: Text(
                    "Ready to match with ${selectedFriend!.name}",
                    style: TextStyle(color: Colors.white, fontSize: 14.sp),
                  ),
                ),
              ],
            ),
          ),
        ],

        // Friend Mode: Show invite options if no friend selected
        if (currentMode == MatchingMode.friend && selectedFriend == null) ...[
          SizedBox(height: 16.h),
          
          // Main invite button
          SizedBox(
            width: double.infinity,
            height: 56.h,
            child: ElevatedButton.icon(
              onPressed: () => _showFriendSelector(),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.r)),
              ),
              icon: Icon(Icons.person_add, color: Colors.black, size: 24.sp),
              label: Text("Invite Friend", 
                style: TextStyle(color: Colors.black, fontSize: 16.sp, fontWeight: FontWeight.bold)),
            ),
          ),
          
          SizedBox(height: 12.h),
          
          // Session code button for TV app
          SizedBox(
            width: double.infinity,
            height: 44.h,
            child: OutlinedButton.icon(
              onPressed: () => _createSessionWithCode(),
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: Colors.grey[600]!, width: 1.w),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
              ),
              icon: Icon(Icons.tv, color: Colors.grey[400], size: 20.sp),
              label: Text("Create Session Code (TV)", 
                style: TextStyle(color: Colors.grey[400], fontSize: 14.sp, fontWeight: FontWeight.w500)),
            ),
          ),
        ],

        // Group Mode: Show group options
        if (currentMode == MatchingMode.group) ...[
          if (selectedGroup.isNotEmpty) ...[
            SizedBox(height: 16.h),
            Container(
              padding: EdgeInsets.all(12.r),
              decoration: BoxDecoration(
                color: const Color(0xFFE5A00D).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.people, color: const Color(0xFFE5A00D), size: 16.sp),
                  SizedBox(width: 8.w),
                  Expanded(
                    child: Text(
                      "Group: You + ${selectedGroup.map((f) => f.name).join(', ')}",
                      style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 12.sp, fontWeight: FontWeight.w600),
                    ),
                  ),
                  GestureDetector(
                    onTap: _showGroupSelectionDialog,
                    child: Icon(Icons.edit, color: const Color(0xFFE5A00D), size: 16.sp),
                  ),
                ],
              ),
            ),
          ] else ...[
            SizedBox(height: 16.h),
            SizedBox(
              width: double.infinity,
              height: 48.h,
              child: OutlinedButton.icon(
                onPressed: _showGroupSelectionDialog,
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: const Color(0xFFE5A00D), width: 2.w),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.r)),
                ),
                icon: Icon(Icons.groups, color: const Color(0xFFE5A00D), size: 20.sp),
                label: Text("Select Group Members", 
                  style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 14.sp, fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ],
      ],
    ),
  );
}

String _getMoodButtonText() {
  switch (currentMode) {
    case MatchingMode.solo:
      return "Choose Your Mood";
    case MatchingMode.friend:
      return selectedFriend != null ? "Choose Mood to Match" : "Select Friend First";
    case MatchingMode.group:
      return selectedGroup.isNotEmpty ? "Choose Group Mood" : "Select Group First";
  }
}

  // Add these new methods for quick session creation
  Future<void> _createSessionWithCode() async {
    setState(() => _isLoadingSession = true);
    
    try {
      final session = await SessionService.createSession(
        hostName: widget.currentUser.name,
        inviteType: InvitationType.code,
      );
      
      if (mounted) {
        _showSessionCodeDialog(session.sessionCode!);
        _startCollaborativeSession(session);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to create session: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoadingSession = false);
    }
  }

  void _showFriendSelector() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.9,
        maxChildSize: 0.95,
        minChildSize: 0.5,
        builder: (context, scrollController) => FriendInviteDialog(
          currentUser: widget.currentUser,
          availableFriends: widget.availableFriends,
          onSessionCreated: _startCollaborativeSession,
        ),
      ),
    );
  }

  void _showSessionCodeDialog(String sessionCode) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "Session Created! 🎉",
          style: TextStyle(color: Colors.white, fontSize: 18.sp),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Share this code with your friend:",
              style: TextStyle(color: Colors.grey[300], fontSize: 14.sp),
            ),
            SizedBox(height: 16.h),
            
            Container(
              padding: EdgeInsets.all(16.r),
              decoration: BoxDecoration(
                color: const Color(0xFFE5A00D).withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(color: const Color(0xFFE5A00D)),
              ),
              child: Text(
                sessionCode,
                style: TextStyle(
                  color: const Color(0xFFE5A00D),
                  fontSize: 32.sp,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 8.w,
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              "Got it!",
              style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 14.sp),
            ),
          ),
        ],
      ),
    );
  }

// NEW: Welcome screen for when no session is active
  Widget _buildWelcomeScreen() {
    print("🔍 DEBUG: _buildWelcomeScreen called");
    print("   isInCollaborativeMode: $isInCollaborativeMode");
    
    // Don't show welcome screen if we're in collaborative mode
    if (isInCollaborativeMode) {
      print("🔍 DEBUG: Calling _buildCollaborativeWaitingScreen from _buildWelcomeScreen");
      return Container(
        color: Colors.teal.withValues(alpha: 0.3), // 🔍 DEBUG: Wrapper for collaborative
        child: _buildCollaborativeWaitingScreen(),
      );
    }
    
    print("🔍 DEBUG: Showing normal welcome screen");
    return Container(
      color: Colors.amber.withValues(alpha: 0.3), // 🔍 DEBUG: Normal welcome screen
      child: SingleChildScrollView(
        padding: EdgeInsets.all(32.r),
        child: ConstrainedBox(
          constraints: BoxConstraints(
            minHeight: MediaQuery.of(context).size.height * 0.4,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Mode-specific icon and message
              Icon(
                _getModeIcon(),
                size: 80.sp,
                color: const Color(0xFFE5A00D),
              ),
              SizedBox(height: 24.h),
              
              Text(
                _getWelcomeTitle(),
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24.sp,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 16.h),
              
              Text(
                _getWelcomeSubtitle(),
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 16.sp,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }


  // Helper methods for welcome screen
  IconData _getModeIcon() {
    switch (currentMode) {
      case MatchingMode.solo:
        return Icons.person;
      case MatchingMode.friend:
        return Icons.people;
      case MatchingMode.group:
        return Icons.groups;
    }
  }

  String _getWelcomeTitle() {
    switch (currentMode) {
      case MatchingMode.solo:
        return "Ready to find your next movie?";
      case MatchingMode.friend:
        return selectedFriend != null 
            ? "Ready to find movies with ${selectedFriend!.name}?"
            : "Select a friend to start matching!";
      case MatchingMode.group:
        return selectedGroup.isNotEmpty
            ? "Ready to find movies for your group?"
            : "Select group members to start!";
    }
  }

  String _getWelcomeSubtitle() {
    switch (currentMode) {
      case MatchingMode.solo:
        return "Pick a mood and start swiping to find movies that match how you're feeling tonight.";
      case MatchingMode.friend:
        return selectedFriend != null 
            ? "Choose a mood and find movies you'll both love."
            : "Choose a friend from your list to start finding movies you'll both enjoy.";
      case MatchingMode.group:
        return selectedGroup.isNotEmpty
            ? "Choose a mood and find movies everyone will enjoy."
            : "Add friends to create a group and find movies everyone will love.";
    }
  }

  Widget _buildModeButton(String title, IconData icon, bool isSelected, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8.r),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 8.w),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFE5A00D) : const Color(0xFF1F1F1F),
          borderRadius: BorderRadius.circular(8.r),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: Colors.white,
              size: 16.sp,
            ),
            SizedBox(width: 4.w),
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 13.sp,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Add friend selection dialog
  void _showFriendSelectionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "Select a Friend", 
          style: TextStyle(color: Colors.white, fontSize: 18.sp)
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: widget.availableFriends.isEmpty
              ? Center(
                  child: Text(
                    "You don't have any friends yet. Add some from the Friends tab!",
                    style: TextStyle(color: Colors.white70, fontSize: 15.sp),
                  ),
                )
              : ListView.builder(
                  shrinkWrap: true,
                  itemCount: widget.availableFriends.length,
                  itemBuilder: (context, index) {
                    final friend = widget.availableFriends[index];
                    final isSelected = selectedFriend?.name == friend.name;
                    
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.grey[800],
                        radius: 20.r,
                        child: Text(
                          friend.name.isNotEmpty ? friend.name[0].toUpperCase() : "?",
                          style: TextStyle(color: Colors.white, fontSize: 16.sp),
                        ),
                      ),
                      title: Text(
                        friend.name,
                        style: TextStyle(color: Colors.white, fontSize: 16.sp),
                      ),
                      subtitle: Text(
                        "Genres: ${friend.preferredGenres.take(2).join(", ")}${friend.preferredGenres.length > 2 ? "..." : ""}",
                        style: TextStyle(color: Colors.white54, fontSize: 14.sp),
                      ),
                      trailing: isSelected
                          ? Icon(Icons.check_circle, color: const Color(0xFFE5A00D), size: 24.sp)
                          : null,
                      selected: isSelected,
                      selectedTileColor: Colors.black26,
                      onTap: () {
                        Navigator.pop(context);
                        _selectFriend(friend);
                      },
                    );
                  },
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel", 
              style: TextStyle(color: Colors.white70, fontSize: 15.sp)
            ),
          ),
        ],
      ),
    );
  }

  // Add group selection dialog
  void _showGroupSelectionDialog() {
    final tempSelected = Set<String>.from(selectedGroup.map((f) => f.name));

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "Select Group Members", 
          style: TextStyle(color: Colors.white, fontSize: 18.sp)
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: widget.availableFriends.length,
            itemBuilder: (context, index) {
              final friend = widget.availableFriends[index];
              return CheckboxListTile(
                title: Text(
                  friend.name, 
                  style: TextStyle(color: Colors.white, fontSize: 16.sp)
                ),
                value: tempSelected.contains(friend.name),
                activeColor: const Color(0xFFE5A00D),
                checkColor: Colors.black,
                onChanged: (selected) {
                  setState(() {
                    if (selected == true) {
                      tempSelected.add(friend.name);
                    } else {
                      tempSelected.remove(friend.name);
                    }
                  });
                },
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel", 
              style: TextStyle(color: Colors.white70, fontSize: 15.sp)
            ),
          ),
          ElevatedButton(
            onPressed: () {
              final group = widget.availableFriends.where((f) => tempSelected.contains(f.name)).toList();
              setState(() {
                selectedGroup = group;
                _initializeApp();
              });
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE5A00D)),
            child: Text(
              "Start Group Session", 
              style: TextStyle(color: Colors.black, fontSize: 15.sp)
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMainContent() {
  print("🔍 DEBUG: _buildMainContent called");
  print("🔍 DEBUG: _isReadyToSwipe: $_isReadyToSwipe");
  print("🔍 DEBUG: sessionPool.length: ${sessionPool.length}");
  print("🔍 DEBUG: currentMode: $currentMode");
  print("🔍 DEBUG: selectedFriend: $selectedFriend");
  
  if (currentMode == MatchingMode.friend && selectedFriend == null && !isInCollaborativeMode) {
    print("🔍 DEBUG: Returning _buildSelectFriendScreen");
    return _buildSelectFriendScreen();
  }

  if (sessionPool.isEmpty) {
    print("🔍 DEBUG: sessionPool is empty, returning _buildEmptyState");
    return _buildEmptyState();
  }

  print("🔍 DEBUG: Returning movie swiper");
  // ... rest of your existing code


    return Padding(
      padding: EdgeInsets.all(8.r),
      child: Column(
        children: [
          // Full-height swiper
          Expanded(
            child: CardSwiper(
              cardsCount: sessionPool.length,
              numberOfCardsDisplayed: 1,
              onSwipe: _onSwipe,
              cardBuilder: (context, index, percentX, percentY) {
                if (index >= sessionPool.length) return const SizedBox.shrink();

                final movie = sessionPool[index];
                
                // Fixed type casting: Convert num to double explicitly
                final leftIntensity = percentX < 0 ? (-percentX.toDouble()).clamp(0.0, 1.0) : 0.0;
                final rightIntensity = percentX > 0 ? percentX.toDouble().clamp(0.0, 1.0) : 0.0;
                
                return Container(
                  margin: EdgeInsets.all(4.r), // ✅ REDUCED margin for taller cards
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16.r),
                    border: Border.all(color: Colors.yellow.shade800, width: 2.w),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14.r),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        // Background color
                        Container(color: const Color(0xFF1A1A1A)),
                        
                        // Movie poster layout - OPTIMIZED FOR HEIGHT
                        Column(
                          children: [
                            // ✅ TALLER poster section
                            Expanded(
                              flex: 12, // ✅ INCREASED flex for much taller cards
                              child: Container(
                                width: double.infinity,
                                child: Image.network(
                                  movie.posterUrl,
                                  fit: BoxFit.contain, // ✅ CONTAIN to show full poster without cropping
                                  width: double.infinity,
                                  errorBuilder: (context, error, stackTrace) {
                                    return Container(
                                      color: Colors.grey[800],
                                      child: Icon(
                                        Icons.broken_image, 
                                        size: 100.sp, 
                                        color: Colors.white24
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                            
                            // ✅ COMPACT bottom info section
                            Container(
                              width: double.infinity,
                              padding: EdgeInsets.symmetric(vertical: 6.h, horizontal: 12.w), // ✅ REDUCED padding
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  // Title
                                  Text(
                                    movie.title,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 15.sp, // ✅ SLIGHTLY reduced for space
                                      fontWeight: FontWeight.bold,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  
                                  SizedBox(height: 6.h), // ✅ REDUCED spacing
                                  
                                  // ✅ COMPACT view more button
                                  Container(
                                    height: 32.h, // ✅ FIXED height for compactness
                                    child: ElevatedButton(
                                      onPressed: () => _showMovieDetailSheet(context, movie),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: const Color(0xFFE5A00D),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(16.r),
                                        ),
                                        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                                      ),
                                      child: Text(
                                        "View more",
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13.sp, // ✅ COMPACT text
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),

                        // Left indicator overlay with gradient
                        if (leftIntensity > 0)
                          Positioned.fill(
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                  colors: [
                                    Colors.red.withAlpha((179 * leftIntensity).toInt()),
                                    Colors.red.withAlpha(0),
                                  ],
                                  stops: const [0.0, 0.3],
                                ),
                              ),
                            ),
                          ),
                          
                        // Right indicator overlay with gradient
                        if (rightIntensity > 0)
                          Positioned.fill(
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.centerRight,
                                  end: Alignment.centerLeft,
                                  colors: [
                                    Colors.green.withAlpha((179 * rightIntensity).toInt()),
                                    Colors.green.withAlpha(0),
                                  ],
                                  stops: const [0.0, 0.3],
                                ),
                              ),
                            ),
                          ),
                        
                        // Tap area for movie details
                        Positioned.fill(
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () => _showMovieDetailSheet(context, movie),
                              splashColor: Colors.white.withAlpha(26),
                              highlightColor: Colors.transparent,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // ✅ KEEP: Swipe instruction text (essential for UX)
          Padding(
            padding: EdgeInsets.only(top: 8.h), // ✅ COMPACT spacing
            child: Text(
              "Swipe left to pass, right to like",
              style: TextStyle(color: Colors.grey[400], fontSize: 13.sp), // ✅ SLIGHTLY smaller
            ),
          ),
          SizedBox(height: 6.h), // ✅ COMPACT bottom spacing
        ],
      ),
    );
  }

  void _showMovieDetailSheet(BuildContext context, Movie movie) {
  final bool isInFavorites = widget.currentUser.likedMovies.contains(movie);

  showMovieDetails(
    context: context,
    movie: movie,
    currentUser: widget.currentUser,
    onAddToFavorites: isInFavorites ? null : (Movie movie) {
      setState(() {
        widget.currentUser.likedMovies.add(movie);
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${movie.title} added to favorites'),
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 2),
        ),
      );
    },
    onRemoveFromFavorites: isInFavorites ? (Movie movie) {
      setState(() {
        widget.currentUser.likedMovies.remove(movie);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${movie.title} removed from favorites'),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 2),
        ),
      );
    } : null,
    onMarkAsWatched: currentMode == MatchingMode.friend || currentMode == MatchingMode.group
        ? (Movie movie) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('${movie.title} marked as watched'),
                backgroundColor: Colors.green,
                duration: const Duration(seconds: 2),
              ),
            );
          }
        : null,
    isInFavorites: isInFavorites,
  );
}

  Widget _buildSelectFriendScreen() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.people_outline,
              size: 80.sp,
              color: Colors.white30,
            ),
            SizedBox(height: 16.h),
            Text(
              "Choose a friend to start finding movies you both want to watch!",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16.sp,
              ),
            ),
            SizedBox(height: 32.h),
            ElevatedButton.icon(
              onPressed: () {
                _showFriendSelectionDialog(); // Show friend selection dialog
              },
              icon: Icon(Icons.people, color: Colors.white, size: 20.sp),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 14.h),
                minimumSize: Size(200.w, 50.h),
              ),
              label: Text(
                "Select a Friend",
                style: TextStyle(color: Colors.white, fontSize: 16.sp),
              ),
            ),
            SizedBox(height: 16.h),
            Text(
              "OR",
              style: TextStyle(
                color: Colors.white54,
                fontSize: 14.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.h),
            OutlinedButton.icon(
              onPressed: () {
                _switchMode(MatchingMode.solo);
              },
              icon: Icon(Icons.movie, color: const Color(0xFFE5A00D), size: 20.sp),
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: const Color(0xFFE5A00D), width: 1.w),
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 14.h),
                minimumSize: Size(200.w, 50.h),
              ),
              label: Text(
                "Start Solo Swiping",
                style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 16.sp),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.movie_filter,
              size: 80.sp,
              color: Colors.grey,
            ),
            SizedBox(height: 24.h),
            Text(
              currentMode == MatchingMode.solo 
                  ? "No movies to swipe yet!" 
                  : "No movies to match yet!",
              style: TextStyle(
                color: Colors.white,
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.h),
            Text(
              currentMode == MatchingMode.friend && selectedFriend != null
              ? "You and ${selectedFriend!.name} need to like some movies first."
              : "You need to like some movies first.",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16.sp,
              ),
            ),
            SizedBox(height: 32.h),
            ElevatedButton.icon(
              onPressed: () async {
                final newMovies = await TMDBApi.getPopularMovies(); // or a different TMDB call
                setState(() {
                  sessionPool = List<Movie>.from(newMovies);
                  if (isInCollaborativeMode && currentSession != null) {
                    sessionPool.shuffle(Random(currentSession!.sessionId.hashCode));
                  } else {
                    sessionPool.shuffle(); // Normal random shuffle
                  }
                  if (sessionPool.length > 20) {
                    sessionPool = sessionPool.sublist(0, 20);
                  }
                });
              },
              icon: Icon(Icons.refresh, color: Colors.white, size: 20.sp),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
              ),
              label: Text(
                "Load Sample Movies", 
                style: TextStyle(color: Colors.white, fontSize: 16.sp)
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTutorialOverlay() {
    final tutorialPages = [
      {
        'title': 'Solo Mode',
        'description': 'Swipe right on movies you like, left on ones you don\'t. This builds your taste profile for better matching with friends later! The more you swipe, the better we can suggest movies you\'ll enjoy.',
        'icon': Icons.person,
        'color': Colors.orange,
      },
      {
        'title': 'Friend Mode',
        'description': 'Swipe right on movies you like, left on ones you don\'t. When both you and your friend like the same movie, it\'s a match! The more you swipe, the better we can suggest movies you\'ll both enjoy.',
        'icon': Icons.people,
        'color': Colors.blue,
      },
      {
        'title': 'Group Mode',
        'description': 'Swipe right on movies with your group. When EVERYONE likes the same film, it\'s a match! The app learns each member\'s preferences to build the perfect shared session.',
        'icon': Icons.groups,
        'color': Colors.purple,
      },
    ];

    return _showTutorial
        ? Container(
            color: Colors.black.withAlpha((255 * 0.85).round()),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Page indicator
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    tutorialPages.length,
                    (index) => Container(
                      margin: EdgeInsets.symmetric(horizontal: 4.w),
                      width: 10.w,
                      height: 10.h,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _tutorialPage == index
                            ? const Color(0xFFE5A00D)
                            : Colors.grey,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 24.h),
                
                // Swipeable content
                Expanded(
                  child: PageView.builder(
                    controller: _tutorialPageController,
                    itemCount: tutorialPages.length,
                    onPageChanged: (index) {
                      setState(() {
                        _tutorialPage = index;
                      });
                    },
                    itemBuilder: (context, index) {
                      final page = tutorialPages[index];
                      return Padding(
                        padding: EdgeInsets.symmetric(horizontal: 32.w),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // Icon
                            Container(
                              padding: EdgeInsets.all(24.r),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: page['color'] as Color,
                                boxShadow: [
                                  BoxShadow(
                                    color: (page['color'] as Color).withAlpha((255 * 0.3).round()),
                                    blurRadius: 20.r,
                                    spreadRadius: 5.r,
                                  ),
                                ],
                              ),
                              child: Icon(
                                page['icon'] as IconData,
                                color: Colors.white,
                                size: 64.sp,
                              ),
                            ),
                            SizedBox(height: 40.h),
                            
                            // Title
                            Text(
                              page['title'] as String,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 28.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 24.h),
                            
                            // Description
                            Text(
                              page['description'] as String,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 16.sp,
                                height: 1.5,
                              ),
                            ),
                            
                            // Swipe hint
                            if (index < tutorialPages.length - 1)
                              Padding(
                                padding: EdgeInsets.only(top: 40.h),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      "Swipe right for next",
                                      style: TextStyle(
                                        color: Colors.white54,
                                        fontSize: 14.sp,
                                      ),
                                    ),
                                    SizedBox(width: 8.w),
                                    Icon(
                                      Icons.arrow_forward,
                                      color: Colors.white54,
                                      size: 16.sp,
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: 32.h),
                
                // Got it button
                ElevatedButton(
                  onPressed: () async {
                    await _markTutorialSeen();
                    setState(() {
                      _showTutorial = false;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE5A00D),
                    padding: EdgeInsets.symmetric(
                      horizontal: 32.w,
                      vertical: 12.h,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.r),
                    ),
                  ),
                  child: Text(
                    "Got it!",
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 16.sp,
                    ),
                  ),
                ),
                SizedBox(height: 40.h),
              ],
            ),
          )
        : const SizedBox.shrink(); // Return empty widget when tutorial is not shown
  }

  void _startCollaborativeSession(SwipeSession session) {
    print("🔍 DEBUG: _startCollaborativeSession called with session: ${session.sessionId}");
    print("🔍 DEBUG: Widget mounted: $mounted");
    print("🔍 DEBUG: Current state before setState:");
    print("   isInCollaborativeMode: $isInCollaborativeMode");
    print("   _showMatcherSettings: $_showMatcherSettings");
    print("   currentMode: $currentMode");

    setState(() {
      currentSession = session;
      isWaitingForFriend = session.status == SessionStatus.created;
      isInCollaborativeMode = true;
      currentMode = MatchingMode.friend;
      _isReadyToSwipe = false;
      _showMatcherSettings = false; // ✅ ADD THIS LINE - important!
      selectedMoods.clear();
      sessionPool.clear();
    });

    print("🔍 DEBUG: setState completed. New state:");
    print("   isInCollaborativeMode: $isInCollaborativeMode");
    print("   _showMatcherSettings: $_showMatcherSettings");
    print("   currentMode: $currentMode");
    print("   isWaitingForFriend: $isWaitingForFriend");

    sessionSubscription?.cancel();
    sessionSubscription = SessionService.watchSession(session.sessionId).listen(
      (updatedSession) {
        print("🔍 DEBUG: Session update received: ${updatedSession.status}");
        
        final wasActive = currentSession?.status == SessionStatus.active;
        final isNowActive = updatedSession.status == SessionStatus.active;
        
        // Handle new matches
        final previousMatches = currentSession?.matches ?? [];
        final newMatches = updatedSession.matches
            .where((movieId) => !previousMatches.contains(movieId))
            .toList();
        
        setState(() {
          currentSession = updatedSession;
          isWaitingForFriend = updatedSession.status == SessionStatus.created;
        });
        
        // Generate movies when needed
        final shouldGenerateMovies = (!wasActive && isNowActive && sessionPool.isEmpty) ||
                                    (updatedSession.moviePool.isNotEmpty && sessionPool.isEmpty);
        
        if (shouldGenerateMovies) {
          _generateCollaborativeSession();
        }
        
        // Process new matches
        for (final movieId in newMatches) {
          _handleSessionMatch(movieId);
        }
      },
      onError: (error) {
        print("❌ ERROR in session stream: $error");
        _endCollaborativeSession();
      },
    );
    
    // 🆕 NEW: Start watching for settings change requests
    _watchSettingsChangeRequests();
    
    print("✅ DEBUG: _startCollaborativeSession completed");
  }



  void _handleSessionMatch(String movieId) {    
    if (currentSession == null) {
      return;
    }
      
    // Find the movie object from our session pool
    Movie? matchedMovie;
    try {
      matchedMovie = sessionPool.firstWhere((movie) => movie.id == movieId);
    } catch (e) {
      // If movie not found in current pool, try to find it in the database
      try {
        matchedMovie = movieDatabase.firstWhere((movie) => movie.id == movieId);
      } catch (e2) {
        // Create a placeholder movie as last resort
        matchedMovie = Movie(
          id: movieId,
          title: "Matched Movie",
          posterUrl: "",
          overview: "You both liked this movie!",
          cast: [],
          genres: [],
          tags: [],
          releaseDate: DateTime.now().toIso8601String().split('T')[0],
        );
      }
    }
        
    // Get friend names
    final friendNames = currentSession!.participantNames
        .where((name) => name != widget.currentUser.name)
        .toList();
    
    print("👥 Friend names for match: $friendNames");
    
    // Show the match screen
    try {
      Navigator.push(
        context,
        PageRouteBuilder(
          opaque: false,
          barrierDismissible: false,
          pageBuilder: (context, animation, secondaryAnimation) {
            print("🎬 MatchCelebrationScreen widget created successfully");
            return MatchCelebrationScreen(  // ✅ FIXED: Use new screen
              movie: matchedMovie!,  // ✅ FIXED: Add ! to make non-nullable
              currentUser: widget.currentUser,  // ✅ FIXED: Use widget.currentUser
              matchedName: friendNames.isNotEmpty ? friendNames.join(", ") : "Your friend",
              allMatchedUsers: currentSession?.participantIds,  // ✅ FIXED: Use real variable
              onContinueSearching: () {
                // User wants to keep swiping in collaborative mode
                print("🔄 User wants to continue collaborative searching");
              },
            );
          },
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            return FadeTransition(
              opacity: animation,
              child: child,
            );
          },
        ),
      );
      print("✅ Match screen navigation completed");
    } catch (e) {
      print("❌ ERROR showing match screen: $e");
    }
  }

  // Add this debug version to your _generateCollaborativeSession method in matcher_screen.dart:

  Future<void> _generateCollaborativeSession() async {
    print("🔍 DEBUG: _generateCollaborativeSession called");
    
    if (currentSession == null) {
      print("❌ DEBUG: currentSession is null, returning");
      return;
    }

    // Check if we have stored session settings to use
    if (currentSessionSettings != null) {
      print("🔍 DEBUG: Using stored session settings");
      await _generateCollaborativeSessionWithSettings(currentSessionSettings!);
      return;
    }

    // Use existing logic for mood-only sessions...
    final seed = currentSession!.sessionId.hashCode;
    print("🎲 Using fixed seed $seed for consistent shuffle across all participants");
    
    final isHost = currentSession!.hostId == widget.currentUser.uid;
    print("🔍 DEBUG: isHost: $isHost");

    setState(() {
      _isLoadingSession = true;
    });

  try {
    // Check if session already has a mood set by the host
    if (currentSession!.hasMoodSelected) {
      print("🎭 Session already has mood set by host: ${currentSession!.selectedMoodName}");
      
      // Find the corresponding CurrentMood enum value
      CurrentMood? sessionMood;
        try {
          sessionMood = CurrentMood.values.firstWhere(
            (mood) => mood.toString().split('.').last == currentSession!.selectedMoodId
          );
        } catch (e) {
          print("⚠️ Could not find matching mood enum for: ${currentSession!.selectedMoodId}");
          // Use the first available mood as fallback (since you removed perfectForUs)
          sessionMood = CurrentMood.values.first;
        }
      
      // Auto-apply the host's mood
      setState(() {
        selectedMoods = [sessionMood!];
        _showMatcherSettings = true;
      });
      
      print("✅ Applied host's mood: ${sessionMood.displayName}");
      
    } else {
      // No mood set yet - show mood selection
      if (selectedMoods.isEmpty) {
        print("🔍 DEBUG: No mood set, showing mood selection");
        setState(() {
          _showMatcherSettings = true;
          _isLoadingSession = false;
        });
        return;
      }
    }

    List<Movie> collaborativePool = [];

    if (isHost) {
      print("👑 HOST: Generating movie pool for session");
      
      // Check if movies already exist in session
      if (currentSession!.moviePool.isNotEmpty) {
        print("🔄 HOST: Movies already exist in session, loading them instead of regenerating");
        collaborativePool = _loadMoviesFromIds(currentSession!.moviePool);
      } else {
        // Generate new movies
        collaborativePool = await _generateMoviesForSession(seed);
        
        // Save ONLY movie IDs to Firestore
        final movieIds = collaborativePool.map((m) => m.id).toList();
        await SessionService.startSession(
          currentSession!.sessionId,
          selectedMoodIds: selectedMoods.map((m) => m.toString().split('.').last).toList(),
          moviePool: movieIds, // Only IDs saved to Firestore
        );
        print("✅ HOST: Saved ${movieIds.length} movie IDs to Firestore");
      }

    } else {
      print("👥 FRIEND: Loading movie pool from host");
      
      if (currentSession!.moviePool.isNotEmpty) {
        print("📥 FRIEND: Found ${currentSession!.moviePool.length} movie IDs in session");
        collaborativePool = _loadMoviesFromIds(currentSession!.moviePool);
        print("✅ FRIEND: Loaded ${collaborativePool.length} movies from host's pool");
      } else {
        print("⚠️ FRIEND: No movie pool in session yet, using sample movies");
      }
    }

    // Update state
    setState(() {
      sessionPool = List.from(collaborativePool);
      currentSessionMovieIds.clear();
      currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
      _isReadyToSwipe = true;
    });
    
    print("🔍 DEBUG: Set _isReadyToSwipe = true, sessionPool.length = ${sessionPool.length}");
    if (sessionPool.isNotEmpty) {
      print("🎬 First movie: ${sessionPool.first.title}");
    }

  } catch (e) {
    print("❌ ERROR in _generateCollaborativeSession: $e");
    
  } finally {
    setState(() {
      _isLoadingSession = false;
    });
  }
}

void _watchSettingsChangeRequests() {
  if (currentSession == null) return;
  
  SessionService.watchSettingsChangeRequests(currentSession!.sessionId).listen(
    (requests) {
      for (final request in requests) {
        _showSettingsChangeRequestDialog(request);
      }
    },
  );
}

// ADD this method to show settings change request dialog:
void _showSettingsChangeRequestDialog(Map<String, dynamic> request) {
  final fromUserName = request['fromUserName'] ?? 'Someone';
  final previewText = request['previewText'] ?? 'Update session settings';
  
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (context) => AlertDialog(
      backgroundColor: const Color(0xFF1F1F1F),
      title: Row(
        children: [
          Icon(Icons.settings, color: const Color(0xFFE5A00D), size: 24.sp),
          SizedBox(width: 12.w),
          Expanded(
            child: Text(
              'Settings Change Request',
              style: TextStyle(color: Colors.white, fontSize: 18.sp),
            ),
          ),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$fromUserName wants to update the session:',
            style: TextStyle(color: Colors.grey[300], fontSize: 14.sp),
          ),
          SizedBox(height: 12.h),
          
          Container(
            padding: EdgeInsets.all(12.r),
            decoration: BoxDecoration(
              color: const Color(0xFFE5A00D).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8.r),
              border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.3)),
            ),
            child: Text(
              previewText,
              style: TextStyle(
                color: const Color(0xFFE5A00D),
                fontSize: 14.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          
          SizedBox(height: 12.h),
          
          Text(
            'Do you want to apply these changes?',
            style: TextStyle(color: Colors.grey[400], fontSize: 12.sp),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.pop(context);
            SessionService.respondToSettingsChangeRequest(
              sessionId: currentSession!.sessionId,
              requestId: request['id'],
              userId: widget.currentUser.uid,
              accepted: false,
            );
          },
          child: Text(
            'Decline',
            style: TextStyle(color: Colors.grey[400]),
          ),
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
            SessionService.respondToSettingsChangeRequest(
              sessionId: currentSession!.sessionId,
              requestId: request['id'],
              userId: widget.currentUser.uid,
              accepted: true,
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFE5A00D),
          ),
          child: Text(
            'Accept',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    ),
  );
}

// 2. ADD this new helper method to generate movies:
Future<List<Movie>> _generateMoviesForSession(int seed) async {
  final seenMovieIds = <String>{
    ...widget.currentUser.likedMovieIds,
    ...widget.currentUser.passedMovieIds,
    ...currentSessionMovieIds,
  };

  List<Movie> movies;

  try {
    // Always use mood-based generation (no more Perfect features)
    final context = SessionContext(
      moods: selectedMoods.first,
      groupMemberIds: currentSession!.participantIds,
    );
    
    movies = await MoodBasedLearningEngine.generateMoodBasedSession(
      user: widget.currentUser,
      movieDatabase: movieDatabase,
      sessionContext: context,
      seenMovieIds: seenMovieIds,
      sessionPassedMovieIds: sessionPassedMovieIds,
      sessionSize: 30,
    );

    // Apply consistent shuffle using session seed
    movies.shuffle(Random(seed));
    print("🎬 HOST: Generated ${movies.length} mood-based movies with consistent shuffle");
    
    return movies;

  } catch (e) {
    print("❌ Error generating movies: $e");
    final fallback = List<Movie>.from(movieDatabase);
    fallback.shuffle(Random(seed));
    return fallback;
  }
}

// 3. ADD this helper method to convert movie IDs to Movie objects:
List<Movie> _loadMoviesFromIds(List<String> movieIds) {
  final movies = <Movie>[];
  
  for (final id in movieIds) {
    try {
      final movie = movieDatabase.firstWhere((m) => m.id == id);
      movies.add(movie);
    } catch (e) {
      print("⚠️ Could not find movie with ID: $id");
    }
  }
  
  print("✅ Converted ${movies.length}/${movieIds.length} IDs to Movie objects");
  return movies;
}

  // 🆕 Handle collaborative swipe
  bool _onCollaborativeSwipe(int previousIndex, int? currentIndex, CardSwiperDirection direction) {
    if (currentSession == null || previousIndex >= sessionPool.length) return false;

    final movie = sessionPool[previousIndex];
    final isLike = direction == CardSwiperDirection.right;

    print("🔄 Collaborative swipe: ${movie.title} (${isLike ? 'LIKE' : 'PASS'})");

    // ✅ NEW: Record swipe in Firebase (includes automatic match detection)
    SessionService.recordSwipe(
      sessionId: currentSession!.sessionId,
      movieId: movie.id,
      isLike: isLike,
    );

    // Apply local learning and update state
    if (isLike) {
      likeMovie(movie);
    } else {
      passMovie(movie);
      sessionPassedMovieIds.add(movie.id);
    }

    return true;
  }

  // 🆕 End collaborative session
  void _endCollaborativeSession() {
    if (currentSession != null) {
      SessionService.endSession(currentSession!.sessionId);
    }
    
    sessionSubscription?.cancel();
    
    setState(() {
      currentSession = null;
      isWaitingForFriend = false;
      isInCollaborativeMode = false;
      currentMode = MatchingMode.solo; // Return to solo mode
      _resetToSelection();
    });
  }

    // 🆕 Build collaborative mode UI elements
  Widget _buildCollaborativeHeader() {
    if (!isInCollaborativeMode || currentSession == null) {
      return const SizedBox.shrink();
    }
    
    // If we're ready to swipe, don't show this header (mood banner will show instead)
    if (_isReadyToSwipe) {
      return const SizedBox.shrink();
    }
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF4A90E2).withValues(alpha: 0.9),
            const Color(0xFF357ABD).withValues(alpha: 0.9),
          ],
        ),
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Column(
        children: [
          // Main session info row
          Row(
            children: [
              // Session info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isWaitingForFriend ? "Waiting for friend..." : "Swiping together!",
                      style: TextStyle(color: Colors.white, fontSize: 16.sp, fontWeight: FontWeight.bold),
                    ),
                    if (currentSession!.sessionCode != null)
                      Text(
                        "Code: ${currentSession!.sessionCode}",
                        style: TextStyle(color: Colors.white70, fontSize: 14.sp),
                      ),
                    if (currentSession!.participantNames.length > 1)
                      Text(
                        "With: ${currentSession!.participantNames.where((name) => name != widget.currentUser.name).join(', ')}",
                        style: TextStyle(color: Colors.white70, fontSize: 12.sp),
                      ),
                  ],
                ),
              ),
              
              // Action buttons column
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Change Vibe button (only show if session has started and mood is selected)
                  if (selectedMoods.isNotEmpty || currentSession!.hasMoodSelected)
                    GestureDetector(
                      onTap: _requestMoodChange,
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 6.h),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5A00D).withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8.r),
                          border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.5)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.mood, color: const Color(0xFFE5A00D), size: 16.sp),
                            SizedBox(width: 4.w),
                            Text(
                              "Change Vibe",
                              style: TextStyle(
                                color: const Color(0xFFE5A00D),
                                fontSize: 12.sp,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  
                  SizedBox(height: 8.h),
                  
                  // End Session button
                  GestureDetector(
                    onTap: _cancelSessionForBoth,
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 6.h),
                      decoration: BoxDecoration(
                        color: Colors.red.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(8.r),
                        border: Border.all(color: Colors.red.withValues(alpha: 0.5)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.close, color: Colors.red, size: 16.sp),
                          SizedBox(width: 4.w),
                          Text(
                            "End Session",
                            style: TextStyle(
                              color: Colors.red,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  // 🆕 Collaborative waiting screen
  Widget _buildCollaborativeWaitingScreen() {
    print("🔍 DEBUG: _buildCollaborativeWaitingScreen called");
    print("   isWaitingForFriend: $isWaitingForFriend");
    print("   currentSession: ${currentSession?.sessionId}");
    print("   currentSession.moviePool.length: ${currentSession?.moviePool.length}");
    
    return Container(
      color: Colors.deepOrange.withValues(alpha: 0.5), // 🔍 DEBUG: VERY VISIBLE orange background
      child: Center(
        child: Padding(
          padding: EdgeInsets.all(32.r),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Debug info at the top
              Container(
                padding: EdgeInsets.all(8.r),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8.r),
                ),
                child: Text(
                  "DEBUG: Collaborative waiting screen is rendering!\nSession: ${currentSession?.sessionId}\nWaiting: $isWaitingForFriend",
                  style: TextStyle(color: Colors.white, fontSize: 12.sp),
                  textAlign: TextAlign.center,
                ),
              ),
              
              SizedBox(height: 32.h),
              
              // Animated waiting indicator
              Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 100.r,
                    height: 100.r,
                    child: CircularProgressIndicator(
                      valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFE5A00D)),
                      strokeWidth: 4.w,
                    ),
                  ),
                  Icon(
                    Icons.people,
                    size: 40.sp,
                    color: const Color(0xFFE5A00D),
                  ),
                ],
              ),
              
              SizedBox(height: 32.h),
              
              Text(
                isWaitingForFriend 
                    ? "Waiting for your friend..."
                    : currentSession != null && currentSession!.moviePool.isEmpty
                      ? "Waiting for host to set up movies..."
                      : "Get ready to swipe!",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24.sp,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              
              SizedBox(height: 16.h),
              
              Text(
                isWaitingForFriend 
                    ? "They'll join using your session code"
                    : "Choose your mood and start finding movies together!",
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 16.sp,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _requestMoodChange() {
    if (!isInCollaborativeMode) {
      // Solo mode - show settings directly
      setState(() {
        _showMatcherSettings = true;
      });
      return;
    }
    
    // Collaborative mode - check if host or participant
    final isHost = currentSession?.hostId == widget.currentUser.uid;
    
    if (isHost) {
      // Host can change settings directly
      setState(() {
        _showMatcherSettings = true;
      });
    } else {
      // Participants request changes
      _showSettingsChangeRequestDialog({
        'fromUserName': widget.currentUser.name,
        'previewText': 'Update session settings',
        'id': DateTime.now().millisecondsSinceEpoch.toString(), // or however you ID requests
      });
    }
  }

  // 🆕 NEW: Cancel session for all participants
  Future<void> _cancelSessionForBoth() async {
    if (currentSession == null) return;
    
    try {
      await SessionService.cancelSession(
        currentSession!.sessionId,
        cancelledBy: widget.currentUser.name,
      );
      
      _endCollaborativeSession();
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Session ended for everyone'),
          backgroundColor: Colors.orange,
        ),
      );
    } catch (e) {
      print("❌ Error ending session: $e");
    }
  }
}