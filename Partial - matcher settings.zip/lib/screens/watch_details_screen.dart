// File: lib/screens/watch_details_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'dart:ui';
import '../models/user_profile.dart';
import '../movie.dart';
import '../utils/tmdb_api.dart';
import '../screens/movie_detail_screen.dart';

class WatchDetailsScreen extends StatefulWidget {
  final Movie movie;
  final UserProfile currentUser;
  final String? matchedName;
  final List<String>? allMatchedUsers;

  const WatchDetailsScreen({
    Key? key,
    required this.movie,
    required this.currentUser,
    this.matchedName,
    this.allMatchedUsers,
  }) : super(key: key);

  @override
  State<WatchDetailsScreen> createState() => _WatchDetailsScreenState();
}

class _WatchDetailsScreenState extends State<WatchDetailsScreen>
    with SingleTickerProviderStateMixin {
  bool _isLoadingDetails = true;
  bool _isLoadingStreaming = true;
  Movie? _enrichedMovie;
  WatchProviders? _streamingOptions;
  
  late final AnimationController _fadeController;
  late final Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _loadMovieData();
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeOut),
    );
    
    _fadeController.forward();
  }

  Future<void> _loadMovieData() async {
    try {
      final results = await Future.wait([
        TMDBApi.fetchFullMovieById(widget.movie.id),
        TMDBApi.getWatchProviders(widget.movie.id),
      ]);
      
      if (mounted) {
        setState(() {
          _enrichedMovie = results[0] as Movie?;
          _streamingOptions = results[1] as WatchProviders?;
          _isLoadingDetails = false;
          _isLoadingStreaming = false;
        });
      }
    } catch (e) {
      print("Failed to load movie data: $e");
      if (mounted) {
        setState(() {
          _enrichedMovie = widget.movie;
          _isLoadingDetails = false;
          _isLoadingStreaming = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  Movie get displayMovie => _enrichedMovie ?? widget.movie;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              const Color(0xFF1A1A2E),
              const Color(0xFF16213E),
              Colors.black,
            ],
          ),
        ),
        child: Stack(
          children: [
            // Background poster with blur
            Positioned.fill(
              child: Image.network(
                displayMovie.posterUrl,
                fit: BoxFit.cover,
                color: Colors.black.withValues(alpha: 0.7),
                colorBlendMode: BlendMode.darken,
                errorBuilder: (context, error, stackTrace) => Container(),
              ),
            ),
            
            // Blur overlay
            Positioned.fill(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                child: Container(
                  color: Colors.black.withValues(alpha: 0.3),
                ),
              ),
            ),
            
            // Main content
            SafeArea(
              child: AnimatedBuilder(
                animation: _fadeAnimation,
                builder: (context, child) {
                  return Opacity(
                    opacity: _fadeAnimation.value,
                    child: Column(
                      children: [
                        // Header with back button
                        _buildHeader(),
                        
                        // Movie details
                        Expanded(
                          child: SingleChildScrollView(
                            padding: EdgeInsets.symmetric(horizontal: 20.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Movie hero section
                                _buildMovieHero(),
                                
                                SizedBox(height: 32.h),
                                
                                // Streaming options - MAIN FOCUS
                                _buildStreamingSection(),
                                
                                SizedBox(height: 32.h),
                                
                                // Movie details
                                _buildMovieDetails(),
                                
                                SizedBox(height: 40.h),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: EdgeInsets.all(16.w),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.arrow_back, color: Colors.white, size: 24.sp),
            style: IconButton.styleFrom(
              backgroundColor: Colors.black.withValues(alpha: 0.3),
              padding: EdgeInsets.all(12.r),
            ),
          ),
          
          SizedBox(width: 16.w),
          
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Ready to Watch",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (widget.allMatchedUsers?.length != null && widget.allMatchedUsers!.length > 2)
                  Text(
                    "Group Match • ${widget.allMatchedUsers!.length} people",
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.7),
                      fontSize: 14.sp,
                    ),
                  )
                else if (widget.matchedName != null)
                  Text(
                    "You & ${widget.matchedName}",
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.7),
                      fontSize: 14.sp,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMovieHero() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Movie poster
        Container(
          width: 120.w,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16.r),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.5),
                blurRadius: 20.r,
                spreadRadius: 4.r,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16.r),
            child: AspectRatio(
              aspectRatio: 2/3,
              child: Image.network(
                displayMovie.posterUrl,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  color: Colors.grey[800],
                  child: Icon(Icons.movie, size: 40.sp, color: Colors.white54),
                ),
              ),
            ),
          ),
        ),
        
        SizedBox(width: 20.w),
        
        // Movie info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                displayMovie.title,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24.sp,
                  fontWeight: FontWeight.bold,
                  height: 1.2,
                ),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              
              SizedBox(height: 12.h),
              
              // Quick stats row
              if (!_isLoadingDetails) ...[
                Wrap(
                  spacing: 16.w,
                  runSpacing: 8.h,
                  children: [
                    if (displayMovie.rating != null)
                      _buildStatChip(
                        icon: Icons.star,
                        text: displayMovie.rating!.toStringAsFixed(1),
                        color: Colors.amber,
                      ),
                    
                    if (displayMovie.runtime != null)
                      _buildStatChip(
                        icon: Icons.schedule,
                        text: _formatRuntime(displayMovie.runtime!),
                        color: Colors.blue,
                      ),
                    
                    if (displayMovie.releaseDate != null)
                      _buildStatChip(
                        icon: Icons.calendar_today,
                        text: _getYearFromDate(displayMovie.releaseDate!),
                        color: Colors.green,
                      ),
                  ],
                ),
              ] else ...[
                _buildLoadingChips(),
              ],
              
              SizedBox(height: 16.h),
              
              // Genres
              if (displayMovie.genres.isNotEmpty)
                Wrap(
                  spacing: 8.w,
                  runSpacing: 6.h,
                  children: displayMovie.genres.take(4).map((genre) =>
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(20.r),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.3),
                          width: 1.w,
                        ),
                      ),
                      child: Text(
                        genre,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    )
                  ).toList(),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStatChip({
    required IconData icon,
    required String text,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 6.h),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: color.withValues(alpha: 0.5), width: 1.w),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 14.sp),
          SizedBox(width: 4.w),
          Text(
            text,
            style: TextStyle(
              color: Colors.white,
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingChips() {
    return Row(
      children: List.generate(3, (index) {
        return Container(
          margin: EdgeInsets.only(right: 8.w),
          width: (60 + index * 10).w,
          height: 24.h,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(12.r),
          ),
        );
      }),
    );
  }

  Widget _buildStreamingSection() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(24.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF6C5CE7).withValues(alpha: 0.2),
            const Color(0xFF74B9FF).withValues(alpha: 0.1),
            Colors.white.withValues(alpha: 0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(24.r),
        border: Border.all(
          color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
          width: 2.w,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF6C5CE7).withValues(alpha: 0.2),
            blurRadius: 20.r,
            spreadRadius: 4.r,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section header
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(12.r),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                  ),
                  borderRadius: BorderRadius.circular(16.r),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
                      blurRadius: 12.r,
                      spreadRadius: 2.r,
                    ),
                  ],
                ),
                child: Icon(Icons.play_circle_filled, color: Colors.white, size: 32.sp),
              ),
              
              SizedBox(width: 16.w),
              
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Where to Watch",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "Available streaming options",
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.8),
                        fontSize: 14.sp,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          
          SizedBox(height: 24.h),
          
          // Streaming content
          if (_isLoadingStreaming)
            _buildStreamingLoader()
          else
            _buildStreamingOptions(),
        ],
      ),
    );
  }

  Widget _buildStreamingLoader() {
    return Column(
      children: List.generate(3, (index) {
        return Container(
          margin: EdgeInsets.only(bottom: 12.h),
          height: 60.h,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(16.r),
          ),
          child: Row(
            children: [
              Container(
                margin: EdgeInsets.all(12.w),
                width: 36.w,
                height: 36.h,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8.r),
                ),
              ),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 120.w,
                      height: 12.h,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(6.r),
                      ),
                    ),
                    SizedBox(height: 4.h),
                    Container(
                      width: 80.w,
                      height: 10.h,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(5.r),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(12.w),
                width: 60.w,
                height: 24.h,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(12.r),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildStreamingOptions() {
    final cleanProviders = _getCleanProviders();
    
    if (cleanProviders.totalCount == 0) {
      return _buildNoStreamingAvailable();
    }
    
    return Column(
      children: [
        // Subscription services (free with subscription)
        if (cleanProviders.subscription.isNotEmpty) ...[
          _buildStreamingCategory(
            title: "Stream for Free",
            subtitle: "With your subscription",
            providers: cleanProviders.subscription,
            isSubscription: true,
          ),
          
          if (cleanProviders.rental.isNotEmpty) SizedBox(height: 20.h),
        ],
        
        // Rental services
        if (cleanProviders.rental.isNotEmpty)
          _buildStreamingCategory(
            title: "Rent or Buy",
            subtitle: "One-time payment",
            providers: cleanProviders.rental,
            isSubscription: false,
          ),
      ],
    );
  }

  Widget _buildStreamingCategory({
    required String title,
    required String subtitle,
    required List<StreamingProvider> providers,
    required bool isSubscription,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Category header
        Padding(
          padding: EdgeInsets.only(bottom: 12.h),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(6.r),
                decoration: BoxDecoration(
                  color: isSubscription 
                      ? Colors.green.withValues(alpha: 0.2)
                      : Colors.orange.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8.r),
                ),
                child: Icon(
                  isSubscription ? Icons.check_circle : Icons.attach_money,
                  color: isSubscription ? Colors.green : Colors.orange,
                  size: 16.sp,
                ),
              ),
              SizedBox(width: 8.w),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.7),
                      fontSize: 12.sp,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        
        // Provider buttons
        ...providers.map((provider) => _buildProviderButton(provider, isSubscription)).toList(),
      ],
    );
  }

  Widget _buildProviderButton(StreamingProvider provider, bool isSubscription) {
    return Container(
      margin: EdgeInsets.only(bottom: 8.h),
      child: InkWell(
        onTap: () => _openStreamingApp(provider),
        borderRadius: BorderRadius.circular(16.r),
        child: Container(
          padding: EdgeInsets.all(16.w),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(16.r),
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.2),
              width: 1.w,
            ),
          ),
          child: Row(
            children: [
              // Provider icon
              Container(
                width: 40.w,
                height: 40.h,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8.r),
                ),
                child: Icon(
                  _getServiceIcon(provider.providerName),
                  color: Colors.black87,
                  size: 20.sp,
                ),
              ),
              
              SizedBox(width: 16.w),
              
              // Provider name and type
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      provider.providerName,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      isSubscription ? "Included with subscription" : "Rent or purchase",
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.7),
                        fontSize: 12.sp,
                      ),
                    ),
                  ],
                ),
              ),
              
              // Action button
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                decoration: BoxDecoration(
                  color: isSubscription 
                      ? Colors.green
                      : Colors.orange,
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Text(
                  isSubscription ? "WATCH" : "RENT",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNoStreamingAvailable() {
    return Container(
      padding: EdgeInsets.all(20.w),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: Colors.orange.withValues(alpha: 0.3),
          width: 1.w,
        ),
      ),
      child: Column(
        children: [
          Icon(
            Icons.search_off,
            color: Colors.orange,
            size: 32.sp,
          ),
          SizedBox(height: 12.h),
          Text(
            "No Streaming Options Found",
            style: TextStyle(
              color: Colors.white,
              fontSize: 16.sp,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 8.h),
          Text(
            "This movie might be available on other platforms or in theaters",
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.7),
              fontSize: 14.sp,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildMovieDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "About This Movie",
          style: TextStyle(
            color: Colors.white,
            fontSize: 20.sp,
            fontWeight: FontWeight.bold,
          ),
        ),
        
        SizedBox(height: 16.h),
        
        // Overview
        if (displayMovie.overview.isNotEmpty) ...[
          Container(
            padding: EdgeInsets.all(16.w),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(16.r),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.1),
                width: 1.w,
              ),
            ),
            child: Text(
              displayMovie.overview,
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.9),
                fontSize: 14.sp,
                height: 1.5,
              ),
            ),
          ),
          
          SizedBox(height: 20.h),
        ],
        
        // Full details button
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () {
              showMovieDetails(
                context: context,
                movie: displayMovie,
                currentUser: widget.currentUser,
                isInFavorites: true,
              );
            },
            icon: Icon(Icons.info_outline, size: 18.sp),
            label: Text(
              "Full Movie Details",
              style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w600),
            ),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white,
              side: BorderSide(color: Colors.white.withValues(alpha: 0.3), width: 2.w),
              padding: EdgeInsets.symmetric(vertical: 16.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16.r),
              ),
              backgroundColor: Colors.white.withValues(alpha: 0.05),
            ),
          ),
        ),
      ],
    );
  }

  // Helper methods
  CleanProviders _getCleanProviders() {
    if (_streamingOptions == null) {
      return CleanProviders(subscription: [], rental: []);
    }
    
    final unwantedProviders = {'Fandango At Home', 'FandangoNOW', 'Fandango'};
    
    final subscriptionMap = <String, StreamingProvider>{};
    final rentalMap = <String, StreamingProvider>{};
    
    for (final provider in _streamingOptions!.streaming) {
      if (!unwantedProviders.contains(provider.providerName)) {
        subscriptionMap[provider.providerName] = provider;
      }
    }
    
    for (final provider in [..._streamingOptions!.rent, ..._streamingOptions!.buy]) {
      if (!unwantedProviders.contains(provider.providerName)) {
        rentalMap[provider.providerName] = provider;
      }
    }
    
    return CleanProviders(
      subscription: subscriptionMap.values.toList(),
      rental: rentalMap.values.toList(),
    );
  }

  IconData _getServiceIcon(String serviceName) {
    switch (serviceName.toLowerCase()) {
      case 'netflix':
        return Icons.movie;
      case 'disney plus':
      case 'disney+':
        return Icons.auto_awesome;
      case 'amazon prime video':
      case 'prime video':
        return Icons.local_movies;
      case 'hulu':
        return Icons.play_circle_filled;
      case 'hbo max':
      case 'max':
        return Icons.hd;
      case 'apple tv plus':
      case 'apple tv+':
        return Icons.apple;
      default:
        return Icons.play_arrow;
    }
  }

  void _openStreamingApp(StreamingProvider provider) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Opening ${provider.providerName} for "${displayMovie.title}"'),
        backgroundColor: const Color(0xFF6C5CE7),
        behavior: SnackBarBehavior.floating,
        action: SnackBarAction(
          label: 'OK',
          textColor: Colors.white,
          onPressed: () {},
        ),
      ),
    );
  }

  String _formatRuntime(int minutes) {
    final hours = minutes ~/ 60;
    final mins = minutes % 60;
    return hours > 0 ? '${hours}h ${mins}m' : '${mins}m';
  }

  String _getYearFromDate(String dateString) {
    try {
      final date = DateTime.parse(dateString);
      return date.year.toString();
    } catch (e) {
      return dateString;
    }
  }
}

// Helper class for organizing providers
class CleanProviders {
  final List<StreamingProvider> subscription;
  final List<StreamingProvider> rental;
  
  CleanProviders({required this.subscription, required this.rental});
  
  int get totalCount => subscription.length + rental.length;
}