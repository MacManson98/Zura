import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/user_profile.dart';
import '../utils/mood_based_learning_engine.dart';
import '../services/session_service.dart';
import '../models/session_models.dart';

class MatcherSettingsScreen extends StatefulWidget {
  final UserProfile hostUser;
  final List<UserProfile> selectedFriends;
  final Function(SwipeSession session) onSessionCreated;
  final Function(SessionSettings settings)? onStartMatching;  

  const MatcherSettingsScreen({
    Key? key,
    required this.hostUser,
    required this.selectedFriends,
    required this.onSessionCreated,
    this.onStartMatching,
  }) : super(key: key);

  @override
  State<MatcherSettingsScreen> createState() => _MatcherSettingsScreenState();
}

class _MatcherSettingsScreenState extends State<MatcherSettingsScreen> {
  CurrentMood? selectedMood;
  Set<String> selectedGenres = {};
  StreamingPreferences hostStreamingPrefs = StreamingPreferences();
  bool _isCreatingSession = false;
  bool _showAdvancedOptions = false;

  // All available genres
  final List<String> availableGenres = [
    'Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary',
    'Drama', 'Family', 'Fantasy', 'History', 'Horror', 'Music', 'Mystery',
    'Romance', 'Science Fiction', 'Thriller', 'War', 'Western'
  ];

  // Common streaming services
  final List<String> commonServices = [
    'Netflix', 'Amazon Prime', 'Disney+', 'Hulu', 'HBO Max', 
    'Apple TV+', 'Paramount+', 'Peacock'
  ];

  @override
  void initState() {
    super.initState();
    hostStreamingPrefs = widget.hostUser.streamingPreferences.copyWith();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Set Up Friend Session',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Settings will apply to everyone',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 12.sp,
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          // Participants preview
          _buildParticipantsSection(),
          
          // Settings content
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(16.w),
              child: Column(
                children: [
                  _buildQuickStartOptions(),
                  SizedBox(height: 24.h),
                  _buildMoodSelection(),
                  SizedBox(height: 24.h),
                  _buildStreamingSection(),
                  if (_showAdvancedOptions) ...[
                    SizedBox(height: 24.h),
                    _buildGenreSection(),
                  ],
                  SizedBox(height: 16.h),
                  _buildAdvancedToggle(),
                  SizedBox(height: 32.h),
                  _buildCreateSessionButton(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildParticipantsSection() {
    final allParticipants = [widget.hostUser, ...widget.selectedFriends];
    
    return Container(
      margin: EdgeInsets.all(16.w),
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A2A),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.people, color: const Color(0xFFE5A00D), size: 20.sp),
              SizedBox(width: 8.w),
              Text(
                'Session Participants (${allParticipants.length})',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          SizedBox(height: 12.h),
          
          Wrap(
            spacing: 8.w,
            runSpacing: 8.h,
            children: allParticipants.map((participant) {
              final isHost = participant.uid == widget.hostUser.uid;
              
              return Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                decoration: BoxDecoration(
                  color: isHost 
                      ? const Color(0xFFE5A00D).withValues(alpha: 0.2)
                      : Colors.grey[800],
                  borderRadius: BorderRadius.circular(20.r),
                  border: isHost 
                      ? Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.5))
                      : null,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircleAvatar(
                      radius: 10.r,
                      backgroundColor: isHost ? const Color(0xFFE5A00D) : Colors.grey[600],
                      child: Text(
                        participant.name.isNotEmpty ? participant.name[0].toUpperCase() : '?',
                        style: TextStyle(
                          color: isHost ? Colors.black : Colors.white,
                          fontSize: 10.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(width: 6.w),
                    Text(
                      participant.name,
                      style: TextStyle(
                        color: isHost ? const Color(0xFFE5A00D) : Colors.white,
                        fontSize: 12.sp,
                        fontWeight: isHost ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                    if (isHost) ...[
                      SizedBox(width: 4.w),
                      Icon(
                        Icons.star,
                        color: const Color(0xFFE5A00D),
                        size: 12.sp,
                      ),
                    ],
                  ],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStartOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Start Options',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.sp,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 12.h),
        
        Row(
          children: [
            Expanded(
              child: _buildQuickOption(
                title: 'All Movies',
                subtitle: 'No filters',
                icon: Icons.movie,
                color: Colors.purple,
                onTap: () => _createQuickSession(null),
              ),
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: _buildQuickOption(
                title: 'Common Streaming',
                subtitle: 'Shared services only',
                icon: Icons.tv,
                color: Colors.green,
                onTap: () => _createQuickSession(_getCommonStreamingSettings()),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildQuickOption({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: _isCreatingSession ? null : onTap,
      child: Container(
        padding: EdgeInsets.all(16.w),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 32.sp),
            SizedBox(height: 8.h),
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 14.sp,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 4.h),
            Text(
              subtitle,
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 11.sp,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMoodSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Choose Mood (Optional)',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.sp,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 12.h),
        
        Wrap(
          spacing: 8.w,
          runSpacing: 8.h,
          children: CurrentMood.values.map((mood) {
            final isSelected = selectedMood == mood;
            
            return GestureDetector(
              onTap: () {
                setState(() {
                  selectedMood = isSelected ? null : mood;
                });
              },
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                decoration: BoxDecoration(
                  color: isSelected 
                      ? const Color(0xFFE5A00D).withValues(alpha: 0.2)
                      : const Color(0xFF2A2A2A),
                  borderRadius: BorderRadius.circular(20.r),
                  border: Border.all(
                    color: isSelected 
                        ? const Color(0xFFE5A00D)
                        : Colors.grey[700]!,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(mood.emoji, style: TextStyle(fontSize: 16.sp)),
                    SizedBox(width: 8.w),
                    Text(
                      mood.displayName,
                      style: TextStyle(
                        color: isSelected ? const Color(0xFFE5A00D) : Colors.white,
                        fontSize: 14.sp,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildStreamingSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Streaming Services (Optional)',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.sp,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 8.h),
        
        Text(
          'Select services everyone should have access to:',
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 14.sp,
          ),
        ),
        SizedBox(height: 12.h),
        
        Wrap(
          spacing: 8.w,
          runSpacing: 8.h,
          children: commonServices.map((service) {
            final isSelected = hostStreamingPrefs.ownedServices.contains(service);
            
            return GestureDetector(
              onTap: () {
                setState(() {
                  if (isSelected) {
                    hostStreamingPrefs = hostStreamingPrefs.copyWith(
                      ownedServices: Set<String>.from(hostStreamingPrefs.ownedServices)..remove(service),
                    );
                  } else {
                    hostStreamingPrefs = hostStreamingPrefs.copyWith(
                      ownedServices: Set<String>.from(hostStreamingPrefs.ownedServices)..add(service),
                    );
                  }
                });
              },
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
                decoration: BoxDecoration(
                  color: isSelected 
                      ? Colors.green.withValues(alpha: 0.2)
                      : const Color(0xFF2A2A2A),
                  borderRadius: BorderRadius.circular(16.r),
                  border: Border.all(
                    color: isSelected ? Colors.green : Colors.grey[700]!,
                  ),
                ),
                child: Text(
                  service,
                  style: TextStyle(
                    color: isSelected ? Colors.green : Colors.white,
                    fontSize: 12.sp,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
            );
          }).toList(),
        ),
        
        SizedBox(height: 16.h),
        
        // Rental option
        CheckboxListTile(
          value: hostStreamingPrefs.willingToRent,
          onChanged: (value) {
            setState(() {
              hostStreamingPrefs = hostStreamingPrefs.copyWith(willingToRent: value ?? false);
            });
          },
          activeColor: Colors.orange,
          checkColor: Colors.black,
          title: Text(
            'Include rental movies',
            style: TextStyle(color: Colors.white, fontSize: 14.sp),
          ),
          subtitle: Text(
            'Show movies available to rent if not on streaming services',
            style: TextStyle(color: Colors.grey[400], fontSize: 12.sp),
          ),
          contentPadding: EdgeInsets.zero,
        ),
      ],
    );
  }

  Widget _buildGenreSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Additional Genres (Optional)',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.sp,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 12.h),
        
        Wrap(
          spacing: 8.w,
          runSpacing: 8.h,
          children: availableGenres.map((genre) {
            final isSelected = selectedGenres.contains(genre);
            
            return GestureDetector(
              onTap: () {
                setState(() {
                  if (isSelected) {
                    selectedGenres.remove(genre);
                  } else {
                    selectedGenres.add(genre);
                  }
                });
              },
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
                decoration: BoxDecoration(
                  color: isSelected 
                      ? Colors.blue.withValues(alpha: 0.2)
                      : const Color(0xFF2A2A2A),
                  borderRadius: BorderRadius.circular(16.r),
                  border: Border.all(
                    color: isSelected ? Colors.blue : Colors.grey[700]!,
                  ),
                ),
                child: Text(
                  genre,
                  style: TextStyle(
                    color: isSelected ? Colors.blue : Colors.white,
                    fontSize: 12.sp,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildAdvancedToggle() {
    return GestureDetector(
      onTap: () {
        setState(() {
          _showAdvancedOptions = !_showAdvancedOptions;
        });
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
        decoration: BoxDecoration(
          color: const Color(0xFF2A2A2A),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: Colors.grey[700]!),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              _showAdvancedOptions ? Icons.expand_less : Icons.expand_more,
              color: Colors.grey[400],
              size: 20.sp,
            ),
            SizedBox(width: 8.w),
            Text(
              _showAdvancedOptions ? 'Hide Advanced Options' : 'Show Advanced Options',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCreateSessionButton() {
    return SizedBox(
      width: double.infinity,
      height: 56.h,
      child: ElevatedButton(
        onPressed: _isCreatingSession ? null : _createCustomSession,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFE5A00D),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.r),
          ),
        ),
        child: _isCreatingSession
            ? SizedBox(
                width: 24.w,
                height: 24.h,
                child: CircularProgressIndicator(
                  strokeWidth: 2.w,
                  valueColor: const AlwaysStoppedAnimation<Color>(Colors.black),
                ),
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Create Session & Send Invites',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (_hasAnySettings())
                    Text(
                      _getSettingsSummary(),
                      style: TextStyle(
                        color: Colors.black.withValues(alpha: 0.7),
                        fontSize: 12.sp,
                      ),
                    ),
                ],
              ),
      ),
    );
  }

  // Helper methods

  bool _hasAnySettings() {
    return selectedMood != null || 
           hostStreamingPrefs.ownedServices.isNotEmpty || 
           hostStreamingPrefs.willingToRent ||
           selectedGenres.isNotEmpty;
  }

  String _getSettingsSummary() {
    final parts = <String>[];
    
    if (selectedMood != null) {
      parts.add(selectedMood!.displayName);
    }
    
    if (hostStreamingPrefs.ownedServices.isNotEmpty) {
      parts.add("${hostStreamingPrefs.ownedServices.length} services");
    }
    
    if (selectedGenres.isNotEmpty) {
      parts.add("${selectedGenres.length} genres");
    }
    
    return parts.isEmpty ? "All movies" : parts.join(" • ");
  }

  SessionSettings _getCommonStreamingSettings() {
    // Find streaming services that all participants have
    Set<String> commonServices = widget.hostUser.streamingPreferences.ownedServices;
    
    for (final friend in widget.selectedFriends) {
      commonServices = commonServices.intersection(friend.streamingPreferences.ownedServices);
    }
    
    final commonStreamingPrefs = StreamingPreferences(
      ownedServices: commonServices,
      willingToRent: widget.selectedFriends.every((f) => f.streamingPreferences.willingToRent),
    );
    
    return SessionSettings(
      streamingPreferences: commonStreamingPrefs,
      isGroupSession: widget.selectedFriends.length > 1,
    );
  }

  Future<void> _createQuickSession(SessionSettings? predefinedSettings) async {
    setState(() => _isCreatingSession = true);
    
    try {
      final settings = predefinedSettings ?? SessionSettings(
        isGroupSession: widget.selectedFriends.length > 1,
        streamingPreferences: hostStreamingPrefs,
      );
      
      await _createAndInviteSession(settings);
    } finally {
      if (mounted) setState(() => _isCreatingSession = false);
    }
  }

  Future<void> _createCustomSession() async {
    print("🔍 DEBUG: _createCustomSession called");
    
    setState(() => _isCreatingSession = true);

    try {
      final settings = SessionSettings(
        selectedMood: selectedMood,
        additionalGenres: selectedGenres,
        streamingPreferences: hostStreamingPrefs,
        isGroupSession: widget.selectedFriends.length > 1,
      );

      print("🔍 DEBUG: Created settings: ${settings.toJson()}");
      print("🔍 DEBUG: Selected friends count: ${widget.selectedFriends.length}");
      print("🔍 DEBUG: onStartMatching is null: ${widget.onStartMatching == null}");

      // ✅ If callback is provided (used by FriendInviteDialog), call it and exit:
      if (widget.onStartMatching != null) {
        print("🔍 DEBUG: Calling onStartMatching callback");
        widget.onStartMatching!(settings);
        return;
      }

      print("🔍 DEBUG: About to call _createAndInviteSession");
      // Default behavior (invite all friends etc.)
      await _createAndInviteSession(settings);
      print("🔍 DEBUG: _createAndInviteSession completed successfully");
      
    } catch (e, stackTrace) {
      print("❌ ERROR in _createCustomSession: $e");
      print("❌ Stack trace: $stackTrace");
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error creating session: $e'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 5),
          ),
        );
      }
    } finally {
      print("🔍 DEBUG: Setting _isCreatingSession = false");
      if (mounted) setState(() => _isCreatingSession = false);
    }
  }

  Future<void> _createAndInviteSession(SessionSettings settings) async {
    print("🔍 DEBUG: _createAndInviteSession called");
    
    try {
      print("🔍 DEBUG: About to call SessionService.createCollaborativeSession");
      
      // Create the session with settings
      final session = await SessionService.createCollaborativeSession(
        hostName: widget.hostUser.name,
        inviteType: InvitationType.friend,
        sessionSettings: settings,
        groupMembers: [widget.hostUser, ...widget.selectedFriends],
      );

      print("🔍 DEBUG: Session created: ${session.sessionId}");

      // Send invitations to all friends
      for (final friend in widget.selectedFriends) {
        print("🔍 DEBUG: Sending invitation to ${friend.name}");
        
        await SessionService.sendCollaborativeInvitation(
          sessionId: session.sessionId,
          friendId: friend.uid,
          friendName: friend.name,
          sessionSettings: settings,
        );
      }

      print("🔍 DEBUG: All invitations sent");

      if (mounted) {
        print("🔍 DEBUG: Calling onSessionCreated callback");
        widget.onSessionCreated(session);
        
        print("🔍 DEBUG: Popping navigator");
        Navigator.pop(context);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Session created! Invitations sent to ${widget.selectedFriends.length} friend(s)',
            ),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e, stackTrace) {
      print("❌ ERROR in _createAndInviteSession: $e");
      print("❌ Stack trace: $stackTrace");
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to create session: $e'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 5),
          ),
        );
      }
    }
  }
}