import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/session_models.dart';
import '../models/user_profile.dart';
import '../services/session_service.dart';
import '../screens/matcher_settings_screen.dart'; // Your actual settings screen

// Simple dialog for friend selection that works with your existing MatcherSettingsScreen
class FriendInviteDialog extends StatefulWidget {
  final UserProfile currentUser;
  final List<UserProfile> availableFriends;
  final Function(SwipeSession session) onSessionCreated;

  const FriendInviteDialog({
    Key? key,
    required this.currentUser,
    required this.availableFriends,
    required this.onSessionCreated,
  }) : super(key: key);

  @override
  State<FriendInviteDialog> createState() => _FriendInviteDialogState();
}

class _FriendInviteDialogState extends State<FriendInviteDialog> {
  final Set<String> selectedFriendIds = {};
  bool _isCreatingSession = false;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFF1F1F1F),
      title: Text(
        'Start Friend Session',
        style: TextStyle(color: Colors.white, fontSize: 18.sp),
      ),
      content: SizedBox(
        width: double.maxFinite,
        height: 300.h,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Quick options at top
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isCreatingSession ? null : _createQuickCodeSession,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      padding: EdgeInsets.symmetric(vertical: 12.h),
                    ),
                    icon: Icon(Icons.flash_on, size: 16.sp),
                    label: Text(
                      'Quick Code',
                      style: TextStyle(fontSize: 12.sp),
                    ),
                  ),
                ),
                SizedBox(width: 8.w),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isCreatingSession ? null : _createCustomSession,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE5A00D),
                      padding: EdgeInsets.symmetric(vertical: 12.h),
                    ),
                    icon: Icon(Icons.tune, size: 16.sp),
                    label: Text(
                      'Custom',
                      style: TextStyle(fontSize: 12.sp),
                    ),
                  ),
                ),
              ],
            ),
            
            SizedBox(height: 16.h),
            
            Text(
              'Or select friends for custom session:',
              style: TextStyle(color: Colors.grey[300], fontSize: 14.sp),
            ),
            SizedBox(height: 12.h),
            
            Expanded(
              child: widget.availableFriends.isEmpty
                  ? Center(
                      child: Text(
                        "You don't have any friends yet.\nAdd some from the Friends tab!",
                        style: TextStyle(color: Colors.white70, fontSize: 14.sp),
                        textAlign: TextAlign.center,
                      ),
                    )
                  : ListView.builder(
                      itemCount: widget.availableFriends.length,
                      itemBuilder: (context, index) {
                        final friend = widget.availableFriends[index];
                        final isSelected = selectedFriendIds.contains(friend.uid);
                        
                        return CheckboxListTile(
                          value: isSelected,
                          onChanged: _isCreatingSession ? null : (selected) {
                            setState(() {
                              if (selected == true) {
                                selectedFriendIds.add(friend.uid);
                              } else {
                                selectedFriendIds.remove(friend.uid);
                              }
                            });
                          },
                          activeColor: const Color(0xFFE5A00D),
                          checkColor: Colors.black,
                          title: Text(
                            friend.name,
                            style: TextStyle(color: Colors.white, fontSize: 14.sp),
                          ),
                          subtitle: Text(
                            "Ready to swipe",
                            style: TextStyle(color: Colors.grey[400], fontSize: 12.sp),
                          ),
                          secondary: CircleAvatar(
                            backgroundColor: Colors.grey[800],
                            radius: 18.r,
                            child: Text(
                              friend.name.isNotEmpty ? friend.name[0].toUpperCase() : "?",
                              style: TextStyle(color: Colors.white, fontSize: 14.sp),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _isCreatingSession ? null : () => Navigator.pop(context),
          child: Text(
            'Cancel',
            style: TextStyle(color: Colors.grey[400], fontSize: 14.sp),
          ),
        ),
        if (selectedFriendIds.isNotEmpty)
          ElevatedButton(
            onPressed: _isCreatingSession ? null : _proceedToCustomSettings,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFE5A00D),
            ),
            child: _isCreatingSession
                ? SizedBox(
                    width: 16.w,
                    height: 16.h,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.w,
                      valueColor: const AlwaysStoppedAnimation<Color>(Colors.black),
                    ),
                  )
                : Text(
                    'Next: Settings',
                    style: TextStyle(color: Colors.black, fontSize: 14.sp),
                  ),
          ),
      ],
    );
  }

  // Quick session with just a code (no settings)
  Future<void> _createQuickCodeSession() async {
    setState(() => _isCreatingSession = true);
    
    try {
      final session = await SessionService.createSession(
        hostName: widget.currentUser.name,
        inviteType: InvitationType.code,
      );
      
      if (mounted) {
        widget.onSessionCreated(session);
        Navigator.pop(context);
        _showSessionCodeDialog(session.sessionCode!);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to create session: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isCreatingSession = false);
    }
  }

  // Custom session (solo settings for now)
  Future<void> _createCustomSession() async {
    Navigator.pop(context); // Close this dialog

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MatcherSettingsScreen(
          hostUser: widget.currentUser,
          selectedFriends: [], 
          onSessionCreated: (session) {
            print("🎉 Session created in FriendInviteDialog: ${session.sessionId}");
            
            // ✅ FIXED: Properly handle the created session
            widget.onSessionCreated(session);
            
            // ✅ FIXED: Navigate back to main screen instead of just popping
            Navigator.of(context).popUntil((route) => route.isFirst);
            
            // Show success message
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Session created! Friend invited successfully'),
                backgroundColor: Colors.green,
                duration: Duration(seconds: 3),
              ),
            );
          },
        ),
      ),
    );
  }

  void _proceedToCustomSettings() {
    final selectedFriends = widget.availableFriends
        .where((friend) => selectedFriendIds.contains(friend.uid))
        .toList();

    Navigator.pop(context); // Close friend selection

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MatcherSettingsScreen(
          hostUser: widget.currentUser,
          selectedFriends: selectedFriends,
          onSessionCreated: (session) {
            print("🎉 Collaborative session created: ${session.sessionId}");
            
            // ✅ FIXED: Properly handle the created session
            widget.onSessionCreated(session);
            
            // ✅ FIXED: Navigate back to main screen instead of just popping
            Navigator.of(context).popUntil((route) => route.isFirst);
            
            // Show success message
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Session created! Invitations sent to ${selectedFriends.length} friend(s)'),
                backgroundColor: Colors.green,
                duration: Duration(seconds: 3),
              ),
            );
          },
        ),
      ),
    );
  }

  void _showSessionCodeDialog(String sessionCode) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "Session Ready! 🎉",
          style: TextStyle(color: Colors.white, fontSize: 18.sp),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Share this code with your friend:",
              style: TextStyle(color: Colors.grey[300], fontSize: 14.sp),
            ),
            SizedBox(height: 16.h),
            
            Container(
              padding: EdgeInsets.all(16.r),
              decoration: BoxDecoration(
                color: const Color(0xFFE5A00D).withOpacity(0.2),
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(color: const Color(0xFFE5A00D)),
              ),
              child: Text(
                sessionCode,
                style: TextStyle(
                  color: const Color(0xFFE5A00D),
                  fontSize: 32.sp,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 8.w,
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              "Got it!",
              style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 14.sp),
            ),
          ),
        ],
      ),
    );
  }
}