// File: lib/widgets/streaming_options_widget.dart
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../movie.dart';
import '../utils/tmdb_api.dart';

class StreamingOptionsWidget extends StatefulWidget {
  final Movie movie;
  final bool isLoading;
  final WatchProviders? streamingOptions;
  final Color dominantColor;
  final Color vibrantColor;
  final Color mutedColor;
  final Function(Color) getContrastColor;

  const StreamingOptionsWidget({
    Key? key,
    required this.movie,
    required this.isLoading,
    required this.streamingOptions,
    required this.dominantColor,
    required this.vibrantColor,
    required this.mutedColor,
    required this.getContrastColor,
  }) : super(key: key);

  @override
  State<StreamingOptionsWidget> createState() => _StreamingOptionsWidgetState();
}

class _StreamingOptionsWidgetState extends State<StreamingOptionsWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _shimmerController;
  late Animation<double> _shimmerAnimation;

  @override
  void initState() {
    super.initState();
    _shimmerController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _shimmerAnimation = Tween<double>(
      begin: -1.0,
      end: 2.0,
    ).animate(CurvedAnimation(
      parent: _shimmerController,
      curve: Curves.easeInOut,
    ));
    
    if (widget.isLoading) {
      _shimmerController.repeat();
    }
  }

  @override
  void didUpdateWidget(StreamingOptionsWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isLoading && !oldWidget.isLoading) {
      _shimmerController.repeat();
    } else if (!widget.isLoading && oldWidget.isLoading) {
      _shimmerController.stop();
    }
  }

  @override
  void dispose() {
    _shimmerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.black.withValues(alpha: 0.7),
            Colors.black.withValues(alpha: 0.6),
            widget.vibrantColor.withValues(alpha: 0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(
          color: widget.vibrantColor.withValues(alpha: 0.6),
          width: 2.w,
        ),
        boxShadow: [
          BoxShadow(
            color: widget.vibrantColor.withValues(alpha: 0.25),
            blurRadius: 12.r,
            spreadRadius: 1.r,
            offset: Offset(0, 4.h),
          ),
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 8.r,
            spreadRadius: 0.5.r,
            offset: Offset(0, 2.h),
          ),
        ],
      ),
      child: Container(
        padding: EdgeInsets.all(20.w),
        child: widget.isLoading ? _buildLoadingState() : _buildStreamingContent(),
      ),
    );
  }

  Widget _buildLoadingState() {
    return AnimatedBuilder(
      animation: _shimmerAnimation,
      builder: (context, child) {
        return Stack(
          children: [
            Row(
              children: [
                // Animated TV icon
                Container(
                  padding: EdgeInsets.all(14.r),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        widget.vibrantColor.withValues(alpha: 0.6),
                        widget.vibrantColor.withValues(alpha: 0.4),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(16.r),
                  ),
                  child: Icon(
                    Icons.tv,
                    color: Colors.white,
                    size: 28.sp,
                  ),
                ),
                
                SizedBox(width: 16.w),
                
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Finding Streaming Options",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18.sp,
                          fontWeight: FontWeight.bold,
                          shadows: [
                            Shadow(
                              color: Colors.black.withValues(alpha: 0.5),
                              blurRadius: 2.r,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 6.h),
                      Text(
                        "Checking where you can watch...",
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.9),
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w500,
                          shadows: [
                            Shadow(
                              color: Colors.black.withValues(alpha: 0.5),
                              blurRadius: 2.r,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Loading indicator
                SizedBox(
                  width: 24.w,
                  height: 24.h,
                  child: CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 2.5.w,
                  ),
                ),
              ],
            ),
            
            // Shimmer effect overlay
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18.r),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [
                        Colors.transparent,
                        Colors.white.withValues(alpha: 0.1),
                        Colors.transparent,
                      ],
                      stops: [
                        (_shimmerAnimation.value - 0.3).clamp(0.0, 1.0),
                        _shimmerAnimation.value.clamp(0.0, 1.0),
                        (_shimmerAnimation.value + 0.3).clamp(0.0, 1.0),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildStreamingContent() {
    final cleanProviders = _getCleanProviders();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header row (existing preview)
        Row(
          children: [
            // Enhanced TV icon with streaming indicator
            Container(
              padding: EdgeInsets.all(14.r),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    widget.vibrantColor,
                    widget.vibrantColor.withValues(alpha: 0.8),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16.r),
                boxShadow: [
                  BoxShadow(
                    color: widget.vibrantColor.withValues(alpha: 0.4),
                    blurRadius: 8.r,
                    spreadRadius: 1.r,
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Icon(
                    Icons.tv,
                    color: Colors.white,
                    size: 28.sp,
                  ),
                  // Streaming indicator dot
                  if (cleanProviders.totalCount > 0)
                    Positioned(
                      right: -2,
                      top: -2,
                      child: Container(
                        width: 12.w,
                        height: 12.h,
                        decoration: BoxDecoration(
                          color: Colors.green[400],
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.white,
                            width: 2.w,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            
            SizedBox(width: 16.w),
            
            // Main content with preview text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          "Watch Now",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18.sp,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                            shadows: [
                              Shadow(
                                color: Colors.black.withValues(alpha: 0.5),
                                blurRadius: 2.r,
                              ),
                            ],
                          ),
                        ),
                      ),
                      // Streaming count badge
                      if (cleanProviders.totalCount > 0)
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.9),
                            borderRadius: BorderRadius.circular(12.r),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.2),
                                blurRadius: 4.r,
                                spreadRadius: 1.r,
                              ),
                            ],
                          ),
                          child: Text(
                            "${cleanProviders.totalCount} option${cleanProviders.totalCount > 1 ? 's' : ''}",
                            style: TextStyle(
                              color: widget.vibrantColor,
                              fontSize: 11.sp,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                    ],
                  ),
                  SizedBox(height: 6.h),
                  _buildStreamingPreview(cleanProviders),
                ],
              ),
            ),
          ],
        ),
        
        SizedBox(height: 16.h),
        
        // NEW: Show streaming services directly inline
        if (cleanProviders.totalCount > 0) _buildInlineServices(cleanProviders),
      ],
    );
  }

  Widget _buildStreamingPreview(CleanProviders cleanProviders) {
    if (cleanProviders.totalCount == 0) {
      return Row(
        children: [
          Icon(
            Icons.search,
            color: Colors.orange[300],
            size: 16.sp,
          ),
          SizedBox(width: 6.w),
          Expanded(
            child: Text(
              "No streaming options available",
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.9),
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                shadows: [
                  Shadow(
                    color: Colors.black.withValues(alpha: 0.5),
                    blurRadius: 2.r,
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    }
    
    if (cleanProviders.subscription.isNotEmpty) {
      final firstProvider = cleanProviders.subscription.first;
      return Row(
        children: [
          // Success icon for subscription
          Container(
            padding: EdgeInsets.all(3.r),
            decoration: BoxDecoration(
              color: Colors.green[400],
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.check,
              color: Colors.white,
              size: 12.sp,
            ),
          ),
          SizedBox(width: 8.w),
          Expanded(
            child: RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: "Available on ",
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.95),
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                      shadows: [
                        Shadow(
                          color: Colors.black.withValues(alpha: 0.5),
                          blurRadius: 2.r,
                        ),
                      ],
                    ),
                  ),
                  TextSpan(
                    text: firstProvider.providerName,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(
                          color: Colors.black.withValues(alpha: 0.5),
                          blurRadius: 2.r,
                        ),
                      ],
                    ),
                  ),
                  if (cleanProviders.totalCount > 1)
                    TextSpan(
                      text: " +${cleanProviders.totalCount - 1} more",
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.8),
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w500,
                        shadows: [
                          Shadow(
                            color: Colors.black.withValues(alpha: 0.5),
                            blurRadius: 2.r,
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      );
    } else if (cleanProviders.rental.isNotEmpty) {
      return Row(
        children: [
          Container(
            padding: EdgeInsets.all(3.r),
            decoration: BoxDecoration(
              color: Colors.orange[400],
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.attach_money,
              color: Colors.white,
              size: 12.sp,
            ),
          ),
          SizedBox(width: 8.w),
          Expanded(
            child: Text(
              "Available to rent on ${cleanProviders.rental.length} platform${cleanProviders.rental.length > 1 ? 's' : ''}",
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.9),
                fontSize: 14.sp,
                fontWeight: FontWeight.w600,
                shadows: [
                  Shadow(
                    color: Colors.black.withValues(alpha: 0.5),
                    blurRadius: 2.r,
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    }
    
    return Text(
      "Check streaming options",
      style: TextStyle(
        color: Colors.white.withValues(alpha: 0.8),
        fontSize: 14.sp,
        fontWeight: FontWeight.w500,
        shadows: [
          Shadow(
            color: Colors.black.withValues(alpha: 0.5),
            blurRadius: 2.r,
          ),
        ],
      ),
    );
  }

  // NEW METHOD: Show services inline
  Widget _buildInlineServices(CleanProviders cleanProviders) {
    final allProviders = [...cleanProviders.subscription, ...cleanProviders.rental];
    
    // Limit to first 6 popular services for clean display
    final displayProviders = allProviders.take(6).toList();
    
    return Wrap(
      spacing: 8.w,
      runSpacing: 8.h,
      children: displayProviders.map((provider) {
        final isSubscription = cleanProviders.subscription.contains(provider);
        
        return GestureDetector(
          onTap: () => _openStreamingApp(provider, context),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
            decoration: BoxDecoration(
              color: isSubscription 
                  ? Colors.green[600]!.withValues(alpha: 0.9)
                  : Colors.orange[600]!.withValues(alpha: 0.9),
              borderRadius: BorderRadius.circular(20.r),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.3),
                width: 1.w,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.2),
                  blurRadius: 4.r,
                  spreadRadius: 1.r,
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Service icon
                Container(
                  width: 20.w,
                  height: 20.h,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    _getServiceIcon(provider.providerName),
                    color: Colors.white,
                    size: 12.sp,
                  ),
                ),
                SizedBox(width: 6.w),
                
                // Service name
                Text(
                  _getShortServiceName(provider.providerName),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12.sp,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(
                        color: Colors.black.withValues(alpha: 0.3),
                        blurRadius: 2.r,
                      ),
                    ],
                  ),
                ),
                
                SizedBox(width: 4.w),
                
                // Type indicator
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.25),
                    borderRadius: BorderRadius.circular(6.r),
                  ),
                  child: Text(
                    isSubscription ? "FREE" : "RENT",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 8.sp,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.3,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  // Helper method to get appropriate icon for each service
  IconData _getServiceIcon(String serviceName) {
    switch (serviceName.toLowerCase()) {
      case 'netflix':
        return Icons.movie;
      case 'disney plus':
      case 'disney+':
        return Icons.auto_awesome;
      case 'amazon prime video':
      case 'prime video':
      case 'amazon video':
        return Icons.local_movies;
      case 'hulu':
        return Icons.play_circle_filled;
      case 'hbo max':
      case 'max':
        return Icons.hd;
      case 'apple tv plus':
      case 'apple tv+':
      case 'apple tv':
        return Icons.apple;
      case 'paramount plus':
      case 'paramount+':
        return Icons.movie_filter;
      case 'peacock':
        return Icons.live_tv;
      default:
        return Icons.play_arrow;
    }
  }

  // Helper method to shorten service names for better display
  String _getShortServiceName(String serviceName) {
    switch (serviceName.toLowerCase()) {
      case 'amazon prime video':
      case 'prime video':
        return 'Prime';
      case 'disney plus':
      case 'disney+':
        return 'Disney+';
      case 'hbo max':
        return 'HBO Max';
      case 'apple tv plus':
      case 'apple tv+':
        return 'Apple TV';
      case 'paramount plus':
      case 'paramount+':
        return 'Paramount+';
      default:
        // Keep original name if 8 characters or less, otherwise truncate
        return serviceName.length <= 8 ? serviceName : '${serviceName.substring(0, 7)}...';
    }
  }

  // Clean providers data class helper
  CleanProviders _getCleanProviders() {
    if (widget.streamingOptions == null) {
      return CleanProviders(subscription: [], rental: []);
    }
    
    // Filter out unwanted providers and deduplicate
    final unwantedProviders = {'Fandango At Home', 'FandangoNOW', 'Fandango'};
    
    final subscriptionMap = <String, StreamingProvider>{};
    final rentalMap = <String, StreamingProvider>{};
    
    // Process subscription services
    for (final provider in widget.streamingOptions!.streaming) {
      if (!unwantedProviders.contains(provider.providerName)) {
        subscriptionMap[provider.providerName] = provider;
      }
    }
    
    // Process rental services (combine rent and buy)
    for (final provider in [...widget.streamingOptions!.rent, ...widget.streamingOptions!.buy]) {
      if (!unwantedProviders.contains(provider.providerName)) {
        rentalMap[provider.providerName] = provider;
      }
    }
    
    // Sort by priority
    final priorityServices = [
      'Netflix', 'Disney Plus', 'Amazon Prime Video', 'Hulu', 
      'HBO Max', 'Apple TV Plus', 'Paramount Plus', 'Peacock',
      'Apple TV', 'Amazon Video'
    ];
    
    List<StreamingProvider> sortProviders(Map<String, StreamingProvider> providers) {
      final sorted = providers.values.toList();
      sorted.sort((a, b) {
        final aPriority = priorityServices.indexOf(a.providerName);
        final bPriority = priorityServices.indexOf(b.providerName);
        
        if (aPriority != -1 && bPriority != -1) {
          return aPriority.compareTo(bPriority);
        } else if (aPriority != -1) {
          return -1;
        } else if (bPriority != -1) {
          return 1;
        } else {
          return a.providerName.compareTo(b.providerName);
        }
      });
      return sorted;
    }
    
    return CleanProviders(
      subscription: sortProviders(subscriptionMap),
      rental: sortProviders(rentalMap),
    );
  }

  // Helper method for opening streaming apps
  void _openStreamingApp(StreamingProvider provider, BuildContext context) {
    try {
      final deepLinks = _getStreamingDeepLinks(provider.providerName);
      if (deepLinks.isNotEmpty) {
        _launchStreamingApp(deepLinks.first, provider.providerName, context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Opening ${provider.providerName}...'),
            backgroundColor: widget.dominantColor,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (e) {
      print('Error opening streaming app: $e');
    }
  }

  List<String> _getStreamingDeepLinks(String providerName) {
    final movieId = widget.movie.id;
    final movieTitle = Uri.encodeComponent(widget.movie.title);
    
    switch (providerName.toLowerCase()) {
      case 'netflix':
        return [
          'netflix://title/$movieId',
          'https://www.netflix.com/search?q=$movieTitle',
        ];
      case 'disney plus':
      case 'disney+':
        return [
          'disneyplus://content/movies/$movieId',
          'https://www.disneyplus.com/search?q=$movieTitle',
        ];
      case 'amazon prime video':
      case 'prime video':
      case 'amazon video':
        return [
          'aiv://aiv/view?gti=$movieId',
          'https://www.amazon.com/s?k=$movieTitle&i=instant-video',
        ];
      case 'hulu':
        return [
          'hulu://movie/$movieId',
          'https://www.hulu.com/search?q=$movieTitle',
        ];
      case 'hbo max':
      case 'max':
        return [
          'hbomax://content/$movieId',
          'https://www.max.com/search?q=$movieTitle',
        ];
      case 'apple tv plus':
      case 'apple tv+':
      case 'apple tv':
        return [
          'https://tv.apple.com/search?q=$movieTitle',
        ];
      default:
        return ['https://www.google.com/search?q=$movieTitle+${Uri.encodeComponent(providerName)}'];
    }
  }

  void _launchStreamingApp(String url, String providerName, BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Opening on $providerName'),
            Text(
              'Search for: "${widget.movie.title}"',
              style: TextStyle(fontSize: 12.sp, color: Colors.white70),
            ),
          ],
        ),
        backgroundColor: widget.dominantColor,
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 4),
      ),
    );
  }
}

// Clean providers data class
class CleanProviders {
  final List<StreamingProvider> subscription;
  final List<StreamingProvider> rental;
  
  CleanProviders({required this.subscription, required this.rental});
  
  int get totalCount => subscription.length + rental.length;
}