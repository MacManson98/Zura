// File: lib/widgets/pending_invitations_widget.dart

import 'package:flutter/material.dart';
import '../models/session_models.dart';
import '../models/user_profile.dart';

class PendingInvitationsWidget extends StatelessWidget {
  final List<SwipeSession> pendingInvitations;
  final UserProfile currentUser;
  final Function(SwipeSession) onAcceptInvitation;
  final Function(SwipeSession) onDeclineInvitation;
  final Function(SwipeSession) onViewInvitation;

  const PendingInvitationsWidget({
    Key? key,
    required this.pendingInvitations,
    required this.currentUser,
    required this.onAcceptInvitation,
    required this.onDeclineInvitation,
    required this.onViewInvitation,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (pendingInvitations.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      margin: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.mail_outline,
                color: Colors.orange,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Pending Invitations (${pendingInvitations.length})',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: pendingInvitations.length,
            separatorBuilder: (context, index) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final invitation = pendingInvitations[index];
              return _buildInvitationCard(context, invitation);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildInvitationCard(BuildContext context, SwipeSession invitation) {
    final isExpired = _isInvitationExpired(invitation);
    final timeAgo = _getTimeAgo(invitation.createdAt);
    
    return Container(
      decoration: BoxDecoration(
        color: isExpired ? Colors.grey[900] : Colors.grey[850],
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isExpired ? Colors.grey[700]! : Colors.orange.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isExpired ? null : () => onViewInvitation(invitation),
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header with host info and session type
                Row(
                  children: [
                    // Host avatar
                    CircleAvatar(
                      radius: 20,
                      backgroundColor: Colors.red,
                      child: Text(
                        invitation.hostName.isNotEmpty 
                            ? invitation.hostName[0].toUpperCase()
                            : '?',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    
                    // Invitation details
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${invitation.hostName} invited you',
                            style: TextStyle(
                              color: isExpired ? Colors.grey[400] : Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Row(
                            children: [
                              Icon(
                                _getSessionIcon(invitation),
                                color: isExpired ? Colors.grey[500] : Colors.grey[400],
                                size: 14,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                _getSessionTypeText(invitation),
                                style: TextStyle(
                                  color: isExpired ? Colors.grey[500] : Colors.grey[400],
                                  fontSize: 12,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                '• $timeAgo',
                                style: TextStyle(
                                  color: isExpired ? Colors.grey[600] : Colors.grey[500],
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    
                    // Expiry indicator
                    if (isExpired)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.red.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          'Expired',
                          style: TextStyle(
                            color: Colors.red[300],
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // Session details
                if (invitation.hasMoodSelected) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: isExpired ? Colors.grey[800] : Colors.red.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: isExpired ? Colors.grey[700]! : Colors.red.withValues(alpha: 0.3),
                      ),
                    ),
                    child: Row(
                      children: [
                        Text(
                          invitation.selectedMoodEmoji ?? '🎬',
                          style: const TextStyle(fontSize: 18),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                invitation.selectedMoodName,
                                style: TextStyle(
                                  color: isExpired ? Colors.grey[400] : Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                              if (invitation.streamingSettings != null) ...[
                                const SizedBox(height: 2),
                                Text(
                                  invitation.sessionStreamingSummary,
                                  style: TextStyle(
                                    color: isExpired ? Colors.grey[500] : Colors.grey[400],
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                              if (invitation.additionalGenres.isNotEmpty) ...[
                                const SizedBox(height: 2),
                                Text(
                                  'Genres: ${invitation.additionalGenres.join(', ')}',
                                  style: TextStyle(
                                    color: isExpired ? Colors.grey[500] : Colors.grey[400],
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
                
                // Streaming compatibility check
                if (invitation.streamingSettings != null && !isExpired)
                  _buildStreamingCompatibility(invitation),
                
                // Action buttons
                if (!isExpired) ...[
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => onDeclineInvitation(invitation),
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.grey[600]!),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                          child: Text(
                            'Decline',
                            style: TextStyle(color: Colors.grey[300]),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        flex: 2,
                        child: ElevatedButton(
                          onPressed: () => onAcceptInvitation(invitation),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                          child: const Text(
                            'Join Session',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStreamingCompatibility(SwipeSession invitation) {
    final userServices = currentUser.streamingPreferences.ownedServices;
    final sessionServices = invitation.streamingSettings!.availableServices;
    final compatibility = _calculateStreamingCompatibility(invitation);
    
    Color compatibilityColor;
    IconData compatibilityIcon;
    String compatibilityText;
    
    if (compatibility >= 0.8) {
      compatibilityColor = Colors.green;
      compatibilityIcon = Icons.check_circle;
      compatibilityText = 'Great streaming match!';
    } else if (compatibility >= 0.5) {
      compatibilityColor = Colors.orange;
      compatibilityIcon = Icons.warning;
      compatibilityText = 'Some streaming compatibility';
    } else {
      compatibilityColor = Colors.red;
      compatibilityIcon = Icons.error;
      compatibilityText = 'Limited streaming options';
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: compatibilityColor.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: compatibilityColor.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Icon(compatibilityIcon, color: compatibilityColor, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  compatibilityText,
                  style: TextStyle(
                    color: compatibilityColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
                if (sessionServices.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(
                    'Common: ${sessionServices.intersection(userServices).join(', ')}',
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 10,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Helper methods
  
  bool _isInvitationExpired(SwipeSession invitation) {
    // Invitations expire after 24 hours
    final expiryTime = invitation.createdAt.add(const Duration(hours: 24));
    return DateTime.now().isAfter(expiryTime);
  }
  
  String _getTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    
    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }
  
  IconData _getSessionIcon(SwipeSession invitation) {
    switch (invitation.inviteType) {
      case InvitationType.friend:
        return Icons.person;
      case InvitationType.code:
        return Icons.code;
      case InvitationType.qr:
        return Icons.qr_code;
    }
  }
  
  String _getSessionTypeText(SwipeSession invitation) {
    final participantCount = invitation.participantIds.length;
    if (participantCount <= 2) {
      return 'Friend session';
    } else {
      return 'Group session (${participantCount} people)';
    }
  }
  
  double _calculateStreamingCompatibility(SwipeSession invitation) {
    final userServices = currentUser.streamingPreferences.ownedServices;
    final sessionServices = invitation.streamingSettings!.someoneHasServices;
    
    if (sessionServices.isEmpty) return 0.0;
    
    final commonServices = userServices.intersection(sessionServices);
    return commonServices.length / sessionServices.length;
  }
}