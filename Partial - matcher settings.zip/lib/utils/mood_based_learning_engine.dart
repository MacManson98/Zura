// File: lib/utils/enhanced_mood_based_learning_engine.dart

import '../movie.dart';
import '../models/user_profile.dart';

// Enhanced mood-based session management with streaming and genre filters
enum CurrentMood {
  trueStory('True Stories', '📖', ['Biography', 'History', 'Drama', 'Documentary'], ['Based on a True Story', 'Real Events', 'True Story']),
  emotional('Deep & Emotional', '💭', ['Drama', 'Romance'], ['Emotional', 'Heartwarming', 'Moving']),
  thoughtful('Mind-Bending', '🤔', ['Drama', 'Sci-Fi', 'Mystery', 'Thriller'], ['Mind-Bending', 'Complex', 'Thought-Provoking', 'Twist']),
  lighthearted('Laid-Back & Fun', '🎉', ['Family', 'Animation', 'Comedy', 'TV Movie'], ['Comfort', 'Peaceful', 'Wholesome', 'Cozy', 'Funny', 'Silly', 'Upbeat']),
  scary('Thrills & Chills', '😱', ['Horror', 'Thriller'], ['Scary', 'Suspenseful', 'Dark']),
  romantic('Love Stories', '💕', ['Romance'], ['Romantic', 'Sweet', 'Heartwarming']),
  adventurous('Epic Adventure', '🗺️', ['Adventure', 'Fantasy', 'Action'], ['Epic', 'Action-Packed', 'Journey']);

  const CurrentMood(this.displayName, this.emoji, this.preferredGenres, this.preferredVibes);
  
  final String displayName;
  final String emoji;
  final List<String> preferredGenres;
  final List<String> preferredVibes;
}

class SessionContext {
  final CurrentMood moods;
  final DateTime startTime;
  final List<String> groupMemberIds;
  
  SessionContext({
    required this.moods,
    required this.groupMemberIds,
    DateTime? startTime,
  }) : startTime = startTime ?? DateTime.now();
}

class MoodBasedLearningEngine {

  static Future<List<Movie>> generateBlendedMoodSession({
    required UserProfile user,
    required List<Movie> movieDatabase,
    required List<CurrentMood> selectedMoods,
    required Set<String> seenMovieIds,
    required Set<String> sessionPassedMovieIds,
    int sessionSize = 30,
  }) async {
    print("🎭 Generating PURE blended mood session for: ${selectedMoods.map((m) => m.displayName).join(' + ')}");
    
    // Combine all preferred genres and vibes from selected moods
    final Set<String> allPreferredGenres = {};
    final Set<String> allPreferredVibes = {};
    
    for (final mood in selectedMoods) {
      allPreferredGenres.addAll(mood.preferredGenres);
      allPreferredVibes.addAll(mood.preferredVibes);
    }
    
    print("   Combined genres: ${allPreferredGenres.join(', ')}");
    print("   Combined vibes: ${allPreferredVibes.join(', ')}");
        
    // Filter movies that match any of the blended criteria
    final blendedMovies = <Movie>[];
    final excludedMovieIds = <String>{};
    excludedMovieIds.addAll(seenMovieIds);
    excludedMovieIds.addAll(sessionPassedMovieIds);
    
    for (final movie in movieDatabase) {
      if (excludedMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      
      final hasGenreMatch = movie.genres.any((g) => allPreferredGenres.contains(g));
      final hasVibeMatch = movie.tags.any((v) => allPreferredVibes.contains(v));
      
      if (hasGenreMatch || hasVibeMatch) {
        blendedMovies.add(movie);
      }
    }
    
    // Apply light personalization
    final scoredMovies = SessionSettings_lightPersonalization(blendedMovies, user, null);
    
    // Balance personalization with discovery
    final result = _balancePersonalizationWithDiscovery(scoredMovies, sessionSize);
    
    print("🎬 Generated ${result.length} blended mood movies");
    return result;
  }
  
  /// 🆕 ENHANCED: Generate mood-based session with streaming and genre filters
  static Future<List<Movie>> generateMoodBasedSession({
    required UserProfile user,
    required List<Movie> movieDatabase,
    required SessionContext sessionContext,
    required Set<String> seenMovieIds,
    required Set<String> sessionPassedMovieIds,
    int sessionSize = 30,
    StreamingPreferences? streamingPreferences, // 🆕 NEW
    Set<String>? additionalGenres,              // 🆕 NEW
  }) async {
    print("🎭 Generating enhanced mood session: ${sessionContext.moods.displayName}");
    print("   Target genres: ${sessionContext.moods.preferredGenres}");
    print("   Target vibes: ${sessionContext.moods.preferredVibes}");
    
    if (streamingPreferences != null) {
      print("   Streaming filter: ${streamingPreferences.ownedServices.length} services");
    }
    
    if (additionalGenres != null && additionalGenres.isNotEmpty) {
      print("   Additional genres: ${additionalGenres.join(', ')}");
    }
    
    // Step 1: Filter by mood with enhanced criteria
    final moodFilteredMovies = _filterByMood(
      movieDatabase, 
      sessionContext.moods, 
      seenMovieIds, 
      sessionPassedMovieIds,
      streamingPreferences: streamingPreferences,
      additionalGenres: additionalGenres,
    );
    
    if (moodFilteredMovies.isEmpty) {
      print("⚠️ No movies found for enhanced criteria, falling back");
      return _getFallbackMoviesEnhanced(movieDatabase, seenMovieIds, sessionSize, streamingPreferences);
    }
    
    // Step 2: Light personalization within filtered results
    final scoredMovies = SessionSettings_lightPersonalization(moodFilteredMovies, user, streamingPreferences);
    
    // Step 3: Balance personalization with discovery
    final result = _balancePersonalizationWithDiscovery(scoredMovies, sessionSize);
    
    print("🎬 Generated ${result.length} enhanced mood movies");
    print("   Sample: ${result.take(3).map((m) => m.title).join(', ')}");
    
    return result;
  }
  
  /// 🆕 ENHANCED: Generate session with streaming preferences only (no mood)
  static Future<List<Movie>> generateStreamingFilteredSession({
    required UserProfile user,
    required List<Movie> movieDatabase,
    required Set<String> seenMovieIds,
    required Set<String> sessionPassedMovieIds,
    required StreamingPreferences streamingPreferences,
    Set<String>? additionalGenres,
    int sessionSize = 30,
  }) async {
    print("📺 Generating streaming-filtered session");
    print("   Services: ${streamingPreferences.ownedServices.join(', ')}");
    print("   Willing to rent: ${streamingPreferences.willingToRent}");
    
    final filteredMovies = <Movie>[];
    final excludedMovieIds = <String>{};
    excludedMovieIds.addAll(seenMovieIds);
    excludedMovieIds.addAll(sessionPassedMovieIds);
    
    for (final movie in movieDatabase) {
      if (excludedMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      
      // Apply streaming filter
      if (!streamingPreferences.canWatchMovie(movie)) continue;
      
      // Apply genre filter if specified
      if (additionalGenres != null && additionalGenres.isNotEmpty) {
        final hasGenreMatch = movie.genres.any((g) => additionalGenres.contains(g));
        if (!hasGenreMatch) continue;
      }
      
      filteredMovies.add(movie);
    }
    
    if (filteredMovies.isEmpty) {
      print("⚠️ Streaming filter too restrictive, using fallback");
      return _getFallbackMoviesEnhanced(movieDatabase, seenMovieIds, sessionSize, streamingPreferences);
    }
    
    // Light personalization
    final scoredMovies = SessionSettings_lightPersonalization(filteredMovies, user, streamingPreferences);
    
    // Balance and return
    final result = _balancePersonalizationWithDiscovery(scoredMovies, sessionSize);
    
    print("📺 Generated ${result.length} streaming-filtered movies");
    return result;
  }
  
  /// 🆕 ENHANCED: Generate group session with streaming consensus
  static Future<List<Movie>> generateGroupSessionEnhanced({
    required List<UserProfile> groupMembers,
    required List<Movie> movieDatabase,
    required SessionContext sessionContext,
    required Set<String> seenMovieIds,
    StreamingPreferences? groupStreamingPreferences,
    Set<String>? additionalGenres,
    int sessionSize = 25,
  }) async {
    print("👥 Generating enhanced group session for ${groupMembers.length} people");
    print("   Mood: ${sessionContext.moods.displayName}");
    
    // Step 1: Filter by mood and group preferences
    final moodFilteredMovies = _filterByMood(
      movieDatabase, 
      sessionContext.moods, 
      seenMovieIds, 
      <String>{}, // No session passed movies for group sessions
      streamingPreferences: groupStreamingPreferences,
      additionalGenres: additionalGenres,
    );
    
    if (moodFilteredMovies.isEmpty) {
      print("⚠️ No movies found for group criteria, using fallback");
      return _getFallbackMoviesEnhanced(movieDatabase, seenMovieIds, sessionSize, groupStreamingPreferences);
    }
    
    // Step 2: Group personalization with streaming awareness
    final scoredMovies = _lightGroupPersonalization(
      moodFilteredMovies, 
      groupMembers,
      groupStreamingPreferences,
    );
    
    // Step 3: Create shared pool
    final sharedPool = _createSharedPoolEnhanced(scoredMovies, sessionSize);
    
    print("🎬 Generated ${sharedPool.length} enhanced group movies");
    return sharedPool;
  }
  
  /// 🆕 ENHANCED: Generate blended mood session with filters
  static Future<List<Movie>> generateBlendedMoodSessionEnhanced({
    required UserProfile user,
    required List<Movie> movieDatabase,
    required List<CurrentMood> selectedMoods,
    required Set<String> seenMovieIds,
    required Set<String> sessionPassedMovieIds,
    StreamingPreferences? streamingPreferences,
    Set<String>? additionalGenres,
    int sessionSize = 30,
  }) async {
    print("🎭 Generating enhanced blended mood session: ${selectedMoods.map((m) => m.displayName).join(' + ')}");
    
    // Combine all preferred genres and vibes
    final Set<String> allPreferredGenres = {};
    final Set<String> allPreferredVibes = {};
    
    for (final mood in selectedMoods) {
      allPreferredGenres.addAll(mood.preferredGenres);
      allPreferredVibes.addAll(mood.preferredVibes);
    }
    
    // Add additional genres if specified
    if (additionalGenres != null) {
      allPreferredGenres.addAll(additionalGenres);
    }
    
    print("   Combined genres: ${allPreferredGenres.join(', ')}");
    print("   Combined vibes: ${allPreferredVibes.join(', ')}");
    
    // Filter movies with enhanced criteria
    final blendedMovies = <Movie>[];
    final excludedMovieIds = <String>{};
    excludedMovieIds.addAll(seenMovieIds);
    excludedMovieIds.addAll(sessionPassedMovieIds);
    
    for (final movie in movieDatabase) {
      if (excludedMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      
      // Apply streaming filter if specified
      if (streamingPreferences != null && !streamingPreferences.canWatchMovie(movie)) continue;
      
      // Must match genre OR vibe
      final hasGenreMatch = movie.genres.any((g) => allPreferredGenres.contains(g));
      final hasVibeMatch = movie.tags.any((v) => allPreferredVibes.contains(v));
      
      if (hasGenreMatch || hasVibeMatch) {
        blendedMovies.add(movie);
      }
    }
    
    // Apply light personalization
    final scoredMovies = SessionSettings_lightPersonalization(blendedMovies, user, streamingPreferences);
    
    // Balance and return
    final result = _balancePersonalizationWithDiscovery(scoredMovies, sessionSize);
    
    print("🎬 Generated ${result.length} enhanced blended mood movies");
    return result;
  }
  
  // PRIVATE ENHANCED HELPER METHODS
  
  /// 🆕 ENHANCED: Filter movies by mood with streaming and genre support
  static List<Movie> _filterByMood(
    List<Movie> movieDatabase, 
    CurrentMood mood, 
    Set<String> seenMovieIds, 
    Set<String> sessionPassedMovieIds, {
    StreamingPreferences? streamingPreferences,
    Set<String>? additionalGenres,
  }) {
    final moodMovies = <Movie>[];
    final targetGenres = mood.preferredGenres.toSet();
    final targetVibes = mood.preferredVibes.toSet();
    
    // Add additional genres to target genres
    if (additionalGenres != null) {
      targetGenres.addAll(additionalGenres);
    }
    
    final excludedMovieIds = <String>{};
    excludedMovieIds.addAll(seenMovieIds);
    excludedMovieIds.addAll(sessionPassedMovieIds);

    final disqualifyingTagsPerMood = {
      'Laid-Back & Fun': {
        'Disturbing', 'Dark', 'Mind-Bending', 'Twisty', 'Grim', 'Sad', 'Philosophical',
        'Traumatic', 'Violent', 'War', 'Tragic', 'Horror', 'Slow Burn', 'Emotional',
        'Trauma', 'Gory', 'Grief', 'Serious', 'Heavy', 'Depressing', 'Romantic Drama',
        'Melancholy', 'Cerebral', 'Slasher',
      },
      'Deep & Emotional': {
        'Twisty', 'Action-Packed', 'Violent', 'Gory', 'Disturbing', 'Supernatural',
        'Slasher', 'Fantasy', 'Abstract', 'High Stakes', 'Fast-Paced', 'Experimental',
        'Over-Stylized', 'Weird', 'Silly', 'Parody', 'Horror', 'Dark Comedy', 'Stalker',
        'Cynical Humor', 'Cringe', 'Uncomfortable', 'Obsession', 'Psychological Comedy'
      },
      'Mind-Bending': {
        'Silly', 'Wholesome', 'Light-Hearted', 'Family-Friendly', 'Romantic Comedy',
        'Slapstick', 'Simple', 'Straightforward', 'Comfort', 'Cozy', 'Heartwarming',
        'Musical', 'Kids', 'Rewatchable', 'Uplifting', 'Cheesy', 'Predictable'
      },
      'Thrills & Chills': {
        'Comfort', 'Cozy', 'Peaceful', 'Wholesome', 'Heartwarming', 'Feel-Good',
        'Romantic', 'Light-Hearted', 'Family-Friendly', 'Animation', 'Musical',
        'Funny', 'Silly', 'Uplifting', 'Easy Watch', 'Kids', 'Rewatchable', 'Cheesy'
      },
      'Love Stories': {
        'Horror', 'Violent', 'Dark', 'Disturbing', 'Mind-Bending', 'Surrealism',
        'Twisty', 'Sci-Fi/Techy', 'War', 'Crime', 'Gory', 'Slasher', 'Supernatural',
        'Abstract', 'High Stakes', 'Action-Packed', 'Cynical', 'Unromantic', 'Grim',
        'Trauma', 'Philosophical', 'Experimental'
      },
      'Epic Adventure': {
        'Romantic', 'Heartwarming', 'Wholesome', 'Cozy', 'Light-Hearted', 'Slow Burn',
        'Philosophical', 'Abstract', 'Surrealism', 'Emotional', 'Musical',
        'Family-Friendly', 'Slice of Life', 'Peaceful', 'Minimalist', 'Feel-Good',
        'Domestic', 'Cerebral', 'Comedy-Driven', 'Sad', 'Tragic'
      },
      'True Stories': {
        'Sci-Fi/Techy', 'Fantasy', 'Supernatural', 'Mind-Bending', 'Surrealism',
        'Magical', 'Alien', 'Time Travel', 'Multiverse', 'Mythical', 'Epic Fantasy',
        'Superhero', 'Paranormal', 'Witchcraft', 'Space', 'Cyberpunk', 'Monster',
        'Fictional', 'Made Up', 'Alternate Reality', 'Dystopian'
      }
    };

    final disqualifyingTags = disqualifyingTagsPerMood[mood.displayName] ?? {};

    for (final movie in movieDatabase) {
      if (excludedMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;

      // Runtime check (only for Laid-Back & Fun)
      if (mood.displayName == 'Laid-Back & Fun' && movie.runtime != null && movie.runtime! > 130) continue;

      // 🆕 ENHANCED: Apply streaming filter
      if (streamingPreferences != null && !streamingPreferences.canWatchMovie(movie)) continue;

      // Disqualifying tags check
      final hasConflictTag = movie.tags.any((tag) => disqualifyingTags.contains(tag));
      if (hasConflictTag) continue;

      // Must match genre OR vibe
      final hasGenreMatch = movie.genres.any((g) => targetGenres.contains(g));
      final hasVibeMatch = movie.tags.any((v) => targetVibes.contains(v));

      if (hasGenreMatch || hasVibeMatch) {
        moodMovies.add(movie);
      }
    }
    
    print("✅ Found ${moodMovies.length} movies matching enhanced criteria");
    return moodMovies;
  }
  
  /// 🆕 ENHANCED: Light personalization with streaming awareness
  static Map<Movie, double> SessionSettings_lightPersonalization(
    List<Movie> movies, 
    UserProfile user,
    StreamingPreferences? streamingPreferences,
  ) {
    final scoredMovies = <Movie, double>{};
    
    for (final movie in movies) {
      double score = 5.0; // Base "good for tonight" score
      
      // Light user preference boost
      for (final genre in movie.genres) {
        final userLikes = user.genreScores[genre] ?? 0;
        final userDislikes = user.dislikeScores[genre] ?? 0;
        score += (userLikes * 0.3) - (userDislikes * 0.2);
      }
      
      for (final vibe in movie.tags) {
        final userLikes = user.vibeScores[vibe] ?? 0;
        final userDislikes = user.dislikeVibeScores[vibe] ?? 0;
        score += (userLikes * 0.3) - (userDislikes * 0.2);
      }
      
      // Quality boost
      if (movie.rating != null && movie.rating! > 7.0) {
        score += 1.5;
      }
      
      // Popular movies boost
      if (movie.voteCount != null && movie.voteCount! > 5000) {
        score += 1.0;
      }
      
      // 🆕 ENHANCED: Streaming availability boost
      if (streamingPreferences != null) {
        // Boost movies available on user's subscriptions
        if (movie.availableOn.any((service) => streamingPreferences.ownedServices.contains(service))) {
          score += 2.0; // Strong boost for subscription availability
        }
        // Smaller boost for rental if user is willing
        else if (streamingPreferences.willingToRent && movie.rentOn.isNotEmpty) {
          score += 0.5;
        }
      }
      
      scoredMovies[movie] = score;
    }
    
    return scoredMovies;
  }
  
  /// 🆕 ENHANCED: Group personalization with streaming consensus
  static Map<Movie, double> _lightGroupPersonalization(
    List<Movie> movies, 
    List<UserProfile> groupMembers,
    StreamingPreferences? groupStreamingPreferences,
  ) {
    final scoredMovies = <Movie, double>{};
    
    for (final movie in movies) {
      double score = 5.0; // Base score
      
      // Light group preference calculation
      double groupBonus = 0.0;
      bool anyoneStronglyDislikes = false;
      
      for (final member in groupMembers) {
        double memberScore = 0.0;
        
        for (final genre in movie.genres) {
          final memberLikes = member.genreScores[genre] ?? 0;
          final memberDislikes = member.dislikeScores[genre] ?? 0;
          memberScore += (memberLikes * 0.2) - (memberDislikes * 0.3);
          
          if (memberDislikes > 4.0) {
            anyoneStronglyDislikes = true;
            break;
          }
        }
        
        for (final vibe in movie.tags) {
          final memberLikes = member.vibeScores[vibe] ?? 0;
          final memberDislikes = member.dislikeVibeScores[vibe] ?? 0;
          memberScore += (memberLikes * 0.2) - (memberDislikes * 0.3);
        }
        
        groupBonus += memberScore;
      }
      
      // Skip movies anyone strongly dislikes
      if (anyoneStronglyDislikes) continue;
      
      // Add group preference
      score += (groupBonus / groupMembers.length);
      
      // Extra boost for crowd-pleasers
      if (movie.rating != null && movie.rating! > 7.5) {
        score += 2.0;
      }
      
      // 🆕 ENHANCED: Group streaming boost
      if (groupStreamingPreferences != null) {
        // Strong boost if available on common services
        if (movie.availableOn.any((service) => groupStreamingPreferences.ownedServices.contains(service))) {
          score += 3.0; // Higher boost for group consensus
        }
        // Rental boost if group is willing
        else if (groupStreamingPreferences.willingToRent && movie.rentOn.isNotEmpty) {
          score += 1.0;
        }
      }
      
      scoredMovies[movie] = score;
    }
    
    return scoredMovies;
  }
  
  /// Enhanced fallback movies with streaming awareness
  static List<Movie> _getFallbackMoviesEnhanced(
    List<Movie> movieDatabase, 
    Set<String> excludedMovieIds, 
    int count,
    StreamingPreferences? streamingPreferences,
  ) {
    final fallbackMovies = movieDatabase.where((movie) => 
        !excludedMovieIds.contains(movie.id) && 
        _meetsQualityThreshold(movie) && 
        _isSfwMovie(movie) &&
        (streamingPreferences == null || streamingPreferences.canWatchMovie(movie))
    ).toList();
    
    // If streaming filter is too restrictive, ignore it for fallback
    if (fallbackMovies.length < count ~/ 2 && streamingPreferences != null) {
      print("⚠️ Streaming filter too restrictive for fallback, ignoring");
      return movieDatabase.where((movie) => 
          !excludedMovieIds.contains(movie.id) && 
          _meetsQualityThreshold(movie) && 
          _isSfwMovie(movie)
      ).toList()..shuffle();
    }
    
    fallbackMovies.shuffle();
    return fallbackMovies.take(count).toList();
  }
  
  /// Enhanced shared pool creation
  static List<Movie> _createSharedPoolEnhanced(Map<Movie, double> scoredMovies, int sessionSize) {
    final sorted = scoredMovies.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    // For groups, focus more on consensus picks (80% top-rated, 20% discovery)
    final topCount = (sessionSize * 0.8).round();
    final topMovies = sorted.take(topCount).map((e) => e.key).toList();
    
    final remaining = sorted.skip(topCount).map((e) => e.key).toList();
    remaining.shuffle();
    final discoveryCount = sessionSize - topCount;
    final discoveryMovies = remaining.take(discoveryCount).toList();
    
    // DON'T shuffle for groups - everyone needs same order
    final result = [...topMovies, ...discoveryMovies];
    
    return result.take(sessionSize).toList();
  }
  
  // Keep all existing helper methods...
  static List<Movie> _balancePersonalizationWithDiscovery(Map<Movie, double> scoredMovies, int sessionSize) {
    final sorted = scoredMovies.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    final topCount = (sessionSize * 0.7).round();
    final topMovies = sorted.take(topCount).map((e) => e.key).toList();
    
    final remaining = sorted.skip(topCount).map((e) => e.key).toList();
    remaining.shuffle();
    final discoveryCount = sessionSize - topCount;
    final discoveryMovies = remaining.take(discoveryCount).toList();
    
    final result = [...topMovies, ...discoveryMovies];
    result.shuffle();
    
    return result.take(sessionSize).toList();
  }
  
  /// Light learning for mood interactions (unchanged)
  static void learnFromMoodInteraction(UserProfile user, Movie movie, SessionContext context, bool isLike) {
    print("📊 LIGHT LEARNING: ${isLike ? 'LIKE' : 'PASS'} ${movie.title} in ${context.moods.displayName} context");
    
    if (isLike) {
      for (final genre in movie.genres) {
        user.genreScores[genre] = _updateScore(user.genreScores[genre] ?? 0, 0.3, true);
      }
      
      for (final vibe in movie.tags) {
        user.vibeScores[vibe] = _updateScore(user.vibeScores[vibe] ?? 0, 0.3, true);
      }
      
      user.likedMovies.add(movie);
      user.likedMovieIds.add(movie.id);
    } else {
      for (final genre in movie.genres) {
        user.dislikeScores[genre] = _updateScore(user.dislikeScores[genre] ?? 0, 0.1, true);
      }
      
      user.passedMovieIds.add(movie.id);
    }
    
    user.lastActivityDate = DateTime.now();
    print("   ⚠️ This learning will NOT affect current mood session - only future sessions");
  }
  
  static double _updateScore(double currentScore, double weight, bool isPositive) {
    const double maxScore = 20.0;
    const double minScore = 0.0;
    
    final newScore = isPositive 
        ? currentScore + weight 
        : (currentScore - weight).clamp(minScore, double.infinity);
    return newScore.clamp(minScore, maxScore);
  }
  
  static bool _meetsQualityThreshold(Movie movie) {
    return movie.posterUrl.isNotEmpty &&
           movie.rating != null &&
           movie.rating! >= 5.0 &&
           movie.voteCount != null &&
           movie.voteCount! >= 1000;
  }
  
  static bool _isSfwMovie(Movie movie) {
    final bannedKeywords = ['porn', 'erotic', 'xxx', 'adult', 'sex', 'nude', 'strip'];
    final lcTitle = movie.title.toLowerCase();
    final lcOverview = movie.overview.toLowerCase();
    return !bannedKeywords.any((kw) => lcTitle.contains(kw) || lcOverview.contains(kw));
  }

  // Public wrappers for helper methods
  static bool meetsQualityThreshold(Movie movie) {
    return _meetsQualityThreshold(movie);
  }

  static bool isSfwMovie(Movie movie) {
    return _isSfwMovie(movie);
  }
}