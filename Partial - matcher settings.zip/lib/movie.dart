// File: lib/movie.dart (Enhanced Version with Streaming)

class Movie {
  final String id;
  final String title;
  final String posterUrl;
  final String overview;
  final List<String> cast;
  final List<String> genres;
  final List<String> tags; // Your vibe tags + TMDB keywords
  
  // Enhanced fields from your database
  final List<String>? subGenres; // Your enhanced vibe system
  final int? runtime; // Runtime in minutes
  final double? rating; // TMDB vote_average
  final int? voteCount; // TMDB vote_count
  final String? releaseDate; // Release date
  final String? originalLanguage; // Original language
  final double? rottenTomatoesScore;
  final List<String> directors;
  final List<String> writers;
  
  // 🆕 NEW: Streaming availability
  final List<String> availableOn;     // Free/subscription services (Netflix, Hulu, etc.)
  final List<String> rentOn;          // Rental services (Amazon Prime Video, Apple TV, etc.)
  final List<String> buyOn;           // Purchase services
  final List<String> allServices;     // All services combined
  

  Movie({
    required this.id,
    required this.title,
    required this.posterUrl,
    required this.overview,
    required this.cast,
    required this.genres,
    required this.tags,
    this.subGenres,
    this.runtime,
    this.rating,
    this.voteCount,
    this.releaseDate,
    this.originalLanguage,
    this.rottenTomatoesScore,
    this.directors = const [],
    this.writers = const [],
    // Streaming defaults
    this.availableOn = const [],
    this.rentOn = const [],
    this.buyOn = const [],
    this.allServices = const [],
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'posterUrl': posterUrl,
      'overview': overview,
      'cast': cast,
      'genres': genres,
      'tags': tags,
      'subGenres': subGenres,
      'runtime': runtime,
      'rating': rating,
      'voteCount': voteCount,
      'releaseDate': releaseDate,
      'originalLanguage': originalLanguage,
      'directors': directors,
      'writers': writers,
      // Streaming data
      'available_on': availableOn,
      'rent_on': rentOn,
      'buy_on': buyOn,
      'all_services': allServices,
    };
  }

  factory Movie.fromJson(Map<String, dynamic> json) {
    return Movie(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      posterUrl: json['posterUrl'] ?? '',
      overview: json['overview'] ?? '',
      cast: List<String>.from(json['cast'] ?? []),
      genres: List<String>.from(json['genres'] ?? []),
      tags: List<String>.from(json['tags'] ?? []),
      subGenres: json['subGenres'] != null ? List<String>.from(json['subGenres']) : null,
      runtime: json['runtime']?.toInt(),
      rating: json['rating']?.toDouble(),
      voteCount: json['voteCount']?.toInt(),
      releaseDate: json['releaseDate'],
      originalLanguage: json['originalLanguage'],
      rottenTomatoesScore: json['rottenTomatoesScore'],
      directors: List<String>.from(json['directors'] ?? []),
      writers: List<String>.from(json['writers'] ?? []),
      // Streaming data
      availableOn: List<String>.from(json['available_on'] ?? []),
      rentOn: List<String>.from(json['rent_on'] ?? []),
      buyOn: List<String>.from(json['buy_on'] ?? []),
      allServices: List<String>.from(json['all_services'] ?? []),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is Movie && id == other.id);

  @override
  int get hashCode => id.hashCode;
  
  /// Helper methods for the learning engine
  
  /// Get quality score based on rating and vote count
  double get qualityScore {
    if (rating == null || voteCount == null) return 0.0;
    
    // Weighted score considering both rating and popularity
    final ratingWeight = (rating! / 10.0) * 0.7;
    final popularityWeight = (voteCount! > 1000 ? 1.0 : voteCount! / 1000.0) * 0.3;
    
    return ratingWeight + popularityWeight;
  }
  
  /// Check if this is a high-quality movie suitable for discovery
  bool get isHighQuality {
    return rating != null && 
           rating! >= 7.0 && 
           voteCount != null && 
           voteCount! >= 100;
  }
  
  /// Get runtime category for learning purposes
  String get runtimeCategory {
    if (runtime == null) return 'unknown';
    if (runtime! < 90) return 'short';
    if (runtime! < 130) return 'medium';
    return 'long';
  }
  
  /// Get rating category for learning purposes
  String get ratingCategory {
    if (rating == null) return 'unknown';
    if (rating! < 6.0) return 'low';
    if (rating! < 7.5) return 'medium';
    if (rating! < 8.5) return 'high';
    return 'exceptional';
  }
  
  /// Check if movie is in English (for language preference learning)
  bool get isEnglish => originalLanguage == 'en';
  
  /// Get decade for potential trend analysis
  String get decade {
    if (releaseDate == null || releaseDate!.length < 4) return 'unknown';
    try {
      final year = int.parse(releaseDate!.substring(0, 4));
      final decade = (year ~/ 10) * 10;
      return '${decade}s';
    } catch (e) {
      return 'unknown';
    }
  }
  
  // 🆕 NEW: Streaming availability helpers
  
  /// Check if movie is available on any subscription service
  bool get hasSubscriptionStreaming => availableOn.isNotEmpty;
  
  /// Check if movie is available for rental
  bool get hasRentalOption => rentOn.isNotEmpty;
  
  /// Check if movie is available for purchase
  bool get hasPurchaseOption => buyOn.isNotEmpty;
  
  /// Check if movie is available on any streaming service at all
  bool get hasAnyStreaming => allServices.isNotEmpty;
  
  /// Check if movie is available on specific service
  bool isAvailableOn(String service) {
    return availableOn.contains(service) || 
           rentOn.contains(service) || 
           buyOn.contains(service);
  }
  
  /// Check if movie is free to watch (subscription or free services)
  bool isAvailableOnSubscription(String service) {
    return availableOn.contains(service);
  }
  
  /// Get all streaming options formatted for display
  String get streamingDisplay {
    final List<String> options = [];
    
    if (availableOn.isNotEmpty) {
      options.add("Stream: ${availableOn.join(', ')}");
    }
    
    if (rentOn.isNotEmpty) {
      options.add("Rent: ${rentOn.join(', ')}");
    }
    
    if (options.isEmpty) {
      return "No streaming options available";
    }
    
    return options.join(' • ');
  }
  
  /// Get primary streaming service (first subscription service, or first rental)
  String? get primaryStreamingService {
    if (availableOn.isNotEmpty) return availableOn.first;
    if (rentOn.isNotEmpty) return rentOn.first;
    if (buyOn.isNotEmpty) return buyOn.first;
    return null;
  }
}