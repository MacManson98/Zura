import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'screens/auth/login_screen.dart';
import 'main_navigation.dart';
import 'models/user_profile.dart';
import 'movie.dart';
import 'utils/tmdb_api.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final user = snapshot.data;
        print('🔥 Auth state changed:');
        print('  user: $user');
        print('  isAnonymous: ${user?.isAnonymous}');
        print('  uid: ${user?.uid}');
        
        if (user == null || user.isAnonymous) {
          print('➡️ Showing LoginScreen');
          return const LoginScreen();
        }

        return FutureBuilder<UserProfileScreenBundle>(
          future: _loadUserProfileAndMovies(user.uid),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              );
            }

            if (snapshot.hasError) {
              print('❌ Error loading profile: ${snapshot.error}');
              return const Scaffold(
                body: Center(child: Text('Error loading profile')),
              );
            }

            final data = snapshot.data!;
            
            // ✅ NO ONBOARDING - Direct to main app
            print('➡️ User authenticated, showing MainNavigation');
            return MainNavigation(
              profile: data.profile, 
              movies: data.movies,
            );
          },
        );
      },
    );
  }

  Future<UserProfileScreenBundle> _loadUserProfileAndMovies(String uid) async {
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();

    late final UserProfile profile;

    if (!doc.exists) {
      // ✅ NEW USER - Create basic profile, no onboarding needed
      print('🆕 Creating new user profile for $uid');
      profile = UserProfile.empty().copyWith(
        uid: uid,
        name: FirebaseAuth.instance.currentUser?.displayName ?? 
              FirebaseAuth.instance.currentUser?.email?.split('@')[0] ?? 
              'Movie Lover',
      );
      
      await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .set(profile.toJson(), SetOptions(merge: true));

      print('✅ New user profile created and saved');
    } else {
      // ✅ EXISTING USER - Load their profile
      print('📂 Loading existing user profile');
      profile = UserProfile.fromJson(doc.data()!);
    }

    // Load movies
    print('🎬 Loading movies...');
    final movies = await TMDBApi.getPopularMovies();
    print('✅ Loaded ${movies.length} movies');
    
    return UserProfileScreenBundle(profile, movies);
  }
}

class UserProfileScreenBundle {
  final UserProfile profile;
  final List<Movie> movies;

  UserProfileScreenBundle(this.profile, this.movies);
}