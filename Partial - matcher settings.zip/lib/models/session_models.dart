// File: lib/models/session_models.dart (Enhanced with Streaming)
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../utils/mood_based_learning_engine.dart';
import 'user_profile.dart';

enum SessionStatus {
  created,     // Host created, waiting for friend
  active,      // Both users joined, swiping together
  completed,   // Session finished
  cancelled,   // Session cancelled by someone
}

enum InvitationType {
  friend,      // Direct friend invite
  code,        // Share code method
  qr,          // QR code sharing
}

class MoodChangeRequest {
  final String fromUserId;
  final String fromUserName;
  final String requestedMoodId;
  final String requestedMoodName;
  final DateTime requestedAt;
  final Map<String, bool> responses; // userId -> accepted/declined

  MoodChangeRequest({
    required this.fromUserId,
    required this.fromUserName,
    required this.requestedMoodId,
    required this.requestedMoodName,
    required this.requestedAt,
    required this.responses,
  });

  Map<String, dynamic> toJson() {
    return {
      'fromUserId': fromUserId,
      'fromUserName': fromUserName,
      'requestedMoodId': requestedMoodId,
      'requestedMoodName': requestedMoodName,
      'requestedAt': requestedAt.toIso8601String(),
      'responses': responses,
    };
  }

  factory MoodChangeRequest.fromJson(Map<String, dynamic> json) {
    return MoodChangeRequest(
      fromUserId: json['fromUserId'] ?? '',
      fromUserName: json['fromUserName'] ?? '',
      requestedMoodId: json['requestedMoodId'] ?? '',
      requestedMoodName: json['requestedMoodName'] ?? '',
      requestedAt: DateTime.parse(json['requestedAt']),
      responses: Map<String, bool>.from(json['responses'] ?? {}),
    );
  }
}



// 🆕 NEW: Session streaming preferences for group consensus
class SessionStreamingSettings {
  final Set<String> availableServices;      // Services available to everyone
  final Set<String> someoneHasServices;     // Services at least one person has
  final bool groupWillingToRent;            // If anyone in group will rent
  final double maxGroupRentalPrice;         // Lowest max rental price in group
  final Map<String, List<String>> memberServices; // userId -> services they have
  
  SessionStreamingSettings({
    required this.availableServices,
    required this.someoneHasServices,
    required this.groupWillingToRent,
    required this.maxGroupRentalPrice,
    required this.memberServices,
  });
  
  factory SessionStreamingSettings.fromGroupMembers(List<UserProfile> members) {
    Set<String> available = members.first.streamingPreferences.ownedServices;
    Set<String> someoneHas = Set<String>.from(members.first.streamingPreferences.ownedServices);
    bool anyoneWillRent = members.first.streamingPreferences.willingToRent;
    double lowestMaxPrice = members.first.streamingPreferences.maxRentalPrice;
    Map<String, List<String>> memberServices = {};
    
    for (final member in members) {
      // Find services everyone has (intersection)
      available = available.intersection(member.streamingPreferences.ownedServices);
      
      // Find services someone has (union)
      someoneHas.addAll(member.streamingPreferences.ownedServices);
      
      // Check if anyone is willing to rent
      if (member.streamingPreferences.willingToRent) {
        anyoneWillRent = true;
      }
      
      // Find lowest max rental price
      if (member.streamingPreferences.maxRentalPrice < lowestMaxPrice) {
        lowestMaxPrice = member.streamingPreferences.maxRentalPrice;
      }
      
      // Track individual member services
      memberServices[member.uid] = member.streamingPreferences.ownedServices.toList();
    }
    
    return SessionStreamingSettings(
      availableServices: available,
      someoneHasServices: someoneHas,
      groupWillingToRent: anyoneWillRent,
      maxGroupRentalPrice: lowestMaxPrice,
      memberServices: memberServices,
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'availableServices': availableServices.toList(),
      'someoneHasServices': someoneHasServices.toList(),
      'groupWillingToRent': groupWillingToRent,
      'maxGroupRentalPrice': maxGroupRentalPrice,
      'memberServices': memberServices,
    };
  }
  
  factory SessionStreamingSettings.fromJson(Map<String, dynamic> json) {
    return SessionStreamingSettings(
      availableServices: Set<String>.from(json['availableServices'] ?? []),
      someoneHasServices: Set<String>.from(json['someoneHasServices'] ?? []),
      groupWillingToRent: json['groupWillingToRent'] ?? false,
      maxGroupRentalPrice: (json['maxGroupRentalPrice'] ?? 6.99).toDouble(),
      memberServices: Map<String, List<String>>.from(
        (json['memberServices'] as Map<String, dynamic>? ?? {}).map(
          (key, value) => MapEntry(key, List<String>.from(value ?? [])),
        ),
      ),
    );
  }
  
  /// Get streaming summary for display
  String get streamingSummary {
    if (availableServices.isEmpty) {
      return groupWillingToRent ? "Rental only" : "No common services";
    }
    
    final services = availableServices.take(2).join(', ');
    final extra = availableServices.length > 2 ? " +${availableServices.length - 2}" : "";
    final rental = groupWillingToRent ? " + rentals" : "";
    
    return "$services$extra$rental";
  }
}

class SessionSettings {
  final CurrentMood? selectedMood;
  final Set<String> additionalGenres;
  final StreamingPreferences streamingPreferences;
  final bool isGroupSession;

  SessionSettings({
    this.selectedMood,
    this.additionalGenres = const {},
    required this.streamingPreferences,
    this.isGroupSession = false,
  });

  Map<String, dynamic> toJson() {
    return {
      'selectedMood': selectedMood?.name,
      'additionalGenres': additionalGenres.toList(),
      'streamingPreferences': streamingPreferences.toJson(),
      'isGroupSession': isGroupSession,
    };
  }

  factory SessionSettings.fromJson(Map<String, dynamic> json) {
    return SessionSettings(
      selectedMood: json['selectedMood'] != null
          ? CurrentMood.values.firstWhere(
              (m) => m.name == json['selectedMood'],
              orElse: () => CurrentMood.lighthearted,
            )
          : null,
      additionalGenres: Set<String>.from(json['additionalGenres'] ?? []),
      streamingPreferences:
          StreamingPreferences.fromJson(json['streamingPreferences'] ?? {}),
      isGroupSession: json['isGroupSession'] ?? false,
    );
  }
}


class SwipeSession {
  final String sessionId;
  final String hostId;
  final String hostName;
  final List<String> participantIds;
  final List<String> participantNames;
  final SessionStatus status;
  final List<String> matches;
  final String? sessionCode;
  final List<String> moviePool;
  final bool hasMoodSelected;
  final String selectedMoodId;
  final String selectedMoodName;
  final String? selectedMoodEmoji;
  final InvitationType inviteType;
  final Map<String, List<String>> userLikes;
  final Map<String, List<String>> userPasses;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final DateTime? startedAt;
  final DateTime? completedAt;
  
  // Fields for cancellation support
  final String? cancelledBy;
  final DateTime? cancelledAt;
  final DateTime? moodChangedAt;
  final MoodChangeRequest? pendingMoodChangeRequest;
  
  // Additional fields
  final Map<String, dynamic> sessionSettings;
  final List<String> selectedMoodIds;
  final int currentMovieIndex;
  
  // 🆕 NEW: Streaming-related fields
  final SessionStreamingSettings? streamingSettings;
  final List<String> additionalGenres;
  final bool streamingFilterEnabled;
  final int originalMoviePoolSize;  // Before streaming filter was applied

  SwipeSession({
    required this.sessionId,
    required this.hostId,
    required this.hostName,
    required this.participantIds,
    required this.participantNames,
    required this.status,
    required this.matches,
    this.sessionCode,
    required this.moviePool,
    required this.hasMoodSelected,
    required this.selectedMoodId,
    required this.selectedMoodName,
    this.selectedMoodEmoji,
    required this.inviteType,
    required this.userLikes,
    required this.userPasses,
    required this.createdAt,
    this.updatedAt,
    this.startedAt,
    this.completedAt,
    this.cancelledBy,
    this.cancelledAt,
    this.moodChangedAt,
    this.pendingMoodChangeRequest,
    required this.sessionSettings,
    required this.selectedMoodIds,
    required this.currentMovieIndex,
    // Streaming fields
    this.streamingSettings,
    this.additionalGenres = const [],
    this.streamingFilterEnabled = false,
    this.originalMoviePoolSize = 0,
  });

  factory SwipeSession.create({
    required String hostId,
    required String hostName,
    required InvitationType inviteType,
    String? sessionCode,
    String? selectedMoodId,
    String? selectedMoodName,
    String? selectedMoodEmoji,
    SessionStreamingSettings? streamingSettings, // 🆕 NEW
    List<String>? additionalGenres,             // 🆕 NEW
  }) {
    return SwipeSession(
      sessionId: DateTime.now().millisecondsSinceEpoch.toString(),
      hostId: hostId,
      hostName: hostName,
      participantIds: [hostId],
      participantNames: [hostName],
      status: SessionStatus.created,
      sessionCode: sessionCode,
      createdAt: DateTime.now(),
      sessionSettings: {},
      selectedMoodIds: selectedMoodId != null ? [selectedMoodId] : [],
      moviePool: [],
      userLikes: {hostId: []},
      userPasses: {hostId: []},
      matches: [],
      inviteType: inviteType,
      currentMovieIndex: 0,
      // Mood fields
      hasMoodSelected: selectedMoodId != null && selectedMoodName != null,
      selectedMoodId: selectedMoodId ?? '',
      selectedMoodName: selectedMoodName ?? '',
      selectedMoodEmoji: selectedMoodEmoji,
      // Streaming fields
      streamingSettings: streamingSettings,
      additionalGenres: additionalGenres ?? [],
      streamingFilterEnabled: streamingSettings != null,
    );
  }

  SwipeSession copyWith({
    String? sessionId,
    String? hostId,
    String? hostName,
    List<String>? participantIds,
    List<String>? participantNames,
    SessionStatus? status,
    String? sessionCode,
    DateTime? createdAt,
    DateTime? startedAt,
    DateTime? completedAt,
    Map<String, dynamic>? sessionSettings,
    List<String>? selectedMoodIds,
    List<String>? moviePool,
    Map<String, List<String>>? userLikes,
    Map<String, List<String>>? userPasses,
    List<String>? matches,
    int? currentMovieIndex,
    InvitationType? inviteType,
    bool? hasMoodSelected,
    String? selectedMoodId,
    String? selectedMoodName,
    String? selectedMoodEmoji,
    String? cancelledBy,
    DateTime? cancelledAt,
    DateTime? moodChangedAt,
    DateTime? updatedAt,
    MoodChangeRequest? pendingMoodChangeRequest,
    // Streaming parameters
    SessionStreamingSettings? streamingSettings,
    List<String>? additionalGenres,
    bool? streamingFilterEnabled,
    int? originalMoviePoolSize,
  }) {
    return SwipeSession(
      sessionId: sessionId ?? this.sessionId,
      hostId: hostId ?? this.hostId,
      hostName: hostName ?? this.hostName,
      participantIds: participantIds ?? this.participantIds,
      participantNames: participantNames ?? this.participantNames,
      status: status ?? this.status,
      sessionCode: sessionCode ?? this.sessionCode,
      createdAt: createdAt ?? this.createdAt,
      startedAt: startedAt ?? this.startedAt,
      completedAt: completedAt ?? this.completedAt,
      sessionSettings: sessionSettings ?? this.sessionSettings,
      selectedMoodIds: selectedMoodIds ?? this.selectedMoodIds,
      moviePool: moviePool ?? this.moviePool,
      userLikes: userLikes ?? this.userLikes,
      userPasses: userPasses ?? this.userPasses,
      matches: matches ?? this.matches,
      currentMovieIndex: currentMovieIndex ?? this.currentMovieIndex,
      inviteType: inviteType ?? this.inviteType,
      hasMoodSelected: hasMoodSelected ?? this.hasMoodSelected,
      selectedMoodId: selectedMoodId ?? this.selectedMoodId,
      selectedMoodName: selectedMoodName ?? this.selectedMoodName,
      selectedMoodEmoji: selectedMoodEmoji ?? this.selectedMoodEmoji,
      cancelledBy: cancelledBy ?? this.cancelledBy,
      cancelledAt: cancelledAt ?? this.cancelledAt,
      moodChangedAt: moodChangedAt ?? this.moodChangedAt,
      updatedAt: updatedAt ?? this.updatedAt,
      pendingMoodChangeRequest: pendingMoodChangeRequest ?? this.pendingMoodChangeRequest,
      // Streaming fields
      streamingSettings: streamingSettings ?? this.streamingSettings,
      additionalGenres: additionalGenres ?? this.additionalGenres,
      streamingFilterEnabled: streamingFilterEnabled ?? this.streamingFilterEnabled,
      originalMoviePoolSize: originalMoviePoolSize ?? this.originalMoviePoolSize,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'sessionId': sessionId,
      'hostId': hostId,
      'hostName': hostName,
      'participantIds': participantIds,
      'participantNames': participantNames,
      'status': status.name,
      'matches': matches,
      'sessionCode': sessionCode,
      'moviePool': moviePool,
      'hasMoodSelected': hasMoodSelected,
      'selectedMoodId': selectedMoodId,
      'selectedMoodName': selectedMoodName,
      'selectedMoodEmoji': selectedMoodEmoji,
      'inviteType': inviteType.name,
      'userLikes': userLikes,
      'userPasses': userPasses,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
      'startedAt': startedAt?.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
      'cancelledBy': cancelledBy,
      'cancelledAt': cancelledAt?.toIso8601String(),
      'moodChangedAt': moodChangedAt?.toIso8601String(),
      'pendingMoodChangeRequest': pendingMoodChangeRequest?.toJson(),
      // Additional fields
      'sessionSettings': sessionSettings,
      'selectedMoodIds': selectedMoodIds,
      'currentMovieIndex': currentMovieIndex,
      // Streaming fields
      'streamingSettings': streamingSettings?.toJson(),
      'additionalGenres': additionalGenres,
      'streamingFilterEnabled': streamingFilterEnabled,
      'originalMoviePoolSize': originalMoviePoolSize,
    };
  }

  factory SwipeSession.fromJson(Map<String, dynamic> json) {
    return SwipeSession(
      sessionId: json['sessionId'] ?? '',
      hostId: json['hostId'] ?? '',
      hostName: json['hostName'] ?? '',
      participantIds: List<String>.from(json['participantIds'] ?? []),
      participantNames: List<String>.from(json['participantNames'] ?? []),
      status: _parseStatus(json['status']),
      matches: List<String>.from(json['matches'] ?? []),
      sessionCode: json['sessionCode'],
      moviePool: List<String>.from(json['moviePool'] ?? []),
      hasMoodSelected: json['hasMoodSelected'] ?? false,
      selectedMoodId: json['selectedMoodId'] ?? '',
      selectedMoodName: json['selectedMoodName'] ?? '',
      selectedMoodEmoji: json['selectedMoodEmoji'],
      inviteType: _parseInviteType(json['inviteType']),
      userLikes: Map<String, List<String>>.from(
        (json['userLikes'] as Map<String, dynamic>? ?? {}).map(
          (key, value) => MapEntry(key, List<String>.from(value ?? [])),
        ),
      ),
      userPasses: Map<String, List<String>>.from(
        (json['userPasses'] as Map<String, dynamic>? ?? {}).map(
          (key, value) => MapEntry(key, List<String>.from(value ?? [])),
        ),
      ),
      createdAt: _parseDateTime(json['createdAt']) ?? DateTime.now(),
      updatedAt: _parseDateTime(json['updatedAt']),
      startedAt: _parseDateTime(json['startedAt']),
      completedAt: _parseDateTime(json['completedAt']),
      cancelledBy: json['cancelledBy'],
      cancelledAt: _parseDateTime(json['cancelledAt']),
      moodChangedAt: _parseDateTime(json['moodChangedAt']),
      pendingMoodChangeRequest: json['pendingMoodChangeRequest'] != null
          ? MoodChangeRequest.fromJson(json['pendingMoodChangeRequest'])
          : null,
      // Additional fields
      sessionSettings: Map<String, dynamic>.from(json['sessionSettings'] ?? {}),
      selectedMoodIds: List<String>.from(json['selectedMoodIds'] ?? []),
      currentMovieIndex: json['currentMovieIndex'] ?? 0,
      // Streaming fields
      streamingSettings: json['streamingSettings'] != null
          ? SessionStreamingSettings.fromJson(json['streamingSettings'])
          : null,
      additionalGenres: List<String>.from(json['additionalGenres'] ?? []),
      streamingFilterEnabled: json['streamingFilterEnabled'] ?? false,
      originalMoviePoolSize: json['originalMoviePoolSize'] ?? 0,
    );
  }

  // Helper methods for parsing (same as before)
  static SessionStatus _parseStatus(String? status) {
    switch (status) {
      case 'created': return SessionStatus.created;
      case 'active': return SessionStatus.active;
      case 'completed': return SessionStatus.completed;
      case 'cancelled': return SessionStatus.cancelled;
      default: return SessionStatus.created;
    }
  }

  static InvitationType _parseInviteType(String? type) {
    switch (type) {
      case 'code': return InvitationType.code;
      case 'friend': return InvitationType.friend;
      case 'qr': return InvitationType.qr;
      default: return InvitationType.code;
    }
  }

  static DateTime? _parseDateTime(dynamic dateTime) {
    if (dateTime == null) return null;
    
    try {
      if (dateTime is Timestamp) {
        return dateTime.toDate();
      } else if (dateTime is String) {
        return DateTime.parse(dateTime);
      } else if (dateTime is int) {
        // Handle milliseconds since epoch
        return DateTime.fromMillisecondsSinceEpoch(dateTime);
      }
    } catch (e) {
      print("⚠️ Error parsing datetime $dateTime: $e");
      return null;
    }
    
    return null;
  }

  // Helper methods
  bool get isHost => FirebaseAuth.instance.currentUser?.uid == hostId;
  bool get isActive => status == SessionStatus.active;
  bool get isWaitingForParticipants => status == SessionStatus.created;
  bool get isCancelled => status == SessionStatus.cancelled;
  bool get isCompleted => status == SessionStatus.completed;
  bool get hasPendingMoodRequest => pendingMoodChangeRequest != null;
  
  bool hasUserLiked(String userId, String movieId) {
    return userLikes[userId]?.contains(movieId) ?? false;
  }
  
  bool hasUserPassed(String userId, String movieId) {
    return userPasses[userId]?.contains(movieId) ?? false;
  }
  
  bool isMovieMatch(String movieId) {
    return matches.contains(movieId);
  }
  
  int getUserSwipeCount(String userId) {
    final likes = userLikes[userId]?.length ?? 0;
    final passes = userPasses[userId]?.length ?? 0;
    return likes + passes;
  }
  
  double getSessionProgress() {
    if (moviePool.isEmpty) return 0.0;
    return currentMovieIndex / moviePool.length;
  }
  
  // 🆕 NEW: Streaming-related helper methods
  
  /// Get streaming filter effectiveness
  double get streamingFilterEffectiveness {
    if (originalMoviePoolSize == 0) return 1.0;
    return moviePool.length / originalMoviePoolSize;
  }
  
  /// Check if streaming filter was too restrictive
  bool get streamingFilterTooRestrictive {
    return streamingFilterEffectiveness < 0.3; // Less than 30% of movies available
  }
  
  /// Get session streaming summary for display
  String get sessionStreamingSummary {
    if (streamingSettings == null) return "No streaming filter";
    return streamingSettings!.streamingSummary;
  }
  
  /// Check if session has good movie variety despite streaming filter
  bool get hasGoodMovieVariety {
    return moviePool.length >= 20; // Minimum for good variety
  }
}