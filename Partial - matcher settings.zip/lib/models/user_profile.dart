import '/movie.dart';

class MovieLike {
  final String movieId;
  final DateTime likedAt;
  final String sessionType; // "solo", "friend", "group"
  
  MovieLike({
    required this.movieId, 
    required this.likedAt, 
    required this.sessionType
  });
  
  factory MovieLike.fromJson(Map<String, dynamic> json) {
    return MovieLike(
      movieId: json['movieId'],
      likedAt: DateTime.parse(json['likedAt']),
      sessionType: json['sessionType'] ?? 'solo',
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'movieId': movieId,
      'likedAt': likedAt.toIso8601String(),
      'sessionType': sessionType,
    };
  }
}

// 🆕 NEW: Streaming preferences for users
class StreamingPreferences {
  final Set<String> ownedServices;        // Services user subscribes to
  final bool willingToRent;               // Whether user is willing to rent movies
  final bool willingToBuy;                // Whether user is willing to buy movies
  final Set<String> preferredRentalServices; // Preferred services for renting
  final double maxRentalPrice;            // Maximum rental price user is willing to pay
  
  StreamingPreferences({
    Set<String>? ownedServices,
    this.willingToRent = true,
    this.willingToBuy = false,
    Set<String>? preferredRentalServices,
    this.maxRentalPrice = 6.99,
  }) : ownedServices = ownedServices ?? {},
       preferredRentalServices = preferredRentalServices ?? {'Amazon Prime Video', 'Apple TV'};

  StreamingPreferences copyWith({
    Set<String>? ownedServices,
    bool? willingToRent,
    bool? willingToBuy,
    Set<String>? preferredRentalServices,
    double? maxRentalPrice,
  }) {
    return StreamingPreferences(
      ownedServices: ownedServices ?? this.ownedServices,
      willingToRent: willingToRent ?? this.willingToRent,
      willingToBuy: willingToBuy ?? this.willingToBuy,
      preferredRentalServices: preferredRentalServices ?? this.preferredRentalServices,
      maxRentalPrice: maxRentalPrice ?? this.maxRentalPrice,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'ownedServices': ownedServices.toList(),
      'willingToRent': willingToRent,
      'willingToBuy': willingToBuy,
      'preferredRentalServices': preferredRentalServices.toList(),
      'maxRentalPrice': maxRentalPrice,
    };
  }

  factory StreamingPreferences.fromJson(Map<String, dynamic> json) {
    return StreamingPreferences(
      ownedServices: Set<String>.from(json['ownedServices'] ?? []),
      willingToRent: json['willingToRent'] ?? true,
      willingToBuy: json['willingToBuy'] ?? false,
      preferredRentalServices: Set<String>.from(json['preferredRentalServices'] ?? ['Amazon Prime Video', 'Apple TV']),
      maxRentalPrice: (json['maxRentalPrice'] ?? 6.99).toDouble(),
    );
  }
  
  /// Check if user can watch a movie based on their streaming preferences
  bool canWatchMovie(Movie movie) {
    // Check subscription services first
    if (movie.availableOn.any((service) => ownedServices.contains(service))) {
      return true;
    }
    
    // Check rental options if user is willing to rent
    if (willingToRent && movie.rentOn.isNotEmpty) {
      return true;
    }
    
    // Check purchase options if user is willing to buy
    if (willingToBuy && movie.buyOn.isNotEmpty) {
      return true;
    }
    
    return false;
  }
  
  /// Get the best way to watch this movie for the user
  String getBestWatchOption(Movie movie) {
    // Prefer subscription services
    for (final service in movie.availableOn) {
      if (ownedServices.contains(service)) {
        return "Stream on $service";
      }
    }
    
    // Fallback to rental if willing
    if (willingToRent && movie.rentOn.isNotEmpty) {
      // Prefer user's preferred rental services
      for (final service in preferredRentalServices) {
        if (movie.rentOn.contains(service)) {
          return "Rent on $service";
        }
      }
      // Any rental service
      return "Rent on ${movie.rentOn.first}";
    }
    
    // Fallback to purchase if willing
    if (willingToBuy && movie.buyOn.isNotEmpty) {
      return "Buy on ${movie.buyOn.first}";
    }
    
    return "Not available with your preferences";
  }
}

class UserProfile {
  String uid;
  String name;
  Set<String> preferredGenres;
  Set<String> preferredVibes;
  Set<String> blockedGenres;
  Set<String> blockedAttributes;
  Set<Movie> likedMovies;
  Set<Movie> matchedMovies;
  Set<String> matchedMovieIds;
  Set<String> likedMovieIds;
  Set<String> favouriteMovieIds;
  Map<String, double> genreScores;
  Map<String, double> vibeScores;
  List<Map<String, dynamic>> matchHistory;
  final bool hasCompletedOnboarding;
  final List<String> friendIds;
  List<MovieLike> recentLikes;
  Map<String, DateTime> passedTimestamps;
  
  // Enhanced learning fields for sophisticated recommendations
  Map<String, int> genreFatigue = {};
  Map<String, double> dislikeScores;        // Track genre dislikes
  Map<String, double> dislikeVibeScores;    // Track vibe dislikes
  Map<String, double> subGenreScores;       // Specific sub-genre preferences
  Map<String, double> actorScores;          // Actor preferences
  Map<String, double> dislikeActorScores;   // Actor dislikes
  Map<String, double> keywordScores;        // Keyword/theme preferences
  Map<String, double> runtimePreferences;   // Runtime category preferences (short/medium/long)
  Map<String, double> ratingPreferences;    // Rating preferences (low/medium/high/exceptional)
  Map<String, double> languagePreferences;  // Language preferences
  DateTime lastActivityDate;                // For recency weighting
  bool discoveryModeEnabled;                // Exploration toggle
  Set<String> passedMovieIds;               // Movies they've passed on
  bool hasSeenMatcher = false;
  
  // 🆕 NEW: Streaming preferences
  StreamingPreferences streamingPreferences;

  UserProfile({
    required this.uid,
    this.name = '',
    this.friendIds = const [],
    required this.preferredGenres,
    required this.preferredVibes,
    required this.blockedGenres,
    required this.blockedAttributes,
    required this.likedMovies,
    required this.matchedMovies,
    required this.matchedMovieIds,
    required this.likedMovieIds,
    required this.favouriteMovieIds,
    required this.matchHistory,
    this.hasCompletedOnboarding = false,
    this.hasSeenMatcher = false,
    Map<String, double>? genreScores,
    Map<String, double>? vibeScores,
    // Enhanced parameters
    Map<String, double>? dislikeScores,
    Map<String, double>? dislikeVibeScores,
    Map<String, double>? subGenreScores,
    Map<String, double>? actorScores,
    Map<String, double>? dislikeActorScores,
    Map<String, double>? keywordScores,
    Map<String, double>? runtimePreferences,
    Map<String, double>? ratingPreferences,
    Map<String, double>? languagePreferences,
    DateTime? lastActivityDate,
    this.discoveryModeEnabled = false,
    Set<String>? passedMovieIds,
    List<MovieLike>? recentLikes,
    Map<String, DateTime>? passedTimestamps,
    StreamingPreferences? streamingPreferences, // 🆕 NEW
  })  : genreScores = genreScores ?? {},
        vibeScores = vibeScores ?? {},
        dislikeScores = dislikeScores ?? {},
        dislikeVibeScores = dislikeVibeScores ?? {},
        subGenreScores = subGenreScores ?? {},
        actorScores = actorScores ?? {},
        dislikeActorScores = dislikeActorScores ?? {},
        keywordScores = keywordScores ?? {},
        runtimePreferences = runtimePreferences ?? {},
        ratingPreferences = ratingPreferences ?? {},
        languagePreferences = languagePreferences ?? {},
        lastActivityDate = lastActivityDate ?? DateTime.now(),
        passedMovieIds = passedMovieIds ?? {},
        recentLikes = recentLikes ?? [],
        passedTimestamps = passedTimestamps ?? {},
        streamingPreferences = streamingPreferences ?? StreamingPreferences(); // 🆕 NEW

  factory UserProfile.empty() {
    return UserProfile(
      uid: '',
      name: '',
      friendIds: const [],
      preferredGenres: {},
      preferredVibes: {},
      blockedGenres: {},
      blockedAttributes: {},
      likedMovies: {},
      matchedMovies: {},
      matchedMovieIds: {},
      likedMovieIds: {},
      favouriteMovieIds: {},
      genreScores: {},
      vibeScores: {},
      matchHistory: [],
      dislikeScores: {},
      dislikeVibeScores: {},
      subGenreScores: {},
      actorScores: {},
      dislikeActorScores: {},
      keywordScores: {},
      runtimePreferences: {},
      ratingPreferences: {},
      languagePreferences: {},
      discoveryModeEnabled: false,
      passedMovieIds: {},
      recentLikes: [],
      passedTimestamps: {},
      streamingPreferences: StreamingPreferences(), // 🆕 NEW
    );
  }

  UserProfile copyWith({
    String? uid,
    String? name,
    List<String>? friendIds,
    Set<String>? preferredGenres,
    Set<String>? preferredVibes,
    Set<String>? blockedGenres,
    Set<String>? blockedAttributes,
    Set<Movie>? likedMovies,
    Set<Movie>? matchedMovies,
    Set<String>? matchedMovieIds,
    Set<String>? likedMovieIds,
    Set<String>? favouriteMovieIds,
    Map<String, double>? genreScores,
    Map<String, double>? vibeScores,
    List<Map<String, dynamic>>? matchHistory,
    bool? hasCompletedOnboarding,
    bool? hasSeenMatcher,
    // Enhanced copyWith parameters
    Map<String, double>? dislikeScores,
    Map<String, double>? dislikeVibeScores,
    Map<String, double>? subGenreScores,
    Map<String, double>? actorScores,
    Map<String, double>? dislikeActorScores,
    Map<String, double>? keywordScores,
    Map<String, double>? runtimePreferences,
    Map<String, double>? ratingPreferences,
    Map<String, double>? languagePreferences,
    DateTime? lastActivityDate,
    bool? discoveryModeEnabled,
    Set<String>? passedMovieIds,
    List<MovieLike>? recentLikes,
    Map<String, DateTime>? passedTimestamps,
    StreamingPreferences? streamingPreferences, // 🆕 NEW
  }) {
    return UserProfile(
      uid: uid ?? this.uid,
      name: name ?? this.name,
      friendIds: friendIds ?? this.friendIds,
      preferredGenres: preferredGenres ?? this.preferredGenres,
      preferredVibes: preferredVibes ?? this.preferredVibes,
      blockedGenres: blockedGenres ?? this.blockedGenres,
      blockedAttributes: blockedAttributes ?? this.blockedAttributes,
      likedMovies: likedMovies ?? this.likedMovies,
      matchedMovies: matchedMovies ?? this.matchedMovies,
      matchedMovieIds: matchedMovieIds ?? this.matchedMovieIds,
      likedMovieIds: likedMovieIds ?? this.likedMovieIds,
      favouriteMovieIds: favouriteMovieIds ?? this.favouriteMovieIds,
      genreScores: genreScores ?? this.genreScores,
      vibeScores: vibeScores ?? this.vibeScores,
      matchHistory: matchHistory ?? this.matchHistory,
      hasCompletedOnboarding: hasCompletedOnboarding ?? this.hasCompletedOnboarding,
      hasSeenMatcher: hasSeenMatcher ?? this.hasSeenMatcher,
      dislikeScores: dislikeScores ?? this.dislikeScores,
      dislikeVibeScores: dislikeVibeScores ?? this.dislikeVibeScores,
      subGenreScores: subGenreScores ?? this.subGenreScores,
      actorScores: actorScores ?? this.actorScores,
      dislikeActorScores: dislikeActorScores ?? this.dislikeActorScores,
      keywordScores: keywordScores ?? this.keywordScores,
      runtimePreferences: runtimePreferences ?? this.runtimePreferences,
      ratingPreferences: ratingPreferences ?? this.ratingPreferences,
      languagePreferences: languagePreferences ?? this.languagePreferences,
      lastActivityDate: lastActivityDate ?? this.lastActivityDate,
      discoveryModeEnabled: discoveryModeEnabled ?? this.discoveryModeEnabled,
      passedMovieIds: passedMovieIds ?? this.passedMovieIds,
      recentLikes: recentLikes ?? this.recentLikes,
      passedTimestamps: passedTimestamps ?? this.passedTimestamps,
      streamingPreferences: streamingPreferences ?? this.streamingPreferences, // 🆕 NEW
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'uid': uid,
      'name': name,
      'friendIds': friendIds,
      'preferredGenres': preferredGenres.toList(),
      'preferredVibes': preferredVibes.toList(),
      'blockedGenres': blockedGenres.toList(),
      'blockedAttributes': blockedAttributes.toList(),
      'likedMovieIds': likedMovieIds.toList(),
      'favouriteMovieIds': favouriteMovieIds.toList(),
      'matchedMovieIds': matchedMovieIds.toList(),
      'genreScores': genreScores,
      'vibeScores': vibeScores,
      'matchHistory': matchHistory,
      'hasCompletedOnboarding': hasCompletedOnboarding,
      'hasSeenMatcher': hasSeenMatcher,
      // Enhanced fields in JSON
      'dislikeScores': dislikeScores,
      'dislikeVibeScores': dislikeVibeScores,
      'subGenreScores': subGenreScores,
      'actorScores': actorScores,
      'dislikeActorScores': dislikeActorScores,
      'keywordScores': keywordScores,
      'runtimePreferences': runtimePreferences,
      'ratingPreferences': ratingPreferences,
      'languagePreferences': languagePreferences,
      'lastActivityDate': lastActivityDate.toIso8601String(),
      'discoveryModeEnabled': discoveryModeEnabled,
      'passedMovieIds': passedMovieIds.toList(),
      'recentLikes': recentLikes.map((like) => like.toJson()).toList(),
      'passedTimestamps': passedTimestamps.map((k, v) => MapEntry(k, v.toIso8601String())),
      'streamingPreferences': streamingPreferences.toJson(), // 🆕 NEW
    };
  }

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      uid: json['uid'] ?? '',
      name: json['name'] ?? '',
      friendIds: List<String>.from(json['friendIds'] ?? []),
      preferredGenres: Set<String>.from(json['preferredGenres'] ?? []),
      preferredVibes: Set<String>.from(json['preferredVibes'] ?? []),
      blockedGenres: Set<String>.from(json['blockedGenres'] ?? []),
      blockedAttributes: Set<String>.from(json['blockedAttributes'] ?? []),
      likedMovieIds: Set<String>.from(json['likedMovieIds'] ?? []),
      favouriteMovieIds: Set<String>.from(json['favouriteMovieIds'] ?? []),
      matchedMovieIds: Set<String>.from(json['matchedMovieIds'] ?? []),
      matchedMovies: {},
      likedMovies: {},
      genreScores: Map<String, double>.from(json['genreScores'] ?? {}),
      vibeScores: Map<String, double>.from(json['vibeScores'] ?? {}),
      matchHistory: (json['matchHistory'] as List<dynamic>? ?? [])
          .map((entry) => Map<String, dynamic>.from(entry))
          .toList(),
      hasCompletedOnboarding: json['hasCompletedOnboarding'] ?? false,
      hasSeenMatcher: json['hasSeenMatcher'] ?? false,
      // Enhanced fields from JSON
      dislikeScores: Map<String, double>.from(json['dislikeScores'] ?? {}),
      dislikeVibeScores: Map<String, double>.from(json['dislikeVibeScores'] ?? {}),
      subGenreScores: Map<String, double>.from(json['subGenreScores'] ?? {}),
      actorScores: Map<String, double>.from(json['actorScores'] ?? {}),
      dislikeActorScores: Map<String, double>.from(json['dislikeActorScores'] ?? {}),
      keywordScores: Map<String, double>.from(json['keywordScores'] ?? {}),
      runtimePreferences: Map<String, double>.from(json['runtimePreferences'] ?? {}),
      ratingPreferences: Map<String, double>.from(json['ratingPreferences'] ?? {}),
      languagePreferences: Map<String, double>.from(json['languagePreferences'] ?? {}),
      lastActivityDate: json['lastActivityDate'] != null 
          ? DateTime.parse(json['lastActivityDate'])
          : DateTime.now(),
      discoveryModeEnabled: json['discoveryModeEnabled'] ?? false,
      passedMovieIds: Set<String>.from(json['passedMovieIds'] ?? []),
      recentLikes: (json['recentLikes'] as List<dynamic>?)
        ?.map((item) => MovieLike.fromJson(item as Map<String, dynamic>))
        .toList() ?? [],
      passedTimestamps: (json['passedTimestamps'] as Map<String, dynamic>?)
        ?.map((k, v) => MapEntry(k, DateTime.parse(v))) ?? {},
      streamingPreferences: json['streamingPreferences'] != null  // 🆕 NEW
          ? StreamingPreferences.fromJson(json['streamingPreferences'])
          : StreamingPreferences(),
    );
  }

  // Helper methods for taste evolution and analytics
  
  /// Check if user is exploring new genres recently
  bool get isExploringNewGenres {
    final recentLikes = likedMovies.where((movie) => 
      DateTime.now().difference(lastActivityDate).inDays < 30
    );
    
    final newGenresExplored = recentLikes
        .expand((movie) => movie.genres)
        .where((genre) => !preferredGenres.contains(genre))
        .toSet();
    
    return newGenresExplored.length >= 2;
  }
  
  /// Get genres the user might want to explore
  List<String> get genresToExplore {
    const allGenres = ['Action', 'Comedy', 'Drama', 'Horror', 'Romance', 'Sci-Fi', 'Fantasy', 'Thriller', 'Mystery', 'Animation'];
    
    return allGenres.where((genre) => 
      !preferredGenres.contains(genre) && 
      (dislikeScores[genre] ?? 0) < 3 // Haven't strongly disliked
    ).toList();
  }
  
  /// Calculate overall preference strength for a genre (likes - dislikes)
  double getGenrePreference(String genre) {
    final likes = genreScores[genre] ?? 0;
    final dislikes = dislikeScores[genre] ?? 0;
    return likes - (dislikes * 0.5); // Dislikes weigh less than likes
  }
  
  /// Get user's top actors by preference
  List<String> get topActors {
    final actorEntries = actorScores.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return actorEntries.take(10).map((e) => e.key).toList();
  }
  
  /// Get user's taste diversity score (how varied their preferences are)
  double get tasteDiversityScore {
    final totalGenres = genreScores.keys.length;
    final strongPreferences = genreScores.values.where((score) => score > 5.0).length;
    
    if (totalGenres == 0) return 0.0;
    return (totalGenres - strongPreferences) / totalGenres;
  }
  
  /// Check if user prefers a specific runtime category
  String get preferredRuntimeCategory {
    if (runtimePreferences.isEmpty) return 'medium';
    
    final sorted = runtimePreferences.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    return sorted.first.key;
  }

  // Helper methods for friendship functionality
  
  /// Check if user is friends with another user
  bool isFriendsWith(String userId) {
    return friendIds.contains(userId);
  }
  
  /// Get number of friends
  int get friendCount => friendIds.length;
  
  /// Check if user has any friends
  bool get hasFriends => friendIds.isNotEmpty;
  
  // 🆕 NEW: Streaming-related helper methods
  
  /// Check if user can watch a specific movie
  bool canWatchMovie(Movie movie) {
    return streamingPreferences.canWatchMovie(movie);
  }
  
  /// Get the best way for this user to watch a movie
  String getBestWatchOption(Movie movie) {
    return streamingPreferences.getBestWatchOption(movie);
  }
  
  /// Get count of how many owned streaming services user has
  int get ownedStreamingServiceCount => streamingPreferences.ownedServices.length;
  
  /// Check if user has any streaming services
  bool get hasStreamingServices => streamingPreferences.ownedServices.isNotEmpty;
  
  /// Get summary of streaming setup for display
  String get streamingSetupSummary {
    final serviceCount = ownedStreamingServiceCount;
    if (serviceCount == 0) {
      return streamingPreferences.willingToRent ? "Rental only" : "No streaming setup";
    }
    
    final services = streamingPreferences.ownedServices.take(2).join(', ');
    final extra = serviceCount > 2 ? " +${serviceCount - 2} more" : "";
    final rental = streamingPreferences.willingToRent ? " + rentals" : "";
    
    return "$services$extra$rental";
  }
}