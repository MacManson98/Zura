// File: lib/widgets/notifications_dropdown_widget.dart

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/session_models.dart';
import '../services/session_service.dart';
import '../models/user_profile.dart';

class NotificationsDropdownWidget extends StatefulWidget {
  final Function(SwipeSession session) onSessionJoined;
  final UserProfile currentUser;

  const NotificationsDropdownWidget({
    super.key,
    required this.onSessionJoined,
    required this.currentUser,
  });

  @override
  State<NotificationsDropdownWidget> createState() => _NotificationsDropdownWidgetState();
}

class _NotificationsDropdownWidgetState extends State<NotificationsDropdownWidget> {
  final GlobalKey _buttonKey = GlobalKey();
  OverlayEntry? _overlayEntry;
  bool _isDropdownOpen = false;

  @override
  void dispose() {
    _safeCloseDropdown();
    super.dispose();
  }

  void _toggleDropdown() {
    if (!mounted) return; // Safety check
    
    if (_isDropdownOpen) {
      _closeDropdown();
    } else {
      _openDropdown();
    }
  }

  void _openDropdown() {
    if (!mounted) return; // Safety check
    
    final RenderBox? renderBox = _buttonKey.currentContext?.findRenderObject() as RenderBox?;
    if (renderBox == null) return; // Safety check
    
    final Size size = renderBox.size;
    final Offset offset = renderBox.localToGlobal(Offset.zero);

    _overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        top: offset.dy + size.height + 8.h,
        right: 16.w, // Align to right edge
        child: Material(
          color: Colors.transparent,
          child: Container(
            width: 320.w,
            constraints: BoxConstraints(maxHeight: 400.h),
            decoration: BoxDecoration(
              color: const Color(0xFF1F1F1F),
              borderRadius: BorderRadius.circular(12.r),
              border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.3)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 10.r,
                  offset: Offset(0, 4.h),
                ),
              ],
            ),
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: SessionService.watchPendingInvitations(),
              builder: (context, snapshot) {
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return _buildEmptyState();
                }

                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Header
                    Container(
                      padding: EdgeInsets.all(16.r),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: Colors.grey.withValues(alpha: 0.2),
                            width: 1.w,
                          ),
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.notifications,
                            color: const Color(0xFFE5A00D),
                            size: 20.sp,
                          ),
                          SizedBox(width: 8.w),
                          Text(
                            "Notifications",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16.sp,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const Spacer(),
                          GestureDetector(
                            onTap: () {
                              if (mounted) {
                                _closeDropdown();
                              }
                            },
                            child: Icon(
                              Icons.close,
                              color: Colors.grey[400],
                              size: 20.sp,
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    // Invitations list
                    Flexible(
                      child: ListView.builder(
                        shrinkWrap: true,
                        padding: EdgeInsets.symmetric(vertical: 8.h),
                        itemCount: snapshot.data!.length,
                        itemBuilder: (context, index) {
                          return _buildCompactInvitationCard(
                            context, 
                            snapshot.data![index],
                          );
                        },
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );

    if (mounted) {
      Overlay.of(context).insert(_overlayEntry!);
      setState(() => _isDropdownOpen = true);
    }
  }

  void _closeDropdown() {
    if (_overlayEntry != null) {
      _overlayEntry!.remove();
      _overlayEntry = null;
    }
    if (mounted) {
      setState(() => _isDropdownOpen = false);
    }
  }

  void _safeCloseDropdown() {
    if (_overlayEntry != null) {
      _overlayEntry!.remove();
      _overlayEntry = null;
    }
    // Don't call setState in dispose - just update the flag
    _isDropdownOpen = false;
  }

  Widget _buildEmptyState() {
    return Container(
      padding: EdgeInsets.all(24.r),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header
          Row(
            children: [
              Icon(
                Icons.notifications,
                color: const Color(0xFFE5A00D),
                size: 20.sp,
              ),
              SizedBox(width: 8.w),
              Text(
                "Notifications",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  if (mounted) {
                    _closeDropdown();
                  }
                },
                child: Icon(
                  Icons.close,
                  color: Colors.grey[400],
                  size: 20.sp,
                ),
              ),
            ],
          ),
          
          SizedBox(height: 16.h),
          
          Icon(
            Icons.notifications_off_outlined,
            color: Colors.grey[600],
            size: 48.sp,
          ),
          SizedBox(height: 12.h),
          Text(
            "No new notifications",
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
          Text(
            "You're all caught up!",
            style: TextStyle(
              color: Colors.grey[500],
              fontSize: 12.sp,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompactInvitationCard(BuildContext context, Map<String, dynamic> invitation) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
      padding: EdgeInsets.all(12.r),
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A2A),
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(
          color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
          width: 1.w,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(6.r),
                decoration: BoxDecoration(
                  color: const Color(0xFFE5A00D).withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(6.r),
                ),
                child: Icon(
                  Icons.people,
                  color: const Color(0xFFE5A00D),
                  size: 16.sp,
                ),
              ),
              SizedBox(width: 8.w),
              Expanded(
                child: Text(
                  "${invitation['fromUserName']} invited you",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          
          SizedBox(height: 8.h),
          
          Text(
            "to swipe movies together",
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 12.sp,
            ),
          ),
          
          SizedBox(height: 12.h),
          
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => _declineInvitation(
                    invitation['id'], 
                    invitation['sessionId'], // Pass sessionId
                  ),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Colors.grey[600]!, width: 1.w),
                    minimumSize: Size(0, 32.h),
                    padding: EdgeInsets.symmetric(horizontal: 16.w),
                  ),
                  child: Text(
                    "Decline",
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 11.sp,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 8.w),
              Expanded(
                child: ElevatedButton(
                  onPressed: () => _acceptInvitation(context, invitation),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE5A00D),
                    minimumSize: Size(0, 32.h),
                    padding: EdgeInsets.symmetric(horizontal: 16.w),
                  ),
                  child: Text(
                    "Accept",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 11.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: SessionService.watchPendingInvitations(),
      builder: (context, snapshot) {
        final hasNotifications = snapshot.hasData && snapshot.data!.isNotEmpty;
        final notificationCount = snapshot.hasData ? snapshot.data!.length : 0;

        return GestureDetector(
          key: _buttonKey,
          onTap: _toggleDropdown,
          child: Container(
            margin: EdgeInsets.only(right: 8.w),
            padding: EdgeInsets.all(8.r),
            decoration: BoxDecoration(
              color: _isDropdownOpen 
                  ? const Color(0xFFE5A00D).withValues(alpha: 0.15)
                  : hasNotifications 
                      ? const Color(0xFFE5A00D).withValues(alpha: 0.1)
                      : Colors.transparent,
              borderRadius: BorderRadius.circular(12.r),
              border: _isDropdownOpen 
                  ? Border.all(
                      color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
                      width: 1.w,
                    )
                  : null,
            ),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(
                  hasNotifications 
                      ? Icons.notifications 
                      : Icons.notifications_none_outlined,
                  color: _isDropdownOpen 
                      ? const Color(0xFFE5A00D)
                      : hasNotifications 
                          ? const Color(0xFFE5A00D)
                          : Colors.white.withValues(alpha: 0.8),
                  size: 22.sp,
                ),
                
                // Professional notification badge
                if (hasNotifications && notificationCount > 0)
                  Positioned(
                    right: -4.w,
                    top: -4.h,
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFE5A00D), Color(0xFFD4940A)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(10.r),
                        border: Border.all(
                          color: const Color(0xFF121212), // Background color for separation
                          width: 1.5.w,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
                            blurRadius: 4.r,
                            offset: Offset(0, 1.h),
                          ),
                        ],
                      ),
                      constraints: BoxConstraints(
                        minWidth: 18.r,
                        minHeight: 18.r,
                      ),
                      child: Text(
                        notificationCount > 9 ? '9+' : notificationCount.toString(),
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 10.sp,
                          fontWeight: FontWeight.bold,
                          height: 1.0,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _acceptInvitation(BuildContext context, Map<String, dynamic> invitation) async {
    // Capture the context reference before any async operations
    final scaffoldMessenger = ScaffoldMessenger.of(context);
    
    // Close dropdown immediately to prevent lifecycle issues
    _safeCloseDropdown();
    
    try {
      final session = await SessionService.acceptInvitation(
        invitation['sessionId'],
        widget.currentUser.name,
      );
      
      if (!mounted) return; // Early exit if widget disposed
      
      if (session != null) {
        // Call the callback to join session
        widget.onSessionJoined(session);
        
        // Show success message
        scaffoldMessenger.showSnackBar(
          const SnackBar(
            content: Text('Successfully joined session!'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
      } else {
        // Session not available
        scaffoldMessenger.showSnackBar(
          const SnackBar(
            content: Text('Session no longer available'),
            backgroundColor: Colors.orange,
            duration: Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      print("❌ Error accepting invitation: $e");
      
      // Show error message
      scaffoldMessenger.showSnackBar(
        SnackBar(
          content: Text('Failed to join session: $e'),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  Future<void> _declineInvitation(String invitationId, String? sessionId) async {
    try {
      // Close dropdown when declining
      if (mounted) {
        _closeDropdown();
      }
      
      await SessionService.declineInvitation(invitationId, sessionId);
      
      print("✅ Invitation declined successfully");
    } catch (e) {
      print("❌ Error declining invitation: $e");
      // Optionally show an error message to the user
    }
  }
}