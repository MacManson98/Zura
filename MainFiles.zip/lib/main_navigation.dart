import 'package:flutter/material.dart';
import 'screens/matcher_screen.dart';
import 'screens/friends_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/home_screen.dart';
import 'models/user_profile.dart';
import 'movie.dart';
import 'custom_nav_bar.dart';
import 'screens/movies_screen.dart';
import 'services/friendship_service.dart';
import 'services/session_service.dart';
import 'screens/notifications_screen.dart';

class MainNavigation extends StatefulWidget {
  final UserProfile profile;
  final List<Movie> movies;

  const MainNavigation({
    super.key,
    required this.profile,
    required this.movies,
  });

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;
  
  static const int matchesTabIndex = 1;
  static const int matcherTabIndex = 2;

  UserProfile? _selectedFriend;
  MatchingMode _matcherMode = MatchingMode.solo;
  List<UserProfile> _availableFriends = [];
  late Widget _matcherScreen;

  @override
  void initState() {
    super.initState();
    _initializeUserSession();
    _matcherScreen = _buildMatcherScreen();
  }

  // ✅ Enhanced initialization with cleanup
  Future<void> _initializeUserSession() async {
    try {
      // Load friends
      await _loadFriends();
      
      // Clean up user's old data (run in background)
      _performUserCleanup();
    } catch (e) {
      print('Error initializing user session: $e');
    }
  }

  // ✅ User-specific cleanup
  Future<void> _performUserCleanup() async {
    try {
      print("🧹 Cleaning up user data for ${widget.profile.name}...");
      
      // Clean up user's old invitations
      await SessionService.cleanupUserInvitations(widget.profile.uid);
      
      print("✅ User cleanup completed");
    } catch (e) {
      print("Note: User cleanup failed: $e");
      // Don't affect user experience if cleanup fails
    }
  }

  Future<void> _loadFriends() async {
    try {
      final friends = await FriendshipService.getFriends(widget.profile.uid);
      if (mounted) {
        setState(() {
          _availableFriends = friends;
          _matcherScreen = _buildMatcherScreen();
        });
      }
    } catch (e) {
      print('Error loading friends: $e');
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _goToMatchesTab() {
    _onItemTapped(matchesTabIndex);
  }

  void _goToMatcherTab() {
    _onItemTapped(matcherTabIndex);
  }

  void _goToFriendMatcher(UserProfile friend) {
    print("🟢 Switching to Matcher tab with ${friend.name}");
    setState(() {
      _selectedFriend = friend;
      _matcherMode = MatchingMode.friend;
      _matcherScreen = _buildMatcherScreen();
      _selectedIndex = matcherTabIndex;
    });
  }

  Widget _buildMatcherScreen() {
    return MatcherScreen(
      allMovies: widget.movies,
      currentUser: widget.profile,
      availableFriends: _availableFriends,
      selectedFriend: _selectedFriend,
      mode: _matcherMode,
    );
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(
        profile: widget.profile,
        movies: widget.movies,
        onNavigateToMatches: _goToMatchesTab,
        onNavigateToMatcher: _goToMatcherTab,
      ),
      MoviesScreen(currentUser: widget.profile),
      _matcherScreen,
      FriendsScreen(
        currentUser: widget.profile,
        allMovies: widget.movies,
        onShowMatches: _goToMatchesTab,
        onMatchWithFriend: _goToFriendMatcher,
      ),
      ProfileScreen(
        currentUser: widget.profile,
        onNavigateToMatches: _goToMatchesTab,
      ),
    ];

    return Stack(
      children: [
        Scaffold(
          backgroundColor: const Color(0xFF121212),
          body: IndexedStack(
            index: _selectedIndex,
            children: screens,
          ),
          bottomNavigationBar: CustomNavBar(
            selectedIndex: _selectedIndex,
            onItemTapped: _onItemTapped,
          ),
        ),
        Positioned(
          top: MediaQuery.of(context).padding.top + 10,
          right: 16,
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => NotificationsScreen(
                    currentUser: widget.profile,
                    allMovies: widget.movies, // <-- pass in the full list
                  ),
                ),
              );

            },
            child: Stack(
              alignment: Alignment.center,
              children: [
                Icon(Icons.notifications, size: 28, color: Colors.white),
                // 🔴 TODO: Add unread count badge here later
              ],
            ),
          ),
        ),
      ],
    );
  }
}