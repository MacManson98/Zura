// File: lib/movie.dart (Enhanced Version)

class Movie {
  final String id;
  final String title;
  final String posterUrl;
  final String overview;
  final List<String> cast;
  final List<String> genres;
  final List<String> tags; // Your vibe tags + TMDB keywords
  
  // 🆕 NEW: Enhanced fields from your database
  final List<String>? subGenres; // Your enhanced vibe system
  final int? runtime; // Runtime in minutes
  final double? rating; // TMDB vote_average
  final int? voteCount; // TMDB vote_count
  final String? releaseDate; // Release date
  final String? originalLanguage; // Original language
  final double? rottenTomatoesScore;
  final List<String> directors;
  final List<String> writers;
  

  Movie({
    required this.id,
    required this.title,
    required this.posterUrl,
    required this.overview,
    required this.cast,
    required this.genres,
    required this.tags,
    this.subGenres,
    this.runtime,
    this.rating,
    this.voteCount,
    this.releaseDate,
    this.originalLanguage,
    this.rottenTomatoesScore,
    this.directors = const [],
    this.writers = const [],
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'posterUrl': posterUrl,
      'overview': overview,
      'cast': cast,
      'genres': genres,
      'tags': tags,
      'subGenres': subGenres,
      'runtime': runtime,
      'rating': rating,
      'voteCount': voteCount,
      'releaseDate': releaseDate,
      'originalLanguage': originalLanguage,
      'directors': directors,
      'writers': writers,
    };
  }

  factory Movie.fromJson(Map<String, dynamic> json) {
    return Movie(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      posterUrl: json['posterUrl'] ?? '',
      overview: json['overview'] ?? '',
      cast: List<String>.from(json['cast'] ?? []),
      genres: List<String>.from(json['genres'] ?? []),
      tags: List<String>.from(json['tags'] ?? []),
      subGenres: json['subGenres'] != null ? List<String>.from(json['subGenres']) : null,
      runtime: json['runtime']?.toInt(),
      rating: json['rating']?.toDouble(),
      voteCount: json['voteCount']?.toInt(),
      releaseDate: json['releaseDate'],
      originalLanguage: json['originalLanguage'],
      rottenTomatoesScore: json['rottenTomatoesScore'],
      directors: List<String>.from(json['directors'] ?? []),
      writers: List<String>.from(json['writers'] ?? []),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is Movie && id == other.id);

  @override
  int get hashCode => id.hashCode;
  
  /// Helper methods for the learning engine
  
  /// Get quality score based on rating and vote count
  double get qualityScore {
    if (rating == null || voteCount == null) return 0.0;
    
    // Weighted score considering both rating and popularity
    final ratingWeight = (rating! / 10.0) * 0.7;
    final popularityWeight = (voteCount! > 1000 ? 1.0 : voteCount! / 1000.0) * 0.3;
    
    return ratingWeight + popularityWeight;
  }
  
  /// Check if this is a high-quality movie suitable for discovery
  bool get isHighQuality {
    return rating != null && 
           rating! >= 7.0 && 
           voteCount != null && 
           voteCount! >= 100;
  }
  
  /// Get runtime category for learning purposes
  String get runtimeCategory {
    if (runtime == null) return 'unknown';
    if (runtime! < 90) return 'short';
    if (runtime! < 130) return 'medium';
    return 'long';
  }
  
  /// Get rating category for learning purposes
  String get ratingCategory {
    if (rating == null) return 'unknown';
    if (rating! < 6.0) return 'low';
    if (rating! < 7.5) return 'medium';
    if (rating! < 8.5) return 'high';
    return 'exceptional';
  }
  
  /// Check if movie is in English (for language preference learning)
  bool get isEnglish => originalLanguage == 'en';
  
  /// Get decade for potential trend analysis
  String get decade {
    if (releaseDate == null || releaseDate!.length < 4) return 'unknown';
    try {
      final year = int.parse(releaseDate!.substring(0, 4));
      final decade = (year ~/ 10) * 10;
      return '${decade}s';
    } catch (e) {
      return 'unknown';
    }
  }
}

// Sample movies for fallback (keep your existing implementation)
final List<Movie> sampleMovies = [
  Movie(
    id: '1',
    title: "The Dark Knight",
    posterUrl: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg",
    overview: "Batman faces the Joker, a criminal mastermind who plunges Gotham into chaos.",
    cast: ["Christian Bale", "Heath Ledger", "Aaron Eckhart"],
    genres: ["Action", "Crime", "Thriller"],
    tags: ["Dark", "Intense", "Mind-bending"],
    subGenres: ["Superhero", "Dark"],
    runtime: 152,
    rating: 9.0,
    voteCount: 2500000,
    releaseDate: "2008-07-18",
    originalLanguage: "en",
  ),
  Movie(
    id: '2',
    title: "Fight Club",
    posterUrl: "https://image.tmdb.org/t/p/w500/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg",
    overview: "An insomniac office worker forms an underground fight club with a soap maker.",
    cast: ["Edward Norton", "Brad Pitt", "Helena Bonham Carter"],
    genres: ["Drama"],
    tags: ["Twisty", "Mind-bending", "Dark/Disturbing"],
    subGenres: ["Psychological", "Dark"],
    runtime: 139,
    rating: 8.8,
    voteCount: 1800000,
    releaseDate: "1999-10-15",
    originalLanguage: "en",
  ),
  Movie(
    id: '3',
    title: "Forrest Gump",
    posterUrl: "https://image.tmdb.org/t/p/w500/saHP97rTPS5eLmrLQEcANmKrsFl.jpg",
    overview: "The story of a man with a low IQ who witnesses and influences historical events.",
    cast: ["Tom Hanks", "Robin Wright", "Gary Sinise"],
    genres: ["Drama", "Romance"],
    tags: ["Feel-good", "Based on a True Story", "Emotional"],
    subGenres: ["Feel-Good", "Epic"],
    runtime: 142,
    rating: 8.8,
    voteCount: 1900000,
    releaseDate: "1994-07-06",
    originalLanguage: "en",
  ),
  Movie(
    id: '4',
    title: "The Lord of the Rings",
    posterUrl: "https://image.tmdb.org/t/p/w500/6oom5QYQ2yQTMJIbnvbkBL9cHo6.jpg",
    overview: "A hobbit sets out on a quest to destroy a powerful ring and defeat evil.",
    cast: ["Elijah Wood", "Ian McKellen", "Viggo Mortensen"],
    genres: ["Fantasy", "Adventure"],
    tags: ["Epic", "Action-Packed", "Adventure"],
    subGenres: ["Epic", "Fantasy"],
    runtime: 178,
    rating: 8.8,
    voteCount: 1700000,
    releaseDate: "2001-12-19",
    originalLanguage: "en",
  ),
];