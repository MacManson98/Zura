// File: lib/utils/mood_based_learning_engine.dart

import '../movie.dart';
import '../models/user_profile.dart';

// Mood-based session management
enum CurrentMood {
  perfectForMe('Perfect For Me', '🎯', [], []), // Solo mode - uses enhanced learning
  perfectForUs('Perfect For Us', '🤝', [], []),
  chill('Chill & Relaxed', '😌', ['Comedy', 'Romance', 'Animation'], ['Feel-Good', 'Romantic', 'Funny']),
  emotional('In My Feelings', '💭', ['Drama', 'Romance', 'Biography'], ['Emotional', 'Romantic', 'Deep']),
  thoughtful('Deep & Thoughtful', '🤔', ['Drama', 'Mystery', 'Sci-Fi'], ['Mind-Bending', 'Artsy/Indie', 'Deep']),
  fun('Just Want Fun', '🎉', ['Comedy', 'Animation', 'Adventure'], ['Funny', 'Feel-Good', 'Light']),
  scary('Thrill Seeker', '😱', ['Horror', 'Thriller', 'Mystery'], ['Scary', 'Dark/Disturbing', 'Intense']),
  romantic('Love Is In The Air', '💕', ['Romance', 'Comedy', 'Drama'], ['Romantic', 'Feel-Good', 'Emotional']),
  adventurous('Adventure Awaits!', '🗺️', ['Adventure', 'Action', 'Fantasy'], ['Epic', 'Action-Packed', 'Adventure']);

  const CurrentMood(this.displayName, this.emoji, this.preferredGenres, this.preferredVibes);
  
  final String displayName;
  final String emoji;
  final List<String> preferredGenres;
  final List<String> preferredVibes;
  
  // Helper to check if this is a profile-based mood
  bool get isProfileBased => this == CurrentMood.perfectForMe || this == CurrentMood.perfectForUs;
}

class SessionContext {
  final CurrentMood moods;
  final DateTime startTime;
  final List<String> groupMemberIds;
  final Map<String, int> sessionGenreLikes = {};
  final Map<String, int> sessionGenrePasses = {};
  final List<String> recentSwipes = [];
  String? detectedMomentum;
  
  SessionContext({
    required this.moods,
    required this.groupMemberIds,
    DateTime? startTime,
  }) : startTime = startTime ?? DateTime.now();
  
  // Quick session adaptation - learn from just 3-5 swipes
  void trackSwipe(Movie movie, bool isLike) {
    recentSwipes.add(isLike ? 'like' : 'pass');
    if (recentSwipes.length > 8) recentSwipes.removeAt(0); // Keep last 8 swipes
    
    for (final genre in movie.genres) {
      if (isLike) {
        sessionGenreLikes[genre] = sessionGenreLikes.containsKey(genre) 
            ? sessionGenreLikes[genre]! + 1 
            : 1;
      } else {
        sessionGenrePasses[genre] = sessionGenrePasses.containsKey(genre) 
            ? sessionGenrePasses[genre]! + 1 
            : 1;
      }
    }
    
    _detectQuickMomentum();
  }
  
  void _detectQuickMomentum() {
    // Detect momentum after just 3 consecutive likes in same genre
    for (final entry in sessionGenreLikes.entries) {
      if (entry.value >= 3) {
        detectedMomentum = entry.key;
        break;
      }
    }
    
    // Detect if user is being too picky (need variety)
    final recentPasses = recentSwipes.where((s) => s == 'pass').length;
    if (recentPasses >= 5 && recentSwipes.length >= 6) {
      detectedMomentum = 'variety_needed';
    }
  }
  
  bool get needsVariety => detectedMomentum == 'variety_needed';
  bool get hasGenreMomentum => detectedMomentum != null && detectedMomentum != 'variety_needed';
  
  double get currentLikeRate {
    if (recentSwipes.isEmpty) return 0.5;
    final likes = recentSwipes.where((s) => s == 'like').length;
    return likes / recentSwipes.length;
  }
}

class MoodBasedLearningEngine {
  static const double moodWeight = 3.0; // Strong weight for current mood
  static const double sessionWeight = 2.5; // Medium weight for session learning
  static const double generalWeight = 1.0; // Light weight for general taste
  static const double groupConsensusThreshold = 0.6; // 60% group agreement needed
  static const double groupIntersectionThreshold = 0.7; // 70% for "Perfect For Us"
  
  /// Generate mood-based session for immediate watchability
  static Future<List<Movie>> generateMoodBasedSession({
    required UserProfile user,
    required List<Movie> movieDatabase,
    required SessionContext sessionContext,
    required Set<String> seenMovieIds,
    int sessionSize = 30,
  }) async {
    // Handle profile-based moods differently
    if (sessionContext.moods == CurrentMood.perfectForMe) {
      print("🎯 Generating 'Perfect For Me' session using Enhanced Learning Engine");
      // This will be handled in the matcher screen directly
      return [];
    }
    
    print("🎭 Generating mood-based session: ${sessionContext.moods.displayName}");
    
    final moviePool = <Movie, double>{};
    
    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      
      double score = _calculateMoodScore(user, movie, sessionContext);
      
      if (score > 0) {
        moviePool[movie] = score;
      }
    }
    
    // Sort by score and take top movies
    final sortedMovies = moviePool.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    final selectedMovies = sortedMovies.take(sessionSize).map((e) => e.key).toList();
    
    // Add variety if needed (curveballs)
    if (sessionContext.needsVariety) {
      final varietyMovies = _getCurveballMovies(movieDatabase, seenMovieIds, user, 5);
      selectedMovies.addAll(varietyMovies);
    }
    
    selectedMovies.shuffle();
    print("🎬 Generated ${selectedMovies.length} mood-appropriate movies");
    return selectedMovies;
  }
  
  /// Generate "Perfect For Us" session based on group profile intersection
  static Future<List<Movie>> generatePerfectForUsSession({
    required List<UserProfile> groupMembers,
    required List<Movie> movieDatabase,
    required Set<String> seenMovieIds,
    int sessionSize = 25,
    int minMoviesPerPerson = 10,
  }) async {
    print("🤝 Generating 'Perfect For Us' session for ${groupMembers.length} people");
    
    // Step 1: Find intersection of everyone's preferences
    final intersectionMovies = await _findGroupIntersectionMovies(
      groupMembers, 
      movieDatabase, 
      seenMovieIds
    );
    
    // Step 2: Ensure everyone has at least minMoviesPerPerson they'd like
    final finalPool = <Movie>{};
    finalPool.addAll(intersectionMovies);
    
    // Step 3: Add individual preferences until everyone has enough movies
    for (final member in groupMembers) {
      final memberMovies = _getMoviesForUser(member, movieDatabase, seenMovieIds);
      final memberLikelyMovies = memberMovies.where((movie) => 
        _calculateUserMovieScore(member, movie) > 3.0
      ).toList();
      
      finalPool.addAll(memberLikelyMovies.take(minMoviesPerPerson));
      
      if (finalPool.length >= sessionSize) break;
    }
    
    final result = finalPool.toList()..shuffle();
    print("🤝 Generated ${result.length} group-compatible movies");
    return result.take(sessionSize).toList();
  }
  
  /// Find movies that work well for ALL group members
  static Future<List<Movie>> _findGroupIntersectionMovies(
    List<UserProfile> groupMembers,
    List<Movie> movieDatabase,
    Set<String> seenMovieIds,
  ) async {
    final intersectionMovies = <Movie, double>{};
    
    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      
      // Calculate how well this movie works for the entire group
      double groupScore = 0.0;
      bool anyoneDislikesIt = false;
      
      for (final member in groupMembers) {
        final memberScore = _calculateUserMovieScore(member, movie);
        
        // If anyone strongly dislikes it, skip this movie
        if (memberScore < 1.0) {
          anyoneDislikesIt = true;
          break;
        }
        
        groupScore += memberScore;
      }
      
      if (!anyoneDislikesIt) {
        final averageScore = groupScore / groupMembers.length;
        if (averageScore >= groupIntersectionThreshold) {
          intersectionMovies[movie] = averageScore;
        }
      }
    }
    
    // Sort by group compatibility
    final sorted = intersectionMovies.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    return sorted.map((e) => e.key).toList();
  }
  
  /// Calculate how much a specific user would like a specific movie
  static double _calculateUserMovieScore(UserProfile user, Movie movie) {
    double score = 0.0;
    
    // Genre preferences
    for (final genre in movie.genres) {
      final genreScore = user.genreScores[genre] ?? 0;
      final dislikeScore = user.dislikeScores[genre] ?? 0;
      score += (genreScore - dislikeScore * 0.8);
    }
    
    // Vibe preferences
    for (final vibe in movie.tags) {
      final vibeScore = user.vibeScores[vibe] ?? 0;
      final dislikeScore = user.dislikeVibeScores[vibe] ?? 0;
      score += (vibeScore - dislikeScore * 1.0);
    }
    
    // Quality boost
    if (movie.rating != null && movie.rating! > 7.5) {
      score += 2.0;
    }
    
    return score;
  }
  
  /// Get movies that a specific user would likely enjoy
  static List<Movie> _getMoviesForUser(UserProfile user, List<Movie> movieDatabase, Set<String> seenMovieIds) {
    final userMovies = <Movie, double>{};
    
    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      
      final score = _calculateUserMovieScore(user, movie);
      if (score > 2.0) {
        userMovies[movie] = score;
      }
    }
    
    final sorted = userMovies.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    return sorted.map((e) => e.key).toList();
  }
  
  /// Calculate how well a movie matches current mood + user preferences
  static double _calculateMoodScore(UserProfile user, Movie movie, SessionContext context) {
    double score = 0.0;
    
    // 1. MOOD ALIGNMENT (strongest factor)
    final moodGenreMatch = movie.genres.any((g) => context.moods.preferredGenres.contains(g));
    final moodVibeMatch = movie.tags.any((v) => context.moods.preferredVibes.contains(v));
    
    if (moodGenreMatch && moodVibeMatch) {
      score += moodWeight * 3.0; // Higher reward for perfect matches
    } else if (moodGenreMatch || moodVibeMatch) {
      score += moodWeight * 0.5; // Much lower score for partial matches
    }
    
    // 2. SESSION MOMENTUM (adapt to current session)
    if (context.hasGenreMomentum && movie.genres.contains(context.detectedMomentum)) {
      score += sessionWeight * 1.5;
    }
    
    // 3. USER'S HISTORICAL PREFERENCES (lighter weight)
    for (final genre in movie.genres) {
      final userScore = user.getGenrePreference(genre);
      score += userScore * generalWeight * 0.3;
    }
    
    for (final vibe in movie.tags) {
      final vibeScore = (user.vibeScores[vibe] ?? 0) - (user.dislikeVibeScores[vibe] ?? 0);
      score += vibeScore * generalWeight * 0.2;
    }
    
    // 4. QUALITY BOOST
    if (movie.rating != null && movie.rating! > 7.5) {
      score += 1.5;
    }
    
    // 5. FATIGUE PENALTY (avoid overused genres)
    for (final genre in movie.genres) {
      final fatigue = user.genreFatigue[genre] ?? 0;
      score -= fatigue * 0.5;
    }
    
    return score;
  }
  
  /// Smart group recommendation engine
  static Future<List<Movie>> generateGroupSession({
    required List<UserProfile> groupMembers,
    required List<Movie> movieDatabase,
    required SessionContext sessionContext,
    required Set<String> seenMovieIds,
    int sessionSize = 25,
  }) async {
    // Handle "Perfect For Us" mood
    if (sessionContext.moods == CurrentMood.perfectForUs) {
      return generatePerfectForUsSession(
        groupMembers: groupMembers,
        movieDatabase: movieDatabase,
        seenMovieIds: seenMovieIds,
        sessionSize: sessionSize,
      );
    }
    
    print("👥 Generating group session for ${groupMembers.length} people");
    
    final groupMovies = <Movie, double>{};
    
    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      
      // Calculate group consensus score
      double groupScore = _calculateGroupConsensus(groupMembers, movie, sessionContext);
      
      if (groupScore >= groupConsensusThreshold) {
        groupMovies[movie] = groupScore;
      }
    }
    
    // Sort and select
    final sortedMovies = groupMovies.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    final result = sortedMovies.take(sessionSize).map((e) => e.key).toList()..shuffle();
    print("🤝 Found ${result.length} group-friendly movies");
    return result;
  }
  
  /// Calculate how well a movie works for the entire group
  static double _calculateGroupConsensus(List<UserProfile> group, Movie movie, SessionContext context) {
    double totalScore = 0.0;
    int memberCount = group.length;
    
    for (final member in group) {
      double memberScore = 0.0;
      
      // Mood compatibility
      final moodMatch = movie.genres.any((g) => context.moods.preferredGenres.contains(g));
      if (moodMatch) memberScore += 2.0;
      
      // Personal preference
      for (final genre in movie.genres) {
        memberScore += member.getGenrePreference(genre) * 0.3;
      }
      
      // Avoid movies they've strongly disliked
      bool hasStrongDislike = movie.genres.any((g) => (member.dislikeScores[g] ?? 0) > 3.0);
      if (hasStrongDislike) memberScore = 0.0; // Veto power
      
      totalScore += memberScore;
    }
    
    // Return average score (0-1 range)
    return totalScore / memberCount / 4.0; // Normalize to 0-1
  }
  
  /// Learn from mood-based interactions
  static void learnFromMoodInteraction(UserProfile user, Movie movie, SessionContext context, bool isLike) {
    if (isLike) {
      _learnFromMoodLike(user, movie, context);
    } else {
      _learnFromMoodPass(user, movie, context);
    }
    
    // Track session progression
    context.trackSwipe(movie, isLike);
  }
  
  static void _learnFromMoodLike(UserProfile user, Movie movie, SessionContext context) {
    // Strong learning for mood-appropriate likes
    for (final genre in movie.genres) {
      // If they liked it and it matches their current mood, boost preference
      if (context.moods.preferredGenres.contains(genre)) {
        user.genreScores[genre] = _updateScore(user.genreScores[genre] ?? 0, moodWeight, true);
      } else {
        // They liked it even though it doesn't match mood - strong signal
        user.genreScores[genre] = _updateScore(user.genreScores[genre] ?? 0, sessionWeight, true);
      }
    }
    
    // Learn vibe preferences
    for (final vibe in movie.tags) {
      if (context.moods.preferredVibes.contains(vibe)) {
        user.vibeScores[vibe] = _updateScore(user.vibeScores[vibe] ?? 0, moodWeight, true);
      } else {
        user.vibeScores[vibe] = _updateScore(user.vibeScores[vibe] ?? 0, sessionWeight, true);
      }
    }
    
    user.likedMovies.add(movie);
    user.likedMovieIds.add(movie.id);
    user.lastActivityDate = DateTime.now();
    
    print("✅ Mood-based LIKE: ${movie.title} (${context.moods.displayName})");
  }
  
  static void _learnFromMoodPass(UserProfile user, Movie movie, SessionContext context) {
    // Light penalty for mood mismatches
    for (final genre in movie.genres) {
      user.dislikeScores[genre] = _updateScore(user.dislikeScores[genre] ?? 0, 1.0, true);
      
      // Track fatigue if they keep passing on same genres
      user.genreFatigue[genre] = user.genreFatigue.containsKey(genre) 
          ? user.genreFatigue[genre]! + 1 
          : 1;
    }
    
    user.passedMovieIds.add(movie.id);
    user.lastActivityDate = DateTime.now();
    
    print("❌ Mood-based PASS: ${movie.title}");
  }
  
  /// Get curveball movies for variety
  static List<Movie> _getCurveballMovies(List<Movie> movieDatabase, Set<String> seenMovieIds, UserProfile user, int count) {
    // Find highly-rated movies from genres they haven't explored much
    final unexploredGenres = ['Action', 'Comedy', 'Drama', 'Horror', 'Romance', 'Sci-Fi', 'Fantasy', 'Thriller']
        .where((g) => (user.genreScores[g] ?? 0) < 2.0 && (user.dislikeScores[g] ?? 0) < 2.0)
        .toList();
    
    final curveballs = <Movie>[];
    
    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      if (curveballs.length >= count) break;
      
      // Must be highly rated for curveball
      if (movie.rating == null || movie.rating! < 7.0) continue;
      
      final hasUnexploredGenre = movie.genres.any((g) => unexploredGenres.contains(g));
      if (hasUnexploredGenre) {
        curveballs.add(movie);
      }
    }
    
    curveballs.shuffle();
    return curveballs;
  }
  
  /// Adaptive session refresh during swiping
  static Future<List<Movie>> adaptSession({
    required UserProfile user,
    required List<Movie> movieDatabase,
    required SessionContext context,
    required Set<String> seenMovieIds,
    int adaptiveCount = 10,
  }) async {
    print("🔄 Adapting session based on current momentum");
    
    if (context.hasGenreMomentum) {
      // User is in a groove - give them more of what they want
      return _getMoreOfSameGenre(movieDatabase, context.detectedMomentum!, seenMovieIds, adaptiveCount);
    } else if (context.needsVariety) {
      // User needs variety - mix it up
      return _getCurveballMovies(movieDatabase, seenMovieIds, user, adaptiveCount);
    } else {
      // Standard mood-based generation
      return generateMoodBasedSession(
        user: user,
        movieDatabase: movieDatabase,
        sessionContext: context,
        seenMovieIds: seenMovieIds,
        sessionSize: adaptiveCount,
      );
    }
  }
  
  static List<Movie> _getMoreOfSameGenre(List<Movie> movieDatabase, String genre, Set<String> seenMovieIds, int count) {
    final genreMovies = movieDatabase.where((movie) =>
      !seenMovieIds.contains(movie.id) &&
      movie.genres.contains(genre) &&
      _meetsQualityThreshold(movie) &&
      _isSfwMovie(movie)
    ).toList();
    
    genreMovies.shuffle();
    return genreMovies.take(count).toList();
  }
  
  // Helper methods
  static double _updateScore(double currentScore, double weight, bool isPositive) {
    const double maxScore = 20.0;
    const double minScore = 0.0;
    
    final newScore = isPositive 
        ? currentScore + weight 
        : (currentScore - weight).clamp(minScore, double.infinity);
    return newScore.clamp(minScore, maxScore);
  }
  
  static bool _meetsQualityThreshold(Movie movie) {
    return movie.posterUrl.isNotEmpty &&
           movie.rating != null &&
           movie.rating! >= 5.0 &&
           movie.voteCount != null &&
           movie.voteCount! >= 1000;
  }
  
  static bool _isSfwMovie(Movie movie) {
    final bannedKeywords = ['porn', 'erotic', 'xxx', 'adult', 'sex', 'nude', 'strip'];
    final lcTitle = movie.title.toLowerCase();
    final lcOverview = movie.overview.toLowerCase();
    return !bannedKeywords.any((kw) => lcTitle.contains(kw) || lcOverview.contains(kw));
  }

  static bool meetsQualityThreshold(Movie movie) {
    return _meetsQualityThreshold(movie);
  }

  /// Helper method to check if movie is SFW (make it accessible)
  static bool isSfwMovie(Movie movie) {
    return _isSfwMovie(movie);
  }

  /// Generate session for blended moods
  static Future<List<Movie>> generateBlendedMoodSession({
    required UserProfile user,
    required List<Movie> movieDatabase,
    required List<CurrentMood> selectedMoods,
    required Set<String> seenMovieIds,
    int sessionSize = 30,
  }) async {
    print("🎭 Generating blended mood session for: ${selectedMoods.map((m) => m.displayName).join(' + ')}");
    
    final moviePool = <Movie, double>{};
    
    // Combine all preferred genres and vibes from selected moods
    final Set<String> allPreferredGenres = {};
    final Set<String> allPreferredVibes = {};
    
    for (final mood in selectedMoods) {
      allPreferredGenres.addAll(mood.preferredGenres);
      allPreferredVibes.addAll(mood.preferredVibes);
    }
    
    print("   Combined genres: ${allPreferredGenres.join(', ')}");
    print("   Combined vibes: ${allPreferredVibes.join(', ')}");
    
    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      
      double score = _calculateBlendedMoodScore(user, movie, selectedMoods, allPreferredGenres, allPreferredVibes);
      
      if (score > 0) {
        moviePool[movie] = score;
      }
    }
    
    // Sort by score and take top movies
    final sortedMovies = moviePool.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    final selectedMovies = sortedMovies.take(sessionSize).map((e) => e.key).toList();
    selectedMovies.shuffle();
    
    print("🎬 Generated ${selectedMovies.length} blended mood movies");
    return selectedMovies;
  }

  /// Calculate score for blended moods
  static double _calculateBlendedMoodScore(
    UserProfile user, 
    Movie movie, 
    List<CurrentMood> moods,
    Set<String> allPreferredGenres,
    Set<String> allPreferredVibes,
  ) {
    double score = 0.0;
    const double moodWeight = 3.0;
    const double generalWeight = 1.0;
    
    // 1. MOOD ALIGNMENT (strongest factor)
    final moodGenreMatches = movie.genres.where((g) => allPreferredGenres.contains(g)).length;
    final moodVibeMatches = movie.tags.where((v) => allPreferredVibes.contains(v)).length;
    
    // Score based on number of mood matches (more matches = higher score)
    score += moodGenreMatches * moodWeight * 2.0;
    score += moodVibeMatches * moodWeight * 1.5;
    
    // Bonus for movies that match multiple selected moods
    if (moodGenreMatches > 1 || moodVibeMatches > 1) {
      score += 2.0; // Multi-mood bonus
    }
    
    // Extra bonus if movie matches genres/vibes from multiple different moods
    int moodMatchCount = 0;
    for (final mood in moods) {
      bool matchesThisMood = movie.genres.any((g) => mood.preferredGenres.contains(g)) ||
                            movie.tags.any((v) => mood.preferredVibes.contains(v));
      if (matchesThisMood) moodMatchCount++;
    }
    
    if (moodMatchCount > 1) {
      score += moodMatchCount * 1.0; // Cross-mood compatibility bonus
    }
    
    // 2. USER'S HISTORICAL PREFERENCES (lighter weight)
    for (final genre in movie.genres) {
      final userScore = user.getGenrePreference(genre);
      score += userScore * generalWeight * 0.3;
    }
    
    for (final vibe in movie.tags) {
      final vibeScore = (user.vibeScores[vibe] ?? 0) - (user.dislikeVibeScores[vibe] ?? 0);
      score += vibeScore * generalWeight * 0.2;
    }
    
    // 3. QUALITY BOOST
    if (movie.rating != null && movie.rating! > 7.5) {
      score += 1.5;
    }
    
    // 4. FATIGUE PENALTY (avoid overused genres)
    for (final genre in movie.genres) {
      final fatigue = user.genreFatigue[genre] ?? 0;
      score -= fatigue * 0.5;
    }
    
    return score;
  }  
}