// File: lib/models/friend_group.dart

import 'user_profile.dart';

class FriendGroup {
  final String id;
  final String name;
  final List<UserProfile> members;
  final String createdBy;
  final String imageUrl;

  FriendGroup({
    required this.id,
    required this.name,
    required this.members,
    required this.createdBy,
    required this.imageUrl,
  });

  // Optional: Add toJson and fromJson methods if you want to store groups

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'members': members.map((member) => member.toJson()).toList(),
      'createdBy': createdBy,
      'imageUrl': imageUrl,
    };
  }

  factory FriendGroup.fromJson(Map<String, dynamic> json) {
    return FriendGroup(
      id: json['id'] as String,
      name: json['name'] as String,
      members: (json['members'] as List).map((e) => UserProfile.fromJson(e as Map<String, dynamic>)).toList(),
      createdBy: json['createdBy'] as String,
      imageUrl: json['imageUrl'] as String,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is FriendGroup &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;
}