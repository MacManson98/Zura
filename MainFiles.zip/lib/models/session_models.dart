// File: lib/models/session_models.dart
import 'package:firebase_auth/firebase_auth.dart';

enum SessionStatus {
  created,     // Host created, waiting for friend
  active,      // Both users joined, swiping together
  completed,   // Session finished
  cancelled,   // Session cancelled by someone
}

enum InvitationType {
  friend,      // Direct friend invite
  code,        // Share code method
  qr,          // QR code sharing
}

class SwipeSession {
  final String sessionId;
  final String hostId;
  final String hostName;
  final List<String> participantIds;
  final List<String> participantNames;
  final SessionStatus status;
  final String? sessionCode;
  final DateTime createdAt;
  final DateTime? startedAt;
  final DateTime? completedAt;
  final Map<String, dynamic> sessionSettings;
  final List<String> selectedMoodIds;
  final List<String> moviePool;
  final Map<String, List<String>> userLikes;  // userId -> [movieIds]
  final Map<String, List<String>> userPasses; // userId -> [movieIds]
  final List<String> matches; // movieIds that everyone liked
  final int currentMovieIndex;
  final InvitationType inviteType;
  
  // 🆕 NEW: Host's chosen mood for the session
  final String? selectedMoodId;      // The mood ID/name chosen by host (e.g., "cozyNightIn")
  final String? selectedMoodName;    // Display name (e.g., "Cozy Night In")
  final String? selectedMoodEmoji;   // Emoji for the mood (e.g., "🏠")

  SwipeSession({
    required this.sessionId,
    required this.hostId,
    required this.hostName,
    required this.participantIds,
    required this.participantNames,
    required this.status,
    this.sessionCode,
    required this.createdAt,
    this.startedAt,
    this.completedAt,
    required this.sessionSettings,
    required this.selectedMoodIds,
    required this.moviePool,
    required this.userLikes,
    required this.userPasses,
    required this.matches,
    this.currentMovieIndex = 0,
    required this.inviteType,
    // 🆕 NEW: Add mood parameters
    this.selectedMoodId,
    this.selectedMoodName,
    this.selectedMoodEmoji,
  });

  factory SwipeSession.create({
    required String hostId,
    required String hostName,
    required InvitationType inviteType,
    String? sessionCode,
    // 🆕 NEW: Add optional mood parameter
    String? selectedMoodId,
    String? selectedMoodName,
    String? selectedMoodEmoji,
  }) {
    return SwipeSession(
      sessionId: DateTime.now().millisecondsSinceEpoch.toString(),
      hostId: hostId,
      hostName: hostName,
      participantIds: [hostId],
      participantNames: [hostName],
      status: SessionStatus.created,
      sessionCode: sessionCode,
      createdAt: DateTime.now(),
      sessionSettings: {},
      selectedMoodIds: selectedMoodId != null ? [selectedMoodId] : [], // Add to existing list too
      moviePool: [],
      userLikes: {hostId: []},
      userPasses: {hostId: []},
      matches: [],
      inviteType: inviteType,
      // 🆕 NEW: Set mood fields
      selectedMoodId: selectedMoodId,
      selectedMoodName: selectedMoodName,
      selectedMoodEmoji: selectedMoodEmoji,
    );
  }

  SwipeSession copyWith({
    String? sessionId,
    String? hostId,
    String? hostName,
    List<String>? participantIds,
    List<String>? participantNames,
    SessionStatus? status,
    String? sessionCode,
    DateTime? createdAt,
    DateTime? startedAt,
    DateTime? completedAt,
    Map<String, dynamic>? sessionSettings,
    List<String>? selectedMoodIds,
    List<String>? moviePool,
    Map<String, List<String>>? userLikes,
    Map<String, List<String>>? userPasses,
    List<String>? matches,
    int? currentMovieIndex,
    InvitationType? inviteType,
    // 🆕 NEW: Add mood parameters to copyWith
    String? selectedMoodId,
    String? selectedMoodName,
    String? selectedMoodEmoji,
  }) {
    return SwipeSession(
      sessionId: sessionId ?? this.sessionId,
      hostId: hostId ?? this.hostId,
      hostName: hostName ?? this.hostName,
      participantIds: participantIds ?? this.participantIds,
      participantNames: participantNames ?? this.participantNames,
      status: status ?? this.status,
      sessionCode: sessionCode ?? this.sessionCode,
      createdAt: createdAt ?? this.createdAt,
      startedAt: startedAt ?? this.startedAt,
      completedAt: completedAt ?? this.completedAt,
      sessionSettings: sessionSettings ?? this.sessionSettings,
      selectedMoodIds: selectedMoodIds ?? this.selectedMoodIds,
      moviePool: moviePool ?? this.moviePool,
      userLikes: userLikes ?? this.userLikes,
      userPasses: userPasses ?? this.userPasses,
      matches: matches ?? this.matches,
      currentMovieIndex: currentMovieIndex ?? this.currentMovieIndex,
      inviteType: inviteType ?? this.inviteType,
      // 🆕 NEW: Include mood fields in copyWith
      selectedMoodId: selectedMoodId ?? this.selectedMoodId,
      selectedMoodName: selectedMoodName ?? this.selectedMoodName,
      selectedMoodEmoji: selectedMoodEmoji ?? this.selectedMoodEmoji,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'sessionId': sessionId,
      'hostId': hostId,
      'hostName': hostName,
      'participantIds': participantIds,
      'participantNames': participantNames,
      'status': status.name,
      'sessionCode': sessionCode,
      'createdAt': createdAt.toIso8601String(),
      'startedAt': startedAt?.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
      'sessionSettings': sessionSettings,
      'selectedMoodIds': selectedMoodIds,
      'moviePool': moviePool,
      'userLikes': userLikes,
      'userPasses': userPasses,
      'matches': matches,
      'currentMovieIndex': currentMovieIndex,
      'inviteType': inviteType.name,
      // 🆕 NEW: Include mood fields in JSON
      'selectedMoodId': selectedMoodId,
      'selectedMoodName': selectedMoodName,
      'selectedMoodEmoji': selectedMoodEmoji,
    };
  }

  factory SwipeSession.fromJson(Map<String, dynamic> json) {
    return SwipeSession(
      sessionId: json['sessionId'],
      hostId: json['hostId'],
      hostName: json['hostName'],
      participantIds: List<String>.from(json['participantIds'] ?? []),
      participantNames: List<String>.from(json['participantNames'] ?? []),
      status: SessionStatus.values.byName(json['status']),
      sessionCode: json['sessionCode'],
      createdAt: DateTime.parse(json['createdAt']),
      startedAt: json['startedAt'] != null ? DateTime.parse(json['startedAt']) : null,
      completedAt: json['completedAt'] != null ? DateTime.parse(json['completedAt']) : null,
      sessionSettings: Map<String, dynamic>.from(json['sessionSettings'] ?? {}),
      selectedMoodIds: List<String>.from(json['selectedMoodIds'] ?? []),
      moviePool: List<String>.from(json['moviePool'] ?? []),
      userLikes: Map<String, List<String>>.from(
        (json['userLikes'] ?? {}).map((k, v) => MapEntry(k, List<String>.from(v)))
      ),
      userPasses: Map<String, List<String>>.from(
        (json['userPasses'] ?? {}).map((k, v) => MapEntry(k, List<String>.from(v)))
      ),
      matches: List<String>.from(json['matches'] ?? []),
      currentMovieIndex: json['currentMovieIndex'] ?? 0,
      inviteType: InvitationType.values.byName(json['inviteType']),
      // 🆕 NEW: Parse mood fields from JSON
      selectedMoodId: json['selectedMoodId'],
      selectedMoodName: json['selectedMoodName'],
      selectedMoodEmoji: json['selectedMoodEmoji'],
    );
  }

  // Helper methods
  bool get isHost => FirebaseAuth.instance.currentUser?.uid == hostId;
  bool get isActive => status == SessionStatus.active;
  bool get isWaitingForParticipants => status == SessionStatus.created;
  
  // 🆕 NEW: Helper method to check if host selected a mood
  bool get hasMoodSelected => selectedMoodId != null && selectedMoodName != null;
  
  bool hasUserLiked(String userId, String movieId) {
    return userLikes[userId]?.contains(movieId) ?? false;
  }
  
  bool hasUserPassed(String userId, String movieId) {
    return userPasses[userId]?.contains(movieId) ?? false;
  }
  
  bool isMovieMatch(String movieId) {
    return matches.contains(movieId);
  }
  
  int getUserSwipeCount(String userId) {
    final likes = userLikes[userId]?.length ?? 0;
    final passes = userPasses[userId]?.length ?? 0;
    return likes + passes;
  }
  
  double getSessionProgress() {
    if (moviePool.isEmpty) return 0.0;
    return currentMovieIndex / moviePool.length;
  }
}