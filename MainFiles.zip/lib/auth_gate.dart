import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:movie_matcher_clean/screens/onboarding/welcome_onboarding_screen.dart';
import 'screens/auth/login_screen.dart';
import 'main_navigation.dart';  // Updated import
import 'models/user_profile.dart';
import 'movie.dart';
import 'utils/tmdb_api.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final user = snapshot.data;
        print('🔥 Auth state changed:');
        print('  user: $user');
        print('  isAnonymous: ${user?.isAnonymous}');
        print('  uid: ${user?.uid}');
        
        if (user == null || user.isAnonymous) {
          print('➡️ Showing LoginScreen');
          return const LoginScreen();
        }

        return FutureBuilder<UserProfileScreenBundle>(
          future: _loadUserProfileAndMovies(user.uid),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              );
            }

            if (snapshot.hasError) {
              return const Scaffold(
                body: Center(child: Text('Error loading profile')),
              );
            }

            final data = snapshot.data!;
            
            // ✅ Direct routing logic - no WelcomeScreen
            if (data.profile.hasCompletedOnboarding) {
              print('➡️ User completed onboarding, showing MainNavigation');
              return MainNavigation(
                profile: data.profile, 
                movies: data.movies,
              );
            } else {
              print('➡️ User needs onboarding, showing WelcomeOnboardingScreen');
              return WelcomeOnboardingScreen(
                profile: data.profile,
                movies: data.movies,
              );
            }
          },
        );
      },
    );
  }

  Future<UserProfileScreenBundle> _loadUserProfileAndMovies(String uid) async {
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();

    late final UserProfile profile;

    if (!doc.exists) {
      profile = UserProfile.empty().copyWith(
        uid: uid,
        name: FirebaseAuth.instance.currentUser?.email ?? '',
        hasCompletedOnboarding: false,
      );
      await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .set(profile.toJson(), SetOptions(merge: true));

    } else {
      profile = UserProfile.fromJson(doc.data()!);
    }

    final movies = await TMDBApi.getPopularMovies();
    return UserProfileScreenBundle(profile, movies);
  }
}

class UserProfileScreenBundle {
  final UserProfile profile;
  final List<Movie> movies;

  UserProfileScreenBundle(this.profile, this.movies);
}