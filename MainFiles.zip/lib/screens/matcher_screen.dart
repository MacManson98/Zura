import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../movie.dart';
import '../utils/enhanced_learning_engine.dart'; // 🆕 NEW
import '../utils/movie_loader.dart'; // 🆕 NEW
import '../models/user_profile.dart';
import '../utils/user_profile_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/session_invitation_widget.dart';
import 'matched_screen.dart';
import 'movie_detail_screen.dart';
import '../utils/tmdb_api.dart';
import '../utils/mood_based_learning_engine.dart';
import '../widgets/mood_selection_widget.dart';
import '../models/session_models.dart';
import '../services/session_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart'; 
import '../widgets/notifications_dropdown_widget.dart';
import 'dart:math';

// Define matching modes
enum MatchingMode { 
  solo,
  friend,
  group,
}

class MatcherScreen extends StatefulWidget {
  final List<Movie> allMovies;
  final UserProfile currentUser;
  final List<UserProfile> availableFriends;
  final bool showTutorial;
  final UserProfile? selectedFriend;
  final MatchingMode mode;

  const MatcherScreen({
    super.key,
    required this.allMovies,
    required this.currentUser,
    required this.availableFriends,
    this.showTutorial = false,
    this.selectedFriend,
    this.mode = MatchingMode.solo,
  });

  @override
  State<MatcherScreen> createState() => _MatcherScreenState();
}

class _MatcherScreenState extends State<MatcherScreen> {
  late List<Movie> sessionPool = [];
  final Set<String> currentUserLikes = {};
  MatchingMode currentMode = MatchingMode.solo;
  UserProfile? selectedFriend; // Track the currently selected friend
  List<UserProfile> selectedGroup = [];
  final Map<String, Set<String>> groupLikes = {};
  bool _showTutorial = true; // Set to false after user completes tutorial
  int _tutorialPage = 0;
  final PageController _tutorialPageController = PageController();
  late List<Movie> movieDatabase = [];
  final Set<String> currentSessionMovieIds = {};
  bool _isLoadingSession = false;
  late List<Movie> _basePool = []; // Original pool
  late List<Movie> _dynamicPool = []; // Current dynamic pool
  int _swipeCount = 0;
  bool _isRefreshingPool = false;
  SessionContext? currentSessionContext;
  List<CurrentMood> selectedMoods = [];
  bool _showMoodSelectionModal = false;  // Replace _showMoodSelection
  bool _isReadyToSwipe = false;
  SwipeSession? currentSession;
  StreamSubscription<SwipeSession>? sessionSubscription;
  bool isWaitingForFriend = false;
  bool isInCollaborativeMode = false;
  bool get _isPerfectForMe => selectedMoods.isNotEmpty && selectedMoods.first == CurrentMood.perfectForMe;
  bool get _isPerfectForUs => selectedMoods.isNotEmpty && selectedMoods.first == CurrentMood.perfectForUs;
  
  
  
  
  @override
  void initState() {
    super.initState();
    
    EnhancedLearningEngine.resetSessionTracking();

    currentMode = widget.mode;
    selectedFriend = widget.selectedFriend;
    _initializeApp();
    _checkTutorialSeen(widget.showTutorial);
    }
    // NEW: Quick start with FYP (bypasses mood selection)
    void _startFYPSession() async {
      print("🔍 DEBUG: _startFYPSession() called");
      
      setState(() {
        selectedMoods = [currentMode == MatchingMode.solo 
            ? CurrentMood.perfectForMe 
            : CurrentMood.perfectForUs];
        _isLoadingSession = true;
        _isReadyToSwipe = true;
      });

      print("🔍 DEBUG: selectedMoods after setState: ${selectedMoods.map((m) => m.displayName)}");
      print("🔍 DEBUG: About to call session generation");

      currentSessionContext = SessionContext(
        moods: selectedMoods.first,
        groupMemberIds: currentMode == MatchingMode.group 
            ? selectedGroup.map((f) => f.uid).toList()
            : currentMode == MatchingMode.friend && selectedFriend != null
                ? [selectedFriend!.uid]
                : [],
      );

      // Use helper methods for cleaner code
      if (_isPerfectForMe) {
        await _generatePerfectForMeSession();
      } else if (_isPerfectForUs) {
        await _generatePerfectForUsSession();
      }
    }

    // NEW: Show mood picker modal
    void _showMoodPicker() {
      setState(() {
        _showMoodSelectionModal = true;
      });
    }

    // NEW: Reset to selection state
    void _resetToSelection() {
      setState(() {
        _isReadyToSwipe = false;
        selectedMoods.clear(); // Changed from selectedMood = null
        currentSessionContext = null;
        sessionPool.clear();
      });
    }

    // Helper methods for button states
    bool _canStartFYP() {
      switch (currentMode) {
        case MatchingMode.solo:
          return true;
        case MatchingMode.friend:
          return selectedFriend != null;
        case MatchingMode.group:
          return selectedGroup.isNotEmpty;
      }
    }

    bool _canChooseMood() {
      return _canStartFYP();
    }

    String _getFYPButtonText() {
      switch (currentMode) {
        case MatchingMode.solo:
          return "Perfect For Me";
        case MatchingMode.friend:
          return selectedFriend != null ? "Perfect For Us" : "Select Friend First";
        case MatchingMode.group:
          return selectedGroup.isNotEmpty ? "Perfect For Us" : "Select Group First";
      }
    }

    void _onMoodSelected(List<CurrentMood> moods) async {
      print("🔍 DEBUG: _onMoodSelected called with ${moods.length} mood(s): ${moods.map((m) => m.displayName).join(', ')}");
      
      setState(() {
        selectedMoods = moods;
        _showMoodSelectionModal = false;
        _isLoadingSession = true;
        _isReadyToSwipe = true;
      });

      print("🔍 DEBUG: After setState - _isReadyToSwipe: $_isReadyToSwipe, _isLoadingSession: $_isLoadingSession");

      // Create session context based on selected moods
      if (moods.length == 1) {
        currentSessionContext = SessionContext(
          moods: moods.first,
          groupMemberIds: currentMode == MatchingMode.group 
              ? selectedGroup.map((f) => f.uid).toList()
              : currentMode == MatchingMode.friend && selectedFriend != null
                  ? [selectedFriend!.uid]
                  : [],
        );
      } else {
        currentSessionContext = _createBlendedSessionContext(moods);
      }

      print("🔍 DEBUG: About to call session generation");

      // ✅ CORRECT: Choose the right generation method based on mode
      if (isInCollaborativeMode) {
        // For collaborative sessions, use the collaborative method
        await _generateCollaborativeSession();
      } else {
        // For solo/local sessions, use the existing methods
        if (moods.length == 1) {
          if (moods.first == CurrentMood.perfectForMe) {
            await _generatePerfectForMeSession();
          } else if (moods.first == CurrentMood.perfectForUs) {
            await _generatePerfectForUsSession();
          } else {
            await _generateMoodBasedSession();
          }
        } else {
          await _generateBlendedMoodSession();
        }
      }

      print("🔍 DEBUG: Session generation complete - _isReadyToSwipe: $_isReadyToSwipe, sessionPool.length: ${sessionPool.length}");
    }

    SessionContext _createBlendedSessionContext(List<CurrentMood> moods) {
      // Combine all preferred genres and vibes from selected moods
      final Set<String> combinedGenres = {};
      final Set<String> combinedVibes = {};
      
      for (final mood in moods) {
        combinedGenres.addAll(mood.preferredGenres);
        combinedVibes.addAll(mood.preferredVibes);
      }
      
      print("🎭 Blending ${moods.length} moods: ${moods.map((m) => m.displayName).join(' + ')}");
      print("   Combined genres: ${combinedGenres.join(', ')}");
      print("   Combined vibes: ${combinedVibes.join(', ')}");
      
      // Create a temporary mood with combined preferences
      // We'll use the first mood as the base and add combined preferences
      return SessionContext(
        moods: selectedMoods.first, // Base mood for the session context
        groupMemberIds: currentMode == MatchingMode.group 
            ? selectedGroup.map((f) => f.uid).toList()
            : currentMode == MatchingMode.friend && selectedFriend != null
                ? [selectedFriend!.uid]
                : [],
      );
    }

    // Replace your _generateBlendedMoodSession method in matcher_screen.dart with this:

    Future<void> _generateBlendedMoodSession() async {
      if (movieDatabase.isEmpty || selectedMoods.isEmpty) {
        print("⚠️ No movie database or selected moods, using fallback");
        setState(() {
          sessionPool = sampleMovies;  // FIXED: Now inside setState
          _isLoadingSession = false;
        });
        return;
      }
      
      final seenMovieIds = <String>{
        ...widget.currentUser.likedMovieIds,
        ...widget.currentUser.passedMovieIds,
        ...currentSessionMovieIds,
      };
      
      // Keep your existing helper methods
      bool _meetsQualityThreshold(Movie movie) {
        return movie.posterUrl.isNotEmpty &&
              movie.rating != null &&
              movie.rating! >= 5.0 &&
              movie.voteCount != null &&
              movie.voteCount! >= 1000;
      }

      bool _isSfwMovie(Movie movie) {
        final bannedKeywords = ['porn', 'erotic', 'xxx', 'adult', 'sex', 'nude', 'strip'];
        final lcTitle = movie.title.toLowerCase();
        final lcOverview = movie.overview.toLowerCase();
        return !bannedKeywords.any((kw) => lcTitle.contains(kw) || lcOverview.contains(kw));
      }

      try {
        print("🎭 Generating BALANCED blended mood session for: ${selectedMoods.map((m) => m.displayName).join(' + ')}");
        
        final Map<CurrentMood, List<Movie>> moodPools = {};
        
        // Create pools for each mood with SHUFFLED scoring
        for (final mood in selectedMoods) {
          final moodMovies = <Movie>[];
          
          print("   📝 Processing mood: ${mood.displayName}");
          print("      Preferred genres: ${mood.preferredGenres.join(', ')}");
          print("      Preferred vibes: ${mood.preferredVibes.join(', ')}");
          
          for (final movie in movieDatabase) {
            if (seenMovieIds.contains(movie.id)) continue;
            if (!_meetsQualityThreshold(movie)) continue;
            if (!_isSfwMovie(movie)) continue;
            
            // Simple qualification check (no heavy scoring bias)
            final hasMatchingGenre = movie.genres.any((g) => mood.preferredGenres.contains(g));
            final hasMatchingVibe = movie.tags.any((v) => mood.preferredVibes.contains(v));
            
            if (hasMatchingGenre || hasMatchingVibe) {
              moodMovies.add(movie);
            }
          }
          
          // SHUFFLE each mood pool to avoid score bias
          moodMovies.shuffle();
          moodPools[mood] = moodMovies;
          
          print("      Found ${moodPools[mood]!.length} movies for ${mood.displayName}");
        }
        
        // Balanced interleaving with equal representation
        final targetSize = 30;
        final moviesPerMood = (targetSize / selectedMoods.length).floor();
        final extraMovies = targetSize % selectedMoods.length;
        
        print("🔀 Balanced interleaving - ${moviesPerMood} movies per mood + ${extraMovies} extra");
        
        // First pass: Guarantee equal representation
        final List<Movie> balancedPool = [];
        
        for (int i = 0; i < moviesPerMood; i++) {
          for (final mood in selectedMoods) {
            final pool = moodPools[mood]!;
            if (i < pool.length) {
              final movie = pool[i];
              
              // Avoid duplicates (in case a movie matches multiple moods)
              if (!balancedPool.any((m) => m.id == movie.id)) {
                balancedPool.add(movie);
              }
            }
            
            if (balancedPool.length >= targetSize) break;
          }
          if (balancedPool.length >= targetSize) break;
        }
        
        // Second pass: Add extra movies round-robin style
        if (balancedPool.length < targetSize && extraMovies > 0) {
          int currentMoodIndex = 0;
          int startIndex = moviesPerMood;
          
          while (balancedPool.length < targetSize && currentMoodIndex < selectedMoods.length) {
            final mood = selectedMoods[currentMoodIndex];
            final pool = moodPools[mood]!;
            
            // Find next unused movie from this mood
            for (int i = startIndex; i < pool.length; i++) {
              final movie = pool[i];
              if (!balancedPool.any((m) => m.id == movie.id)) {
                balancedPool.add(movie);
                break;
              }
            }
            
            currentMoodIndex++;
          }
        }
        
        // Third pass: Fill remaining slots with any qualifying movies if needed
        if (balancedPool.length < targetSize) {
          final allRemainingMovies = <Movie>[];
          
          for (final pool in moodPools.values) {
            for (final movie in pool) {
              if (!balancedPool.any((m) => m.id == movie.id)) {
                allRemainingMovies.add(movie);
              }
            }
          }
          
          allRemainingMovies.shuffle();
          
          final remainingSlots = targetSize - balancedPool.length;
          for (int i = 0; i < remainingSlots && i < allRemainingMovies.length; i++) {
            balancedPool.add(allRemainingMovies[i]);
          }
          
          print("📈 Added ${remainingSlots} additional movies to reach target");
        }
        
        // FIXED: Update sessionPool inside setState
        setState(() {
          sessionPool.clear();
          sessionPool.addAll(balancedPool);
          sessionPool.shuffle();
          _isLoadingSession = false;  // Also update loading state
        });
        
        currentSessionMovieIds.clear();
        currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
        
        print("🎬 Generated ${sessionPool.length} balanced blended mood movies");
        print("   Final distribution:");
        for (final mood in selectedMoods) {
          final moodCount = sessionPool.where((movie) => 
            movie.genres.any((g) => mood.preferredGenres.contains(g)) ||
            movie.tags.any((v) => mood.preferredVibes.contains(v))
          ).length;
          print("      ${mood.displayName}: ~${moodCount} movies");
        }
        
        // Debug: Show first 10 movies to verify interleaving
        print("   🔍 First 10 movies:");
        for (int i = 0; i < min(10, sessionPool.length); i++) {
          final movie = sessionPool[i];
          final moodMatches = <String>[];
          for (final mood in selectedMoods) {
            final matches = movie.genres.any((g) => mood.preferredGenres.contains(g)) ||
                          movie.tags.any((v) => mood.preferredVibes.contains(v));
            if (matches) moodMatches.add(mood.displayName);
          }
          print("      ${i+1}. ${movie.title} → ${moodMatches.join(', ')}");
        }
        
      } catch (e) {
        print("❌ Error generating blended mood session: $e");
        setState(() {
          sessionPool = sampleMovies;  // FIXED: Now inside setState
          _isLoadingSession = false;
        });
      }
    }

    Future<void> _generatePerfectForMeSession() async {
  print("🔍 DEBUG: _generatePerfectForMeSession() STARTED");
  print("🔍 DEBUG: movieDatabase.length: ${movieDatabase.length}");
  
  if (movieDatabase.isEmpty) {
    print("⚠️ No movie database, using fallback");
    setState(() {
      sessionPool = sampleMovies;
      _isLoadingSession = false;
    });
    print("🔍 DEBUG: Used fallback, _isLoadingSession: $_isLoadingSession");
    return;
  }
  
  final seenMovieIds = <String>{
    ...widget.currentUser.likedMovieIds,
    ...widget.currentUser.passedMovieIds,
    ...currentSessionMovieIds,
  };
  
  print("🔍 DEBUG: seenMovieIds.length: ${seenMovieIds.length}");
  
  try {
    print("🎯 Generating 'Perfect For Me' session using Enhanced Learning Engine");
    
    // Use Enhanced Learning Engine for pure personalization
    final personalizedMovies = await EnhancedLearningEngine.generatePersonalizedSession(
      user: widget.currentUser,
      movieDatabase: movieDatabase,
      seenMovieIds: seenMovieIds,
      sessionSize: 50, // Larger initial pool
    );
    
    print("🔍 DEBUG: personalizedMovies.length: ${personalizedMovies.length}");
    
    // Set up for adaptive learning during the session
    _basePool = personalizedMovies;
    _dynamicPool = personalizedMovies.take(20).toList();
    
    print("🔍 DEBUG: About to call setState, _dynamicPool.length: ${_dynamicPool.length}");
    
    // CRITICAL FIX: Update all state together in setState
    setState(() {
      sessionPool = List.from(_dynamicPool);
      _isLoadingSession = false; // This MUST be inside setState!
    });
    
    print("🔍 DEBUG: setState completed, sessionPool.length: ${sessionPool.length}, _isLoadingSession: $_isLoadingSession");
    
    currentSessionMovieIds.clear();
    currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
    
    print("🎯 Generated ${sessionPool.length} personalized movies");
    
  } catch (e) {
    print("❌ Error generating Perfect For Me session: $e");
    print("🔍 DEBUG: Exception caught, about to setState with fallback");
    setState(() {
      sessionPool = sampleMovies;
      _isLoadingSession = false;
    });
    print("🔍 DEBUG: Exception setState completed, _isLoadingSession: $_isLoadingSession");
  }
  
  print("🔍 DEBUG: _generatePerfectForMeSession() FINISHED");
}


      Future<void> _generatePerfectForUsSession() async {
        if (movieDatabase.isEmpty || currentSessionContext == null) {
          print("⚠️ No movie database or session context, using fallback");
          sessionPool = sampleMovies;
          setState(() => _isLoadingSession = false);
          return;
        }
        
        final seenMovieIds = <String>{
          ...widget.currentUser.likedMovieIds,
          ...widget.currentUser.passedMovieIds,
          ...currentSessionMovieIds,
        };
        
        try {
          List<UserProfile> groupMembers = [];
          
          if (currentMode == MatchingMode.group && selectedGroup.isNotEmpty) {
            groupMembers = [widget.currentUser, ...selectedGroup];
          } else if (currentMode == MatchingMode.friend && selectedFriend != null) {
            groupMembers = [widget.currentUser, selectedFriend!];
          } else if (isInCollaborativeMode && currentSession != null) {
            // 🆕 NEW: Load friend profiles from Firebase for collaborative sessions
            groupMembers = [widget.currentUser];
            
            for (final participantId in currentSession!.participantIds) {
              if (participantId != widget.currentUser.uid) {
                try {
                  final friendDoc = await FirebaseFirestore.instance
                      .collection('users')
                      .doc(participantId)
                      .get();
                  
                  if (friendDoc.exists) {
                    final friendProfile = UserProfile.fromJson(friendDoc.data()!);
                    groupMembers.add(friendProfile);
                    print("✅ Loaded friend profile: ${friendProfile.name}");
                  }
                } catch (e) {
                  print("⚠️ Could not load friend profile $participantId: $e");
                }
              }
            }
          } else {
            // Fallback to solo
            await _generatePerfectForMeSession();
            return;
          }
          
          print("🤝 Generating 'Perfect For Us' session for ${groupMembers.length} people");
          
          // Use the Perfect For Us method
          sessionPool = await MoodBasedLearningEngine.generatePerfectForUsSession(
            groupMembers: groupMembers,
            movieDatabase: movieDatabase,
            seenMovieIds: seenMovieIds,
            sessionSize: 30,
            minMoviesPerPerson: 10,
          );
          
          currentSessionMovieIds.clear();
          currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
          
          print("🤝 Generated ${sessionPool.length} group-compatible movies");
          
        } catch (e) {
          print("❌ Error generating Perfect For Us session: $e");
        } finally {
          setState(() => _isLoadingSession = false);
        }
      }


      Future<void> _generateMoodBasedSession() async {
        if (movieDatabase.isEmpty || currentSessionContext == null) {
          print("⚠️ No movie database or session context, using fallback");
          setState(() => _isLoadingSession = false);
          return;
        }
        
    final seenMovieIds = <String>{
      ...widget.currentUser.likedMovieIds,
      ...widget.currentUser.passedMovieIds,
      ...currentSessionMovieIds,
    };
    
    try {
      if (currentMode == MatchingMode.solo) {
        sessionPool = await MoodBasedLearningEngine.generateMoodBasedSession(
          user: widget.currentUser,
          movieDatabase: movieDatabase,
          sessionContext: currentSessionContext!,
          seenMovieIds: seenMovieIds,
          sessionSize: 30,
        );
      } else if (currentMode == MatchingMode.group && selectedGroup.isNotEmpty) {
        final groupMembers = [widget.currentUser, ...selectedGroup];
        sessionPool = await MoodBasedLearningEngine.generateGroupSession(
          groupMembers: groupMembers,
          movieDatabase: movieDatabase,
          sessionContext: currentSessionContext!,
          seenMovieIds: seenMovieIds,
          sessionSize: 25,
        );
      } else if (currentMode == MatchingMode.friend && selectedFriend != null) {
        final friendGroup = [widget.currentUser, selectedFriend!];
        sessionPool = await MoodBasedLearningEngine.generateGroupSession(
          groupMembers: friendGroup,
          movieDatabase: movieDatabase,
          sessionContext: currentSessionContext!,
          seenMovieIds: seenMovieIds,
          sessionSize: 25,
        );
      } else {
        sessionPool = movieDatabase.take(30).toList()..shuffle();
      }
      
      currentSessionMovieIds.clear();
      currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
      
      print("🎭 Mood learning applied for: ${selectedMoods.map((m) => m.displayName).join(' + ')}");
      
      // ADD THESE DEBUG LINES:
      print("🔍 DEBUG: sessionPool after generation: ${sessionPool.length} movies");
      print("🔍 DEBUG: First movie title: ${sessionPool.isNotEmpty ? sessionPool.first.title : 'NO MOVIES'}");
      
    } catch (e) {
      print("❌ Error generating mood-based session: $e");
      sessionPool = sampleMovies;
    } finally {
      setState(() {
        _isLoadingSession = false;
        // ADD THIS DEBUG LINE:
        print("🔍 DEBUG: setState called - _isLoadingSession: $_isLoadingSession, sessionPool.length: ${sessionPool.length}");
      });
    }
  }

    Future<void> _initializeApp() async {
      setState(() => _isLoadingSession = true);
      
      try {
        // Load movie database
        movieDatabase = await MovieDatabaseLoader.loadMovieDatabase();
        
        // Check if we should show the "Learning your taste..." banner
        if (!widget.currentUser.hasSeenMatcher) {
          widget.currentUser.hasSeenMatcher = true;
          await UserProfileStorage.saveProfile(widget.currentUser);
        }

        // Generate personalized session
        await _generatePersonalizedSession();

        
      } catch (e) {
        print("❌ Error initializing app: $e");
        // Fallback to your existing logic
        sessionPool = sampleMovies;
      } finally {
        setState(() => _isLoadingSession = false);
      }
    }
    Widget _buildSmartBanner() {
      if (_showMoodSelectionModal) {
        return const SizedBox.shrink();
      }
      
      // Show mood banner for mood-based sessions OR collaborative sessions
      if (selectedMoods.isNotEmpty) {
        return _buildMoodBanner();
      }
      
      return const SizedBox.shrink();
    }

    Widget _buildMoodBanner() {
      String moodText;
      String moodEmoji;
      String subtitle;
      
      if (selectedMoods.length == 1) {
        moodText = "${selectedMoods.first.displayName} vibes";
        moodEmoji = selectedMoods.first.emoji;
        
        // Different subtitle for collaborative vs solo
        if (isInCollaborativeMode) {
          subtitle = "Swiping together with this mood";
        } else {
          subtitle = "Finding perfect ${selectedMoods.first.displayName.toLowerCase()} movies";
        }
      } else {
        moodText = "Blended vibes: ${selectedMoods.map((m) => m.displayName).take(2).join(' + ')}${selectedMoods.length > 2 ? ' +${selectedMoods.length - 2}' : ''}";
        moodEmoji = selectedMoods.take(3).map((m) => m.emoji).join();
        subtitle = isInCollaborativeMode 
            ? "Blending moods for your group"
            : "Blending your mood preferences perfectly";
      }
      
      return Container(
        margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isInCollaborativeMode 
                ? [
                    const Color(0xFF4A90E2).withValues(alpha: 0.8),
                    const Color(0xFF357ABD).withValues(alpha: 0.8),
                  ]
                : [
                    const Color(0xFF4A90E2).withValues(alpha: 0.8),
                    const Color(0xFF357ABD).withValues(alpha: 0.8),
                  ],
          ),
          borderRadius: BorderRadius.circular(16.r),
        ),
        child: Row(
          children: [
            Text(
              moodEmoji,
              style: TextStyle(fontSize: 20.sp),
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    moodText,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.8),
                      fontSize: 12.sp,
                    ),
                  ),
                ],
              ),
            ),
            if (!isInCollaborativeMode) // Only show refresh for solo sessions
              GestureDetector(
                onTap: () {
                  setState(() {
                    _showMoodSelectionModal = true;
                    selectedMoods.clear();
                    currentSessionContext = null;
                  });
                },
                child: Icon(
                  Icons.refresh,
                  color: Colors.white,
                  size: 18.sp,
                ),
              ),
          ],
        ),
      );
    }
      /// 🆕 NEW: Show user's taste analytics
    void _showTasteAnalytics() {
      final insights = EnhancedLearningEngine.analyzeTasteProfile(widget.currentUser);
      
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          backgroundColor: const Color(0xFF1F1F1F),
          title: const Text(
            "Your Taste Profile 🎭",
            style: TextStyle(color: Colors.white),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Movies Liked: ${insights['totalMoviesLiked']}",
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
                const SizedBox(height: 8),
                Text(
                  "Diversity Score: ${insights['diversityScore']}/10",
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
                const SizedBox(height: 8),
                Text(
                  "Exploration: ${insights['explorationTrend']}",
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
                const SizedBox(height: 16),
                
                const Text(
                  "Top Genres:",
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                ...(insights['topGenres'] as List).take(5).map((genre) => 
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Text(
                      "• ${genre['name']} (${genre['score'].toStringAsFixed(1)})",
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ),
                ),
                
                const SizedBox(height: 12),
                const Text(
                  "Top Vibes:",
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                ...(insights['topVibes'] as List).take(5).map((vibe) => 
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Text(
                      "• ${vibe['name']} (${vibe['score'].toStringAsFixed(1)})",
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(
                "Close",
                style: TextStyle(color: Color(0xFFE5A00D)),
              ),
            ),
          ],
        ),
      );
    }

    /// 🆕 NEW: Loading state for when generating sessions
    Widget _buildLoadingState() {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(color: Color(0xFFE5A00D)),
            SizedBox(height: 16.h),
            Text(
              "Generating personalized recommendations...",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16.sp,
              ),
            ),
          ],
        ),
      );
    }

    /// 🆕 NEW: Print learning insights for debugging
    void _printLearningInsights() {
      final insights = EnhancedLearningEngine.analyzeTasteProfile(widget.currentUser);
      print("🧠 Learning Insights:");
      print("   Movies Liked: ${insights['totalMoviesLiked']}");
      print("   Diversity Score: ${insights['diversityScore']}");
      print("   Exploration: ${insights['explorationTrend']}");
      
      if ((insights['topGenres'] as List).isNotEmpty) {
        print("   Top Genres: ${(insights['topGenres'] as List).take(3).map((g) => g['name']).join(', ')}");
      }
      if ((insights['topVibes'] as List).isNotEmpty) {
        print("   Top Vibes: ${(insights['topVibes'] as List).take(3).map((v) => v['name']).join(', ')}");
      }
    }
    
    // Add this method to your _MatcherScreenState class
    Future<void> _adaptMoodBasedSession() async {
      if (_isRefreshingPool || currentSessionContext == null) return;
      
      setState(() => _isRefreshingPool = true);
      
      try {
        print("🔄 Adapting session based on mood momentum...");
        
        final seenMovieIds = <String>{
          ...widget.currentUser.likedMovieIds,
          ...widget.currentUser.passedMovieIds,
          ...currentSessionMovieIds,
        };
        
        // Get adaptive movies based on current mood context
        final adaptiveMovies = await MoodBasedLearningEngine.adaptSession(
          user: widget.currentUser,
          movieDatabase: movieDatabase,
          context: currentSessionContext!,
          seenMovieIds: seenMovieIds,
          adaptiveCount: 8,
        );
        
        if (adaptiveMovies.isNotEmpty) {
          setState(() {
            // Insert adaptive movies into the session pool
            sessionPool.addAll(adaptiveMovies);
            currentSessionMovieIds.addAll(adaptiveMovies.map((m) => m.id));
            
            print("✨ Added ${adaptiveMovies.length} mood-adaptive movies");
          });
        }
      } catch (e) {
        print("❌ Error adapting mood session: $e");
      } finally {
        setState(() => _isRefreshingPool = false);
      }
    }

  // 🆕 ADD THIS NEW METHOD
  Future<void> _generatePersonalizedSession() async {
    if (movieDatabase.isEmpty) {
      print("⚠️ No movie database loaded, using sample movies");
      sessionPool = sampleMovies;
      return;
    }
    
    final seenMovieIds = <String>{
      ...widget.currentUser.likedMovieIds,
      ...widget.currentUser.passedMovieIds,
      ...currentSessionMovieIds,
    };
    
    if (currentMode == MatchingMode.solo) {
      // Generate initial pool
      _basePool = await EnhancedLearningEngine.generatePersonalizedSession(
        user: widget.currentUser,
        movieDatabase: movieDatabase,
        seenMovieIds: seenMovieIds,
        sessionSize: 50,
      );
      
      // Start with first 20 movies
      _dynamicPool = _basePool.take(20).toList();
      sessionPool = List.from(_dynamicPool);
      
    } else {
      // Your existing logic for friend/group modes
      if (movieDatabase.isNotEmpty) {
        sessionPool = movieDatabase.take(50).toList()..shuffle();
      } else {
        sessionPool = sampleMovies;
      }
    }
    
    currentSessionMovieIds.clear();
    currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
    
    print("🎬 Generated session: ${sessionPool.length} movies for ${currentMode.name} mode");
  }
  

  Future<void> _checkTutorialSeen(bool forceShow) async {
    final prefs = await SharedPreferences.getInstance();
    final tutorialSeen = prefs.getBool('tutorial_seen') ?? false;
    setState(() {
      _showTutorial = forceShow || !tutorialSeen;
    });
  }


  Future<void> _markTutorialSeen() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('tutorial_seen', true);
  }

  void likeMovie(Movie movie) async {
    // 🆕 Apply enhanced learning
    EnhancedLearningEngine.learnFromLikedMovie(widget.currentUser, movie);
    
    setState(() {
      widget.currentUser.likedMovies.add(movie);
      widget.currentUser.likedMovieIds.add(movie.id);
    });

      try {
        await UserProfileStorage.saveProfile(widget.currentUser);
      } catch (e) {
        print("⚠️ Error saving user profile: $e");
      }

  // Match logic
  if (currentMode == MatchingMode.friend &&
      selectedFriend?.likedMovieIds.contains(movie.id) == true) {
    _showMatchDialog(movie);
  }

  if (currentMode == MatchingMode.group) {
    groupLikes[widget.currentUser.name]?.add(movie.title);
    final everyone = [widget.currentUser.name, ...selectedGroup.map((f) => f.name)];
    final allLiked = everyone.every((name) => groupLikes[name]?.contains(movie.title) == true);
    if (allLiked) _showMatchDialog(movie);
  }

  _printLearningInsights();
}

    void passMovie(Movie movie) {
    // 🆕 Apply enhanced learning for passes
      EnhancedLearningEngine.learnFromPassedMovie(widget.currentUser, movie);
      
      // Save profile
      UserProfileStorage.saveProfile(widget.currentUser);
      
      print("👎 Passed on: ${movie.title}");
    }

  void _showMatchDialog(Movie movie) {
    // Navigate to the full animated match screen
    Navigator.push(
      context,
      PageRouteBuilder(
        opaque: false,
        barrierDismissible: false,
        pageBuilder: (context, animation, secondaryAnimation) {
          return MatchedScreen(
            movie: movie,
            currentUser: widget.currentUser,
            matchedName: selectedFriend?.name,
          );
        },
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(
            opacity: animation,
            child: child,
          );
        },
      ),
    );
  }

  bool _onSwipe(int previousIndex, int? currentIndex, CardSwiperDirection direction) {
    if (isInCollaborativeMode && currentSession != null) {
      return _onCollaborativeSwipe(previousIndex, currentIndex, direction);
    }
    if (previousIndex >= sessionPool.length) return false;
    
    final movie = sessionPool[previousIndex];
    _swipeCount++;
    print("🔢 Swipe count: $_swipeCount");
    
    final isLike = direction == CardSwiperDirection.right;
    
    // Handle profile-based moods differently
    if (selectedMoods.contains(CurrentMood.perfectForMe)) {
      // Pure Enhanced Learning Engine approach
      if (isLike) {
        EnhancedLearningEngine.learnFromLikedMovie(
          widget.currentUser, 
          movie,
          isSessionLearning: true,
        );
        likeMovie(movie);
      } else {
        EnhancedLearningEngine.learnFromPassedMovie(
          widget.currentUser, 
          movie,
          isSessionLearning: true,
        );
        passMovie(movie);
      }
      
      // Check if we need to adapt the session
      if (EnhancedLearningEngine.shouldAdaptSession()) {
        _adaptPersonalizedSession();
      }
      
    } else if (selectedMoods.contains(CurrentMood.perfectForUs)) {
      // Group profile-based learning
      if (isLike) {
        // Learn for current user
        EnhancedLearningEngine.learnFromLikedMovie(
          widget.currentUser, 
          movie,
          isSessionLearning: true,
        );
        likeMovie(movie);
      } else {
        EnhancedLearningEngine.learnFromPassedMovie(
          widget.currentUser, 
          movie,
          isSessionLearning: true,
        );
        passMovie(movie);
      }
      
      // Check for group match
      _checkForGroupMatch(movie, isLike);
      
    } else {
      // Original mood-based learning logic
        if (currentSessionContext != null) {
          if (selectedMoods.length == 1) {
            // Single mood learning
            MoodBasedLearningEngine.learnFromMoodInteraction(
              widget.currentUser, 
              movie, 
              currentSessionContext!, 
              isLike
            );
          } else {
            // Multi-mood learning - learn from each mood context
            for (final mood in selectedMoods) {
              final tempContext = SessionContext(
                moods: mood,
                groupMemberIds: currentSessionContext!.groupMemberIds,
              );
              MoodBasedLearningEngine.learnFromMoodInteraction(
                widget.currentUser, 
                movie, 
                tempContext, 
                isLike
              );
            }
          }
          print("🎭 Mood learning applied for: ${selectedMoods.map((m) => m.displayName).join(' + ')}");
        }
      
      if (isLike) {
        EnhancedLearningEngine.learnFromLikedMovie(
          widget.currentUser, 
          movie,
          isSessionLearning: true,
        );
        likeMovie(movie);
      } else {
        EnhancedLearningEngine.learnFromPassedMovie(
          widget.currentUser, 
          movie,
          isSessionLearning: true,
        );
        passMovie(movie);
      }
      
      // Track session feedback
      for (final genre in movie.genres) {
        if (isLike) {
          EnhancedLearningEngine.sessionGenreLikes[genre] = (EnhancedLearningEngine.sessionGenreLikes[genre] ?? 0) + 1;
        } else {
          EnhancedLearningEngine.sessionGenrePasses[genre] = (EnhancedLearningEngine.sessionGenrePasses[genre] ?? 0) + 1;
        }
      }
      
      for (final vibe in movie.tags) {
        if (isLike) {
          EnhancedLearningEngine.sessionVibeLikes[vibe] = (EnhancedLearningEngine.sessionVibeLikes[vibe] ?? 0) + 1;
        } else {
          EnhancedLearningEngine.sessionVibePasses[vibe] = (EnhancedLearningEngine.sessionVibePasses[vibe] ?? 0) + 1;
        }
      }
      
      if (currentMode == MatchingMode.solo && EnhancedLearningEngine.shouldAdaptSession()) {
        _adaptSessionPool();
      }
      
      if (currentSessionContext != null && _swipeCount % 5 == 0) {
        _adaptMoodBasedSession();
      }
    }
    
    _printLearningInsights();
    
    // Check if we're running low on movies
    if (currentIndex != null && currentIndex >= sessionPool.length - 5) {
      _refreshPoolIfNeeded();
    }
    
    return true;
  }

  Future<void> _adaptPersonalizedSession() async {
    if (_isRefreshingPool) return;
    
    setState(() => _isRefreshingPool = true);
    
    try {
      print("🎯 Adapting 'Perfect For Me' session based on current learning");
      
      final seenMovieIds = <String>{
        ...widget.currentUser.likedMovieIds,
        ...widget.currentUser.passedMovieIds,
        ...currentSessionMovieIds,
      };
      
      // Generate adaptive movies using Enhanced Learning Engine
      final adaptiveMovies = await EnhancedLearningEngine.generateAdaptiveSession(
        user: widget.currentUser,
        movieDatabase: movieDatabase,
        seenMovieIds: seenMovieIds,
        sessionSize: 10,
        prioritizeSessionMomentum: true,
      );
      
      if (adaptiveMovies.isNotEmpty) {
        setState(() {
          sessionPool.addAll(adaptiveMovies);
          currentSessionMovieIds.addAll(adaptiveMovies.map((m) => m.id));
          
          print("✨ Added ${adaptiveMovies.length} adaptive movies to Perfect For Me session");
        });
      }
    } catch (e) {
      print("❌ Error adapting Perfect For Me session: $e");
    } finally {
      setState(() => _isRefreshingPool = false);
    }
  }

  void _checkForGroupMatch(Movie movie, bool isLike) {
    if (!isLike) return;
    
    // For now, just check friend mode - group mode matching logic can be expanded later
    if (currentMode == MatchingMode.friend && selectedFriend?.likedMovieIds.contains(movie.id) == true) {
      _showMatchDialog(movie);
    }
    
    // TODO: Implement group matching logic where ALL members need to like the same movie
    if (currentMode == MatchingMode.group) {
      // This is where we'd implement the "everyone likes it = match" logic
      // For now, just use the existing group logic
      groupLikes[widget.currentUser.name]?.add(movie.title);
      final everyone = [widget.currentUser.name, ...selectedGroup.map((f) => f.name)];
      final allLiked = everyone.every((name) => groupLikes[name]?.contains(movie.title) == true);
      if (allLiked) _showMatchDialog(movie);
    }
  }

  // Add adaptive pool refresh
  Future<void> _adaptSessionPool() async {
    if (_isRefreshingPool) return;
    
    setState(() => _isRefreshingPool = true);
    
    try {
      final insights = EnhancedLearningEngine.getSessionInsights();
      print("🔄 Adapting session based on insights: $insights");
      
      final seenMovieIds = <String>{
        ...widget.currentUser.likedMovieIds,
        ...widget.currentUser.passedMovieIds,
        ...currentSessionMovieIds,
      };
      
      // Generate adaptive movies based on current session
      final adaptiveMovies = await EnhancedLearningEngine.generateAdaptiveSession(
        user: widget.currentUser,
        movieDatabase: movieDatabase,
        seenMovieIds: seenMovieIds,
        sessionSize: 10,
        prioritizeSessionMomentum: true,
      );
      
      if (adaptiveMovies.isNotEmpty) {
        setState(() {
          // Insert adaptive movies into the pool
          final currentIndex = sessionPool.length - _dynamicPool.length;
          sessionPool.insertAll(currentIndex + 3, adaptiveMovies);
          _dynamicPool.addAll(adaptiveMovies);
          
          print("✨ Added ${adaptiveMovies.length} adaptive movies to pool");
        });
      }
    } catch (e) {
      print("❌ Error adapting pool: $e");
    } finally {
      setState(() => _isRefreshingPool = false);
    }
  }

  // Add pool refresh when running low
  Future<void> _refreshPoolIfNeeded() async {
    if (_isRefreshingPool) return;
    
    setState(() => _isRefreshingPool = true);
    
    try {
      final remainingInBase = _basePool.length - _dynamicPool.length;
      
      if (remainingInBase > 0) {
        // Add more from base pool
        final nextBatch = _basePool
            .skip(_dynamicPool.length)
            .take(10)
            .toList();
        
        setState(() {
          sessionPool.addAll(nextBatch);
          _dynamicPool.addAll(nextBatch);
        });
      } else {
        // Generate completely new movies
        await _adaptSessionPool();
      }
    } finally {
      setState(() => _isRefreshingPool = false);
    }
  }

  // Add visual indicator for pool refresh
  Widget _buildPoolRefreshIndicator() {
    if (!_isRefreshingPool) return const SizedBox.shrink();
    
    return Positioned(
      top: 100.h,
      right: 16.w,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
        decoration: BoxDecoration(
          color: const Color(0xFFE5A00D),
          borderRadius: BorderRadius.circular(20.r),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 12.w,
              height: 12.w,
              child: CircularProgressIndicator(
                strokeWidth: 2.w,
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            ),
            SizedBox(width: 8.w),
            Text(
              'Finding new picks...',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Handle mode change
  void _switchMode(MatchingMode mode) {
  setState(() {
    currentMode = mode;
    _resetToSelection(); // Reset session when switching modes
    
    // Clear selections when switching away from those modes
    if (mode != MatchingMode.friend) {
      selectedFriend = null;
    }
    if (mode != MatchingMode.group) {
      selectedGroup.clear();
      groupLikes.clear();
    }
  });
}

  // Add method to select a friend
  void _selectFriend(UserProfile friend) {
    setState(() {
      selectedFriend = friend;
      currentMode = MatchingMode.friend;
      _generatePersonalizedSession();
    });
  }

  @override
  Widget build(BuildContext context) {
    // Show mood selection modal if requested
    if (_showMoodSelectionModal) {
      return Scaffold(
        backgroundColor: const Color(0xFF121212),
        body: SafeArea(
          child: Stack(
            children: [
              // Main mood selection widget
              MoodSelectionWidget(
                onMoodsSelected: _onMoodSelected,
                isGroupMode: currentMode != MatchingMode.solo,
                groupSize: currentMode == MatchingMode.group 
                    ? selectedGroup.length + 1 
                    : currentMode == MatchingMode.friend 
                        ? 2 
                        : 1,
              ),
              
              // Subtle cancel button at top-left (less intrusive)
              Positioned(
                top: 24.h,
                left: 24.w,
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      _showMoodSelectionModal = false;
                    });
                  },
                  child: Container(
                    padding: EdgeInsets.all(8.r),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.3),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.arrow_back_ios,
                      color: Colors.white.withValues(alpha: 0.8),
                      size: 20.sp,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          _getAppBarTitle(),
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20.sp,
          ),
        ),
        actions: [
          if (isInCollaborativeMode)
          IconButton(
            icon: Icon(Icons.close, color: Colors.red),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  backgroundColor: const Color(0xFF1F1F1F),
                  title: Text("End Session?", style: TextStyle(color: Colors.white)),
                  content: Text(
                    "Are you sure you want to end this collaborative session?",
                    style: TextStyle(color: Colors.grey[300]),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text("Cancel", style: TextStyle(color: Colors.grey[400])),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _endCollaborativeSession();
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                      child: Text("End Session", style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              );
            },
          ),
          if (kDebugMode && isInCollaborativeMode)
            IconButton(
              icon: Icon(Icons.play_arrow, color: Colors.green),
              onPressed: () {
                print("🔍 FULL SESSION STATE DEBUG:");
                print("   isInCollaborativeMode: $isInCollaborativeMode");
                print("   _isReadyToSwipe: $_isReadyToSwipe");
                print("   _isLoadingSession: $_isLoadingSession");
                print("   selectedMoods.length: ${selectedMoods.length}");
                print("   sessionPool.length: ${sessionPool.length}");
                
                // Force ready to swipe for testing
                setState(() {
                  _isReadyToSwipe = true;
                  if (sessionPool.isEmpty) {
                    sessionPool = sampleMovies;
                  }
                });
                
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Forced ready to swipe: ${sessionPool.length} movies')),
                );
              },
            ),
          // 🆕 NEW: Professional notifications dropdown widget
          NotificationsDropdownWidget(
            onSessionJoined: _startCollaborativeSession,
            currentUser: widget.currentUser,
          ),
          
          // Debug button (only in debug mode) - styled to match
          if (kDebugMode)
            Container(
              margin: EdgeInsets.only(right: 8.w),
              child: IconButton(
                icon: Container(
                  padding: EdgeInsets.all(6.r),
                  decoration: BoxDecoration(
                    color: Colors.red.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Icon(
                    Icons.bug_report, 
                    color: Colors.red.withValues(alpha: 0.8),
                    size: 18.sp,
                  ),
                ),
                onPressed: () {
                  print("🔍 FULL DEBUG STATE:");
                  print("   _isReadyToSwipe: $_isReadyToSwipe");
                  print("   _isLoadingSession: $_isLoadingSession");
                  print("   sessionPool.length: ${sessionPool.length}");
                  print("   selectedMoods: ${selectedMoods.map((m) => m.displayName).toList()}");
                  print("   currentSession?.status: ${currentSession?.status}");
                  print("   currentSession?.participantIds: ${currentSession?.participantIds}");
                  print("   isInCollaborativeMode: $isInCollaborativeMode");
                  
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      backgroundColor: const Color(0xFF1F1F1F),
                      title: Text("Debug Info", style: TextStyle(color: Colors.white)),
                      content: Text(
                        "Ready to swipe: $_isReadyToSwipe\n"
                        "Loading: $_isLoadingSession\n"
                        "Pool size: ${sessionPool.length}\n"
                        "Selected moods: ${selectedMoods.length}",
                        style: TextStyle(color: Colors.white70),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text("OK", style: TextStyle(color: const Color(0xFFE5A00D))),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          
          // Settings/Menu button - professionally styled
          Container(
            margin: EdgeInsets.only(right: 4.w),
            child: PopupMenuButton<String>(
              icon: Container(
                padding: EdgeInsets.all(8.r),
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(12.r),
                ),
                child: Icon(
                  Icons.more_vert, 
                  color: Colors.white.withValues(alpha: 0.8), 
                  size: 22.sp,
                ),
              ),
              color: const Color(0xFF1F1F1F),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.r),
                side: BorderSide(
                  color: const Color(0xFFE5A00D).withValues(alpha: 0.2),
                  width: 1.w,
                ),
              ),
              offset: Offset(0, 8.h),
              onSelected: (value) {
                switch (value) {
                  case 'analytics':
                    _showTasteAnalytics();
                    break;
                  case 'info':
                    _showInfoDialog();
                    break;
                  case 'debug':
                    _printLearningInsights();
                    final insights = EnhancedLearningEngine.analyzeTasteProfile(widget.currentUser);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Liked ${insights['totalMoviesLiked']} movies. Check console for details.'),
                        backgroundColor: const Color(0xFFE5A00D),
                      ),
                    );
                    break;
                }
              },
              itemBuilder: (context) => [
                PopupMenuItem(
                  value: 'analytics',
                  child: Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(6.r),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5A00D).withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(6.r),
                        ),
                        child: Icon(
                          Icons.analytics, 
                          color: const Color(0xFFE5A00D), 
                          size: 18.sp,
                        ),
                      ),
                      SizedBox(width: 12.w),
                      Text(
                        'Your Taste Profile', 
                        style: TextStyle(color: Colors.white, fontSize: 14.sp),
                      ),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 'info',
                  child: Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(6.r),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5A00D).withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(6.r),
                        ),
                        child: Icon(
                          Icons.help_outline, 
                          color: const Color(0xFFE5A00D), 
                          size: 18.sp,
                        ),
                      ),
                      SizedBox(width: 12.w),
                      Text(
                        'How it Works', 
                        style: TextStyle(color: Colors.white, fontSize: 14.sp),
                      ),
                    ],
                  ),
                ),
                if (kDebugMode) // Only show in debug mode
                  PopupMenuItem(
                    value: 'debug',
                    child: Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(6.r),
                          decoration: BoxDecoration(
                            color: Colors.red.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(6.r),
                          ),
                          child: Icon(
                            Icons.bug_report, 
                            color: Colors.red.withValues(alpha: 0.8), 
                            size: 18.sp,
                          ),
                        ),
                        SizedBox(width: 12.w),
                        Text(
                          'Debug Info', 
                          style: TextStyle(color: Colors.white, fontSize: 14.sp),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
        // Keep your existing subtitle logic for collaborative mode
        bottom: isInCollaborativeMode 
            ? PreferredSize(
                preferredSize: Size.fromHeight(30.h),
                child: Container(
                  padding: EdgeInsets.only(bottom: 8.h),
                  child: Text(
                    isWaitingForFriend 
                        ? "Waiting for friend to join..."
                        : "Swiping together",
                    style: TextStyle(
                      color: const Color(0xFFE5A00D),
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              )
            : null,
      ),
      body: Stack(
        children: [
          Column(
            children: [
              // Mode selection (always visible)
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 7.w, vertical: 10.h),
                child: Row(
                  children: [
                    Expanded(
                      child: _buildModeButton(
                        "Solo Mode", 
                        Icons.person,
                        currentMode == MatchingMode.solo,
                        () => _switchMode(MatchingMode.solo),
                      ),
                    ),
                    SizedBox(width: 5.w),
                    Expanded(
                      child: _buildModeButton(
                        "Friend Mode",
                        Icons.people,
                        currentMode == MatchingMode.friend,
                        () => _switchMode(MatchingMode.friend),
                      ),
                    ),
                    SizedBox(width: 5.w),
                    Expanded(
                      child: _buildModeButton(
                        "Group Mode",
                        Icons.groups,
                        currentMode == MatchingMode.group,
                        () => _switchMode(MatchingMode.group),
                      ),
                    ),
                  ],
                ),
              ),
              _buildCollaborativeHeader(),
              // Session controls (when not ready to swipe)
              if (!_isReadyToSwipe) _buildSessionControls(),

              // Smart banner and indicators (when ready to swipe)
              if (_isReadyToSwipe) _buildSmartBanner(),

              // Main content
              Expanded(
                child: _isLoadingSession 
                    ? _buildLoadingState()
                    : _isReadyToSwipe 
                        ? _buildMainContent()
                        : _buildWelcomeScreen(),
              ),
            ],
          ),
          if (_isReadyToSwipe) _buildPoolRefreshIndicator(),
          _buildTutorialOverlay(),
        ],
      ),
    );
  }
  
  
  
  String _getAppBarTitle() {
    if (isInCollaborativeMode && currentSession != null) {
      final friendNames = currentSession!.participantNames
          .where((name) => name != widget.currentUser.name)
          .toList();
      
      if (friendNames.isNotEmpty) {
        return "Swiping with ${friendNames.join(", ")}";
      } else {
        return "Collaborative Session";
      }
    }
    
    switch (currentMode) {
      case MatchingMode.solo:
        return "Find Your Movies";
      case MatchingMode.friend:
        return selectedFriend != null 
            ? "Match with ${selectedFriend!.name}"
            : "Friend Mode";
      case MatchingMode.group:
        return selectedGroup.isNotEmpty
            ? "Group of ${selectedGroup.length + 1}"
            : "Group Mode";
    }
  }

  Widget _buildSessionControls() {
    // Don't show session controls if we're in collaborative mode
    if (isInCollaborativeMode) {
      return const SizedBox.shrink();
    }
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      child: Column(
        children: [
          // Solo Mode: Keep the original FYP + mood selection
          if (currentMode == MatchingMode.solo) ...[
            // Quick start button (FYP)
            SizedBox(
              width: double.infinity,
              height: 56.h,
              child: ElevatedButton.icon(
                onPressed: _canStartFYP() ? _startFYPSession : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE5A00D),
                  disabledBackgroundColor: Colors.grey[700],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.r),
                  ),
                ),
                icon: Icon(
                  Icons.auto_awesome,
                  color: _canStartFYP() ? Colors.black : Colors.grey[400],
                  size: 24.sp,
                ),
                label: Text(
                  _getFYPButtonText(),
                  style: TextStyle(
                    color: _canStartFYP() ? Colors.black : Colors.grey[400],
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            
            SizedBox(height: 12.h),
            
            // Divider with "OR"
            Row(
              children: [
                Expanded(child: Divider(color: Colors.grey[600])),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.w),
                  child: Text(
                    "OR",
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(child: Divider(color: Colors.grey[600])),
              ],
            ),
            
            SizedBox(height: 12.h),
            
            // Choose mood button
            SizedBox(
              width: double.infinity,
              height: 48.h,
              child: OutlinedButton.icon(
                onPressed: _canChooseMood() ? _showMoodPicker : null,
                style: OutlinedButton.styleFrom(
                  side: BorderSide(
                    color: _canChooseMood() ? const Color(0xFFE5A00D) : Colors.grey[700]!,
                    width: 2.w,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.r),
                  ),
                ),
                icon: Icon(
                  Icons.mood,
                  color: _canChooseMood() ? const Color(0xFFE5A00D) : Colors.grey[400],
                  size: 20.sp,
                ),
                label: Text(
                  "Choose Your Mood",
                  style: TextStyle(
                    color: _canChooseMood() ? const Color(0xFFE5A00D) : Colors.grey[400],
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],

          // Friend Mode: Show invite options prominently
          if (currentMode == MatchingMode.friend) ...[
            if (selectedFriend != null) ...[
              // Friend is selected - show start matching button
              Container(
                padding: EdgeInsets.all(16.r),
                decoration: BoxDecoration(
                  color: const Color(0xFF2A2A2A),
                  borderRadius: BorderRadius.circular(12.r),
                  border: Border.all(color: const Color(0xFFE5A00D)),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: const Color(0xFFE5A00D),
                      child: Text(selectedFriend!.name[0].toUpperCase()),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Text(
                        "Ready to match with ${selectedFriend!.name}",
                        style: TextStyle(color: Colors.white, fontSize: 14.sp),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 16.h),
              SizedBox(
                width: double.infinity,
                height: 56.h,
                child: ElevatedButton.icon(
                  onPressed: _startFYPSession,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE5A00D),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.r)),
                  ),
                  icon: Icon(Icons.auto_awesome, color: Colors.black, size: 24.sp),
                  label: Text("Perfect For Us", 
                    style: TextStyle(color: Colors.black, fontSize: 16.sp, fontWeight: FontWeight.bold)),
                ),
              ),
            ] else ...[
            // Main invite button
            SizedBox(
              width: double.infinity,
              height: 56.h,
              child: ElevatedButton.icon(
                onPressed: () => _showInvitationOptions(),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE5A00D),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.r),
                  ),
                ),
                icon: Icon(
                  Icons.group_add,
                  color: Colors.black,
                  size: 24.sp,
                ),
                label: Text(
                  "Invite Friend to Swipe Together",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            
            SizedBox(height: 16.h),
            
            // Quick options row
            Row(
              children: [
                Expanded(
                  child: _buildQuickInviteOption(
                    icon: Icons.share,
                    label: "Share Code",
                    onTap: () => _createSessionWithCode(),
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: _buildQuickInviteOption(
                    icon: Icons.person_add,
                    label: "Direct Invite",
                    onTap: () => _showFriendSelector(),
                  ),
                ),
              ],
            ),
          ],

          // Group Mode: Show group creation options (simplified to prevent overflow)
          if (currentMode == MatchingMode.group) ...[
            SizedBox(
              width: double.infinity,
              height: 56.h,
              child: ElevatedButton.icon(
                onPressed: selectedGroup.isNotEmpty ? _startFYPSession : _showGroupSelectionDialog,
                style: ElevatedButton.styleFrom(
                  backgroundColor: selectedGroup.isNotEmpty ? const Color(0xFFE5A00D) : Colors.grey[700],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.r),
                  ),
                ),
                icon: Icon(
                  selectedGroup.isNotEmpty ? Icons.auto_awesome : Icons.groups,
                  color: selectedGroup.isNotEmpty ? Colors.black : Colors.grey[400],
                  size: 24.sp,
                ),
                label: Text(
                  selectedGroup.isNotEmpty 
                      ? "Perfect For Us (${selectedGroup.length + 1})"
                      : "Select Group Members",
                  style: TextStyle(
                    color: selectedGroup.isNotEmpty ? Colors.black : Colors.grey[400],
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            
            if (selectedGroup.isNotEmpty) ...[
              SizedBox(height: 12.h),
              Container(
                padding: EdgeInsets.all(12.r),
                decoration: BoxDecoration(
                  color: const Color(0xFFE5A00D).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12.r),
                  border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.people, color: const Color(0xFFE5A00D), size: 16.sp),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: Text(
                        "Group: You + ${selectedGroup.map((f) => f.name).join(', ')}",
                        style: TextStyle(
                          color: const Color(0xFFE5A00D),
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: _showGroupSelectionDialog,
                      child: Icon(Icons.edit, color: const Color(0xFFE5A00D), size: 16.sp),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ],
        ]
      ),
    );
  }

  // Add this helper method for the quick invite options
  Widget _buildQuickInviteOption({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 16.w),
        decoration: BoxDecoration(
          color: const Color(0xFF2A2A2A),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: Colors.grey.withValues(alpha: 0.3)),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: const Color(0xFFE5A00D),
              size: 24.sp,
            ),
            SizedBox(height: 4.h),
            Text(
              label,
              style: TextStyle(
                color: Colors.white,
                fontSize: 12.sp,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // Add these new methods for quick session creation
  Future<void> _createSessionWithCode() async {
    setState(() => _isLoadingSession = true);
    
    try {
      final session = await SessionService.createSession(
        hostName: widget.currentUser.name,
        inviteType: InvitationType.code,
      );
      
      if (mounted) {
        _showSessionCodeDialog(session.sessionCode!);
        _startCollaborativeSession(session);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to create session: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoadingSession = false);
    }
  }

  void _showFriendSelector() {
    showDialog(
      context: context,
      builder: (context) => FriendInviteDialog(
        currentUser: widget.currentUser,
        availableFriends: widget.availableFriends,
        onSessionCreated: _startCollaborativeSession,
      ),
    );
  }

  void _showSessionCodeDialog(String sessionCode) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "Session Created! 🎉",
          style: TextStyle(color: Colors.white, fontSize: 18.sp),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Share this code with your friend:",
              style: TextStyle(color: Colors.grey[300], fontSize: 14.sp),
            ),
            SizedBox(height: 16.h),
            
            Container(
              padding: EdgeInsets.all(16.r),
              decoration: BoxDecoration(
                color: const Color(0xFFE5A00D).withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(color: const Color(0xFFE5A00D)),
              ),
              child: Text(
                sessionCode,
                style: TextStyle(
                  color: const Color(0xFFE5A00D),
                  fontSize: 32.sp,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 8.w,
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              "Got it!",
              style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 14.sp),
            ),
          ),
        ],
      ),
    );
  }

// NEW: Welcome screen for when no session is active
  Widget _buildWelcomeScreen() {
    // Don't show welcome screen if we're in collaborative mode
    if (isInCollaborativeMode) {
      return _buildCollaborativeWaitingScreen();
    }
    
    return SingleChildScrollView(
      padding: EdgeInsets.all(32.r),
      child: ConstrainedBox(
        constraints: BoxConstraints(
          minHeight: MediaQuery.of(context).size.height * 0.4,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Mode-specific icon and message
            Icon(
              _getModeIcon(),
              size: 80.sp,
              color: const Color(0xFFE5A00D),
            ),
            SizedBox(height: 24.h),
            
            Text(
              _getWelcomeTitle(),
              style: TextStyle(
                color: Colors.white,
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16.h),
            
            Text(
              _getWelcomeSubtitle(),
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16.sp,
                height: 1.4,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // Helper methods for welcome screen
  IconData _getModeIcon() {
    switch (currentMode) {
      case MatchingMode.solo:
        return Icons.person;
      case MatchingMode.friend:
        return Icons.people;
      case MatchingMode.group:
        return Icons.groups;
    }
  }

  String _getWelcomeTitle() {
    switch (currentMode) {
      case MatchingMode.solo:
        return "Ready to find your next movie?";
      case MatchingMode.friend:
        return selectedFriend != null 
            ? "Ready to find movies with ${selectedFriend!.name}?"
            : "Select a friend to start matching!";
      case MatchingMode.group:
        return selectedGroup.isNotEmpty
            ? "Ready to find movies for your group?"
            : "Select group members to start!";
    }
  }

  String _getWelcomeSubtitle() {
    switch (currentMode) {
      case MatchingMode.solo:
        return "Get instant recommendations based on your taste, or pick a mood for something specific.";
      case MatchingMode.friend:
        return selectedFriend != null 
            ? "Find movies you'll both love, or let our AI suggest perfect matches for your duo."
            : "Choose a friend from your list to start finding movies you'll both enjoy.";
      case MatchingMode.group:
        return selectedGroup.isNotEmpty
            ? "Find movies everyone will enjoy, or get AI recommendations for your group."
            : "Add friends to create a group and find movies everyone will love.";
    }
  }

  Widget _buildModeButton(String title, IconData icon, bool isSelected, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8.r),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 8.w),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFE5A00D) : const Color(0xFF1F1F1F),
          borderRadius: BorderRadius.circular(8.r),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: Colors.white,
              size: 16.sp,
            ),
            SizedBox(width: 4.w),
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 13.sp,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Add friend selection dialog
  void _showFriendSelectionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "Select a Friend", 
          style: TextStyle(color: Colors.white, fontSize: 18.sp)
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: widget.availableFriends.isEmpty
              ? Center(
                  child: Text(
                    "You don't have any friends yet. Add some from the Friends tab!",
                    style: TextStyle(color: Colors.white70, fontSize: 15.sp),
                  ),
                )
              : ListView.builder(
                  shrinkWrap: true,
                  itemCount: widget.availableFriends.length,
                  itemBuilder: (context, index) {
                    final friend = widget.availableFriends[index];
                    final isSelected = selectedFriend?.name == friend.name;
                    
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.grey[800],
                        radius: 20.r,
                        child: Text(
                          friend.name.isNotEmpty ? friend.name[0].toUpperCase() : "?",
                          style: TextStyle(color: Colors.white, fontSize: 16.sp),
                        ),
                      ),
                      title: Text(
                        friend.name,
                        style: TextStyle(color: Colors.white, fontSize: 16.sp),
                      ),
                      subtitle: Text(
                        "Genres: ${friend.preferredGenres.take(2).join(", ")}${friend.preferredGenres.length > 2 ? "..." : ""}",
                        style: TextStyle(color: Colors.white54, fontSize: 14.sp),
                      ),
                      trailing: isSelected
                          ? Icon(Icons.check_circle, color: const Color(0xFFE5A00D), size: 24.sp)
                          : null,
                      selected: isSelected,
                      selectedTileColor: Colors.black26,
                      onTap: () {
                        Navigator.pop(context);
                        _selectFriend(friend);
                      },
                    );
                  },
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel", 
              style: TextStyle(color: Colors.white70, fontSize: 15.sp)
            ),
          ),
        ],
      ),
    );
  }

  // Add group selection dialog
  void _showGroupSelectionDialog() {
    final tempSelected = Set<String>.from(selectedGroup.map((f) => f.name));

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "Select Group Members", 
          style: TextStyle(color: Colors.white, fontSize: 18.sp)
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: widget.availableFriends.length,
            itemBuilder: (context, index) {
              final friend = widget.availableFriends[index];
              return CheckboxListTile(
                title: Text(
                  friend.name, 
                  style: TextStyle(color: Colors.white, fontSize: 16.sp)
                ),
                value: tempSelected.contains(friend.name),
                activeColor: const Color(0xFFE5A00D),
                checkColor: Colors.black,
                onChanged: (selected) {
                  setState(() {
                    if (selected == true) {
                      tempSelected.add(friend.name);
                    } else {
                      tempSelected.remove(friend.name);
                    }
                  });
                },
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel", 
              style: TextStyle(color: Colors.white70, fontSize: 15.sp)
            ),
          ),
          ElevatedButton(
            onPressed: () {
              final group = widget.availableFriends.where((f) => tempSelected.contains(f.name)).toList();
              setState(() {
                selectedGroup = group;
                _initializeApp();
              });
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE5A00D)),
            child: Text(
              "Start Group Session", 
              style: TextStyle(color: Colors.black, fontSize: 15.sp)
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMainContent() {
  print("🔍 DEBUG: _buildMainContent called");
  print("🔍 DEBUG: _isReadyToSwipe: $_isReadyToSwipe");
  print("🔍 DEBUG: sessionPool.length: ${sessionPool.length}");
  print("🔍 DEBUG: currentMode: $currentMode");
  print("🔍 DEBUG: selectedFriend: $selectedFriend");
  
  if (currentMode == MatchingMode.friend && selectedFriend == null && !isInCollaborativeMode) {
    print("🔍 DEBUG: Returning _buildSelectFriendScreen");
    return _buildSelectFriendScreen();
  }

  if (sessionPool.isEmpty) {
    print("🔍 DEBUG: sessionPool is empty, returning _buildEmptyState");
    return _buildEmptyState();
  }

  print("🔍 DEBUG: Returning movie swiper");
  // ... rest of your existing code


    return Padding(
      padding: EdgeInsets.all(12.r),
      child: Column(
        children: [
          // Full-height swiper
          Expanded(
            child: CardSwiper(
              cardsCount: sessionPool.length,
              numberOfCardsDisplayed: 1,
              onSwipe: _onSwipe,
              cardBuilder: (context, index, percentX, percentY) {
                if (index >= sessionPool.length) return const SizedBox.shrink();

                final movie = sessionPool[index];
                
                // Fixed type casting: Convert num to double explicitly
                final leftIntensity = percentX < 0 ? (-percentX.toDouble()).clamp(0.0, 1.0) : 0.0;
                final rightIntensity = percentX > 0 ? percentX.toDouble().clamp(0.0, 1.0) : 0.0;
                
                return Container(
                  margin: EdgeInsets.all(8.r),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16.r),
                    border: Border.all(color: Colors.yellow.shade800, width: 2.w),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14.r),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        // Background color
                        Container(color: const Color(0xFF1A1A1A)),
                        
                        // Movie poster
                        Column(
                          children: [
                            // Poster takes most of the space
                            Expanded(
                              child: Image.network(
                                movie.posterUrl,
                                fit: BoxFit.contain,
                                width: double.infinity,
                                errorBuilder: (context, error, stackTrace) {
                                  return Container(
                                    color: Colors.grey[800],
                                    child: Icon(
                                      Icons.broken_image, 
                                      size: 100.sp, 
                                      color: Colors.white24
                                    ),
                                  );
                                },
                              ),
                            ),
                            
                            // Title at bottom
                            Container(
                              width: double.infinity,
                              padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 16.w),
                              child: Text(
                                movie.title,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            
                            // View more button
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 8.h),
                              child: ElevatedButton(
                                onPressed: () => _showMovieDetailSheet(context, movie),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFFE5A00D),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20.r),
                                  ),
                                  padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                                ),
                                child: Text(
                                  "View more",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14.sp,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),

                        // Left indicator overlay with gradient
                        if (leftIntensity > 0)
                          Positioned.fill(
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                  colors: [
                                    Colors.red.withAlpha((179 * leftIntensity).toInt()),
                                    Colors.red.withAlpha(0),
                                  ],
                                  stops: const [0.0, 0.3],
                                ),
                              ),
                            ),
                          ),
                          
                        // Right indicator overlay with gradient
                        if (rightIntensity > 0)
                          Positioned.fill(
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.centerRight,
                                  end: Alignment.centerLeft,
                                  colors: [
                                    Colors.green.withAlpha((179 * rightIntensity).toInt()),
                                    Colors.green.withAlpha(0),
                                  ],
                                  stops: const [0.0, 0.3],
                                ),
                              ),
                            ),
                          ),
                        
                        // Tap area for movie details
                        Positioned.fill(
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () => _showMovieDetailSheet(context, movie),
                              splashColor: Colors.white.withAlpha(26),
                              highlightColor: Colors.transparent,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // Swipe instruction text
          Padding(
            padding: EdgeInsets.only(top: 12.h),
            child: Text(
              "Swipe left to pass, right to like",
              style: TextStyle(color: Colors.grey[400], fontSize: 14.sp),
            ),
          ),
          SizedBox(height: 8.h),
        ],
      ),
    );
  }

  void _showMovieDetailSheet(BuildContext context, Movie movie) {
  final bool isInFavorites = widget.currentUser.likedMovies.contains(movie);

  showMovieDetails(
    context: context,
    movie: movie,
    currentUser: widget.currentUser,
    onAddToFavorites: isInFavorites ? null : (Movie movie) {
      setState(() {
        widget.currentUser.likedMovies.add(movie);
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${movie.title} added to favorites'),
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 2),
        ),
      );
    },
    onRemoveFromFavorites: isInFavorites ? (Movie movie) {
      setState(() {
        widget.currentUser.likedMovies.remove(movie);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${movie.title} removed from favorites'),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 2),
        ),
      );
    } : null,
    onMarkAsWatched: currentMode == MatchingMode.friend || currentMode == MatchingMode.group
        ? (Movie movie) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('${movie.title} marked as watched'),
                backgroundColor: Colors.green,
                duration: const Duration(seconds: 2),
              ),
            );
          }
        : null,
    isInFavorites: isInFavorites,
  );
}

  Widget _buildSelectFriendScreen() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.people_outline,
              size: 80.sp,
              color: Colors.white30,
            ),
            SizedBox(height: 16.h),
            Text(
              "Choose a friend to start finding movies you both want to watch!",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16.sp,
              ),
            ),
            SizedBox(height: 32.h),
            ElevatedButton.icon(
              onPressed: () {
                _showFriendSelectionDialog(); // Show friend selection dialog
              },
              icon: Icon(Icons.people, color: Colors.white, size: 20.sp),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 14.h),
                minimumSize: Size(200.w, 50.h),
              ),
              label: Text(
                "Select a Friend",
                style: TextStyle(color: Colors.white, fontSize: 16.sp),
              ),
            ),
            SizedBox(height: 16.h),
            Text(
              "OR",
              style: TextStyle(
                color: Colors.white54,
                fontSize: 14.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.h),
            OutlinedButton.icon(
              onPressed: () {
                _switchMode(MatchingMode.solo);
              },
              icon: Icon(Icons.movie, color: const Color(0xFFE5A00D), size: 20.sp),
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: const Color(0xFFE5A00D), width: 1.w),
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 14.h),
                minimumSize: Size(200.w, 50.h),
              ),
              label: Text(
                "Start Solo Swiping",
                style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 16.sp),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.movie_filter,
              size: 80.sp,
              color: Colors.grey,
            ),
            SizedBox(height: 24.h),
            Text(
              currentMode == MatchingMode.solo 
                  ? "No movies to swipe yet!" 
                  : "No movies to match yet!",
              style: TextStyle(
                color: Colors.white,
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.h),
            Text(
              currentMode == MatchingMode.friend && selectedFriend != null
              ? "You and ${selectedFriend!.name} need to like some movies first."
              : "You need to like some movies first.",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16.sp,
              ),
            ),
            SizedBox(height: 32.h),
            ElevatedButton.icon(
              onPressed: () async {
                final newMovies = await TMDBApi.getPopularMovies(); // or a different TMDB call
                setState(() {
                  sessionPool = List<Movie>.from(newMovies)..shuffle();
                  if (sessionPool.length > 20) {
                    sessionPool = sessionPool.sublist(0, 20);
                  }
                });
              },
              icon: Icon(Icons.refresh, color: Colors.white, size: 20.sp),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
              ),
              label: Text(
                "Load Sample Movies", 
                style: TextStyle(color: Colors.white, fontSize: 16.sp)
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTutorialOverlay() {
    final tutorialPages = [
      {
        'title': 'Solo Mode',
        'description': 'Swipe right on movies you like, left on ones you don\'t. This builds your taste profile for better matching with friends later! The more you swipe, the better we can suggest movies you\'ll enjoy.',
        'icon': Icons.person,
        'color': Colors.orange,
      },
      {
        'title': 'Friend Mode',
        'description': 'Swipe right on movies you like, left on ones you don\'t. When both you and your friend like the same movie, it\'s a match! The more you swipe, the better we can suggest movies you\'ll both enjoy.',
        'icon': Icons.people,
        'color': Colors.blue,
      },
      {
        'title': 'Group Mode',
        'description': 'Swipe right on movies with your group. When EVERYONE likes the same film, it\'s a match! The app learns each member\'s preferences to build the perfect shared session.',
        'icon': Icons.groups,
        'color': Colors.purple,
      },
    ];

    return _showTutorial
        ? Container(
            color: Colors.black.withAlpha((255 * 0.85).round()),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Page indicator
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    tutorialPages.length,
                    (index) => Container(
                      margin: EdgeInsets.symmetric(horizontal: 4.w),
                      width: 10.w,
                      height: 10.h,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _tutorialPage == index
                            ? const Color(0xFFE5A00D)
                            : Colors.grey,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 24.h),
                
                // Swipeable content
                Expanded(
                  child: PageView.builder(
                    controller: _tutorialPageController,
                    itemCount: tutorialPages.length,
                    onPageChanged: (index) {
                      setState(() {
                        _tutorialPage = index;
                      });
                    },
                    itemBuilder: (context, index) {
                      final page = tutorialPages[index];
                      return Padding(
                        padding: EdgeInsets.symmetric(horizontal: 32.w),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // Icon
                            Container(
                              padding: EdgeInsets.all(24.r),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: page['color'] as Color,
                                boxShadow: [
                                  BoxShadow(
                                    color: (page['color'] as Color).withAlpha((255 * 0.3).round()),
                                    blurRadius: 20.r,
                                    spreadRadius: 5.r,
                                  ),
                                ],
                              ),
                              child: Icon(
                                page['icon'] as IconData,
                                color: Colors.white,
                                size: 64.sp,
                              ),
                            ),
                            SizedBox(height: 40.h),
                            
                            // Title
                            Text(
                              page['title'] as String,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 28.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 24.h),
                            
                            // Description
                            Text(
                              page['description'] as String,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 16.sp,
                                height: 1.5,
                              ),
                            ),
                            
                            // Swipe hint
                            if (index < tutorialPages.length - 1)
                              Padding(
                                padding: EdgeInsets.only(top: 40.h),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      "Swipe right for next",
                                      style: TextStyle(
                                        color: Colors.white54,
                                        fontSize: 14.sp,
                                      ),
                                    ),
                                    SizedBox(width: 8.w),
                                    Icon(
                                      Icons.arrow_forward,
                                      color: Colors.white54,
                                      size: 16.sp,
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: 32.h),
                
                // Got it button
                ElevatedButton(
                  onPressed: () async {
                    await _markTutorialSeen();
                    setState(() {
                      _showTutorial = false;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE5A00D),
                    padding: EdgeInsets.symmetric(
                      horizontal: 32.w,
                      vertical: 12.h,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.r),
                    ),
                  ),
                  child: Text(
                    "Got it!",
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 16.sp,
                    ),
                  ),
                ),
                SizedBox(height: 40.h),
              ],
            ),
          )
        : const SizedBox.shrink(); // Return empty widget when tutorial is not shown
  }

  void _showInfoDialog() {
    String infoText = "";
    if (currentMode == MatchingMode.solo) {
      infoText = "Solo Mode: Swipe right on movies you like, left on ones you don't.\n\n"
                "This builds your taste profile for better matching with friends later!\n\n"
                "The more you swipe, the better we can suggest movies you'll enjoy.";
    } else if (currentMode == MatchingMode.friend) {
      infoText = "Friend Mode: Swipe right on movies you like, left on ones you don't.\n\n"
                "When both you and your friend like the same movie, it's a match!\n\n"
                "The more you swipe, the better we can suggest movies you'll both enjoy.";
    } else {
      infoText = "Group Mode: Swipe right on movies with your group. When EVERYONE likes the same film, it's a match!\n\n"
                "The app learns each member's preferences to build the perfect shared session.";
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "How Matching Works", 
          style: TextStyle(color: Colors.white, fontSize: 18.sp)
        ),
        content: Text(
          infoText,
          style: TextStyle(color: Colors.white70, fontSize: 15.sp),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Got it!", 
              style: TextStyle(color: Colors.orange, fontSize: 15.sp)
            ),
          ),
        ],
      ),
    );
  }
   @override
  void dispose() {
    sessionSubscription?.cancel();
    super.dispose();
  }

  // 🆕 Show invitation options
  void _showInvitationOptions() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => SessionInvitationWidget(
        currentUser: widget.currentUser,
        availableFriends: widget.availableFriends,
        onSessionCreated: (session) {
          _startCollaborativeSession(session);
        },
      ),
    );
  }

  void _startCollaborativeSession(SwipeSession session) {
    print("🤝 Starting collaborative session: ${session.sessionId}");
    print("   Status: ${session.status}");
    print("   Participants: ${session.participantNames}");
    print("   Is host: ${session.hostId == widget.currentUser.uid}");
    
    setState(() {
      currentSession = session;
      isWaitingForFriend = session.status == SessionStatus.created;
      isInCollaborativeMode = true;
      currentMode = MatchingMode.friend; // Set to friend mode
      
      // Reset session state
      _isReadyToSwipe = false;
      selectedMoods.clear();
      sessionPool.clear();
    });

    // Listen to session updates
    sessionSubscription?.cancel(); // Cancel any existing subscription
    sessionSubscription = SessionService.watchSession(session.sessionId).listen(
      (updatedSession) {
        print("📡 Session update received:");
        print("   Status: ${updatedSession.status}");
        print("   Participants: ${updatedSession.participantNames}");
        
        // Track previous matches to detect new ones
        final previousMatches = currentSession?.matches ?? [];
        
        setState(() {
          currentSession = updatedSession;
          isWaitingForFriend = updatedSession.status == SessionStatus.created;
        });
        
        // ✅ FIXED: When session becomes active, check for existing mood first
      if (updatedSession.status == SessionStatus.active && sessionPool.isEmpty && !_isReadyToSwipe) {
        print("🎬 Session is now active - generating collaborative movie pool");
        
        // ✅ FIXED: Check if session already has a mood set by host
        if (updatedSession.hasMoodSelected && selectedMoods.isEmpty) {
          print("🎭 Session has host's mood: ${updatedSession.selectedMoodName}");
          
          // Find the corresponding CurrentMood enum value
          CurrentMood? sessionMood;
          try {
            sessionMood = CurrentMood.values.firstWhere(
              (mood) => mood.toString().split('.').last == updatedSession.selectedMoodId
            );
          } catch (e) {
            print("⚠️ Could not find matching mood enum for: ${updatedSession.selectedMoodId}");
            sessionMood = CurrentMood.perfectForUs; // Fallback
          }
          
          // Auto-apply the host's mood and generate session
          setState(() {
            selectedMoods = [sessionMood!];
          });
          
          print("✅ Auto-applied host's mood: ${sessionMood.displayName}");
          _generateCollaborativeSession();
          
        } else if (selectedMoods.isEmpty) {
          // No mood in session and no local moods - show mood selection
          print("🔍 No mood set anywhere, showing mood selection");
          setState(() {
            _showMoodSelectionModal = true;
          });
        } else {
          // Moods already selected locally, generate the session directly
          print("🔍 Using locally selected moods");
          _generateCollaborativeSession();
        }
      }
        
        // Check for new matches and show match screen
        final newMatches = updatedSession.matches.where(
          (movieId) => !previousMatches.contains(movieId)
        ).toList();
        
        for (final movieId in newMatches) {
          _handleSessionMatch(movieId);
        }
      },
      onError: (error) {
        print("❌ Session stream error: $error");
        _endCollaborativeSession();
      },
    );


    print("🎯 Collaborative session started successfully");
    
    // Show success message to user
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          session.hostId == widget.currentUser.uid 
              ? 'Session created! Waiting for friends...'
              : 'Successfully joined ${session.hostName}\'s session!',
        ),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 3),
      ),
    );
  }
  void _handleSessionMatch(String movieId) {
    if (currentSession == null) return;
      
    // Find the movie object from our session pool
    Movie? matchedMovie;
    try {
      matchedMovie = sessionPool.firstWhere((movie) => movie.id == movieId);
    } catch (e) {
      // If movie not found in current pool, create a placeholder
      matchedMovie = Movie(
        id: movieId,
        title: "Matched Movie",
        posterUrl: "",
        overview: "You both liked this movie!",
        cast: [], // ✅ Required parameter
        genres: [],
        tags: [],
        releaseDate: DateTime.now().toIso8601String().split('T')[0], // ✅ String format
      );
    }
    
    // Show the match screen
    Navigator.push(
      context,
      PageRouteBuilder(
        opaque: false,
        barrierDismissible: false,
        pageBuilder: (context, animation, secondaryAnimation) {
          return MatchedScreen(
            movie: matchedMovie!,
            currentUser: widget.currentUser,
            matchedName: currentSession!.participantNames
                .where((name) => name != widget.currentUser.name)
                .join(", "),
          );
        },
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(
            opacity: animation,
            child: child,
          );
        },
      ),
    );
  }

  Future<void> _generateCollaborativeSession() async {
    print("🔍 DEBUG: _generateCollaborativeSession called");
    print("🔍 DEBUG: currentSession null? ${currentSession == null}");
    
    if (currentSession == null) {
      print("❌ DEBUG: currentSession is null, returning");
      return;
    }

    // 🆕 CHECK: Are we the host or a friend?
    final isHost = currentSession!.hostId == widget.currentUser.uid;
    print("🔍 DEBUG: isHost: $isHost");

    setState(() {
      _isLoadingSession = true;
    });
    print("🔍 DEBUG: Set _isLoadingSession = true");

    try {
      // Check if session already has a mood set by the host
      if (currentSession!.hasMoodSelected) {
        print("🎭 Session already has mood set by host: ${currentSession!.selectedMoodName}");
        
        // Find the corresponding CurrentMood enum value
        CurrentMood? sessionMood;
        try {
          sessionMood = CurrentMood.values.firstWhere(
            (mood) => mood.toString().split('.').last == currentSession!.selectedMoodId
          );
        } catch (e) {
          print("⚠️ Could not find matching mood enum for: ${currentSession!.selectedMoodId}");
          sessionMood = CurrentMood.perfectForUs;
        }
        
        // Auto-apply the host's mood to this user
        setState(() {
          selectedMoods = [sessionMood!];
          _showMoodSelectionModal = false;
        });
        
        // Create session context with the host's mood
        currentSessionContext = SessionContext(
          moods: sessionMood,
          groupMemberIds: currentSession!.participantIds,
        );
        
        print("✅ Applied host's mood: ${sessionMood.displayName}");
        
      } else {
        // No mood set yet - show mood selection
        if (selectedMoods.isEmpty) {
          print("🔍 DEBUG: No mood set in session and no local moods selected, showing mood selection");
          setState(() {
            _showMoodSelectionModal = true;
            _isLoadingSession = false;
          });
          return;
        }
      }
      
      print("🔍 DEBUG: Selected moods: ${selectedMoods.map((m) => m.displayName).join(', ')}");

      List<Movie> collaborativePool = [];

      // 🆕 FIXED: Host generates, Friend loads
      if (isHost) {
        print("👑 HOST: Generating movie pool for session");
        
        // Generate movie pool for the session
        final seenMovieIds = <String>{
          ...widget.currentUser.likedMovieIds,
          ...widget.currentUser.passedMovieIds,
          ...currentSessionMovieIds,
        };

        // Check if we have a movie database
        if (movieDatabase.isEmpty) {
          print("⚠️ Movie database is empty, using sample movies");
          collaborativePool = sampleMovies;
        } else {
          // Generate based on mood
          if (selectedMoods.length == 1) {
            if (selectedMoods.first == CurrentMood.perfectForUs) {
              print("🤝 HOST: Generating 'Perfect For Us' collaborative pool");
              try {
                // 🆕 For Perfect For Us: Use collaborative logic that considers both users
                // Note: You'll need to load friend profiles from Firestore for full implementation
                final groupMembers = [widget.currentUser]; // Add friend profiles when available
                
                // TODO: Load friend profiles from currentSession!.participantIds
                // for (final participantId in currentSession!.participantIds) {
                //   if (participantId != widget.currentUser.uid) {
                //     final friendProfile = await loadUserProfile(participantId);
                //     groupMembers.add(friendProfile);
                //   }
                // }
                
                collaborativePool = await MoodBasedLearningEngine.generatePerfectForUsSession(
                  groupMembers: groupMembers,
                  movieDatabase: movieDatabase,
                  seenMovieIds: seenMovieIds,
                  sessionSize: 30,
                  minMoviesPerPerson: 10,
                );
              } catch (e) {
                print("❌ Error in generatePerfectForUsSession: $e");
                collaborativePool = sampleMovies;
              }
            } else {
              // Regular mood-based session
              final context = SessionContext(
                moods: selectedMoods.first,
                groupMemberIds: currentSession!.participantIds,
              );
              try {
                collaborativePool = await MoodBasedLearningEngine.generateMoodBasedSession(
                  user: widget.currentUser,
                  movieDatabase: movieDatabase,
                  sessionContext: context,
                  seenMovieIds: seenMovieIds,
                  sessionSize: 30,
                );
              } catch (e) {
                print("❌ Error in generateMoodBasedSession: $e");
                collaborativePool = sampleMovies;
              }
            }
          } else {
            // Multi-mood session
            try {
              await _generateBlendedMoodSession();
              collaborativePool = sessionPool;
            } catch (e) {
              print("❌ Error in generateBlendedMoodSession: $e");
              collaborativePool = sampleMovies;
            }
          }
        }

        // Ensure we have movies
        if (collaborativePool.isEmpty) {
          print("⚠️ Collaborative pool is empty, using sample movies");
          collaborativePool = sampleMovies;
        }

        print("🎬 HOST: Generated ${collaborativePool.length} movies for collaborative session");

        // 🆕 HOST: Save movie pool to Firestore for friends to load
        try {
          await SessionService.startSession(
            currentSession!.sessionId,
            selectedMoodIds: selectedMoods.map((m) => m.toString().split('.').last).toList(),
            moviePool: collaborativePool.map((m) => m.id).toList(),
          );
          print("✅ HOST: Saved movie pool to Firestore");
        } catch (e) {
          print("⚠️ Could not save movie pool to Firestore: $e");
        }

      } else {
        print("👥 FRIEND: Loading movie pool from host");
        
        // 🆕 FRIEND: Load movie pool from session instead of generating
        if (currentSession!.moviePool.isNotEmpty) {
          print("📥 FRIEND: Found ${currentSession!.moviePool.length} movie IDs in session");
          
          // Convert movie IDs back to Movie objects
          for (final movieId in currentSession!.moviePool) {
            try {
              final movie = movieDatabase.firstWhere((m) => m.id == movieId);
              collaborativePool.add(movie);
            } catch (e) {
              print("⚠️ Could not find movie with ID: $movieId");
              // If movie not found in database, you might want to fetch it from TMDB
            }
          }
          
          print("✅ FRIEND: Loaded ${collaborativePool.length} movies from host's pool");
          
        } else {
          print("⚠️ FRIEND: No movie pool in session yet, using sample movies");
          collaborativePool = sampleMovies;
        }
      }

      // CRITICAL: Update state and mark ready to swipe
      setState(() {
        sessionPool = List.from(collaborativePool);
        currentSessionMovieIds.clear();
        currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
        _isReadyToSwipe = true;
      });
      
      print("🔍 DEBUG: Set _isReadyToSwipe = true, sessionPool.length = ${sessionPool.length}");
      if (sessionPool.isNotEmpty) {
        print("🎬 First movie: ${sessionPool.first.title}");
      }

    } catch (e) {
      print("❌ ERROR in _generateCollaborativeSession: $e");
      
      // Fallback to sample movies
      setState(() {
        sessionPool = sampleMovies;
        _isReadyToSwipe = true;
      });
      
    } finally {
      setState(() {
        _isLoadingSession = false;
      });
      print("🔍 DEBUG: Set _isLoadingSession = false");
    }
  }

  // 🆕 Handle collaborative swipe
  bool _onCollaborativeSwipe(int previousIndex, int? currentIndex, CardSwiperDirection direction) {
    if (currentSession == null || previousIndex >= sessionPool.length) return false;

    final movie = sessionPool[previousIndex];
    final isLike = direction == CardSwiperDirection.right;

    // Record swipe in Firebase
    SessionService.recordSwipe(
      sessionId: currentSession!.sessionId,
      movieId: movie.id,
      isLike: isLike,
    );

    // Apply local learning (same as normal swipe)
    if (isLike) {
      likeMovie(movie);
    } else {
      passMovie(movie);
    }

    // Check for matches in real-time (handled by session stream)
    
    return true;
  }

  // 🆕 End collaborative session
  void _endCollaborativeSession() {
    if (currentSession != null) {
      SessionService.endSession(currentSession!.sessionId);
    }
    
    sessionSubscription?.cancel();
    
    setState(() {
      currentSession = null;
      isWaitingForFriend = false;
      isInCollaborativeMode = false;
      currentMode = MatchingMode.solo; // Return to solo mode
      _resetToSelection();
    });
  }

    // 🆕 Build collaborative mode UI elements
    Widget _buildCollaborativeHeader() {
    if (!isInCollaborativeMode || currentSession == null) {
      return const SizedBox.shrink();
    }
    
    // If we're ready to swipe, don't show this header (mood banner will show instead)
    if (_isReadyToSwipe) {
      return const SizedBox.shrink();
    }
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF4A90E2).withValues(alpha: 0.9),
            const Color(0xFF357ABD).withValues(alpha: 0.9),
          ],
        ),
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Row(
        children: [
          // Session info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isWaitingForFriend ? "Waiting for friend..." : "Swiping together!",
                  style: TextStyle(color: Colors.white, fontSize: 16.sp, fontWeight: FontWeight.bold),
                ),
                if (currentSession!.sessionCode != null)
                  Text(
                    "Code: ${currentSession!.sessionCode}",
                    style: TextStyle(color: Colors.white70, fontSize: 14.sp),
                  ),
              ],
            ),
          ),
          
          // Cancel button
          GestureDetector(
            onTap: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  backgroundColor: const Color(0xFF1F1F1F),
                  title: Text("Cancel Session?", style: TextStyle(color: Colors.white)),
                  content: Text(
                    "Are you sure you want to cancel this session?",
                    style: TextStyle(color: Colors.grey[300]),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text("Keep Waiting", style: TextStyle(color: Colors.grey[400])),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _endCollaborativeSession();
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                      child: Text("Cancel Session", style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              );
            },
            child: Container(
              padding: EdgeInsets.all(8.r),
              decoration: BoxDecoration(
                color: Colors.red.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(8.r),
              ),
              child: Icon(Icons.close, color: Colors.white, size: 20.sp),
            ),
          ),
        ],
      ),
    );
  }

  // 🆕 Collaborative waiting screen
  Widget _buildCollaborativeWaitingScreen() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(32.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Animated waiting indicator
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 100.r,
                  height: 100.r,
                  child: CircularProgressIndicator(
                    valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFE5A00D)),
                    strokeWidth: 4.w,
                  ),
                ),
                Icon(
                  Icons.people,
                  size: 40.sp,
                  color: const Color(0xFFE5A00D),
                ),
              ],
            ),
            
            SizedBox(height: 32.h),
            
            Text(
              isWaitingForFriend 
                  ? "Waiting for your friend..."
                  : "Get ready to swipe!",
              style: TextStyle(
                color: Colors.white,
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            
            SizedBox(height: 16.h),
            
            Text(
              isWaitingForFriend 
                  ? "They'll join using your session code"
                  : "Choose your mood and start finding movies together!",
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16.sp,
                height: 1.4,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}