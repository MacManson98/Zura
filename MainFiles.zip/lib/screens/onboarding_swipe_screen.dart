// File: lib/screens/onboarding_swipe_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/user_profile.dart';
import '../movie.dart';
import '../utils/tmdb_api.dart';
import '../utils/user_profile_storage.dart';
import '../main_navigation.dart';
import 'dart:math' as math;

class OnboardingSwipeScreen extends StatefulWidget {
  final UserProfile profile;
  final List<Movie> movies;

  const OnboardingSwipeScreen({
    super.key,
    required this.profile,
    required this.movies,
  });

  @override
  State<OnboardingSwipeScreen> createState() => _OnboardingSwipeScreenState();
}

class _OnboardingSwipeScreenState extends State<OnboardingSwipeScreen> {
  final Set<String> likedGenres = {};
  final Set<String> likedVibes = {};
  final Set<String> dislikedGenres = {};
  final Set<String> dislikedVibes = {};
  
  List<OnboardingCard> cards = [];
  int currentCardIndex = 0;
  bool isLoading = true;
  bool isCompleting = false;

  @override
  void initState() {
    super.initState();
    _loadOnboardingCards();
  }

  Future<void> _loadOnboardingCards() async {
    setState(() => isLoading = true);
    
    try {
      final cardData = await _createCardData();
      cardData.shuffle(math.Random());
      
      setState(() {
        cards = cardData;
        isLoading = false;
      });
    } catch (e) {
      print('Error loading onboarding cards: $e');
      setState(() => isLoading = false);
    }
  }

  Future<List<OnboardingCard>> _createCardData() async {
    final List<OnboardingCard> cardData = [];
    
    // Reduced to 12 total cards (8 genres + 4 key vibes)
    final genreCards = [
      {'type': 'genre', 'name': 'Action', 'tmdbGenre': 28, 'description': 'High-energy thrills'},
      {'type': 'genre', 'name': 'Comedy', 'tmdbGenre': 35, 'description': 'Laugh-out-loud fun'},
      {'type': 'genre', 'name': 'Drama', 'tmdbGenre': 18, 'description': 'Emotional storytelling'},
      {'type': 'genre', 'name': 'Horror', 'tmdbGenre': 27, 'description': 'Spine-chilling scares'},
      {'type': 'genre', 'name': 'Romance', 'tmdbGenre': 10749, 'description': 'Love stories'},
      {'type': 'genre', 'name': 'Sci-Fi', 'tmdbGenre': 878, 'description': 'Future possibilities'},
      {'type': 'genre', 'name': 'Fantasy', 'tmdbGenre': 14, 'description': 'Magical worlds'},
      {'type': 'genre', 'name': 'Thriller', 'tmdbGenre': 53, 'description': 'Edge-of-seat suspense'},
    ];

    // Reduced to 4 most important vibes
    final vibeCards = [
      {'type': 'vibe', 'name': 'Feel-good', 'genres': [35, 10751], 'keywords': ['uplifting', 'heartwarming']},
      {'type': 'vibe', 'name': 'Mind-bending', 'genres': [878, 53], 'keywords': ['psychological', 'twist']},
      {'type': 'vibe', 'name': 'Action-packed', 'genres': [28, 12], 'keywords': ['fast-paced', 'adrenaline']},
      {'type': 'vibe', 'name': 'Dark', 'genres': [27, 80], 'keywords': ['dark', 'gritty']},
    ];

    // Load movies for genre cards
    for (final genreCard in genreCards) {
      try {
        final movies = await _getMoviesForGenre(genreCard['tmdbGenre'] as int);
        if (movies.length >= 4) {
          cardData.add(OnboardingCard(
            type: genreCard['type'] as String,
            name: genreCard['name'] as String,
            description: genreCard['description'] as String,
            movies: movies.take(4).toList(),
          ));
        }
      } catch (e) {
        print('Error loading movies for ${genreCard['name']}: $e');
      }
    }

    // Load movies for vibe cards
    for (final vibeCard in vibeCards) {
      try {
        final movies = await _getMoviesForVibe(
          vibeCard['genres'] as List<int>,
          vibeCard['keywords'] as List<String>,
        );
        if (movies.length >= 4) {
          cardData.add(OnboardingCard(
            type: vibeCard['type'] as String,
            name: vibeCard['name'] as String,
            description: _getVibeDescription(vibeCard['name'] as String),
            movies: movies.take(4).toList(),
          ));
        }
      } catch (e) {
        print('Error loading movies for ${vibeCard['name']}: $e');
      }
    }

    return cardData;
  }

  Future<List<Movie>> _getMoviesForGenre(int genreId) async {
    // Use existing popular movies and filter by genre
    final popularMovies = await TMDBApi.getPopularMovies();
    final genreMovies = popularMovies.where((movie) {
      return movie.genres.any((genre) => _getGenreId(genre) == genreId);
    }).toList();
    
    if (genreMovies.length >= 4) {
      return genreMovies;
    }
    
    // If not enough, return the first 4 popular movies as fallback
    return popularMovies.take(4).toList();
  }

  Future<List<Movie>> _getMoviesForVibe(List<int> genreIds, List<String> keywords) async {
    final popularMovies = await TMDBApi.getPopularMovies();
    final vibeMovies = popularMovies.where((movie) {
      // Check if movie has relevant genres
      final hasRelevantGenre = movie.genres.any((genre) => 
        genreIds.contains(_getGenreId(genre))
      );
      
      // Check if movie overview contains relevant keywords
      final hasRelevantKeywords = keywords.any((keyword) =>
        movie.overview.toLowerCase().contains(keyword.toLowerCase())
      );
      
      return hasRelevantGenre || hasRelevantKeywords;
    }).toList();
    
    if (vibeMovies.length >= 4) {
      return vibeMovies;
    }
    
    // Fallback to genre-only matching
    final genreOnlyMovies = popularMovies.where((movie) =>
      movie.genres.any((genre) => genreIds.contains(_getGenreId(genre)))
    ).toList();
    
    return genreOnlyMovies.take(4).toList();
  }

  int _getGenreId(String genreName) {
    const genreMap = {
      'Action': 28,
      'Adventure': 12,
      'Animation': 16,
      'Comedy': 35,
      'Crime': 80,
      'Documentary': 99,
      'Drama': 18,
      'Family': 10751,
      'Fantasy': 14,
      'History': 36,
      'Horror': 27,
      'Music': 10402,
      'Mystery': 9648,
      'Romance': 10749,
      'Sci-Fi': 878,
      'Science Fiction': 878,
      'TV Movie': 10770,
      'Thriller': 53,
      'War': 10752,
      'Western': 37,
    };
    return genreMap[genreName] ?? 18;
  }

  String _getVibeDescription(String vibe) {
    const descriptions = {
      'Feel-good': 'Movies that lift your spirits',
      'Mind-bending': 'Complex plots that challenge you',
      'Emotional': 'Stories that touch your heart',
      'Action-packed': 'Non-stop thrills and excitement',
      'Dark': 'Intense and gritty narratives',
      'Epic': 'Grand adventures and journeys',
      'Inspiring': 'Stories that motivate and uplift',
      'Twisty': 'Plots with unexpected turns',
    };
    return descriptions[vibe] ?? 'Great movies in this style';
  }

  String _getLearningMessage() {
    final progress = currentCardIndex / cards.length;
    
    if (progress < 0.25) {
      return 'Analyzing your movie preferences...';
    } else if (progress < 0.5) {
      return 'Building your taste profile...';
    } else if (progress < 0.75) {
      return 'Fine-tuning recommendations...';
    } else {
      return 'Almost done learning your style!';
    }
  }

  bool _onSwipe(int previousIndex, int? currentIndex, CardSwiperDirection direction) {
    if (previousIndex >= cards.length) return false;
    
    final card = cards[previousIndex];
    
    if (direction == CardSwiperDirection.right) {
      // User liked this category
      if (card.type == 'genre') {
        likedGenres.add(card.name);
      } else {
        likedVibes.add(card.name);
      }
    } else {
      // User disliked this category
      if (card.type == 'genre') {
        dislikedGenres.add(card.name);
      } else {
        dislikedVibes.add(card.name);
      }
    }
    
    setState(() {
      currentCardIndex = previousIndex + 1;
    });
    
    print('🔄 Swiped card $previousIndex, currentIndex: $currentCardIndex, total cards: ${cards.length}');
    
    // Check if we've completed all cards
    if (currentCardIndex >= cards.length) {
      print('✅ All cards completed! Starting completion...');
      Future.delayed(const Duration(milliseconds: 500), () {
        if (mounted) {
          _completeOnboarding();
        }
      });
    }
    
    return true;
  }

  Future<void> _completeOnboarding() async {
    setState(() => isCompleting = true);
    
    try {
      // Get current user's email for name fallback
      final currentUserEmail = widget.profile.name.isNotEmpty 
          ? widget.profile.name 
          : 'Movie Lover';

      final newProfile = widget.profile.copyWith(
        name: currentUserEmail,
        preferredGenres: likedGenres,
        preferredVibes: likedVibes,
        hasCompletedOnboarding: true,
      );

      await UserProfileStorage.saveProfile(newProfile);

      if (!mounted) return;
      
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => MainNavigation(
            profile: newProfile,
            movies: widget.movies,
          ),
        ),
      );
    } catch (e) {
      print('Error completing onboarding: $e');
      setState(() => isCompleting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        backgroundColor: const Color(0xFF121212),
        body: const Center(
          child: CircularProgressIndicator(color: Color(0xFFE5A00D)),
        ),
      );
    }

    if (cards.isEmpty) {
      return Scaffold(
        backgroundColor: const Color(0xFF121212),
        body: const Center(
          child: Text(
            'Error loading onboarding content',
            style: TextStyle(color: Colors.white),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        automaticallyImplyLeading: false,
        title: const Text(
          'Discover Your Movie Taste',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(50.h),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Learning your taste...',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14.sp,
                      ),
                    ),
                    Text(
                      '${((currentCardIndex / cards.length) * 100).toInt()}% complete',
                      style: TextStyle(
                        color: const Color(0xFFE5A00D),
                        fontSize: 14.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 8.h),
                LinearProgressIndicator(
                  value: currentCardIndex / cards.length,
                  backgroundColor: Colors.grey[800],
                  valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFE5A00D)),
                  minHeight: 4.h,
                ),
              ],
            ),
          ),
        ),
      ),
      body: isCompleting
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: Color(0xFFE5A00D)),
                  SizedBox(height: 16),
                  Text(
                    'Creating your perfect movie profile...',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ],
              ),
            )
          : Column(
              children: [
                // Instructions
                Padding(
                  padding: EdgeInsets.all(16.w),
                  child: Column(
                    children: [
                      Text(
                        _getLearningMessage(),
                        style: TextStyle(
                          color: const Color(0xFFE5A00D),
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 8.h),
                      const Text(
                        'Swipe right on movie styles you love, left on ones you don\'t',
                        style: TextStyle(color: Colors.white70, fontSize: 14),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
                
                // Swipe Cards
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                    child: CardSwiper(
                      cardsCount: cards.length,
                      onSwipe: _onSwipe,
                      cardBuilder: (context, index, percentX, percentY) {
                        if (index >= cards.length) return const SizedBox.shrink();
                        
                        final card = cards[index];
                        
                        // Calculate swipe feedback colors
                        final leftIntensity = percentX < 0 ? (-percentX.toDouble()).clamp(0.0, 1.0) : 0.0;
                        final rightIntensity = percentX > 0 ? percentX.toDouble().clamp(0.0, 1.0) : 0.0;
                        
                        return Container(
                          margin: EdgeInsets.all(8.r),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16.r),
                            color: const Color(0xFF1F1F1F),
                            border: Border.all(
                              color: const Color(0xFFE5A00D),
                              width: 2.w,
                            ),
                          ),
                          child: Stack(
                            children: [
                              // Main card content
                              Column(
                                children: [
                                  // Header
                                  Container(
                                    width: double.infinity,
                                    padding: EdgeInsets.all(20.w),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF2A2A2A),
                                      borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(14.r),
                                        topRight: Radius.circular(14.r),
                                      ),
                                    ),
                                    child: Column(
                                      children: [
                                        Text(
                                          card.name,
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 24.sp,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        SizedBox(height: 4.h),
                                        Text(
                                          card.description,
                                          style: TextStyle(
                                            color: const Color(0xFFE5A00D),
                                            fontSize: 14.sp,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  
                                  // Movie grid
                                  Expanded(
                                    child: Padding(
                                      padding: EdgeInsets.all(16.w),
                                      child: GridView.builder(
                                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 2,
                                          childAspectRatio: 0.7,
                                          crossAxisSpacing: 12,
                                          mainAxisSpacing: 12,
                                        ),
                                        itemCount: card.movies.length,
                                        itemBuilder: (context, movieIndex) {
                                          final movie = card.movies[movieIndex];
                                          return ClipRRect(
                                            borderRadius: BorderRadius.circular(8.r),
                                            child: Image.network(
                                              movie.posterUrl,
                                              fit: BoxFit.cover,
                                              errorBuilder: (context, error, stackTrace) {
                                                return Container(
                                                  color: Colors.grey[800],
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      Icon(
                                                        Icons.movie,
                                                        color: Colors.white30,
                                                        size: 32.sp,
                                                      ),
                                                      SizedBox(height: 8.h),
                                                      Padding(
                                                        padding: EdgeInsets.symmetric(horizontal: 8.w),
                                                        child: Text(
                                                          movie.title,
                                                          style: TextStyle(
                                                            color: Colors.white70,
                                                            fontSize: 10.sp,
                                                          ),
                                                          textAlign: TextAlign.center,
                                                          maxLines: 2,
                                                          overflow: TextOverflow.ellipsis,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              },
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              
                              // Swipe feedback overlays
                              if (leftIntensity > 0)
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(14.r),
                                    color: Colors.red.withValues(alpha: 0.3 * leftIntensity),
                                  ),
                                  child: Center(
                                    child: Icon(
                                      Icons.close,
                                      color: Colors.red,
                                      size: 80.sp * leftIntensity,
                                    ),
                                  ),
                                ),
                              
                              if (rightIntensity > 0)
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(14.r),
                                    color: Colors.green.withValues(alpha: 0.3 * rightIntensity),
                                  ),
                                  child: Center(
                                    child: Icon(
                                      Icons.favorite,
                                      color: Colors.green,
                                      size: 80.sp * rightIntensity,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ),
                
                // Bottom instruction
                Padding(
                  padding: EdgeInsets.all(16.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.close, color: Colors.red, size: 20.sp),
                          SizedBox(width: 8.w),
                          const Text('Not for me', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                      Row(
                        children: [
                          Icon(Icons.favorite, color: Colors.green, size: 20.sp),
                          SizedBox(width: 8.w),
                          const Text('Love it!', style: TextStyle(color: Colors.green)),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

class OnboardingCard {
  final String type; // 'genre' or 'vibe'
  final String name;
  final String description;
  final List<Movie> movies;

  OnboardingCard({
    required this.type,
    required this.name,
    required this.description,
    required this.movies,
  });
}