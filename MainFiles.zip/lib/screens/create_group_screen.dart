import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/user_profile.dart';



class CreateGroupScreen extends StatefulWidget {
  final UserProfile currentUser;
  final List<UserProfile> friends;

  const CreateGroupScreen({
    super.key,
    required this.currentUser,
    required this.friends,
  });

  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final TextEditingController _groupNameController = TextEditingController();
  final TextEditingController _groupDescriptionController = TextEditingController();
  final Set<UserProfile> _selectedFriends = {};
  bool _isCreating = false;
  
  Future<void> _saveGroupToFirestore(String groupName, List<UserProfile> selectedFriends) async {
  final groupDoc = FirebaseFirestore.instance.collection('groups').doc();

  final memberUids = [
    widget.currentUser.uid,
    ...selectedFriends.map((f) => f.uid),
  ];

  await groupDoc.set({
    'name': groupName,
    'createdBy': widget.currentUser.uid,
    'members': memberUids,
    'imageUrl': '', // optional for now
  });

  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text('Group "$groupName" created!'),
      backgroundColor: Colors.green,
    ),
  );

  Navigator.pop(context); // exit the screen
}

  // Group privacy options
  String _privacyOption = 'Public';
  final List<String> _privacyOptions = ['Public', 'Private'];
  
  // Group notification preferences
  bool _notificationsEnabled = true;

  @override
  void dispose() {
    _groupNameController.dispose();
    _groupDescriptionController.dispose();
    super.dispose();
  }

  bool get _canCreate =>
      _groupNameController.text.isNotEmpty && _selectedFriends.isNotEmpty;

  void _toggleFriendSelection(UserProfile friend) {
    setState(() {
      if (_selectedFriends.contains(friend)) {
        _selectedFriends.remove(friend);
      } else {
        _selectedFriends.add(friend);
      }
    });
  }

  void _selectAllFriends() {
    setState(() {
      if (_selectedFriends.length == widget.friends.length) {
        // If all are selected, deselect all
        _selectedFriends.clear();
      } else {
        // Otherwise select all friends
        _selectedFriends.addAll(widget.friends);
      }
    });
  }

  void _createGroup() async {
  if (!_canCreate) return;

  setState(() {
    _isCreating = true;
  });

  await _saveGroupToFirestore(_groupNameController.text, _selectedFriends.toList());

  setState(() {
    _isCreating = false;
  });
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text('Create Group'),
      ),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Group details section
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'GROUP DETAILS',
                      style: TextStyle(
                        color: Colors.white70, 
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    // Group image placeholder
                    Center(
                      child: Stack(
                        children: [
                          CircleAvatar(
                            radius: 50,
                            backgroundColor: Colors.grey[800],
                            child: const Icon(
                              Icons.group,
                              size: 50,
                              color: Colors.white54,
                            ),
                          ),
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: CircleAvatar(
                              radius: 18,
                              backgroundColor: const Color(0xFFE5A00D),
                              child: IconButton(
                                icon: const Icon(
                                  Icons.camera_alt,
                                  size: 18,
                                  color: Colors.white,
                                ),
                                onPressed: () {
                                  // Would handle image selection
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('Group image upload would be implemented here'),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Group name input
                    TextField(
                      controller: _groupNameController,
                      decoration: InputDecoration(
                        labelText: 'Group Name',
                        labelStyle: const TextStyle(color: Colors.white70),
                        hintText: 'Enter a name for your group',
                        hintStyle: const TextStyle(color: Colors.white30),
                        filled: true,
                        fillColor: const Color(0xFF1F1F1F),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                        prefixIcon: const Icon(Icons.group, color: Colors.white70),
                      ),
                      style: const TextStyle(color: Colors.white),
                      onChanged: (_) => setState(() {}), // Refresh to update _canCreate
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Group description input
                    TextField(
                      controller: _groupDescriptionController,
                      decoration: InputDecoration(
                        labelText: 'Description (Optional)',
                        labelStyle: const TextStyle(color: Colors.white70),
                        hintText: 'What kind of movies does this group like?',
                        hintStyle: const TextStyle(color: Colors.white30),
                        filled: true,
                        fillColor: const Color(0xFF1F1F1F),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                        prefixIcon: const Icon(Icons.description, color: Colors.white70),
                      ),
                      style: const TextStyle(color: Colors.white),
                      maxLines: 2,
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Group privacy settings
                    const Text(
                      'PRIVACY',
                      style: TextStyle(
                        color: Colors.white70, 
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    
                    // Privacy toggle
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1F1F1F),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: _privacyOption,
                          isExpanded: true,
                          dropdownColor: const Color(0xFF1F1F1F),
                          icon: const Icon(Icons.arrow_drop_down, color: Colors.white70),
                          items: _privacyOptions.map((String item) {
                            return DropdownMenuItem(
                              value: item,
                              child: Row(
                                children: [
                                  Icon(
                                    item == 'Public' ? Icons.public : Icons.lock,
                                    color: Colors.white70,
                                    size: 20,
                                  ),
                                  const SizedBox(width: 12),
                                  Text(
                                    item,
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            if (newValue != null) {
                              setState(() {
                                _privacyOption = newValue;
                              });
                            }
                          },
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 12),
                    
                    // Help text for privacy setting
                    Text(
                      _privacyOption == 'Public' 
                          ? 'Anyone will be able to find and join this group'
                          : 'Only people you invite can join this group',
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 12,
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Notifications toggle
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1F1F1F),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                Icons.notifications,
                                color: Colors.white70,
                                size: 20,
                              ),
                              const SizedBox(width: 12),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Group Notifications',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                  Text(
                                    'Get notified about matches and activities',
                                    style: TextStyle(color: Colors.white54, fontSize: 12),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Switch(
                            value: _notificationsEnabled,
                            onChanged: (value) {
                              setState(() {
                                _notificationsEnabled = value;
                              });
                            },
                            activeColor: const Color(0xFFE5A00D),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              
              const Divider(color: Colors.white12),

              // Selected friends count and selection
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'ADD FRIENDS (${_selectedFriends.length}/${widget.friends.length})',
                      style: const TextStyle(
                        color: Colors.white70, 
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    TextButton.icon(
                      onPressed: _selectAllFriends,
                      icon: Icon(
                        _selectedFriends.length == widget.friends.length
                            ? Icons.deselect
                            : Icons.select_all,
                        color: const Color(0xFFE5A00D),
                        size: 18,
                      ),
                      label: Text(
                        _selectedFriends.length == widget.friends.length
                            ? 'Deselect All'
                            : 'Select All',
                        style: const TextStyle(
                          color: Color(0xFFE5A00D),
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Friends list
              widget.friends.isEmpty
                  ? const Padding(
                      padding: EdgeInsets.all(24),
                      child: Center(
                        child: Text(
                          'You have no friends to add to a group',
                          style: TextStyle(color: Colors.white54),
                        ),
                      ),
                    )
                  : Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        padding: EdgeInsets.zero,
                        itemCount: widget.friends.length,
                        itemBuilder: (context, index) {
                          final friend = widget.friends[index];
                          final isSelected = _selectedFriends.contains(friend);

                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            color: isSelected
                                ? const Color(0xFF1F1F1F)
                                : Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(
                                color: isSelected
                                    ? const Color(0xFFE5A00D)
                                    : Colors.white12,
                                width: isSelected ? 2 : 1,
                              ),
                            ),
                            child: InkWell(
                              onTap: () => _toggleFriendSelection(friend),
                              borderRadius: BorderRadius.circular(12),
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Row(
                                  children: [
                                    // Friend avatar
                                    CircleAvatar(
                                      radius: 20,
                                      backgroundColor: Colors.grey[800],
                                      child: Text(
                                        friend.name.isNotEmpty
                                            ? friend.name[0].toUpperCase()
                                            : "?",
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 16),
                                    // Friend name
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            friend.name,
                                            style: TextStyle(
                                              color: isSelected
                                                  ? Colors.white
                                                  : Colors.white70,
                                              fontSize: 16,
                                              fontWeight: isSelected
                                                  ? FontWeight.bold
                                                  : FontWeight.normal,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            'Likes: ${friend.preferredGenres.join(", ")}',
                                            style: const TextStyle(
                                              color: Colors.white54,
                                              fontSize: 12,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                    // Checkbox
                                    Checkbox(
                                      value: isSelected,
                                      onChanged: (_) =>
                                          _toggleFriendSelection(friend),
                                      activeColor: const Color(0xFFE5A00D),
                                      checkColor: Colors.black,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
              
              const SizedBox(height: 100), // Space for the bottom button
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        color: const Color(0xFF1F1F1F),
        child: ElevatedButton(
          onPressed: _canCreate && !_isCreating ? _createGroup : null,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFE5A00D),
            disabledBackgroundColor: Colors.grey,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: _isCreating
              ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : const Text(
                  'Create Group',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
        ),
      ),
    );
  }
}