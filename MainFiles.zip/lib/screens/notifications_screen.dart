import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/user_profile.dart';
import '../movie.dart';
import 'movie_detail_screen.dart';
import 'package:collection/collection.dart';


class NotificationsScreen extends StatefulWidget {
  final UserProfile currentUser;
  final List<Movie> allMovies;

  const NotificationsScreen({
    super.key,
    required this.currentUser,
    required this.allMovies,
  });

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<Map<String, dynamic>> _notifications = [];

  @override
  void initState() {
    super.initState();
    _loadNotifications();
  }

  Future<void> _loadNotifications() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.currentUser.uid)
        .collection('notifications')
        .orderBy('timestamp', descending: true)
        .get();

    setState(() {
      _notifications = snapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'title': data['title'] ?? '',
          'message': data['message'] ?? '',
          'movieId': data['movieId'],
          'timestamp': data['timestamp'],
          'read': data['read'] ?? false,
        };
      }).toList();
    });

    // Mark all as read
    for (final doc in snapshot.docs) {
      if (!(doc.data()['read'] ?? false)) {
        doc.reference.update({'read': true});
      }
    }
  }

  Future<void> _openMovieDetails(String movieId) async {
    final movie = widget.allMovies.firstWhereOrNull((m) => m.id == movieId);

    if (movie == null) {
      print("⚠️ Movie not found.");
      return;
    }

    showMovieDetails(
      context: context,
      movie: movie,
      currentUser: widget.currentUser,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Notifications')),
      body: _notifications.isEmpty
          ? Center(child: Text("You're all caught up!", style: TextStyle(fontSize: 16.sp)))
          : ListView.builder(
              itemCount: _notifications.length,
              itemBuilder: (context, index) {
                final note = _notifications[index];
                return ListTile(
                  leading: Icon(note['read'] ? Icons.notifications : Icons.notifications_active),
                  title: Text(note['title']),
                  subtitle: Text(note['message']),
                  trailing: note['movieId'] != null
                      ? Icon(Icons.chevron_right)
                      : null,
                  onTap: note['movieId'] != null
                      ? () => _openMovieDetails(note['movieId'])
                      : null,
                );
              },
            ),
    );
  }
}