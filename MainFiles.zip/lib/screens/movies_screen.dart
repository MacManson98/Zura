import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/user_profile.dart';
import '../movie.dart';
import '../utils/tmdb_api.dart';
import '../utils/enhanced_learning_engine.dart';
import '../utils/movie_loader.dart';
import 'movie_detail_screen.dart';
import 'dart:async';
import '../services/firestore_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:math';

class MoviesScreen extends StatefulWidget {
  final UserProfile? currentUser;

  const MoviesScreen({
    super.key, 
    required this.currentUser,
  });

  @override
  State<MoviesScreen> createState() => _MoviesScreenState();
}

class _MoviesScreenState extends State<MoviesScreen> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late TabController _tabController;
  final FirestoreService _firestoreService = FirestoreService();
  
  // Matches Tab Variables (unchanged)
  List<Map<String, dynamic>> _matchHistory = [];
  final ScrollController _matchesScrollController = ScrollController();
  int _matchesPerPage = 10;
  int _currentMatchesPage = 0;
  List<Map<String, dynamic>> _visibleMatches = [];
  bool _isLoadingMoreMatches = false;
  bool _filterWatched = false;
  bool _filterUnwatched = false;
  bool _filterArchived = false;
  String _sortOrder = 'newest';
  Set<String> _selectedFriends = {};
  Set<String> _selectedGroups = {};

  // Discover Tab Variables
  List<Movie> _movieDatabase = [];
  List<Movie> _personalizedRecommendations = [];
  List<Movie> _trendingMovies = [];
  List<Movie> _becauseYouLiked = [];
  Map<String, List<Movie>> _genreDeepDives = {};
  bool _isLoadingDiscover = true;
  bool _isRefreshingDiscover = false;
  String? _selectedGenreForDeepDive;
  
  // Quick swipe functionality
  Set<String> _quickLikedMovieIds = {};
  Set<String> _quickPassedMovieIds = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(_handleTabChange);
    _matchHistory = widget.currentUser?.matchHistory ?? [];
    
    _initializeArchiveFields();
    _loadInitialMatchesPage();
    _matchesScrollController.addListener(_matchScrollListener);
    
    // Load discover content
    _loadDiscoverContent();
    
    // Add lifecycle observer
    WidgetsBinding.instance.addObserver(this);
  }

  // Load all discover content
  Future<void> _loadDiscoverContent() async {
    if (!mounted) return;
    
    setState(() => _isLoadingDiscover = true);
    
    try {
      // Load movie database first
      _movieDatabase = await MovieDatabaseLoader.loadMovieDatabase();
      
      // Load all sections in parallel for better performance
      await Future.wait([
        _loadPersonalizedRecommendations(),
        _loadTrendingMovies(),
        _loadBecauseYouLiked(),
        _loadGenreDeepDives(),
      ]);
    } catch (e) {
      print("❌ Error loading discover content: $e");
    } finally {
      if (mounted) {
        setState(() => _isLoadingDiscover = false);
      }
    }
  }

  // Load personalized recommendations using Enhanced Learning Engine
  Future<void> _loadPersonalizedRecommendations() async {
    if (widget.currentUser == null || _movieDatabase.isEmpty) return;
    
    try {
      final seenMovieIds = <String>{
        ...widget.currentUser!.likedMovieIds,
        ...widget.currentUser!.passedMovieIds,
        ..._quickLikedMovieIds,
        ..._quickPassedMovieIds,
      };
      
      final recommendations = await EnhancedLearningEngine.generatePersonalizedSession(
        user: widget.currentUser!,
        movieDatabase: _movieDatabase,
        seenMovieIds: seenMovieIds,
        sessionSize: 20,
      );
      
      if (mounted) {
        setState(() {
          _personalizedRecommendations = recommendations;
        });
      }
    } catch (e) {
      print("❌ Error loading personalized recommendations: $e");
    }
  }

  // Load trending movies from TMDB
  Future<void> _loadTrendingMovies() async {
    try {
      final trending = await TMDBApi.getPopularMovies();
      if (mounted) {
        setState(() {
          _trendingMovies = trending.take(20).toList();
        });
      }
    } catch (e) {
      print("❌ Error loading trending movies: $e");
    }
  }

  // Load "Because you liked..." recommendations
  Future<void> _loadBecauseYouLiked() async {
    if (widget.currentUser == null || widget.currentUser!.likedMovies.isEmpty) return;
    
    try {
      // Pick a random recently liked movie
      final recentLikes = widget.currentUser!.likedMovies.toList();
      if (recentLikes.isEmpty) return;
      
      recentLikes.shuffle();
      final referenceMovie = recentLikes.first;
      
      // Find similar movies in the database
      final similarMovies = _movieDatabase.where((movie) {
        if (movie.id == referenceMovie.id) return false;
        if (widget.currentUser!.likedMovieIds.contains(movie.id)) return false;
        
        // Check for genre overlap
        final sharedGenres = movie.genres.toSet().intersection(referenceMovie.genres.toSet());
        final sharedVibes = movie.tags.toSet().intersection(referenceMovie.tags.toSet());
        
        return sharedGenres.isNotEmpty || sharedVibes.isNotEmpty;
      }).toList();
      
      // Sort by similarity score
      similarMovies.sort((a, b) {
        final aScore = _calculateSimilarityScore(a, referenceMovie);
        final bScore = _calculateSimilarityScore(b, referenceMovie);
        return bScore.compareTo(aScore);
      });
      
      if (mounted) {
        setState(() {
          _becauseYouLiked = similarMovies.take(15).toList();
          // Store reference movie for display
          if (_becauseYouLiked.isNotEmpty) {
            _becauseYouLiked.insert(0, referenceMovie); // First item is the reference
          }
        });
      }
    } catch (e) {
      print("❌ Error loading similar movies: $e");
    }
  }

  double _calculateSimilarityScore(Movie movie1, Movie movie2) {
    double score = 0;
    
    // Genre similarity
    final sharedGenres = movie1.genres.toSet().intersection(movie2.genres.toSet());
    score += sharedGenres.length * 3.0;
    
    // Vibe similarity
    final sharedVibes = movie1.tags.toSet().intersection(movie2.tags.toSet());
    score += sharedVibes.length * 2.0;
    
    // Runtime similarity
    if (movie1.runtime != null && movie2.runtime != null) {
      final runtimeDiff = (movie1.runtime! - movie2.runtime!).abs();
      if (runtimeDiff < 30) score += 1.0;
    }
    
    // Rating similarity
    if (movie1.rating != null && movie2.rating != null) {
      final ratingDiff = (movie1.rating! - movie2.rating!).abs();
      if (ratingDiff < 1.0) score += 1.0;
    }
    
    return score;
  }

  // Load genre deep dives based on user preferences
  Future<void> _loadGenreDeepDives() async {
    if (widget.currentUser == null) return;
    
    try {
      // Get user's top genres
      final topGenres = widget.currentUser!.genreScores.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));
      
      // Load movies for top 3 genres
      for (int i = 0; i < min(3, topGenres.length); i++) {
        final genre = topGenres[i].key;
        final genreMovies = MovieDatabaseLoader.getMoviesByGenres(
          _movieDatabase,
          [genre],
          limit: 20,
        ).where((movie) => !widget.currentUser!.likedMovieIds.contains(movie.id)).toList();
        
        if (genreMovies.isNotEmpty) {
          _genreDeepDives[genre] = genreMovies;
        }
      }
      
      if (mounted) setState(() {});
    } catch (e) {
      print("❌ Error loading genre deep dives: $e");
    }
  }

  // Handle tab changes
  void _handleTabChange() {
    if (_tabController.index == 0) {
      _checkForNewMatches();
    } else if (_tabController.index == 1 && _personalizedRecommendations.isEmpty) {
      _loadDiscoverContent();
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasActiveFilters = _filterWatched || _filterUnwatched || _filterArchived ||
                           _sortOrder != 'newest' || 
                           _selectedFriends.isNotEmpty || 
                           _selectedGroups.isNotEmpty;

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: const Color(0xFF121212),
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: const Color(0xFF1F1F1F),
          title: const Text("Movies", style: TextStyle(fontWeight: FontWeight.bold)),
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: const Color(0xFFE5A00D),
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: const [
              Tab(text: "MATCHES"),
              Tab(text: "DISCOVER"),
            ],
          ),
        ),
        body: Column(
          children: [
            // Filter bar for matches tab (unchanged)
            if (_tabController.index == 0)
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                color: const Color(0xFF1A1A1A),
                child: Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: _showFilterOptions,
                        borderRadius: BorderRadius.circular(8.r),
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
                          decoration: BoxDecoration(
                            color: const Color(0xFF2A2A2A),
                            borderRadius: BorderRadius.circular(8.r),
                            border: Border.all(
                              color: hasActiveFilters 
                                  ? const Color(0xFFE5A00D) 
                                  : Colors.transparent,
                              width: 1.w,
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                _filterArchived ? Icons.archive : Icons.filter_list, 
                                color: hasActiveFilters 
                                    ? const Color(0xFFE5A00D) 
                                    : Colors.white70,
                                size: 20.sp,
                              ),
                              SizedBox(width: 8.w),
                              Expanded(
                                child: Text(
                                  hasActiveFilters 
                                      ? _getActiveFiltersText() 
                                      : "Filter Matches",
                                  style: TextStyle(
                                    color: hasActiveFilters 
                                        ? const Color(0xFFE5A00D) 
                                        : Colors.white70,
                                    fontSize: 14.sp,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              if (hasActiveFilters)
                                Icon(
                                  Icons.check_circle, 
                                  color: const Color(0xFFE5A00D),
                                  size: 18.sp,
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    
                    SizedBox(width: 8.w),
                    InkWell(
                      onTap: _showSortOptions,
                      borderRadius: BorderRadius.circular(8.r),
                      child: Container(
                        padding: EdgeInsets.all(10.w),
                        decoration: BoxDecoration(
                          color: const Color(0xFF2A2A2A),
                          borderRadius: BorderRadius.circular(8.r),
                          border: Border.all(
                            color: _sortOrder != 'newest' 
                                ? const Color(0xFFE5A00D) 
                                : Colors.transparent,
                            width: 1.w,
                          ),
                        ),
                        child: Icon(
                          _sortOrder == 'newest' ? Icons.arrow_downward : Icons.arrow_upward,
                          color: _sortOrder != 'newest' 
                              ? const Color(0xFFE5A00D) 
                              : Colors.white70,
                          size: 20.sp,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  // Matches Tab (unchanged)
                  _buildMatchesTab(),
                  
                  // New Discover Tab
                  _buildDiscoverTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Build the new Discover tab
  Widget _buildDiscoverTab() {
    if (_isLoadingDiscover) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Color(0xFFE5A00D)),
            SizedBox(height: 16.h),
            Text(
              "Discovering movies for you...",
              style: TextStyle(color: Colors.white70, fontSize: 16.sp),
            ),
          ],
        ),
      );
    }
    
    return RefreshIndicator(
      color: Color(0xFFE5A00D),
      backgroundColor: Color(0xFF1F1F1F),
      onRefresh: () async {
        setState(() => _isRefreshingDiscover = true);
        await _loadDiscoverContent();
        setState(() => _isRefreshingDiscover = false);
      },
      child: SingleChildScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_isRefreshingDiscover)
              Padding(
                padding: EdgeInsets.symmetric(vertical: 24.h),
                child: Center(
                  child: CircularProgressIndicator(color: Color(0xFFE5A00D)),
                ),
              ),
            if (_personalizedRecommendations.isNotEmpty)
              _buildSection(
                title: "Perfect For You",
                subtitle: "Based on your unique taste",
                icon: Icons.auto_awesome,
                movies: _personalizedRecommendations,
                showQuickActions: true,
              ),
            // Because You Liked Section
            if (_becauseYouLiked.length > 1)
              _buildBecauseYouLikedSection(),
            
            // Trending Now Section
            if (_trendingMovies.isNotEmpty)
              _buildSection(
                title: "Trending Now",
                subtitle: "Popular movies this week",
                icon: Icons.trending_up,
                movies: _trendingMovies,
                showQuickActions: true,
              ),
            
            // Genre Deep Dives
            ..._genreDeepDives.entries.map((entry) => 
              _buildSection(
                title: "More ${entry.key} Movies",
                subtitle: "Explore your favorite genre",
                icon: Icons.category,
                movies: entry.value,
                showQuickActions: true,
              ),
            ).toList(),
            
            // Discovery Mode Toggle
            _buildDiscoveryModeSection(),
            
            SizedBox(height: 32.h),
          ],
        ),
      ),
    );
  }

  // Build a movie section
  Widget _buildSection({
    required String title,
    required String subtitle,
    required IconData icon,
    required List<Movie> movies,
    bool showQuickActions = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(16.w, 24.h, 16.w, 12.h),
          child: Row(
            children: [
              Icon(icon, color: Color(0xFFE5A00D), size: 24.sp),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (subtitle.isNotEmpty)
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 14.sp,
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        SizedBox(
          height: showQuickActions ? 280.h : 220.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            itemCount: movies.length,
            itemBuilder: (context, index) {
              final movie = movies[index];
              return _buildDiscoveryCard(movie, showQuickActions);
            },
          ),
        ),
      ],
    );
  }

  // Build discovery movie card with quick actions
  Widget _buildDiscoveryCard(Movie movie, bool showQuickActions) {
    final isLiked = widget.currentUser?.likedMovieIds.contains(movie.id) ?? false;
    final isPassed = _quickPassedMovieIds.contains(movie.id) || 
                     (widget.currentUser?.passedMovieIds.contains(movie.id) ?? false);
    
    if (isPassed) return SizedBox.shrink(); // Hide passed movies
    
    return Container(
      width: 140.w,
      margin: EdgeInsets.only(right: 12.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Movie poster with overlay
          Stack(
            children: [
              // Poster image
              GestureDetector(
                onTap: () => _showMovieDetails(movie),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12.r),
                  child: Container(
                    height: showQuickActions ? 180.h : 200.h,
                    decoration: BoxDecoration(color: Colors.grey[800]),
                    child: Image.network(
                      movie.posterUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Center(
                        child: Icon(Icons.movie, color: Colors.white30, size: 40.sp),
                      ),
                    ),
                  ),
                ),
              ),

              // 🔳 Bottom gradient overlay
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  height: 40.h,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withValues(alpha: 0.6),
                      ],
                    ),
                    borderRadius: BorderRadius.vertical(bottom: Radius.circular(12.r)),
                  ),
                ),
              ),

              // ⭐ Rating badge (top-right)
              if (movie.rating != null)
                Positioned(
                  top: 8.h,
                  right: 8.w,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.7),
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star, color: Color(0xFFE5A00D), size: 14.sp),
                        SizedBox(width: 2.w),
                        Text(
                          movie.rating!.toStringAsFixed(1),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              // ❤️ Liked icon (optional)
              if (isLiked)
                Positioned(
                  top: 8.h,
                  left: 8.w,
                  child: Container(
                    padding: EdgeInsets.all(6.w),
                    decoration: BoxDecoration(
                      color: Colors.green,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.favorite, color: Colors.white, size: 16.sp),
                  ),
                ),
            ],
          ),

          SizedBox(height: 8.h),

          // Movie title
          Text(
            movie.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white,
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
            ),
          ),

          // ✉️ Inline "Send" action
          Padding(
            padding: EdgeInsets.only(top: 4.h),
            child: GestureDetector(
              onTap: () => _showSendToFriendDialog(movie),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
                decoration: BoxDecoration(
                  color: Color(0xFFE5A00D).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(30.r),
                  border: Border.all(
                    color: Color(0xFFE5A00D),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.send_rounded, size: 14.sp, color: Color(0xFFE5A00D)),
                    SizedBox(width: 6.w),
                    Text(
                      "Send",
                      style: TextStyle(
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w500,
                        color: Color(0xFFE5A00D),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showSendToFriendDialog(Movie movie) async {
    if (widget.currentUser == null || widget.currentUser!.friendIds.isEmpty) return;

    try {
      final friendDocs = await Future.wait(
        widget.currentUser!.friendIds.map((id) {
          return FirebaseFirestore.instance.collection('users').doc(id).get();
        }),
      );

      final friends = friendDocs
          .where((doc) => doc.exists)
          .map((doc) {
            final data = doc.data()!;
            return {
              'id': doc.id,
              'name': data['name'] ?? 'Friend',
            };
          })
          .toList();

      showModalBottomSheet(
        context: context,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        builder: (context) {
          return Container(
            padding: EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Send to a friend',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 12),
                ...friends.map((friend) {
                  return ListTile(
                    leading: Icon(Icons.person),
                    title: Text(friend['name']),
                    onTap: () async {
                      Navigator.pop(context);
                      await _sendMovieToFriend(movie, friend['id'], friend['name']);
                    },
                  );
                }).toList(),
              ],
            ),
          );
        },
      );
    } catch (e) {
      print('Failed to load friends: $e');
    }
  }


  Future<void> _sendMovieToFriend(Movie movie, String friendId, String friendName) async {
    try {
      final suggestionRef = FirebaseFirestore.instance
          .collection('users')
          .doc(friendId)
          .collection('incomingSuggestions')
          .doc(movie.id);

      await suggestionRef.set({
        'movieId': movie.id,
        'fromUserId': widget.currentUser!.uid,
        'fromUserName': widget.currentUser!.name,
        'timestamp': DateTime.now(),
      });

      // Send a general notification to their notifications collection
      await _firestoreService.sendNotification(
        toUserId: friendId,
        type: 'suggestion',
        title: '${widget.currentUser!.name} sent you a movie!',
        message: 'They think you’d enjoy "${movie.title}".',
        movieId: movie.id,
        fromUserId: widget.currentUser!.uid,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Sent to $friendName!')),
      );
    } catch (e) {
      print('Failed to send suggestion: $e');
    }
  }




  // Build "Because You Liked" section
  Widget _buildBecauseYouLikedSection() {
    final referenceMovie = _becauseYouLiked.first;
    final similarMovies = _becauseYouLiked.skip(1).toList();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(16.w, 24.h, 16.w, 12.h),
          child: Row(
            children: [
              // Small poster of reference movie
              ClipRRect(
                borderRadius: BorderRadius.circular(6.r),
                child: Image.network(
                  referenceMovie.posterUrl,
                  width: 40.w,
                  height: 60.h,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    width: 40.w,
                    height: 60.h,
                    color: Colors.grey[800],
                    child: Icon(Icons.movie, size: 20.sp, color: Colors.white30),
                  ),
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Because you liked",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14.sp,
                      ),
                    ),
                    Text(
                      referenceMovie.title,
                      style: TextStyle(
                        color: Color(0xFFE5A00D),
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        SizedBox(
          height: 280.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            itemCount: similarMovies.length,
            itemBuilder: (context, index) {
              return _buildDiscoveryCard(similarMovies[index], true);
            },
          ),
        ),
      ],
    );
  }

  // Build discovery mode section
  Widget _buildDiscoveryModeSection() {
    return Container(
      margin: EdgeInsets.fromLTRB(16.w, 24.h, 16.w, 0),
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xFF1F1F1F),
            Color(0xFF2A2A2A),
          ],
        ),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: Color(0xFFE5A00D).withValues(alpha: 0.3),
          width: 1.w,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.explore, color: Color(0xFFE5A00D), size: 24.sp),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Discovery Mode",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "Find movies outside your comfort zone",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14.sp,
                      ),
                    ),
                  ],
                ),
              ),
              Switch(
                value: widget.currentUser?.discoveryModeEnabled ?? false,
                onChanged: (value) {
                  setState(() {
                    widget.currentUser?.discoveryModeEnabled = value;
                  });
                  _firestoreService.updateUserProfile(widget.currentUser!);
                  
                  if (value) {
                    _loadDiscoverContent(); // Refresh with more diverse content
                  }
                },
                activeColor: Color(0xFFE5A00D),
              ),
            ],
          ),
          
          if (widget.currentUser?.genresToExplore.isNotEmpty ?? false) ...[
            SizedBox(height: 16.h),
            Text(
              "Unexplored genres:",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 14.sp,
              ),
            ),
            SizedBox(height: 8.h),
            Wrap(
              spacing: 8.w,
              runSpacing: 8.h,
              children: widget.currentUser!.genresToExplore.take(5).map((genre) {
                final bool isSelected = _selectedGenreForDeepDive == genre;

                return GestureDetector(
                  onTap: () {
                    setState(() => _selectedGenreForDeepDive = genre);
                    _loadGenreDeepDive(genre);
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? Color(0xFFE5A00D)
                          : Color(0xFFE5A00D).withAlpha(40),
                      borderRadius: BorderRadius.circular(20.r),
                      border: Border.all(
                        color: isSelected
                            ? Color(0xFFE5A00D)
                            : Color(0xFFE5A00D).withAlpha(120),
                        width: 1.w,
                      ),
                    ),
                    child: Text(
                      genre,
                      style: TextStyle(
                        color: isSelected ? Colors.black : Color(0xFFE5A00D),
                        fontSize: 14.sp,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ],
      ),
    );
  }

  // Load specific genre deep dive
  Future<void> _loadGenreDeepDive(String genre) async {
    final genreMovies = MovieDatabaseLoader.getMoviesByGenres(
      _movieDatabase,
      [genre],
      limit: 20,
    );
    
    if (genreMovies.isNotEmpty) {
      setState(() {
        _genreDeepDives[genre] = genreMovies;
      });
    }
  }

  // Show movie details
  void _showMovieDetails(Movie movie) {
    final isInFavorites = widget.currentUser?.likedMovieIds.contains(movie.id) ?? false;
    
    showMovieDetails(
      context: context,
      movie: movie,
      currentUser: widget.currentUser!,
      isInFavorites: isInFavorites,
      onAddToFavorites: !isInFavorites ? (Movie movie) {
        setState(() {
          widget.currentUser!.likedMovieIds.add(movie.id);
          widget.currentUser!.likedMovies.add(movie);
        });
        
        EnhancedLearningEngine.learnFromLikedMovie(widget.currentUser!, movie);
        _firestoreService.updateUserProfile(widget.currentUser!);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${movie.title} added to likes'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
        
        // Refresh recommendations
        _loadPersonalizedRecommendations();
      } : null,
      onRemoveFromFavorites: isInFavorites ? (Movie movie) {
        setState(() {
          widget.currentUser!.likedMovieIds.remove(movie.id);
          widget.currentUser!.likedMovies.removeWhere((m) => m.id == movie.id);
        });
        
        _firestoreService.updateUserProfile(widget.currentUser!);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${movie.title} removed from likes'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 2),
          ),
        );
      } : null,
    );
  }

  // ===================== MATCHES TAB CODE (UNCHANGED) =====================
  
  Widget _buildMatchesTab() {
    if (_matchHistory.isEmpty) {
      return _buildEmptyState(
        icon: Icons.movie_filter,
        message: "No matches yet",
        subMessage: "Movies you match with friends will appear here"
      );
    }
    
    if (_visibleMatches.isEmpty && !_isLoadingDiscover) {
      return _buildEmptyState(
        icon: _filterArchived ? Icons.archive : Icons.filter_alt_off,
        message: _filterArchived ? "No archived matches" : "No matches match your filters",
        subMessage: _filterArchived 
            ? "Archived matches will appear here when you archive them"
            : "Try adjusting your filter settings"
      );
    }
    
    return Column(
      children: [
        if (_filterArchived && _visibleMatches.isNotEmpty)
          Container(
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
            color: const Color(0xFF1A1A1A),
            child: Row(
              children: [
                Icon(Icons.archive, color: Colors.orange, size: 20.sp),
                SizedBox(width: 8.w),
                Text(
                  "Archive (${_visibleMatches.length} items)",
                  style: TextStyle(
                    color: Colors.orange,
                    fontSize: 14.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                TextButton.icon(
                  onPressed: () {
                    _bulkArchiveMatches(true);
                  },
                  icon: Icon(Icons.unarchive, color: Colors.green, size: 16.sp),
                  label: Text(
                    "Restore All",
                    style: TextStyle(color: Colors.green, fontSize: 12.sp),
                  ),
                ),
              ],
            ),
          ),
        
        Expanded(
          child: ListView.builder(
            controller: _matchesScrollController,
            padding: EdgeInsets.all(16.w),
            itemCount: _visibleMatches.length + (_isLoadingMoreMatches ? 1 : 0),
            itemBuilder: (context, index) {
              if (index == _visibleMatches.length) {
                return Center(
                  child: Padding(
                    padding: EdgeInsets.all(16.w),
                    child: const CircularProgressIndicator(
                      color: Color(0xFFE5A00D),
                    ),
                  ),
                );
              }
              
              final match = _visibleMatches[index];
              return _buildMatchCard(match, _getOriginalIndex(match));
            },
          ),
        ),
      ],
    );
  }
  // [Include all the remaining methods from the original matches_screen.dart here]
  // Including: _buildMatchCard, _buildEmptyState, _showFilterOptions, _showSortOptions,
  // _toggleWatched, _toggleArchived, etc.
  // These remain exactly the same as in the original file

  // ... [All other match-related methods from original file] ...

  // ===================== MATCH TAB HELPER METHODS =====================

  Widget _buildSortOption({
    required String title, 
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12.h),
        child: Row(
          children: [
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 16.sp,
              ),
            ),
            const Spacer(),
            if (isSelected)
              Icon(
                Icons.check_circle,
                color: const Color(0xFFE5A00D),
                size: 20.sp,
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip({
    required String label,
    required bool selected,
    required Function(bool) onSelected,
  }) {
    return FilterChip(
      label: Text(label),
      selected: selected,
      onSelected: onSelected,
      selectedColor: const Color(0xFFE5A00D),
      backgroundColor: Colors.black,
      checkmarkColor: Colors.black,
      labelStyle: TextStyle(
        color: selected ? Colors.black : Colors.white,
        fontSize: 14.sp,
      ),
    );
  }
  
  void _checkForNewMatches() {
    final currentMatchHistory = widget.currentUser?.matchHistory ?? [];
    
    if (currentMatchHistory.length != _matchHistory.length) {
      final newMatches = currentMatchHistory.length - _matchHistory.length;
      print("🔄 Found $newMatches new matches, refreshing...");
      
      setState(() {
        _matchHistory = List.from(currentMatchHistory);
        _initializeArchiveFields();
      });
      
      _loadInitialMatchesPage();
      
      if (newMatches > 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$newMatches new match${newMatches > 1 ? 'es' : ''} found!'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  void _initializeArchiveFields() {
    bool hasChanges = false;
    for (var match in _matchHistory) {
      if (!match.containsKey('archived')) {
        match['archived'] = false;
        match['archivedDate'] = null;
        hasChanges = true;
      }
    }
    if (hasChanges) {
      _saveProfile();
    }
  }

  void _loadInitialMatchesPage() {
    setState(() {
      _currentMatchesPage = 0;
      final allFilteredMatches = _getFilteredMatches();
      _visibleMatches = allFilteredMatches.take(_matchesPerPage).toList();
    });
  }

  void _matchScrollListener() {
    if (_matchesScrollController.position.pixels >= 
        _matchesScrollController.position.maxScrollExtent - 200 &&
        !_isLoadingMoreMatches) {
      _loadMoreMatches();
    }
  }

  void _loadMoreMatches() {
    if (_isLoadingMoreMatches) return;
    
    setState(() {
      _isLoadingMoreMatches = true;
    });
    
    Future.delayed(const Duration(milliseconds: 300), () {
      if (!mounted) return;
      
      final allFilteredMatches = _getFilteredMatches();
      final nextPage = _currentMatchesPage + 1;
      final startIndex = nextPage * _matchesPerPage;
      
      if (startIndex >= allFilteredMatches.length) {
        setState(() {
          _isLoadingMoreMatches = false;
        });
        return;
      }
      
      final endIndex = (startIndex + _matchesPerPage) > allFilteredMatches.length
          ? allFilteredMatches.length
          : startIndex + _matchesPerPage;
          
      final nextPageItems = allFilteredMatches.sublist(startIndex, endIndex);
      
      setState(() {
        _visibleMatches.addAll(nextPageItems);
        _currentMatchesPage = nextPage;
        _isLoadingMoreMatches = false;
      });
    });
  }

  List<Map<String, dynamic>> _getFilteredMatches() {
    List<Map<String, dynamic>> filteredMatches = _matchHistory.where((match) {
      final bool isArchived = match['archived'] ?? false;
      
      if (_filterArchived) {
        if (!isArchived) return false;
      } else {
        if (isArchived) return false;
      }
      
      if (_filterWatched && !(match['watched'] ?? false)) {
        return false;
      }
      
      if (_filterUnwatched && (match['watched'] ?? false)) {
        return false;
      }
      
      if (_selectedFriends.isNotEmpty && !_selectedFriends.contains(match['username'])) {
        return false;
      }
      
      if (_selectedGroups.isNotEmpty && 
          (match['groupName'] == null || !_selectedGroups.contains(match['groupName']))) {
        return false;
      }
      
      return true;
    }).toList();
    
    filteredMatches.sort((a, b) {
      if (_sortOrder == 'newest') {
        return b['matchDate'].compareTo(a['matchDate']);
      } else {
        return a['matchDate'].compareTo(b['matchDate']);
      }
    });
    
    return filteredMatches;
  }

  int _getOriginalIndex(Map<String, dynamic> match) {
    return _matchHistory.indexWhere((m) => 
      m['movieTitle'] == match['movieTitle'] && 
      m['username'] == match['username'] &&
      m['matchDate'] == match['matchDate']
    );
  }

  void _toggleWatched(int index) {
    setState(() {
      final match = _matchHistory[index];
      match['watched'] = !match['watched'];
      match['watchedDate'] = match['watched'] ? DateTime.now() : null;
    });
    
    _saveProfile();
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _matchHistory[index]['watched'] 
              ? '${_matchHistory[index]['movieTitle']} marked as watched'
              : '${_matchHistory[index]['movieTitle']} marked as unwatched'
        ),
        duration: const Duration(seconds: 2),
        backgroundColor: _matchHistory[index]['watched'] ? Colors.green : Colors.grey,
      ),
    );
  }

  void _toggleArchived(int index) {
    final match = _matchHistory[index];
    final bool wasArchived = match['archived'] ?? false;
    
    setState(() {
      match['archived'] = !wasArchived;
      match['archivedDate'] = !wasArchived ? DateTime.now() : null;
    });
    
    _saveProfile();
    
    final bool isNowArchived = match['archived'] ?? false;
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          isNowArchived 
              ? '${match['movieTitle']} moved to archive'
              : '${match['movieTitle']} restored from archive'
        ),
        duration: const Duration(seconds: 2),
        backgroundColor: isNowArchived ? Colors.orange : Colors.green,
        action: SnackBarAction(
          label: 'Undo',
          textColor: Colors.white,
          onPressed: () {
            setState(() {
              _matchHistory[index]['archived'] = wasArchived;
              _matchHistory[index]['archivedDate'] = wasArchived ? DateTime.now() : null;
            });
            _saveProfile();
            _loadInitialMatchesPage();
          },
        ),
      ),
    );
    
    _loadInitialMatchesPage();
  }

  void _saveProfile() {
    if (widget.currentUser != null) {
      widget.currentUser!.matchHistory = _matchHistory;
      // Save to Firestore if implemented
    }
  }

  void _bulkArchiveMatches(bool unarchive) {
    setState(() {
      for (var match in _matchHistory) {
        if (unarchive) {
          if (match['archived'] ?? false) {
            match['archived'] = false;
            match['archivedDate'] = null;
          }
        } else {
          if (!(match['archived'] ?? false)) {
            match['archived'] = true;
            match['archivedDate'] = DateTime.now();
          }
        }
      }
    });
    
    _saveProfile();
    _loadInitialMatchesPage();
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(unarchive ? 'All matches restored' : 'All matches archived'),
        backgroundColor: unarchive ? Colors.green : Colors.orange,
      ),
    );
  }

  void _showBulkArchiveDialog() {
    final unArchivedMatches = _matchHistory.where((match) => !(match['archived'] ?? false)).toList();
    
    if (unArchivedMatches.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No matches to archive')),
      );
      return;
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          'Archive All Matches?',
          style: TextStyle(color: Colors.white, fontSize: 18.sp),
        ),
        content: Text(
          'This will move ${unArchivedMatches.length} matches to the archive. You can restore them later.',
          style: TextStyle(color: Colors.white70, fontSize: 15.sp),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _bulkArchiveMatches(false);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
            child: Text('Archive All', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  String _getActiveFiltersText() {
    List<String> activeFilters = [];
    
    if (_filterArchived) {
      activeFilters.add("Archived");
    } else if (_filterWatched) {
      activeFilters.add("Watched");
    } else if (_filterUnwatched) {
      activeFilters.add("Unwatched");
    }
    
    if (_sortOrder == 'oldest') {
      activeFilters.add("Oldest first");
    }
    
    if (_selectedFriends.isNotEmpty) {
      if (_selectedFriends.length == 1) {
        activeFilters.add("Friend: ${_selectedFriends.first}");
      } else {
        activeFilters.add("${_selectedFriends.length} friends");
      }
    }
    
    if (_selectedGroups.isNotEmpty) {
      if (_selectedGroups.length == 1) {
        activeFilters.add("Group: ${_selectedGroups.first}");
      } else {
        activeFilters.add("${_selectedGroups.length} groups");
      }
    }
    
    return activeFilters.join(" • ");
  }

  List<String> _getUniqueFriends() {
    final friendSet = <String>{};
    for (final match in _matchHistory) {
      if (!(match['archived'] ?? false) || _filterArchived) {
        friendSet.add(match['username']);
      }
    }
    return friendSet.toList()..sort();
  }

  List<String> _getUniqueGroups() {
    final groupSet = <String>{};
    for (final match in _matchHistory) {
      if ((!(match['archived'] ?? false) || _filterArchived) && match['groupName'] != null) {
        groupSet.add(match['groupName']);
      }
    }
    return groupSet.toList()..sort();
  }

  // [Include _showFilterOptions, _showSortOptions, _buildMatchCard, _buildEmptyState, etc. from original file]
  // These are extensive methods that remain exactly the same as in the original file

  void _showFilterOptions() {
    final uniqueFriends = _getUniqueFriends();
    final uniqueGroups = _getUniqueGroups();
    
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1F1F1F),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16.r)),
      ),
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) => Container(
          padding: EdgeInsets.all(16.w),
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.7,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header with bulk actions
              Row(
                children: [
                  Icon(Icons.filter_list, color: const Color(0xFFE5A00D), size: 24.sp),
                  SizedBox(width: 8.w),
                  Text(
                    "Filter Matches",
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const Spacer(),
                  
                  // 🆕 Bulk archive button
                  if (!_filterArchived)
                    IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _showBulkArchiveDialog();
                      },
                      icon: Icon(Icons.archive, color: Colors.orange, size: 20.sp),
                      tooltip: 'Archive All',
                    ),
                  
                  TextButton(
                    onPressed: () {
                      setModalState(() {
                        _filterWatched = false;
                        _filterUnwatched = false;
                        _filterArchived = false;
                        _sortOrder = 'newest';
                        _selectedFriends = {};
                        _selectedGroups = {};
                      });
                      // 🔧 FIXED: Apply reset immediately to main state
                      setState(() {
                        _filterWatched = false;
                        _filterUnwatched = false;
                        _filterArchived = false;
                        _sortOrder = 'newest';
                        _selectedFriends = {};
                        _selectedGroups = {};
                      });
                    },
                    child: Text(
                      "Reset",
                      style: TextStyle(color: Colors.white70, fontSize: 14.sp),
                    ),
                  ),
                ],
              ),
              
              Flexible(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 16.h),
                      
                      // 🆕 UPDATED: View filter with archive option
                      Text(
                        "VIEW",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12.sp,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      
                      Row(
                        children: [
                          _buildFilterChip(
                            label: 'Active',
                            selected: !_filterArchived,
                            onSelected: (_) {
                              setModalState(() {
                                _filterArchived = false;
                              });
                              // 🔧 FIXED: Apply change immediately
                              setState(() {
                                _filterArchived = false;
                              });
                            },
                          ),
                          SizedBox(width: 8.w),
                          _buildFilterChip(
                            label: 'Archived',
                            selected: _filterArchived,
                            onSelected: (_) {
                              setModalState(() {
                                _filterArchived = true;
                                // Clear other filters when viewing archive
                                _filterWatched = false;
                                _filterUnwatched = false;
                              });
                              // 🔧 FIXED: Apply change immediately
                              setState(() {
                                _filterArchived = true;
                                _filterWatched = false;
                                _filterUnwatched = false;
                              });
                            },
                          ),
                        ],
                      ),
                      
                      // Only show watch status filter for active matches
                      if (!_filterArchived) ...[
                        SizedBox(height: 16.h),
                        
                        Text(
                          "WATCH STATUS",
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.2,
                          ),
                        ),
                        SizedBox(height: 8.h),
                        
                        Row(
                          children: [
                            _buildFilterChip(
                              label: 'All',
                              selected: !_filterWatched && !_filterUnwatched,
                              onSelected: (_) {
                                setModalState(() {
                                  _filterWatched = false;
                                  _filterUnwatched = false;
                                });
                                setState(() {
                                  _filterWatched = false;
                                  _filterUnwatched = false;
                                });
                              },
                            ),
                            SizedBox(width: 8.w),
                            _buildFilterChip(
                              label: 'Watched',
                              selected: _filterWatched,
                              onSelected: (_) {
                                setModalState(() {
                                  _filterWatched = true;
                                  _filterUnwatched = false;
                                });
                                setState(() {
                                  _filterWatched = true;
                                  _filterUnwatched = false;
                                });
                              },
                            ),
                            SizedBox(width: 8.w),
                            _buildFilterChip(
                              label: 'Unwatched',
                              selected: _filterUnwatched,
                              onSelected: (_) {
                                setModalState(() {
                                  _filterWatched = false;
                                  _filterUnwatched = true;
                                });
                                setState(() {
                                  _filterWatched = false;
                                  _filterUnwatched = true;
                                });
                              },
                            ),
                          ],
                        ),
                      ],
                      
                      SizedBox(height: 16.h),
                      
                      // Sort order
                      Text(
                        "SORT BY",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12.sp,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      
                      Row(
                        children: [
                          _buildFilterChip(
                            label: 'Newest First',
                            selected: _sortOrder == 'newest',
                            onSelected: (_) {
                              setModalState(() {
                                _sortOrder = 'newest';
                              });
                              setState(() {
                                _sortOrder = 'newest';
                              });
                            },
                          ),
                          SizedBox(width: 8.w),
                          _buildFilterChip(
                            label: 'Oldest First',
                            selected: _sortOrder == 'oldest',
                            onSelected: (_) {
                              setModalState(() {
                                _sortOrder = 'oldest';
                              });
                              setState(() {
                                _sortOrder = 'oldest';
                              });
                            },
                          ),
                        ],
                      ),
                      
                      SizedBox(height: 16.h),
                      
                      // Friends filter section
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "FRIENDS",
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2,
                            ),
                          ),
                          
                          TextButton(
                            onPressed: () {
                              setModalState(() {
                                if (_selectedFriends.length == uniqueFriends.length) {
                                  _selectedFriends = {};
                                } else {
                                  _selectedFriends = Set.from(uniqueFriends);
                                }
                              });
                              setState(() {
                                if (_selectedFriends.length == uniqueFriends.length) {
                                  _selectedFriends = {};
                                } else {
                                  _selectedFriends = Set.from(uniqueFriends);
                                }
                              });
                            },
                            child: Text(
                              _selectedFriends.length == uniqueFriends.length
                                  ? "Clear All"
                                  : "Select All",
                              style: TextStyle(
                                color: const Color(0xFFE5A00D),
                                fontSize: 12.sp,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8.h),
                      
                      ...uniqueFriends.map((friend) => 
                        CheckboxListTile(
                          title: Text(
                            friend,
                            style: TextStyle(color: Colors.white, fontSize: 16.sp),
                          ),
                          value: _selectedFriends.contains(friend),
                          onChanged: (bool? value) {
                            setModalState(() {
                              if (value == true) {
                                _selectedFriends.add(friend);
                              } else {
                                _selectedFriends.remove(friend);
                              }
                            });
                            setState(() {
                              if (value == true) {
                                _selectedFriends.add(friend);
                              } else {
                                _selectedFriends.remove(friend);
                              }
                            });
                          },
                          activeColor: const Color(0xFFE5A00D),
                          checkColor: Colors.black,
                          controlAffinity: ListTileControlAffinity.trailing,
                          contentPadding: EdgeInsets.zero,
                        ),
                      ).toList(),

                      SizedBox(height: 16.h),
                      
                      if (uniqueGroups.isNotEmpty) ...[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "GROUPS",
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12.sp,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.2,
                              ),
                            ),
                            
                            TextButton(
                              onPressed: () {
                                setModalState(() {
                                  if (_selectedGroups.length == uniqueGroups.length) {
                                    _selectedGroups = {};
                                  } else {
                                    _selectedGroups = Set.from(uniqueGroups);
                                  }
                                });
                                setState(() {
                                  if (_selectedGroups.length == uniqueGroups.length) {
                                    _selectedGroups = {};
                                  } else {
                                    _selectedGroups = Set.from(uniqueGroups);
                                  }
                                });
                              },
                              child: Text(
                                _selectedGroups.length == uniqueGroups.length
                                    ? "Clear All"
                                    : "Select All",
                                style: TextStyle(
                                  color: const Color(0xFFE5A00D),
                                  fontSize: 12.sp,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 8.h),
                        
                        ...uniqueGroups.map((group) => 
                          CheckboxListTile(
                            title: Text(
                              group,
                              style: TextStyle(color: Colors.white, fontSize: 16.sp),
                            ),
                            value: _selectedGroups.contains(group),
                            onChanged: (bool? value) {
                              setModalState(() {
                                if (value == true) {
                                  _selectedGroups.add(group);
                                } else {
                                  _selectedGroups.remove(group);
                                }
                              });
                              setState(() {
                                if (value == true) {
                                  _selectedGroups.add(group);
                                } else {
                                  _selectedGroups.remove(group);
                                }
                              });
                            },
                            activeColor: const Color(0xFFE5A00D),
                            checkColor: Colors.black,
                            controlAffinity: ListTileControlAffinity.trailing,
                            contentPadding: EdgeInsets.zero,
                          ),
                        ).toList(),
                      ],
                    ],
                  ),
                ),
              ),
              
              SizedBox(height: 16.h),
              
              // Apply button - now just refreshes the view since changes are applied immediately
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    _loadInitialMatchesPage(); // Refresh the filtered view
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE5A00D),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 12.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                  ),
                  child: Text(
                    "Apply Filters",
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSortOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1F1F1F),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16.r)),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.all(16.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.sort, color: const Color(0xFFE5A00D), size: 24.sp),
                SizedBox(width: 8.w),
                Text(
                  "Sort Matches",
                  style: TextStyle(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
            
            SizedBox(height: 24.h),
            
            _buildSortOption(
              title: "Newest First",
              isSelected: _sortOrder == 'newest',
              onTap: () {
                setState(() {
                  _sortOrder = 'newest';
                });
                Navigator.pop(context);
                _loadInitialMatchesPage();
              },
            ),
            
            _buildSortOption(
              title: "Oldest First",
              isSelected: _sortOrder == 'oldest',
              onTap: () {
                setState(() {
                  _sortOrder = 'oldest';
                });
                Navigator.pop(context);
                _loadInitialMatchesPage();
              },
            ),
            
            SizedBox(height: 16.h),
          ],
        ),
      ),
    );
  }

  Widget _buildMatchCard(Map<String, dynamic> match, int index) {
    final bool isWatched = match['watched'] ?? false;
    final bool isArchived = match['archived'] ?? false;
    final String? groupName = match['groupName'];
    
    late final Movie movie;
    if (match['movie'] is Movie) {
      movie = match['movie'] as Movie;
    } else if (match['movie'] is Map<String, dynamic>) {
      movie = Movie.fromJson(match['movie'] as Map<String, dynamic>);
    } else {
      movie = Movie(
        id: match['movieId'] ?? '',
        title: match['movieTitle'] ?? 'Unknown Movie',
        posterUrl: match['posterUrl'] ?? '',
        overview: 'No overview available',
        cast: [],
        genres: [],
        tags: [],
      );
    }

    return Card(
      margin: EdgeInsets.only(bottom: 16.h),
      color: isArchived ? const Color(0xFF1A1A1A) : const Color(0xFF1F1F1F),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.r),
        side: isArchived 
            ? BorderSide(color: Colors.orange.withValues(alpha: 0.3), width: 1.w)
            : BorderSide.none,
      ),
      child: InkWell(
        onTap: () {
          showMovieDetails(
            context: context,
            movie: movie,
            currentUser: widget.currentUser!,
            isInFavorites: widget.currentUser!.likedMovieIds.contains(movie.id),
            onMarkAsWatched: (movie) {
              _toggleWatched(index);
            },
          );
        },
        borderRadius: BorderRadius.circular(12.r),
        child: Padding(
          padding: EdgeInsets.all(16.w),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8.r),
                    child: FadeInImage.assetNetwork(
                      placeholder: 'assets/placeholder.png',
                      image: match['posterUrl'] ?? movie.posterUrl,
                      width: 80.w,
                      height: 120.h,
                      fit: BoxFit.cover,
                      fadeInDuration: const Duration(milliseconds: 200),
                      imageErrorBuilder: (_, __, ___) => Container(
                        width: 80.w,
                        height: 120.h,
                        color: Colors.grey[800],
                        child: Icon(Icons.broken_image, size: 30.sp),
                      ),
                    ),
                  ),
                  
                  // Status overlays
                  if (isWatched)
                    Positioned(
                      top: 0,
                      right: 0,
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                        decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(8.r),
                            topRight: Radius.circular(8.r),
                          ),
                        ),
                        child: Icon(
                          Icons.visibility,
                          color: Colors.white,
                          size: 16.sp,
                        ),
                      ),
                    ),
                  
                  // 🆕 Archive indicator
                  if (isArchived)
                    Positioned(
                      bottom: 0,
                      left: 0,
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                        decoration: BoxDecoration(
                          color: Colors.orange,
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(8.r),
                            bottomLeft: Radius.circular(8.r),
                          ),
                        ),
                        child: Icon(
                          Icons.archive,
                          color: Colors.white,
                          size: 16.sp,
                        ),
                      ),
                    ),
                ],
              ),
              SizedBox(width: 16.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      match['movieTitle'] ?? movie.title,
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                        color: isArchived ? Colors.white70 : Colors.white,
                      ),
                    ),
                    SizedBox(height: 8.h),
                    Row(
                      children: [
                        Icon(Icons.person, size: 16.sp, color: Colors.white70),
                        SizedBox(width: 4.w),
                        Text(
                          'Matched with ${match['username']}',
                          style: TextStyle(color: Colors.white70, fontSize: 14.sp),
                        ),
                      ],
                    ),
                    if (groupName != null) ...[
                      SizedBox(height: 4.h),
                      Row(
                        children: [
                          Icon(Icons.group, size: 16.sp, color: Colors.white70),
                          SizedBox(width: 4.w),
                          Text(
                            'Group: $groupName',
                            style: TextStyle(color: Colors.white70, fontSize: 14.sp),
                          ),
                        ],
                      ),
                    ],
                    SizedBox(height: 4.h),
                    Row(
                      children: [
                        Icon(Icons.calendar_today, size: 16.sp, color: Colors.white70),
                        SizedBox(width: 4.w),
                        Text(
                          _formatDate(_getDateTime(match['matchDate'])),
                          style: TextStyle(color: Colors.white70, fontSize: 14.sp),
                        ),
                      ],
                    ),
                    
                    // 🆕 Archive date
                    if (isArchived && match['archivedDate'] != null) ...[
                      SizedBox(height: 4.h),
                      Row(
                        children: [
                          Icon(Icons.archive, size: 16.sp, color: Colors.orange),
                          SizedBox(width: 4.w),
                          Text(
                            'Archived on ${_formatFullDate(_getDateTime(match['archivedDate']))}',
                            style: TextStyle(color: Colors.orange, fontSize: 14.sp),
                          ),
                        ],
                      ),
                    ],
                    
                    if (isWatched && match['watchedDate'] != null) ...[
                      SizedBox(height: 4.h),
                      Row(
                        children: [
                          Icon(Icons.visibility, size: 16.sp, color: Colors.green),
                          SizedBox(width: 4.w),
                          Text(
                            'Watched on ${_formatFullDate(_getDateTime(match['watchedDate']))}',
                            style: TextStyle(color: Colors.green, fontSize: 14.sp),
                          ),
                        ],
                      ),
                    ],
                    SizedBox(height: 12.h),
                    
                    // 🆕 UPDATED: Action buttons with archive/unarchive
                    Wrap(
                      spacing: 8.w,
                      runSpacing: 8.h,
                      children: [
                        if (!isArchived) ...[
                          OutlinedButton.icon(
                            onPressed: () => _toggleWatched(index),
                            icon: Icon(
                              isWatched ? Icons.visibility_off : Icons.visibility,
                              size: 16.sp,
                            ),
                            label: Text(
                              isWatched ? 'Unwatched' : 'Watched',
                              style: TextStyle(fontSize: 13.sp),
                            ),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: isWatched ? Colors.grey : Colors.green,
                              side: BorderSide(
                                color: isWatched ? Colors.grey : Colors.green,
                                width: 1.w,
                              ),
                            ),
                          ),
                        ],
                        
                        OutlinedButton.icon(
                          onPressed: () => _toggleArchived(index),
                          icon: Icon(
                            isArchived ? Icons.unarchive : Icons.archive,
                            size: 16.sp,
                          ),
                          label: Text(
                            isArchived ? 'Restore' : 'Archive',
                            style: TextStyle(fontSize: 13.sp),
                          ),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: isArchived ? Colors.green : Colors.orange,
                            side: BorderSide(
                              color: isArchived ? Colors.green : Colors.orange,
                              width: 1.w,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState({
    required IconData icon,
    required String message,
    required String subMessage,
  }) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 70.sp,
            color: Colors.white30,
          ),
          SizedBox(height: 16.h),
          Text(
            message,
            style: TextStyle(
              color: Colors.white,
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 8.h),
          Text(
            subMessage,
            style: TextStyle(color: Colors.white70, fontSize: 16.sp),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  DateTime _getDateTime(dynamic dateValue) {
    if (dateValue == null) {
      return DateTime.now();
    } else if (dateValue is DateTime) {
      return dateValue;
    } else if (dateValue is Timestamp) {
      return dateValue.toDate();
    } else if (dateValue is String) {
      return DateTime.parse(dateValue);
    } else {
      return DateTime.now();
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
  
  String _formatFullDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed && _tabController.index == 0) {
      _checkForNewMatches();
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _matchesScrollController.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }
}