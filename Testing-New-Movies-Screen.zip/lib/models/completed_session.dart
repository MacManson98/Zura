import 'package:cloud_firestore/cloud_firestore.dart';

enum SessionType { solo, friend, group }

class CompletedSession {
  final String id;
  final DateTime startTime;
  final DateTime endTime;
  final SessionType type;
  final List<String> participantNames;
  final List<String> likedMovieIds; // For solo sessions
  final List<String> matchedMovieIds; // For collaborative sessions
  final String? mood; // If mood-based session
  final int totalSwipes;

  CompletedSession({
    required this.id,
    required this.startTime,
    required this.endTime,
    required this.type,
    required this.participantNames,
    required this.likedMovieIds,
    required this.matchedMovieIds,
    this.mood,
    this.totalSwipes = 0,
  });

  factory CompletedSession.fromFirestore(String id, Map<String, dynamic> data) {
    final matchesMap = data['matches'] as Map<String, dynamic>? ?? {};
    final matchedMovieIds = matchesMap.keys.toList();

    final start = _parseDate(data['createdAt']) ?? DateTime.now();
    final end = _parseDate(data['endedAt']) ??
        _parseDate(data['completedAt']) ??
        start;

    return CompletedSession(
      id: id,
      startTime: start,
      endTime: end,
      type: _parseSessionType(data['inviteType']),
      participantNames: [data['hostName'] ?? "You"], // update this if storing more names
      likedMovieIds: [], // only used for solo
      matchedMovieIds: matchedMovieIds,
      mood: null,
      totalSwipes: 0,
    );
  }

  static DateTime? _parseDate(dynamic val) {
    if (val == null) return null;
    if (val is Timestamp) return val.toDate();
    if (val is String) return DateTime.tryParse(val);
    return null;
  }

  static SessionType _parseSessionType(String? val) {
    switch (val) {
      case 'solo':
        return SessionType.solo;
      case 'group':
        return SessionType.group;
      case 'friend':
      default:
        return SessionType.friend;
    }
  }

  // Auto-generate fun titles for collaborative sessions
  String get funTitle {
    if (type == SessionType.solo) {
      return _generateSoloTitle();
    } else {
      return _generateCollaborativeTitle();
    }
  }

  String _generateSoloTitle() {
    final timeOfDay = _getTimeOfDay(startTime);
    final dayName = _getDayName(startTime);
    
    if (likedMovieIds.isEmpty) {
      return "$dayName ${timeOfDay}Browsing";
    }
    
    final movieCount = likedMovieIds.length;
    if (movieCount == 1) {
      return "$dayName Perfect Pick";
    } else if (movieCount <= 3) {
      return "$dayName Movie Hunt";
    } else {
      return "$dayName Discovery Session";
    }
  }

  String _generateCollaborativeTitle() {
    final matchCount = matchedMovieIds.length;
    final isGroup = type == SessionType.group;
    
    if (matchCount == 0) {
      return isGroup ? "Group Browse Session" : "Friend Browse Session";
    } else if (matchCount == 1) {
      return isGroup ? "Group Perfect Match" : "Cinema Sync Success";
    } else if (matchCount == 2) {
      return isGroup ? "Group Double Feature" : "Movie Match Duo";
    } else {
      return isGroup ? "Group Movie Magic" : "Match Making Masters";
    }
  }

  String _getTimeOfDay(DateTime time) {
    final hour = time.hour;
    if (hour < 6) return "Late Night ";
    if (hour < 12) return "Morning ";
    if (hour < 17) return "Afternoon ";
    if (hour < 21) return "Evening ";
    return "Night ";
  }

  String _getDayName(DateTime time) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final sessionDay = DateTime(time.year, time.month, time.day);
    
    final difference = today.difference(sessionDay).inDays;
    
    if (difference == 0) return "Today's";
    if (difference == 1) return "Yesterday's";
    if (difference <= 7) {
      const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
      return "${days[time.weekday - 1]}'s";
    }
    return "${time.month}/${time.day}";
  }

  String get displayTitle {
    if (type == SessionType.solo) {
      final count = likedMovieIds.length;
      return "$funTitle • $count movie${count == 1 ? '' : 's'}";
    } else {
      final friendNames = participantNames.where((name) => name != "You").join(", ");
      final count = matchedMovieIds.length;
      return "With $friendNames • $count match${count == 1 ? '' : 'es'}";
    }
  }

  Duration get duration => endTime.difference(startTime);

  // Serialization
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'type': type.toString().split('.').last,
      'participantNames': participantNames,
      'likedMovieIds': likedMovieIds,
      'matchedMovieIds': matchedMovieIds,
      'mood': mood,
      'totalSwipes': totalSwipes,
    };
  }

  factory CompletedSession.fromJson(Map<String, dynamic> json) {
    return CompletedSession(
      id: json['id'],
      startTime: DateTime.parse(json['startTime']),
      endTime: DateTime.parse(json['endTime']),
      type: SessionType.values.firstWhere(
        (e) => e.toString().split('.').last == json['type'],
      ),
      participantNames: List<String>.from(json['participantNames']),
      likedMovieIds: List<String>.from(json['likedMovieIds']),
      matchedMovieIds: List<String>.from(json['matchedMovieIds']),
      mood: json['mood'],
      totalSwipes: json['totalSwipes'] ?? 0,
    );
  }
}

// Session Management Utility
class SessionManager {
  static CompletedSession? _currentSession;
  static DateTime? _lastActivity;
  static int _swipeCount = 0;
  
  // Start a new session
  static void startSession({
    required SessionType type,
    required List<String> participantNames,
    String? mood,
  }) {
    _currentSession = CompletedSession(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      startTime: DateTime.now(),
      endTime: DateTime.now(), // Will be updated when session ends
      type: type,
      participantNames: participantNames,
      likedMovieIds: [],
      matchedMovieIds: [],
      mood: mood,
      totalSwipes: 0,
    );
    _lastActivity = DateTime.now();
    _swipeCount = 0;
  }

  // Record activity (swipe, like, etc.)
  static void recordActivity() {
    _lastActivity = DateTime.now();
    _swipeCount++;
  }

  // Add liked movie to current session
  static void addLikedMovie(String movieId) {
    if (_currentSession != null) {
      _currentSession = CompletedSession(
        id: _currentSession!.id,
        startTime: _currentSession!.startTime,
        endTime: _currentSession!.endTime,
        type: _currentSession!.type,
        participantNames: _currentSession!.participantNames,
        likedMovieIds: [..._currentSession!.likedMovieIds, movieId],
        matchedMovieIds: _currentSession!.matchedMovieIds,
        mood: _currentSession!.mood,
        totalSwipes: _swipeCount,
      );
    }
    recordActivity();
  }

  // Add matched movie to current session
  static void addMatchedMovie(String movieId) {
    if (_currentSession != null) {
      _currentSession = CompletedSession(
        id: _currentSession!.id,
        startTime: _currentSession!.startTime,
        endTime: _currentSession!.endTime,
        type: _currentSession!.type,
        participantNames: _currentSession!.participantNames,
        likedMovieIds: _currentSession!.likedMovieIds,
        matchedMovieIds: [..._currentSession!.matchedMovieIds, movieId],
        mood: _currentSession!.mood,
        totalSwipes: _swipeCount,
      );
    }
    recordActivity();
  }

  // Check if session should auto-end (10 minutes of inactivity)
  static bool shouldAutoEnd() {
    if (_lastActivity == null) return false;
    return DateTime.now().difference(_lastActivity!).inMinutes >= 10;
  }

  // End current session and return it
  static CompletedSession? endSession() {
    if (_currentSession == null) return null;
    
    final completedSession = CompletedSession(
      id: _currentSession!.id,
      startTime: _currentSession!.startTime,
      endTime: DateTime.now(),
      type: _currentSession!.type,
      participantNames: _currentSession!.participantNames,
      likedMovieIds: _currentSession!.likedMovieIds,
      matchedMovieIds: _currentSession!.matchedMovieIds,
      mood: _currentSession!.mood,
      totalSwipes: _swipeCount,
    );
    
    _currentSession = null;
    _lastActivity = null;
    _swipeCount = 0;
    
    return completedSession;
  }

  // Get current session
  static CompletedSession? get currentSession => _currentSession;
  
  // Check if session is active
  static bool get hasActiveSession => _currentSession != null;
  
  // Get session duration so far
  static Duration? get currentSessionDuration {
    if (_currentSession == null) return null;
    return DateTime.now().difference(_currentSession!.startTime);
  }
}