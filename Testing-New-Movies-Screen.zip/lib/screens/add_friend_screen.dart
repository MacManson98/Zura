import 'package:flutter/material.dart';
import '../models/user_profile.dart';
import '../services/friendship_service.dart'; // ✅ Add this import
import '../utils/debug_loader.dart';

class AddFriendScreen extends StatefulWidget {
  final UserProfile currentUser;

  const AddFriendScreen({
    super.key,
    required this.currentUser,
  });

  @override
  State<AddFriendScreen> createState() => _AddFriendScreenState();
}

class _AddFriendScreenState extends State<AddFriendScreen> {
  final TextEditingController _searchController = TextEditingController();
  final List<UserProfile> _searchResults = [];
  bool _isSearching = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _searchUsers(String query) async {
    if (query.isEmpty) {
      setState(() {
        _searchResults.clear();
        _isSearching = false;
      });
      return;
    }

    setState(() => _isSearching = true);

    try {
      // ✅ Use FriendshipService instead of direct Firestore query
      final results = await FriendshipService.searchUsersByName(query, widget.currentUser.uid);
      
      setState(() {
        _searchResults.clear();
        _searchResults.addAll(results);
        _isSearching = false;
      });
    } catch (e) {
      DebugLogger.log('Search error: $e');
      setState(() => _isSearching = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Search failed: $e')),
      );
    }
  }

  void _sendFriendRequest(UserProfile user) async {
    try {
      // ✅ Use FriendshipService to send proper friend request
      await FriendshipService.sendFriendRequest(
        fromUserId: widget.currentUser.uid,
        toUserId: user.uid,
        fromUserName: widget.currentUser.name,
        toUserName: user.name,
      );

      setState(() {}); // Refresh UI to show updated button state
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Friend request sent to ${user.name}!'),
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 2),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to send request: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text('Add Friends'),
      ),
      body: Column(
        children: [
          // Search section
          Container(
            padding: const EdgeInsets.all(16),
            color: const Color(0xFF1F1F1F),
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search for users...',
                    hintStyle: const TextStyle(color: Colors.white54),
                    prefixIcon: const Icon(Icons.search, color: Colors.white54),
                    filled: true,
                    fillColor: Colors.black26,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  style: const TextStyle(color: Colors.white),
                  onChanged: _searchUsers,
                ),
                const SizedBox(height: 16),
                const Text(
                  'Search by name to find friends and send friend requests',
                  style: TextStyle(color: Colors.white54, fontSize: 14),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),

          // QR code/sharing options section (keep your existing design)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildOptionButton(
                  icon: Icons.qr_code,
                  label: 'My QR Code',
                  onTap: () {
                    _showQrCodeDialog();
                  },
                ),
                _buildOptionButton(
                  icon: Icons.qr_code_scanner,
                  label: 'Scan QR',
                  onTap: () {
                    // Start QR scanner
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('QR Scanner coming soon!')),
                    );
                  },
                ),
                _buildOptionButton(
                  icon: Icons.share,
                  label: 'Share Link',
                  onTap: () {
                    // Share your profile link
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Profile sharing coming soon!')),
                    );
                  },
                ),
              ],
            ),
          ),

          // Divider
          const Divider(color: Colors.white12),

          // Search results
          Expanded(
            child: _searchController.text.isEmpty
                ? _buildDefaultContent()
                : _isSearching
                    ? const Center(
                        child: CircularProgressIndicator(
                          color: Color(0xFFE5A00D),
                        ),
                      )
                    : _searchResults.isEmpty
                        ? const Center(
                            child: Text(
                              'No users found',
                              style: TextStyle(color: Colors.white54),
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.all(16),
                            itemCount: _searchResults.length,
                            itemBuilder: (context, index) {
                              final user = _searchResults[index];
                              return _buildUserResultCard(user);
                            },
                          ),
          ),
        ],
      ),
    );
  }

  Widget _buildDefaultContent() {
    // Content shown when no search is performed
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.people_outline,
            size: 70,
            color: Colors.white30,
          ),
          const SizedBox(height: 16),
          const Text(
            'Search for friends to add',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Find friends by name or username',
            style: TextStyle(color: Colors.white54),
          ),
          const SizedBox(height: 24),
          // Friend suggestions section
          Container(
            width: double.infinity,
            margin: const EdgeInsets.symmetric(horizontal: 32),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1F1F1F),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '🎬 Find Friends',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Search for friends by their name to send friend requests',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOptionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 100,
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF1F1F1F),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: const Color(0xFFE5A00D), size: 32),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(color: Colors.white, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserResultCard(UserProfile user) {
    // ✅ Use FutureBuilder to check friendship and request status
    return FutureBuilder<bool>(
      future: FriendshipService.areFriends(widget.currentUser.uid, user.uid),
      builder: (context, friendshipSnapshot) {
        return FutureBuilder<String?>(
          future: FriendshipService.getFriendRequestStatus(widget.currentUser.uid, user.uid),
          builder: (context, requestSnapshot) {
            
            // Determine button state
            String buttonText = "Add";
            bool isDisabled = false;
            Color buttonColor = const Color(0xFFE5A00D);
            
            if (friendshipSnapshot.data == true) {
              buttonText = "Friends ✓";
              isDisabled = true;
              buttonColor = Colors.green;
            } else if (requestSnapshot.data == 'pending') {
              buttonText = "Sent";
              isDisabled = true;
              buttonColor = Colors.grey;
            }

            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              color: const Color(0xFF1F1F1F),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    // Avatar
                    CircleAvatar(
                      radius: 24,
                      backgroundColor: Colors.grey[800],
                      child: Text(
                        user.name.isNotEmpty ? user.name[0].toUpperCase() : "?",
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    // User details
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user.name,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Likes: ${user.preferredGenres.take(3).join(", ")}',
                            style: const TextStyle(
                              color: Colors.white54,
                              fontSize: 14,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    // Add button
                    ElevatedButton(
                      onPressed: isDisabled ? null : () => _sendFriendRequest(user),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: buttonColor,
                        disabledBackgroundColor: Colors.grey[700],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                      ),
                      child: Text(
                        buttonText,
                        style: TextStyle(
                          color: isDisabled ? Colors.grey[400] : Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showQrCodeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text(
          "Your QR Code",
          style: TextStyle(color: Colors.white),
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Let friends scan this code to add you",
              style: TextStyle(color: Colors.white70),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            // Placeholder for QR code
            Container(
              width: 200,
              height: 200,
              color: Colors.white,
              child: const Center(
                child: Text(
                  "QR Code\nPlaceholder",
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Username display
            Text(
              widget.currentUser.name,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              "ID: ${widget.currentUser.uid.substring(0, 8)}",
              style: const TextStyle(
                color: Colors.white54,
                fontSize: 14,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "Close",
              style: TextStyle(color: Color(0xFFE5A00D)),
            ),
          ),
          ElevatedButton.icon(
            onPressed: () {
              // Share QR code logic
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('QR sharing coming soon!')),
              );
            },
            icon: const Icon(Icons.share, color: Colors.white, size: 18),
            label: const Text(
              "Share",
              style: TextStyle(color: Colors.white),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFE5A00D),
            ),
          ),
        ],
      ),
    );
  }
}