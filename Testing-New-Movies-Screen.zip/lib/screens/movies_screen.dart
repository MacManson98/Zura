// File: lib/screens/movies_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/user_profile.dart';
import '../movie.dart';
import '../models/completed_session.dart';
import '../utils/debug_loader.dart';
import '../screens/watch_options_screen.dart';
import '../screens/session_detail_screen.dart';
import 'package:glassmorphism/glassmorphism.dart';
import 'dart:math' as math;

enum ViewMode { feed, calendar, stats, collections }
enum SessionFilter { all, solo, friends, thisWeek, thisMonth }

class MoviesScreen extends StatefulWidget {
  final UserProfile? currentUser;
  final Function(String mode, {String? sessionId, bool resume})? onNavigateToMatcher;

  const MoviesScreen({
    super.key,
    required this.currentUser,
    this.onNavigateToMatcher,
    required bool focusReadyToWatch,
  });

  @override
  State<MoviesScreen> createState() => _MoviesScreenState();
}

class _MoviesScreenState extends State<MoviesScreen>
    with TickerProviderStateMixin {
  ViewMode _currentView = ViewMode.feed;
  SessionFilter _currentFilter = SessionFilter.all;
  AnimationController? _fabController;
  AnimationController? _heroController;
  Animation<double>? _fabAnimation;
  Animation<double>? _heroAnimation;
  
  bool _showFloatingActions = false;
  int _selectedMonthOffset = 0; // 0 = current month, -1 = last month, etc.

  @override
  void initState() {
    super.initState();
    _fabController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _heroController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    
    _fabAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fabController!, curve: Curves.elasticOut),
    );
    _heroAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _heroController!, curve: Curves.easeOutCubic),
    );
    
    _heroController!.forward();
  }

  @override
  void dispose() {
    _fabController?.dispose();
    _heroController?.dispose();
    super.dispose();
  }

  List<CompletedSession> get _filteredSessions {
    if (widget.currentUser == null) return [];
    
    final allSessions = widget.currentUser!.sessionHistory;
    final now = DateTime.now();
    
    switch (_currentFilter) {
      case SessionFilter.all:
        return allSessions;
      case SessionFilter.solo:
        return allSessions.where((s) => s.type == SessionType.solo).toList();
      case SessionFilter.friends:
        return allSessions.where((s) => s.type != SessionType.solo).toList();
      case SessionFilter.thisWeek:
        final weekAgo = now.subtract(Duration(days: 7));
        return allSessions.where((s) => s.startTime.isAfter(weekAgo)).toList();
      case SessionFilter.thisMonth:
        final monthAgo = DateTime(now.year, now.month - 1, now.day);
        return allSessions.where((s) => s.startTime.isAfter(monthAgo)).toList();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.currentUser == null) {
      return _buildNoUserState();
    }

    return Scaffold(
      backgroundColor: const Color(0xFF121212), // Match your existing theme
      body: Stack(
        children: [
          // Subtle gradient background
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF1F1F1F),
                  Color(0xFF161616),
                  Color(0xFF121212),
                ],
              ),
            ),
          ),
          
          // Main content
          CustomScrollView(
            slivers: [
              _buildAnimatedHeader(),
              _buildViewToggle(),
              _buildCurrentView(),
            ],
          ),
          
          // Floating action cluster
          _buildFloatingActionCluster(),
        ],
      ),
    );
  }

  Widget _buildAnimatedHeader() {
    final stats = _getQuickStats();
    
    return SliverToBoxAdapter(
      child: _heroAnimation != null ? AnimatedBuilder(
        animation: _heroAnimation!,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(0, 50 * (1 - _heroAnimation!.value)),
            child: Opacity(
              opacity: _heroAnimation!.value,
              child: Container(
                height: 200.h,
                margin: EdgeInsets.fromLTRB(20.w, 60.h, 20.w, 20.h),
                child: Stack(
                  children: [
                    // Hero background card
                    GlassmorphicContainer(
                      width: double.infinity,
                      height: double.infinity,
                      borderRadius: 24,
                      blur: 20,
                      alignment: Alignment.center,
                      border: 2,
                      linearGradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Colors.white.withValues(alpha: 0.08),
                          Colors.white.withValues(alpha: 0.04),
                          Colors.white.withValues(alpha: 0.02),
                        ],
                      ),
                      borderGradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Colors.white.withValues(alpha: 0.2),
                          Colors.white.withValues(alpha: 0.1),
                        ],
                      ),
                      child: Container(), // Background only
                    ),
                    
                    // Content overlay
                    Padding(
                      padding: EdgeInsets.all(24.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Title row
                          Row(
                            children: [
                              Container(
                                padding: EdgeInsets.all(12.w),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [Color(0xFFE5A00D), Color(0xFFFF6B35)],
                                  ),
                                  borderRadius: BorderRadius.circular(16.r),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0xFFE5A00D).withValues(alpha: 0.3),
                                      blurRadius: 12.r,
                                      spreadRadius: 2.r,
                                    ),
                                  ],
                                ),
                                child: Icon(
                                  Icons.movie_filter,
                                  color: Colors.white,
                                  size: 24.sp,
                                ),
                              ),
                              SizedBox(width: 16.w),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Cinema Chronicles",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 24.sp,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                    Text(
                                      "${widget.currentUser!.name}'s Movie Journey",
                                      style: TextStyle(
                                        color: Colors.white70,
                                        fontSize: 14.sp,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          
                          Spacer(),
                          
                          // Quick stats grid
                          Row(
                            children: [
                              _buildQuickStatBubble(
                                stats['total'].toString(),
                                'Sessions',
                                Color(0xFFE5A00D),
                              ),
                              SizedBox(width: 12.w),
                              _buildQuickStatBubble(
                                stats['streak'].toString(),
                                'Day Streak',
                                Colors.green,
                              ),
                              SizedBox(width: 12.w),
                              _buildQuickStatBubble(
                                stats['matches'].toString(),
                                'Matches',
                                Colors.purple,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ) : Container( // Fallback when animation is not ready
        height: 200.h,
        margin: EdgeInsets.fromLTRB(20.w, 60.h, 20.w, 20.h),
        child: Stack(
          children: [
            // Hero background card
            GlassmorphicContainer(
              width: double.infinity,
              height: double.infinity,
              borderRadius: 24,
              blur: 20,
              alignment: Alignment.center,
              border: 2,
              linearGradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.white.withValues(alpha: 0.08),
                  Colors.white.withValues(alpha: 0.04),
                  Colors.white.withValues(alpha: 0.02),
                ],
              ),
              borderGradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.white.withValues(alpha: 0.2),
                  Colors.white.withValues(alpha: 0.1),
                ],
              ),
              child: Container(), // Background only
            ),
            
            // Content overlay
            Padding(
              padding: EdgeInsets.all(24.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title row with integrated notification
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(12.w),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(16.r),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.2),
                            width: 1.w,
                          ),
                        ),
                        child: Icon(
                          Icons.movie_filter,
                          color: Colors.white,
                          size: 24.sp,
                        ),
                      ),
                      SizedBox(width: 16.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Your Picks",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24.sp,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                              ),
                            ),
                            Text(
                              "${widget.currentUser!.name}'s Movie Journey",
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 14.sp,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Integrated notification button
                      GestureDetector(
                        onTap: () => _showNotifications(),
                        child: Container(
                          padding: EdgeInsets.all(10.w),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(12.r),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.2),
                              width: 1.w,
                            ),
                          ),
                          child: Stack(
                            children: [
                              Icon(
                                Icons.notifications_outlined,
                                color: Colors.white70,
                                size: 20.sp,
                              ),
                              // Notification dot if there are notifications
                              if (_hasUnreadNotifications())
                                Positioned(
                                  top: 0,
                                  right: 0,
                                  child: Container(
                                    width: 8.w,
                                    height: 8.h,
                                    decoration: BoxDecoration(
                                      color: Colors.red,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  
                  Spacer(),
                  
                  // Quick stats grid
                  Row(
                    children: [
                      _buildQuickStatBubble(
                        stats['total'].toString(),
                        'Sessions',
                        Colors.white,
                      ),
                      SizedBox(width: 12.w),
                      _buildQuickStatBubble(
                        stats['streak'].toString(),
                        'Day Streak',
                        Colors.white70,
                      ),
                      SizedBox(width: 12.w),
                      _buildQuickStatBubble(
                        stats['matches'].toString(),
                        'Matches',
                        Colors.white60,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickStatBubble(String value, String label, Color color) {
    return Expanded(
      child: GlassmorphicContainer(
        width: double.infinity,
        height: 60.h,
        borderRadius: 16,
        blur: 10,
        alignment: Alignment.center,
        border: 1,
        linearGradient: LinearGradient(
          colors: [
            Colors.white.withValues(alpha: 0.08),
            Colors.white.withValues(alpha: 0.04),
          ],
        ),
        borderGradient: LinearGradient(
          colors: [
            Colors.white.withValues(alpha: 0.2),
            Colors.white.withValues(alpha: 0.1),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: Colors.white54,
                fontSize: 10.sp,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildViewToggle() {
    return SliverToBoxAdapter(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
        child: Row(
          children: [
            // View mode selector
            Expanded(
              child: GlassmorphicContainer(
                width: double.infinity,
                height: 50.h,
                borderRadius: 25,
                blur: 10,
                alignment: Alignment.center,
                border: 1,
                linearGradient: LinearGradient(
                  colors: [
                    Colors.white.withValues(alpha: 0.1),
                    Colors.white.withValues(alpha: 0.05),
                  ],
                ),
                borderGradient: LinearGradient(
                  colors: [
                    Colors.white.withValues(alpha: 0.3),
                    Colors.white.withValues(alpha: 0.1),
                  ],
                ),
                child: Row(
                  children: ViewMode.values.map((mode) {
                    final isSelected = _currentView == mode;
                    return Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _currentView = mode),
                        child: Container(
                          height: double.infinity,
                          margin: EdgeInsets.all(4.w),
                          decoration: BoxDecoration(
                            color: isSelected 
                                ? Color(0xFFE5A00D).withValues(alpha: 0.8)
                                : null,
                            borderRadius: BorderRadius.circular(20.r),
                          ),
                          child: Icon(
                            _getViewModeIcon(mode),
                            color: isSelected ? Colors.white : Colors.white60,
                            size: 18.sp,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
            
            SizedBox(width: 12.w),
            
            // Filter button
            GestureDetector(
              onTap: _showFilterMenu,
              child: GlassmorphicContainer(
                width: 50.w,
                height: 50.h,
                borderRadius: 25,
                blur: 10,
                alignment: Alignment.center,
                border: 1,
                linearGradient: LinearGradient(
                  colors: [
                    Colors.white.withValues(alpha: 0.1),
                    Colors.white.withValues(alpha: 0.05),
                  ],
                ),
                borderGradient: LinearGradient(
                  colors: [
                    Colors.white.withValues(alpha: 0.3),
                    Colors.white.withValues(alpha: 0.1),
                  ],
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(
                      Icons.filter_list,
                      color: Colors.white70,
                      size: 20.sp,
                    ),
                    if (_currentFilter != SessionFilter.all)
                      Positioned(
                        top: 8.h,
                        right: 8.w,
                        child: Container(
                          width: 8.w,
                          height: 8.h,
                          decoration: BoxDecoration(
                            color: Color(0xFFE5A00D),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentView() {
    switch (_currentView) {
      case ViewMode.feed:
        return _buildFeedView();
      case ViewMode.calendar:
        return _buildCalendarView();
      case ViewMode.stats:
        return _buildStatsView();
      case ViewMode.collections:
        return _buildCollectionsView();
    }
  }

  Widget _buildFeedView() {
    final sessions = _filteredSessions;
    
    if (sessions.isEmpty) {
      return SliverToBoxAdapter(child: _buildEmptyState());
    }

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) {
          final session = sessions[index];
          return Container(
            margin: EdgeInsets.fromLTRB(20.w, 8.h, 20.w, 8.h),
            child: _buildSessionFeedCard(session, index),
          );
        },
        childCount: sessions.length,
      ),
    );
  }

  Widget _buildSessionFeedCard(CompletedSession session, int index) {
    final isSolo = session.type == SessionType.solo;
    final movieCount = isSolo ? session.likedMovieIds.length : session.matchedMovieIds.length;
    final relevantMovieIds = isSolo ? session.likedMovieIds : session.matchedMovieIds;
    
    // Get preview movies
    final previewMovies = relevantMovieIds.take(4).map((movieId) {
      return widget.currentUser!.likedMovies.firstWhere(
        (m) => m.id == movieId,
        orElse: () => Movie.empty(),
      );
    }).where((movie) => movie.id.isNotEmpty).toList();

    return GestureDetector(
      onTap: () => _openSessionDetail(session),
      child: TweenAnimationBuilder<double>(
        duration: Duration(milliseconds: 600 + (index * 100)),
        tween: Tween(begin: 0.0, end: 1.0),
        builder: (context, value, child) {
          return Transform.translate(
            offset: Offset(50 * (1 - value), 0),
            child: Opacity(
              opacity: value,
              child: GlassmorphicContainer(
                width: double.infinity,
                height: movieCount > 0 ? 160.h : 120.h,
                borderRadius: 20,
                blur: 15,
                alignment: Alignment.centerLeft,
                border: 2,
                linearGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: isSolo
                      ? [
                          Color(0xFFE5A00D).withValues(alpha: 0.15),
                          Colors.orange.withValues(alpha: 0.1),
                          Colors.white.withValues(alpha: 0.05),
                        ]
                      : [
                          Colors.blue.withValues(alpha: 0.15),
                          Colors.purple.withValues(alpha: 0.1),
                          Colors.white.withValues(alpha: 0.05),
                        ],
                ),
                borderGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    (isSolo ? Color(0xFFE5A00D) : Colors.blue).withValues(alpha: 0.6),
                    Colors.white.withValues(alpha: 0.2),
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.all(20.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header row
                      Row(
                        children: [
                          // Session type icon
                          Container(
                            padding: EdgeInsets.all(10.w),
                            decoration: BoxDecoration(
                              color: (isSolo ? Color(0xFFE5A00D) : Colors.blue).withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(12.r),
                              border: Border.all(
                                color: (isSolo ? Color(0xFFE5A00D) : Colors.blue).withValues(alpha: 0.3),
                                width: 1.w,
                              ),
                            ),
                            child: Icon(
                              isSolo ? Icons.person : Icons.people,
                              color: isSolo ? Color(0xFFE5A00D) : Colors.blue,
                              size: 16.sp,
                            ),
                          ),
                          
                          SizedBox(width: 16.w),
                          
                          // Session info
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  session.funTitle,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 18.sp,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 4.h),
                                Row(
                                  children: [
                                    Text(
                                      _formatRelativeDate(session.startTime),
                                      style: TextStyle(
                                        color: (isSolo ? Color(0xFFE5A00D) : Colors.blue),
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    if (!isSolo) ...[
                                      SizedBox(width: 8.w),
                                      Icon(
                                        Icons.circle,
                                        size: 4.sp,
                                        color: Colors.white54,
                                      ),
                                      SizedBox(width: 8.w),
                                      Expanded(
                                        child: Text(
                                          "With ${session.participantNames.where((name) => name != "You").join(", ")}",
                                          style: TextStyle(
                                            color: Colors.blue,
                                            fontSize: 12.sp,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ],
                            ),
                          ),
                          
                          // Movie count badge
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                            decoration: BoxDecoration(
                              color: (isSolo ? Color(0xFFE5A00D) : Colors.blue).withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(20.r),
                              border: Border.all(
                                color: (isSolo ? Color(0xFFE5A00D) : Colors.blue).withValues(alpha: 0.4),
                                width: 1.w,
                              ),
                            ),
                            child: Text(
                              "$movieCount",
                              style: TextStyle(
                                color: isSolo ? Color(0xFFE5A00D) : Colors.blue,
                                fontSize: 14.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      
                      // Movie posters preview
                      if (movieCount > 0 && previewMovies.isNotEmpty) ...[
                        SizedBox(height: 16.h),
                        Row(
                          children: [
                            Text(
                              isSolo ? "Your picks:" : "Matches:",
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12.sp,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(width: 12.w),
                            Expanded(
                              child: SizedBox(
                                height: 60.h,
                                child: Stack(
                                  children: [
                                    ...previewMovies.take(4).toList().asMap().entries.map((entry) {
                                      final index = entry.key;
                                      final movie = entry.value;
                                      return Positioned(
                                        left: index * 35.w,
                                        child: Container(
                                          width: 45.w,
                                          height: 60.h,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(8.r),
                                            border: Border.all(
                                              color: Colors.white.withValues(alpha: 0.3),
                                              width: 2.w,
                                            ),
                                          ),
                                          child: ClipRRect(
                                            borderRadius: BorderRadius.circular(6.r),
                                            child: Image.network(
                                              movie.posterUrl,
                                              fit: BoxFit.cover,
                                              errorBuilder: (_, __, ___) => Container(
                                                color: Colors.grey[800],
                                                child: Icon(
                                                  Icons.movie,
                                                  size: 16.sp,
                                                  color: Colors.white30,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    }).toList(),
                                    if (movieCount > 4)
                                      Positioned(
                                        left: 4 * 35.w,
                                        child: Container(
                                          width: 45.w,
                                          height: 60.h,
                                          decoration: BoxDecoration(
                                            color: Colors.black54,
                                            borderRadius: BorderRadius.circular(8.r),
                                            border: Border.all(
                                              color: Colors.white.withValues(alpha: 0.3),
                                              width: 2.w,
                                            ),
                                          ),
                                          child: Center(
                                            child: Text(
                                              "+${movieCount - 4}",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 10.sp,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCalendarView() {
    return SliverToBoxAdapter(
      child: Container(
        margin: EdgeInsets.all(20.w),
        child: Column(
          children: [
            _buildCalendarHeader(),
            SizedBox(height: 20.h),
            _buildCalendarGrid(),
          ],
        ),
      ),
    );
  }

  Widget _buildCalendarHeader() {
    final now = DateTime.now();
    final targetMonth = DateTime(now.year, now.month + _selectedMonthOffset, 1);
    final monthName = _getMonthName(targetMonth.month);
    
    return Row(
      children: [
        GestureDetector(
          onTap: () => setState(() => _selectedMonthOffset--),
          child: Container(
            padding: EdgeInsets.all(12.w),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12.r),
            ),
            child: Icon(Icons.chevron_left, color: Colors.white, size: 20.sp),
          ),
        ),
        
        Expanded(
          child: Text(
            "$monthName ${targetMonth.year}",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        
        GestureDetector(
          onTap: _selectedMonthOffset < 0 ? () => setState(() => _selectedMonthOffset++) : null,
          child: Container(
            padding: EdgeInsets.all(12.w),
            decoration: BoxDecoration(
              color: _selectedMonthOffset < 0 
                  ? Colors.white.withValues(alpha: 0.1)
                  : Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(12.r),
            ),
            child: Icon(
              Icons.chevron_right,
              color: _selectedMonthOffset < 0 ? Colors.white : Colors.white30,
              size: 20.sp,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCalendarGrid() {
    final now = DateTime.now();
    final targetMonth = DateTime(now.year, now.month + _selectedMonthOffset, 1);
    final daysInMonth = DateTime(targetMonth.year, targetMonth.month + 1, 0).day;
    final firstDayWeekday = targetMonth.weekday;
    
    // Get sessions for this month
    final monthSessions = _filteredSessions.where((session) {
      return session.startTime.year == targetMonth.year &&
             session.startTime.month == targetMonth.month;
    }).toList();
    
    // Group sessions by day
    final sessionsByDay = <int, List<CompletedSession>>{};
    for (final session in monthSessions) {
      final day = session.startTime.day;
      sessionsByDay[day] = [...(sessionsByDay[day] ?? []), session];
    }

    return GlassmorphicContainer(
      width: double.infinity,
      height: 300.h,
      borderRadius: 20,
      blur: 15,
      alignment: Alignment.center,
      border: 1,
      linearGradient: LinearGradient(
        colors: [
          Colors.white.withValues(alpha: 0.1),
          Colors.white.withValues(alpha: 0.05),
        ],
      ),
      borderGradient: LinearGradient(
        colors: [
          Colors.white.withValues(alpha: 0.3),
          Colors.white.withValues(alpha: 0.1),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(16.w),
        child: Column(
          children: [
            // Weekday headers
            Row(
              children: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
                  .map((day) => Expanded(
                        child: Text(
                          day,
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ))
                  .toList(),
            ),
            
            SizedBox(height: 12.h),
            
            // Calendar grid
            Expanded(
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 7,
                  childAspectRatio: 1,
                ),
                itemCount: 42, // 6 weeks
                itemBuilder: (context, index) {
                  final dayNumber = index - firstDayWeekday + 2;
                  final isValidDay = dayNumber > 0 && dayNumber <= daysInMonth;
                  final hasSessions = isValidDay && sessionsByDay.containsKey(dayNumber);
                  final sessionCount = hasSessions ? sessionsByDay[dayNumber]!.length : 0;
                  
                  if (!isValidDay) {
                    return Container(); // Empty cell
                  }
                  
                  return GestureDetector(
                    onTap: hasSessions ? () => _showDayDetailPopup(dayNumber, sessionsByDay[dayNumber]!) : null,
                    child: Container(
                      margin: EdgeInsets.all(2.w),
                      decoration: BoxDecoration(
                        gradient: hasSessions
                            ? LinearGradient(
                                colors: [Color(0xFFE5A00D), Colors.orange],
                              )
                            : null,
                        borderRadius: BorderRadius.circular(8.r),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.1),
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            dayNumber.toString(),
                            style: TextStyle(
                              color: hasSessions ? Colors.white : Colors.white60,
                              fontSize: 12.sp,
                              fontWeight: hasSessions ? FontWeight.bold : FontWeight.normal,
                            ),
                          ),
                          if (hasSessions)
                            Container(
                              margin: EdgeInsets.only(top: 2.h),
                              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.3),
                                borderRadius: BorderRadius.circular(6.r),
                              ),
                              child: Text(
                                sessionCount.toString(),
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 8.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsView() {
    final stats = _getDetailedStats();
    
    return SliverToBoxAdapter(
      child: Container(
        margin: EdgeInsets.all(20.w),
        child: Column(
          children: [
            _buildStatsCard("Overview", [
              _buildStatRow("Total Sessions", stats['totalSessions'].toString(), Icons.movie_filter),
              _buildStatRow("Total Matches", stats['totalMatches'].toString(), Icons.favorite),
              _buildStatRow("Success Rate", "${stats['successRate']}%", Icons.trending_up),
              _buildStatRow("Current Streak", "${stats['currentStreak']} days", Icons.local_fire_department),
            ]),
            
            SizedBox(height: 20.h),
            
            _buildStatsCard("Preferences", [
              _buildStatRow("Favorite Genre", stats['topGenre'], Icons.category),
              _buildStatRow("Avg Session", "${stats['avgDuration']} min", Icons.timer),
              _buildStatRow("Best Day", stats['bestDay'], Icons.calendar_today),
              _buildStatRow("Most Active", stats['mostActiveTime'], Icons.access_time),
            ]),
            
            SizedBox(height: 20.h),
            
            _buildStatsCard("Social", [
              _buildStatRow("Friend Sessions", stats['friendSessions'].toString(), Icons.people),
              _buildStatRow("Solo Sessions", stats['soloSessions'].toString(), Icons.person),
              _buildStatRow("Best Partner", stats['bestPartner'], Icons.star),
              _buildStatRow("Group Sessions", stats['groupSessions'].toString(), Icons.groups),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsCard(String title, List<Widget> rows) {
    return GlassmorphicContainer(
      width: double.infinity,
      height: (80 + (rows.length * 50)).h,
      borderRadius: 20,
      blur: 15,
      alignment: Alignment.topCenter,
      border: 2,
      linearGradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withValues(alpha: 0.1),
          Colors.white.withValues(alpha: 0.05),
        ],
      ),
      borderGradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color(0xFFE5A00D).withValues(alpha: 0.6),
          Colors.white.withValues(alpha: 0.2),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(20.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.h),
            ...rows,
          ],
        ),
      ),
    );
  }

  Widget _buildStatRow(String label, String value, IconData icon) {
    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      child: Row(
        children: [
          Icon(icon, color: Color(0xFFE5A00D), size: 20.sp),
          SizedBox(width: 12.w),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 14.sp,
              ),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              color: Colors.white,
              fontSize: 14.sp,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCollectionsView() {
    return SliverToBoxAdapter(
      child: Container(
        margin: EdgeInsets.all(20.w),
        child: Column(
          children: [
            _buildCollectionCard(
              "Favorite Picks",
              "Movies you loved most",
              Icons.favorite,
              Color(0xFFE5A00D),
              widget.currentUser!.likedMovies.take(6).toList(),
            ),
            
            SizedBox(height: 20.h),
            
            _buildCollectionCard(
              "Friend Matches",
              "Movies you matched with friends",
              Icons.people,
              Colors.blue,
              widget.currentUser!.matchedMovies.take(6).toList(),
            ),
            
            SizedBox(height: 20.h),
            
            _buildCollectionCard(
              "This Week's Finds",
              "Recent discoveries",
              Icons.new_releases,
              Colors.purple,
              _getThisWeekMovies(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCollectionCard(
    String title,
    String subtitle,
    IconData icon,
    Color color,
    List<Movie> movies,
  ) {
    return GlassmorphicContainer(
      width: double.infinity,
      height: 200.h,
      borderRadius: 20,
      blur: 15,
      alignment: Alignment.topLeft,
      border: 2,
      linearGradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          color.withValues(alpha: 0.15),
          Colors.white.withValues(alpha: 0.05),
        ],
      ),
      borderGradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          color.withValues(alpha: 0.6),
          Colors.white.withValues(alpha: 0.2),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(20.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 24.sp),
                SizedBox(width: 12.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12.sp,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  "${movies.length}",
                  style: TextStyle(
                    color: color,
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            
            SizedBox(height: 16.h),
            
            // Movie posters grid
            if (movies.isNotEmpty)
              Expanded(
                child: GridView.builder(
                  scrollDirection: Axis.horizontal,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 1,
                    childAspectRatio: 0.7,
                    mainAxisSpacing: 8.w,
                  ),
                  itemCount: math.min(movies.length, 6),
                  itemBuilder: (context, index) {
                    final movie = movies[index];
                    return GestureDetector(
                      onTap: () => _openWatchOptions(movie),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.r),
                          border: Border.all(
                            color: color.withValues(alpha: 0.3),
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(7.r),
                          child: Image.network(
                            movie.posterUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: Colors.grey[800],
                              child: Icon(Icons.movie, color: Colors.white30),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              )
            else
              Expanded(
                child: Center(
                  child: Text(
                    "No movies yet",
                    style: TextStyle(
                      color: Colors.white54,
                      fontSize: 14.sp,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildFloatingActionCluster() {
    return Positioned(
      bottom: 30.h,
      right: 20.w,
      child: _fabAnimation != null ? AnimatedBuilder(
        animation: _fabAnimation!,
        builder: (context, child) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Secondary actions (when expanded)
              if (_showFloatingActions) ...[
                Transform.scale(
                  scale: _fabAnimation!.value,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.blue.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(28.r),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.2),
                        width: 1.w,
                      ),
                    ),
                    child: FloatingActionButton(
                      heroTag: "friend",
                      mini: true,
                      backgroundColor: Colors.transparent,
                      elevation: 0,
                      onPressed: () => _startMatching('friend'),
                      child: Icon(Icons.people, size: 20.sp, color: Colors.white),
                    ),
                  ),
                ),
                SizedBox(height: 12.h),
                Transform.scale(
                  scale: _fabAnimation!.value * 0.9,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0xFFE5A00D).withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(28.r),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.2),
                        width: 1.w,
                      ),
                    ),
                    child: FloatingActionButton(
                      heroTag: "solo",
                      mini: true,
                      backgroundColor: Colors.transparent,
                      elevation: 0,
                      onPressed: () => _startMatching('solo'),
                      child: Icon(Icons.person, size: 20.sp, color: Colors.white),
                    ),
                  ),
                ),
                SizedBox(height: 16.h),
              ],
              
              // Main FAB
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.9),
                  borderRadius: BorderRadius.circular(28.r),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.3),
                    width: 1.w,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 8.r,
                      spreadRadius: 1.r,
                    ),
                  ],
                ),
                child: FloatingActionButton(
                  heroTag: "main",
                  backgroundColor: Colors.transparent,
                  foregroundColor: Colors.black87,
                  elevation: 0,
                  onPressed: () {
                    setState(() {
                      _showFloatingActions = !_showFloatingActions;
                    });
                    if (_showFloatingActions) {
                      _fabController?.forward();
                    } else {
                      _fabController?.reverse();
                    }
                  },
                  child: AnimatedRotation(
                    turns: _showFloatingActions ? 0.125 : 0,
                    duration: Duration(milliseconds: 300),
                    child: Icon(
                      _showFloatingActions ? Icons.close : Icons.add,
                      size: 24.sp,
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ) : // Fallback when animation is not ready
      Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Main FAB only when animations aren't ready
          Container(
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.9),
              borderRadius: BorderRadius.circular(28.r),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.3),
                width: 1.w,
              ),
            ),
            child: FloatingActionButton(
              heroTag: "main",
              backgroundColor: Colors.transparent,
              foregroundColor: Colors.black87,
              elevation: 0,
              onPressed: () => _startMatching('solo'), // Default to solo
              child: Icon(Icons.add, size: 24.sp),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      margin: EdgeInsets.all(40.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(32.w),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFFE5A00D).withValues(alpha: 0.2),
                  Colors.purple.withValues(alpha: 0.1),
                ],
              ),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.movie_creation,
              size: 64.sp,
              color: Color(0xFFE5A00D),
            ),
          ),
          
          SizedBox(height: 32.h),
          
          Text(
            "Your Cinema Journey Awaits",
            style: TextStyle(
              color: Colors.white,
              fontSize: 24.sp,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 12.h),
          
          Text(
            "Start your first movie session to begin building your personalized collection",
            style: TextStyle(
              color: Colors.white70,
              fontSize: 16.sp,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 32.h),
          
          ElevatedButton.icon(
            onPressed: () => _startMatching('solo'),
            icon: Icon(Icons.play_arrow, size: 20.sp),
            label: Text("Start First Session"),
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFFE5A00D),
              foregroundColor: Colors.black,
              padding: EdgeInsets.symmetric(horizontal: 32.w, vertical: 16.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25.r),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoUserState() {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.person_off, size: 64.sp, color: Colors.white30),
            SizedBox(height: 16.h),
            Text(
              "Profile Required",
              style: TextStyle(color: Colors.white, fontSize: 20.sp, fontWeight: FontWeight.bold),
            ),
            Text(
              "Please set up your profile first",
              style: TextStyle(color: Colors.white70, fontSize: 14.sp),
            ),
          ],
        ),
      ),
    );
  }

  // Helper methods
  IconData _getViewModeIcon(ViewMode mode) {
    switch (mode) {
      case ViewMode.feed:
        return Icons.view_stream;
      case ViewMode.calendar:
        return Icons.calendar_month;
      case ViewMode.stats:
        return Icons.analytics;
      case ViewMode.collections:
        return Icons.collections;
    }
  }

  Map<String, dynamic> _getQuickStats() {
    final sessions = widget.currentUser?.sessionHistory ?? [];
    return {
      'total': sessions.length,
      'streak': _calculateStreak(),
      'matches': sessions.fold(0, (sum, s) => sum + s.matchedMovieIds.length),
    };
  }

  Map<String, dynamic> _getDetailedStats() {
    final sessions = widget.currentUser?.sessionHistory ?? [];
    
    return {
      'totalSessions': sessions.length,
      'totalMatches': sessions.fold(0, (sum, s) => sum + s.matchedMovieIds.length),
      'successRate': sessions.isEmpty ? 0 : 
          (sessions.where((s) => s.likedMovieIds.isNotEmpty || s.matchedMovieIds.isNotEmpty).length / sessions.length * 100).round(),
      'currentStreak': _calculateStreak(),
      'topGenre': _getTopGenre(),
      'avgDuration': sessions.isEmpty ? 0 : 
          sessions.map((s) => s.duration.inMinutes).reduce((a, b) => a + b) ~/ sessions.length,
      'bestDay': _getBestDay(),
      'mostActiveTime': _getMostActiveTime(),
      'friendSessions': sessions.where((s) => s.type != SessionType.solo).length,
      'soloSessions': sessions.where((s) => s.type == SessionType.solo).length,
      'bestPartner': _getBestPartner(),
      'groupSessions': sessions.where((s) => s.type == SessionType.group).length,
    };
  }

  int _calculateStreak() {
    final sessions = widget.currentUser?.sessionHistory ?? [];
    if (sessions.isEmpty) return 0;
    
    final sortedSessions = sessions.toList()
      ..sort((a, b) => b.startTime.compareTo(a.startTime));
    
    int streak = 0;
    DateTime? lastDate;
    
    for (final session in sortedSessions) {
      final sessionDate = DateTime(
        session.startTime.year,
        session.startTime.month,
        session.startTime.day,
      );
      
      if (lastDate == null) {
        lastDate = sessionDate;
        streak = 1;
      } else {
        final daysDiff = lastDate.difference(sessionDate).inDays;
        if (daysDiff == 1) {
          streak++;
          lastDate = sessionDate;
        } else {
          break;
        }
      }
    }
    
    return streak;
  }

  String _getTopGenre() {
    final genreScores = widget.currentUser?.genreScores ?? {};
    if (genreScores.isEmpty) return "None";
    
    final topEntry = genreScores.entries.reduce((a, b) => a.value > b.value ? a : b);
    return topEntry.key;
  }

  String _getBestDay() {
    final sessions = widget.currentUser?.sessionHistory ?? [];
    if (sessions.isEmpty) return "None";
    
    final dayCount = <int, int>{};
    for (final session in sessions) {
      final weekday = session.startTime.weekday;
      dayCount[weekday] = (dayCount[weekday] ?? 0) + 1;
    }
    
    final bestDay = dayCount.entries.reduce((a, b) => a.value > b.value ? a : b);
    const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return dayNames[bestDay.key - 1];
  }

  String _getMostActiveTime() {
    final sessions = widget.currentUser?.sessionHistory ?? [];
    if (sessions.isEmpty) return "None";
    
    final hourCount = <int, int>{};
    for (final session in sessions) {
      final hour = session.startTime.hour;
      hourCount[hour] = (hourCount[hour] ?? 0) + 1;
    }
    
    final mostActiveHour = hourCount.entries.reduce((a, b) => a.value > b.value ? a : b);
    final hour = mostActiveHour.key;
    
    if (hour < 12) return "Morning";
    if (hour < 17) return "Afternoon";
    if (hour < 21) return "Evening";
    return "Night";
  }

  String _getBestPartner() {
    final sessions = widget.currentUser?.sessionHistory ?? [];
    final partnerSessions = sessions.where((s) => s.type != SessionType.solo);
    
    if (partnerSessions.isEmpty) return "None";
    
    final partnerCount = <String, int>{};
    for (final session in partnerSessions) {
      for (final participant in session.participantNames) {
        if (participant != "You") {
          partnerCount[participant] = (partnerCount[participant] ?? 0) + 1;
        }
      }
    }
    
    if (partnerCount.isEmpty) return "None";
    
    final bestPartner = partnerCount.entries.reduce((a, b) => a.value > b.value ? a : b);
    return bestPartner.key;
  }

  List<Movie> _getThisWeekMovies() {
    final now = DateTime.now();
    final weekAgo = now.subtract(Duration(days: 7));
    
    final thisWeekSessions = widget.currentUser?.sessionHistory
        .where((s) => s.startTime.isAfter(weekAgo)) ?? [];
    
    final movieIds = <String>{};
    for (final session in thisWeekSessions) {
      movieIds.addAll(session.likedMovieIds);
      movieIds.addAll(session.matchedMovieIds);
    }
    
    return movieIds.map((id) {
      return widget.currentUser!.likedMovies.firstWhere(
        (m) => m.id == id,
        orElse: () => Movie.empty(),
      );
    }).where((movie) => movie.id.isNotEmpty).take(6).toList();
  }

  String _getMonthName(int month) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return months[month - 1];
  }

  void _showFilterMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.all(20.w),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1F1F1F),
              Color(0xFF121212),
            ],
          ),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Filter Sessions",
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 20.h),
            ...SessionFilter.values.map((filter) {
              return ListTile(
                leading: Icon(
                  _currentFilter == filter ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                  color: Color(0xFFE5A00D),
                ),
                title: Text(
                  _getFilterName(filter),
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  setState(() => _currentFilter = filter);
                  Navigator.pop(context);
                },
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  String _getFilterName(SessionFilter filter) {
    switch (filter) {
      case SessionFilter.all:
        return "All Sessions";
      case SessionFilter.solo:
        return "Solo Only";
      case SessionFilter.friends:
        return "With Friends";
      case SessionFilter.thisWeek:
        return "This Week";
      case SessionFilter.thisMonth:
        return "This Month";
    }
  }

  void _showDayDetailPopup(int day, List<CompletedSession> sessions) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: GlassmorphicContainer(
          width: 300.w,
          height: 400.h,
          borderRadius: 20,
          blur: 15,
          alignment: Alignment.center,
          border: 2,
          linearGradient: LinearGradient(
            colors: [
              Color(0xFF1A1A2E).withValues(alpha: 0.9),
              Color(0xFF16213E).withValues(alpha: 0.9),
            ],
          ),
          borderGradient: LinearGradient(
            colors: [
              Color(0xFFE5A00D).withValues(alpha: 0.6),
              Colors.white.withValues(alpha: 0.2),
            ],
          ),
          child: Padding(
            padding: EdgeInsets.all(20.w),
            child: Column(
              children: [
                Text(
                  "Day $day Sessions",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 20.h),
                Expanded(
                  child: ListView.builder(
                    itemCount: sessions.length,
                    itemBuilder: (context, index) {
                      final session = sessions[index];
                      return Container(
                        margin: EdgeInsets.only(bottom: 12.h),
                        padding: EdgeInsets.all(12.w),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              session.funTitle,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              "${session.type == SessionType.solo ? session.likedMovieIds.length : session.matchedMovieIds.length} movies",
                              style: TextStyle(
                                color: Color(0xFFE5A00D),
                                fontSize: 12.sp,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text("Close"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFE5A00D),
                    foregroundColor: Colors.black,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openSessionDetail(CompletedSession session) {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => SessionDetailScreen(
          session: session,
          currentUser: widget.currentUser!,
          onStartNewSession: () {
            Navigator.pop(context);
            _startMatching(session.type == SessionType.solo ? 'solo' : 'friend');
          },
        ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: animation.drive(
              Tween(begin: const Offset(1.0, 0.0), end: Offset.zero)
                  .chain(CurveTween(curve: Curves.easeInOut)),
            ),
            child: child,
          );
        },
      ),
    );
  }

  void _openWatchOptions(Movie movie) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => WatchOptionsScreen(
          movie: movie,
          currentUser: widget.currentUser!,
          onContinueSession: () {
            Navigator.pop(context);
            _startMatching('solo');
          },
        ),
      ),
    );
  }

  void _startMatching(String mode) {
    DebugLogger.log("🎯 Starting $mode matching...");
    
    if (widget.onNavigateToMatcher != null) {
      widget.onNavigateToMatcher!(mode);
    } else {
      DebugLogger.log("❌ No navigation callback provided");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Unable to start matching session'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  void _showNotifications() {
    // TODO: Implement notification panel
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Notifications - Coming soon!'),
        backgroundColor: Color(0xFF1A1A2E),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  bool _hasUnreadNotifications() {
    // TODO: Implement actual notification logic
    // For now, return false to hide the red dot
    return false;
  }

  String _formatRelativeDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays == 0) {
      if (difference.inHours == 0) {
        return '${difference.inMinutes}m ago';
      }
      return '${difference.inHours}h ago';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
}