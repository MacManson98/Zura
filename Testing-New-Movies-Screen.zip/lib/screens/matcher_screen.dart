import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../movie.dart';
import '../utils/movie_loader.dart';
import '../models/user_profile.dart';
import '../utils/user_profile_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/session_invitation_widget.dart';
import 'match_celebration_screen.dart';
import 'movie_detail_screen.dart';
import '../utils/tmdb_api.dart';
import '../utils/mood_based_learning_engine.dart';
import '../widgets/mood_selection_widget.dart';
import '../models/session_models.dart';
import '../services/session_service.dart';
import '../main_navigation.dart';
import '../utils/debug_loader.dart';
import '../models/completed_session.dart';

// Define matching modes
enum MatchingMode { 
  solo,
  friend,
  group,
}

class MatcherScreen extends StatefulWidget {
  final List<Movie> allMovies;
  final UserProfile currentUser;
  final List<UserProfile> availableFriends;
  final bool showTutorial;
  final UserProfile? selectedFriend;
  final MatchingMode mode;

  const MatcherScreen({
    super.key,
    required this.allMovies,
    required this.currentUser,
    required this.availableFriends,
    this.showTutorial = false,
    this.selectedFriend,
    this.mode = MatchingMode.solo,
  });

  @override
  State<MatcherScreen> createState() => _MatcherScreenState();
}

class _MatcherScreenState extends State<MatcherScreen> {
  late List<Movie> sessionPool = [];
  final Set<String> currentUserLikes = {};
  MatchingMode currentMode = MatchingMode.solo;
  UserProfile? selectedFriend;
  List<UserProfile> selectedGroup = [];
  final Map<String, Set<String>> groupLikes = {};
  bool _showTutorial = true;
  int _tutorialPage = 0;
  final PageController _tutorialPageController = PageController();
  late List<Movie> movieDatabase = [];
  final Set<String> currentSessionMovieIds = {};
  bool _isLoadingSession = false;
  late List<Movie> _basePool = [];
  late List<Movie> _dynamicPool = [];
  int _swipeCount = 0;
  bool _isRefreshingPool = false;
  SessionContext? currentSessionContext;
  List<CurrentMood> selectedMoods = [];
  bool _showMoodSelectionModal = false;
  bool _isReadyToSwipe = false;
  SwipeSession? currentSession;
  StreamSubscription<SwipeSession>? sessionSubscription;
  bool isWaitingForFriend = false;
  bool isInCollaborativeMode = false;
  Set<String> sessionPassedMovieIds = {};
  Timer? _sessionTimer;
  bool _hasStartedSession = false;

  
  @override
  void initState() {
    super.initState();
    
    // Register callback for direct session joining
    MainNavigation.setSessionCallback(_startCollaborativeSession);
    currentMode = widget.mode;
    selectedFriend = widget.selectedFriend;
    _initializeApp();
    _startSessionTimer();
  }

  void _startSessionTimer() {
    _sessionTimer = Timer.periodic(const Duration(minutes: 1), (timer) {
      if (SessionManager.shouldAutoEnd()) {
        _autoEndSession();
      }
    });
  }

    // NEW: Auto-end session due to inactivity
  void _autoEndSession() {
    if (SessionManager.hasActiveSession) {
      final completedSession = SessionManager.endSession();
      if (completedSession != null) {
        widget.currentUser.addCompletedSession(completedSession);
        UserProfileStorage.saveProfile(widget.currentUser);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Session ended due to inactivity'),
            backgroundColor: Colors.orange,
            duration: const Duration(seconds: 3),
          ),
        );
      }
      
      setState(() {
        _hasStartedSession = false;
      });
    }
  }

  // NEW: Manual end session
  void _endSession() {
    if (SessionManager.hasActiveSession) {
      final completedSession = SessionManager.endSession();
      if (completedSession != null) {
        widget.currentUser.addCompletedSession(completedSession);
        UserProfileStorage.saveProfile(widget.currentUser);
        
        // Show session summary
        _showSessionSummary(completedSession);
      }
      
      setState(() {
        _hasStartedSession = false;
      });
    }
  }

  // NEW: Show session summary dialog
  void _showSessionSummary(CompletedSession session) {
    final isSolo = session.type == SessionType.solo;
    final count = isSolo ? session.likedMovieIds.length : session.matchedMovieIds.length;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "Session Complete! 🎉",
          style: TextStyle(color: Colors.white, fontSize: 18.sp),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              session.funTitle,
              style: TextStyle(
                color: const Color(0xFFE5A00D),
                fontSize: 16.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 12.h),
            Text(
              isSolo 
                  ? "You liked $count movie${count == 1 ? '' : 's'}"
                  : "You made $count match${count == 1 ? '' : 'es'}",
              style: TextStyle(color: Colors.white70, fontSize: 14.sp),
            ),
            SizedBox(height: 8.h),
            Text(
              "Duration: ${_formatDuration(session.duration)}",
              style: TextStyle(color: Colors.white70, fontSize: 14.sp),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              "Great!",
              style: TextStyle(color: const Color(0xFFE5A00D)),
            ),
          ),
        ],
      ),
    );
  }

  // NEW: Format duration helper
  String _formatDuration(Duration duration) {
    if (duration.inHours > 0) {
      return "${duration.inHours}h ${duration.inMinutes % 60}m";
    } else {
      return "${duration.inMinutes}m";
    }
  }

  void _startSessionIfNeeded() {
    if (!_hasStartedSession && !SessionManager.hasActiveSession) {
      final sessionType = currentMode == MatchingMode.solo 
          ? SessionType.solo
          : currentMode == MatchingMode.friend 
              ? SessionType.friend 
              : SessionType.group;
      
      final participantNames = <String>["You"];
      if (sessionType == SessionType.friend && selectedFriend != null) {
        participantNames.add(selectedFriend!.name);
      } else if (sessionType == SessionType.group) {
        participantNames.addAll(selectedGroup.map((f) => f.name));
      }
      
      SessionManager.startSession(
        type: sessionType,
        participantNames: participantNames,
        mood: selectedMoods.isNotEmpty ? selectedMoods.first.displayName : null,
      );
      
      setState(() {
        _hasStartedSession = true;
      });
    }
  }

  // NEW: Start popular movies session
  void _startPopularMoviesSession() async {
    DebugLogger.log("🔥 Starting popular movies session");
    
    setState(() {
      _isLoadingSession = true;
      _isReadyToSwipe = true;
      selectedMoods.clear(); // Clear any existing moods
      currentSessionContext = null; // Clear mood context
    });

    try {
      final popularMovies = await TMDBApi.getPopularMovies();
      
      if (popularMovies.isEmpty) {
        _showErrorAndReset("Failed to load popular movies. Please check your internet connection.");
        return;
      }

      // Filter out movies the user has already seen
      final seenMovieIds = <String>{
        ...widget.currentUser.likedMovieIds,
        ...widget.currentUser.passedMovieIds,
      };

      final unseenMovies = popularMovies
          .where((movie) => !seenMovieIds.contains(movie.id))
          .toList();

      if (unseenMovies.isEmpty) {
        _showErrorAndReset("You've seen all the popular movies! Try selecting a mood instead.");
        return;
      }

      setState(() {
        sessionPool = unseenMovies;
        currentSessionMovieIds.clear();
        currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
      });

      DebugLogger.log("🎬 Loaded ${sessionPool.length} popular movies");

    } catch (e) {
      DebugLogger.log("❌ Error loading popular movies: $e");
      _showErrorAndReset("Failed to load popular movies. Please try again.");
    } finally {
      setState(() => _isLoadingSession = false);
    }
  }

  // NEW: Show error and reset to selection state
  void _showErrorAndReset(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 3),
      ),
    );
    
    setState(() {
      _isLoadingSession = false;
      _isReadyToSwipe = false;
      sessionPool.clear();
      currentSessionMovieIds.clear();
    });
  }

  // Show mood picker modal
  void _showMoodPicker() {
    setState(() {
      _showMoodSelectionModal = true;
    });
  }

  // Reset to selection state
  void _resetToSelection() {
    setState(() {
      _isReadyToSwipe = false;
      selectedMoods.clear();
      currentSessionContext = null;
      sessionPool.clear();
      sessionPassedMovieIds.clear();
    });
  }

  // Helper methods for button states
  bool _canStartSession() {
    switch (currentMode) {
      case MatchingMode.solo:
        return true;
      case MatchingMode.friend:
        return selectedFriend != null;
      case MatchingMode.group:
        return selectedGroup.isNotEmpty;
    }
  }

  void _onMoodSelected(List<CurrentMood> moods) async {
    DebugLogger.log("🔍 DEBUG: _onMoodSelected called with ${moods.length} mood(s)");
    
    setState(() {
      selectedMoods = moods;
      _showMoodSelectionModal = false;
      _isLoadingSession = true;
      _isReadyToSwipe = true;
    });

    // Create session context based on selected moods
    if (moods.length == 1) {
      currentSessionContext = SessionContext(
        moods: moods.first,
        groupMemberIds: currentMode == MatchingMode.group 
            ? selectedGroup.map((f) => f.uid).toList()
            : currentMode == MatchingMode.friend && selectedFriend != null
                ? [selectedFriend!.uid]
                : [],
      );
    } else {
      currentSessionContext = _createBlendedSessionContext(moods);
    }

    // For collaborative sessions, send mood change request instead of direct generation
    if (isInCollaborativeMode && currentSession != null) {
      final isHost = currentSession!.hostId == widget.currentUser.uid;
      DebugLogger.log("🔍 DEBUG: isHost: $isHost");
      
      // If session already has different mood, send mood change request
      if (currentSession!.hasMoodSelected && 
          currentSession!.selectedMoodId != moods.first.toString().split('.').last) {
        
        await _sendMoodChangeRequest(requestedMood: moods.first);
        setState(() => _isLoadingSession = false);
        return;
      }
      
      // Otherwise, generate collaborative session normally
      await _generateCollaborativeSession();
    } else {
      // Solo/local sessions
      if (moods.length == 1) {
        await _generateMoodBasedSession();
      } else {
        await _generateBlendedMoodSession();
      }
    }
  }

  SessionContext _createBlendedSessionContext(List<CurrentMood> moods) {
    // Combine all preferred genres and vibes from selected moods
    final Set<String> combinedGenres = {};
    final Set<String> combinedVibes = {};
    
    for (final mood in moods) {
      combinedGenres.addAll(mood.preferredGenres);
      combinedVibes.addAll(mood.preferredVibes);
    }
    
    DebugLogger.log("🎭 Blending ${moods.length} moods: ${moods.map((m) => m.displayName).join(' + ')}");
    DebugLogger.log("   Combined genres: ${combinedGenres.join(', ')}");
    DebugLogger.log("   Combined vibes: ${combinedVibes.join(', ')}");
    
    // Create a temporary mood with combined preferences
    // We'll use the first mood as the base and add combined preferences
    return SessionContext(
      moods: selectedMoods.first, // Base mood for the session context
      groupMemberIds: currentMode == MatchingMode.group 
          ? selectedGroup.map((f) => f.uid).toList()
          : currentMode == MatchingMode.friend && selectedFriend != null
              ? [selectedFriend!.uid]
              : [],
    );
  }

  Future<void> _generateBlendedMoodSession() async {
    if (movieDatabase.isEmpty || selectedMoods.isEmpty) {
      _showErrorAndReset("Movie database not loaded. Please try again.");
      return;
    }
    
    final seenMovieIds = <String>{
      ...widget.currentUser.likedMovieIds,
      ...widget.currentUser.passedMovieIds,
      ...currentSessionMovieIds,
    };
    
    try {
      DebugLogger.log("🎭 Generating PURE blended mood session for: ${selectedMoods.map((m) => m.displayName).join(' + ')}");
      
      final blendedMovies = await MoodBasedLearningEngine.generateBlendedMoodSession(
        user: widget.currentUser,
        movieDatabase: movieDatabase,
        selectedMoods: selectedMoods,
        seenMovieIds: seenMovieIds,
        sessionPassedMovieIds: sessionPassedMovieIds,
        sessionSize: 30,
      );
      
      if (blendedMovies.isEmpty) {
        _showErrorAndReset("No movies found for this mood combination. Try a different mood.");
        return;
      }
      
      setState(() {
        sessionPool.clear();
        sessionPool.addAll(blendedMovies);
        _isLoadingSession = false;
      });
      
      currentSessionMovieIds.clear();
      currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
      
      DebugLogger.log("🎬 Generated ${sessionPool.length} pure blended mood movies");
      
    } catch (e) {
      DebugLogger.log("❌ Error generating blended mood session: $e");
      _showErrorAndReset("Failed to generate movies for this mood. Please try again.");
    }
  }

  @override
  void didUpdateWidget(MatcherScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    
    // Check if the mode parameter has changed
    if (oldWidget.mode != widget.mode) {
      DebugLogger.log("🔄 Mode changed from ${oldWidget.mode} to ${widget.mode}");
      
      setState(() {
        currentMode = widget.mode;
        
        // Reset session state when mode changes
        _resetToSelection();
        
        // Clear selections when switching away from those modes
        if (currentMode != MatchingMode.friend) {
          selectedFriend = null;
        }
        if (currentMode != MatchingMode.group) {
          selectedGroup.clear();
          groupLikes.clear();
        }
      });
      
      // Regenerate session if needed
      if (currentMode == MatchingMode.solo) {
        _initializeApp();
      }
    }
    
    // Check if selectedFriend parameter has changed
    if (oldWidget.selectedFriend != widget.selectedFriend) {
      DebugLogger.log("🔄 Selected friend changed from ${oldWidget.selectedFriend?.name} to ${widget.selectedFriend?.name}");
      
      setState(() {
        selectedFriend = widget.selectedFriend;
      });
    }
  }

  Future<void> _generateMoodBasedSession() async {
    if (movieDatabase.isEmpty || currentSessionContext == null) {
      _showErrorAndReset("Movie database not loaded. Please try again.");
      return;
    }
    
    final seenMovieIds = <String>{
      ...widget.currentUser.likedMovieIds,
      ...widget.currentUser.passedMovieIds,
      ...currentSessionMovieIds,
    };
    
    try {
      DebugLogger.log("🎭 Generating mood-based session: ${selectedMoods.first.displayName}");
      
      if (currentMode == MatchingMode.solo) {
        // Solo mood session
        sessionPool = await MoodBasedLearningEngine.generateMoodBasedSession(
          user: widget.currentUser,
          movieDatabase: movieDatabase,
          sessionContext: currentSessionContext!,
          seenMovieIds: seenMovieIds,
          sessionPassedMovieIds: sessionPassedMovieIds,
          sessionSize: 30,
        );
      } else {
        // Friend/Group mood session - everyone gets same pool
        final groupMembers = currentMode == MatchingMode.friend && selectedFriend != null
            ? [widget.currentUser, selectedFriend!]
            : currentMode == MatchingMode.group
                ? [widget.currentUser, ...selectedGroup]
                : [widget.currentUser];
        
        sessionPool = await MoodBasedLearningEngine.generateGroupSession(
          groupMembers: groupMembers,
          movieDatabase: movieDatabase,
          sessionContext: currentSessionContext!,
          seenMovieIds: seenMovieIds,
          sessionSize: 25,
        );
      }
      
      if (sessionPool.isEmpty) {
        _showErrorAndReset("No movies found for this mood. Try a different mood or popular movies.");
        return;
      }
      
      currentSessionMovieIds.clear();
      currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
      
      DebugLogger.log("🎭 Generated ${sessionPool.length} movies for ${currentMode.name} mood session");
      if (sessionPool.isNotEmpty) {
        DebugLogger.log("   Sample movies: ${sessionPool.take(3).map((m) => m.title).join(', ')}");
      }
      
    } catch (e) {
      DebugLogger.log("❌ Error generating mood-based session: $e");
      _showErrorAndReset("Failed to generate movies for this mood. Please try again.");
    } finally {
      setState(() {
        _isLoadingSession = false;
      });
    }
  }

  Future<void> _initializeApp() async {
    setState(() => _isLoadingSession = true);
    
    try {
      // Load movie database
      movieDatabase = await MovieDatabaseLoader.loadMovieDatabase();
      
      if (movieDatabase.isEmpty) {
        _showErrorAndReset("Failed to load movie database. Please check your internet connection.");
        return;
      }
      
      // Check if we should show the "Learning your taste..." banner
      if (!widget.currentUser.hasSeenMatcher) {
        widget.currentUser.hasSeenMatcher = true;
        await UserProfileStorage.saveProfile(widget.currentUser);
      }
    } catch (e) {
      DebugLogger.log("❌ Error initializing app: $e");
      _showErrorAndReset("Failed to initialize the app. Please try again.");
    } finally {
      setState(() => _isLoadingSession = false);
    }
  }

  Widget _buildSmartBanner() {
    if (_showMoodSelectionModal) {
      return const SizedBox.shrink();
    }
    
    // Show mood banner for mood-based sessions OR collaborative sessions
    if (selectedMoods.isNotEmpty) {
      return _buildMoodBanner();
    }
    
    // Show popular movies banner
    if (_isReadyToSwipe && selectedMoods.isEmpty) {
      return _buildPopularMoviesBanner();
    }
    
    return const SizedBox.shrink();
  }

  Widget _buildPopularMoviesBanner() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 6.h),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFFE5A00D).withValues(alpha: 0.8),
            const Color(0xFFB8860B).withValues(alpha: 0.8),
          ],
        ),
        borderRadius: BorderRadius.circular(12.r),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
            blurRadius: 4.r,
            offset: Offset(0, 1.h),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(12.r),
        child: Row(
          children: [
            // Popular movies emoji
            Container(
              padding: EdgeInsets.all(6.r),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8.r),
              ),
              child: Text(
                "🔥",
                style: TextStyle(fontSize: 18.sp),
              ),
            ),
            SizedBox(width: 10.w),
            
            // Text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "Popular Movies",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13.sp,
                      fontWeight: FontWeight.bold,
                      height: 1.2,
                    ),
                  ),
                  Text(
                    "Trending movies everyone's watching",
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.85),
                      fontSize: 11.sp,
                      height: 1.2,
                    ),
                  ),
                ],
              ),
            ),
            
            // Try different button
            GestureDetector(
              onTap: () {
                setState(() {
                  _showMoodSelectionModal = true;
                });
              },
              child: Container(
                padding: EdgeInsets.all(6.r),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.white.withValues(alpha: 0.6), width: 1.w),
                  borderRadius: BorderRadius.circular(6.r),
                ),
                child: Icon(
                  Icons.mood,
                  color: Colors.white,
                  size: 16.sp,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMoodBanner() {
    String moodText;
    String moodEmoji;
    
    if (selectedMoods.length == 1) {
      moodText = "${selectedMoods.first.displayName} vibes";
      moodEmoji = selectedMoods.first.emoji;
    } else {
      moodText = "Blended vibes: ${selectedMoods.map((m) => m.displayName).take(2).join(' + ')}${selectedMoods.length > 2 ? ' +${selectedMoods.length - 2}' : ''}";
      moodEmoji = selectedMoods.take(3).map((m) => m.emoji).join();
    }
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 6.h),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isInCollaborativeMode 
              ? [
                  const Color(0xFF4A90E2).withValues(alpha: 0.9),
                  const Color(0xFF357ABD).withValues(alpha: 0.9),
                ]
              : [
                  const Color(0xFF4A90E2).withValues(alpha: 0.8),
                  const Color(0xFF357ABD).withValues(alpha: 0.8),
                ],
        ),
        borderRadius: BorderRadius.circular(12.r),
        boxShadow: [
          BoxShadow(
            color: (isInCollaborativeMode ? const Color(0xFF4A90E2) : const Color(0xFF4A90E2)).withValues(alpha: 0.3),
            blurRadius: 4.r,
            offset: Offset(0, 1.h),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(12.r),
        child: Row(
          children: [
            // Compact mood emoji
            Container(
              padding: EdgeInsets.all(6.r),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8.r),
              ),
              child: Text(
                moodEmoji,
                style: TextStyle(fontSize: 18.sp),
              ),
            ),
            SizedBox(width: 10.w),
            
            // Compact mood text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    moodText,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13.sp,
                      fontWeight: FontWeight.bold,
                      height: 1.2,
                    ),
                  ),
                  Text(
                    isInCollaborativeMode ? "Swiping together with this mood" : "Finding perfect movies",
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.85),
                      fontSize: 11.sp,
                      height: 1.2,
                    ),
                  ),
                ],
              ),
            ),
            
            // Action buttons
            if (isInCollaborativeMode) ...[
              // Change Vibe button
              GestureDetector(
                onTap: _requestMoodChange,
                child: Container(
                  padding: EdgeInsets.all(6.r),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white.withValues(alpha: 0.6), width: 1.w),
                    borderRadius: BorderRadius.circular(6.r),
                  ),
                  child: Icon(
                    Icons.mood,
                    color: Colors.white,
                    size: 16.sp,
                  ),
                ),
              ),
              SizedBox(width: 8.w),
              
              // End Session button
              GestureDetector(
                onTap: _cancelSessionForBoth,
                child: Container(
                  padding: EdgeInsets.all(6.r),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.red.withValues(alpha: 0.8), width: 1.w),
                    borderRadius: BorderRadius.circular(6.r),
                  ),
                  child: Icon(
                    Icons.close,
                    color: Colors.red.withValues(alpha: 0.9),
                    size: 16.sp,
                  ),
                ),
              ),
            ] else ...[
              // Solo mode - just refresh button
              GestureDetector(
                onTap: () {
                  setState(() {
                    _showMoodSelectionModal = true;
                    selectedMoods.clear();
                    currentSessionContext = null;
                  });
                },
                child: Container(
                  padding: EdgeInsets.all(6.r),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white.withValues(alpha: 0.6), width: 1.w),
                    borderRadius: BorderRadius.circular(6.r),
                  ),
                  child: Icon(
                    Icons.refresh,
                    color: Colors.white,
                    size: 16.sp,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Loading state for when generating sessions
  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(color: Color(0xFFE5A00D)),
          SizedBox(height: 16.h),
          Text(
            "Generating personalized recommendations...",
            style: TextStyle(
              color: Colors.white70,
              fontSize: 16.sp,
            ),
          ),
        ],
      ),
    );
  }

  void likeMovie(Movie movie) async {
    _startSessionIfNeeded();
    SessionManager.addLikedMovie(movie.id);
    // Track with timestamp and session type
        final sessionType = currentMode == MatchingMode.solo 
          ? "solo" 
          : currentMode == MatchingMode.friend 
              ? "friend" 
              : "group";
              
      widget.currentUser.recentLikes.add(MovieLike(
        movieId: movie.id,
        likedAt: DateTime.now(),
        sessionType: sessionType,
      ));
      
      // Keep only last 50 likes to prevent unlimited growth
      if (widget.currentUser.recentLikes.length > 50) {
        widget.currentUser.recentLikes.removeRange(
          0, 
          widget.currentUser.recentLikes.length - 50
        );
      }
      
      setState(() {
        widget.currentUser.likedMovies.add(movie);
        widget.currentUser.likedMovieIds.add(movie.id);
      });

      try {
        await UserProfileStorage.saveProfile(widget.currentUser);
      } catch (e) {
        DebugLogger.log("⚠️ Error saving user profile: $e");
      }

      // Match logic (existing code)
      if (currentMode == MatchingMode.friend &&
          selectedFriend?.likedMovieIds.contains(movie.id) == true) {
        SessionManager.addMatchedMovie(movie.id);
        _showMatchCelebration(movie);
      }

      if (currentMode == MatchingMode.group) {
        groupLikes[widget.currentUser.name]?.add(movie.title);
        final everyone = [widget.currentUser.name, ...selectedGroup.map((f) => f.name)];
        final allLiked = everyone.every((name) => groupLikes[name]?.contains(movie.title) == true);
        if (allLiked) {
          SessionManager.addMatchedMovie(movie.id);
          _showMatchCelebration(movie);
        }
      }
    }

  void passMovie(Movie movie) {
    _startSessionIfNeeded();
    SessionManager.recordActivity();
    // For mood sessions, this is just "not in mood tonight" - very light learning
    if (currentSessionContext != null && !currentSessionContext!.moods.isProfileBased) {
      // Already handled in _onSwipe via MoodBasedLearningEngine.learnFromMoodInteraction
      DebugLogger.log("👎 Not in mood for: ${movie.title} (light learning applied)");
    }
    // Save profile
    UserProfileStorage.saveProfile(widget.currentUser);
  }

  void _showMatchCelebration(Movie matchedMovie) {
    DebugLogger.log("🔍 ===========================================");
    DebugLogger.log("🔍 _showMatchCelebration DEBUG START");
    DebugLogger.log("🔍 ===========================================");
    DebugLogger.log("🔍 isInCollaborativeMode: $isInCollaborativeMode");
    DebugLogger.log("🔍 currentSession == null: ${currentSession == null}");
    
    if (currentSession != null) {
      DebugLogger.log("🔍 ✅ currentSession EXISTS!");
      DebugLogger.log("🔍 currentSession.sessionId: ${currentSession!.sessionId}");
      DebugLogger.log("🔍 currentSession.status: ${currentSession!.status}");
      DebugLogger.log("🔍 currentSession.matches: ${currentSession!.matches}");
      DebugLogger.log("🔍 currentSession.participantNames: ${currentSession!.participantNames}");
    } else {
      DebugLogger.log("🔍 ❌ currentSession is NULL - this should NOT happen!");
    }
    
    // Get friend name
    String? friendName;
    if (isInCollaborativeMode && currentSession != null) {
      final friendNames = currentSession!.participantNames
          .where((name) => name != widget.currentUser.name)
          .toList();
      friendName = friendNames.isNotEmpty ? friendNames.first : null;
    }
    
    DebugLogger.log("🔍 About to create MatchCelebrationScreen...");
    DebugLogger.log("🔍 Passing currentSession: ${currentSession?.sessionId}");
    
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          DebugLogger.log("🔍 MatchCelebrationScreen builder called");
          DebugLogger.log("🔍 In builder - currentSession: ${currentSession?.sessionId}");
          
          return MatchCelebrationScreen(
            movie: matchedMovie,
            currentUser: widget.currentUser,
            matchedName: friendName,
            allMatchedUsers: currentSession?.participantNames,
            currentSession: currentSession,
          );
        },
      ),
    ).then((_) {
      DebugLogger.log("🔍 Returned from MatchCelebrationScreen");
    });
    
    DebugLogger.log("🔍 ===========================================");
    DebugLogger.log("🔍 _showMatchCelebration DEBUG END");
    DebugLogger.log("🔍 ===========================================");
  }

  bool _onSwipe(int previousIndex, int? currentIndex, CardSwiperDirection direction) {
    SessionManager.recordActivity();
    if (isInCollaborativeMode && currentSession != null) {
      return _onCollaborativeSwipe(previousIndex, currentIndex, direction);
    }
    
    if (previousIndex >= sessionPool.length) return false;
    
    final movie = sessionPool[previousIndex];
    _swipeCount++;
    DebugLogger.log("🔢 Swipe count: $_swipeCount");
    
    final isLike = direction == CardSwiperDirection.right;
    
    // UNIFIED LEARNING: Light learning for all mood sessions
    if (currentSessionContext != null && !currentSessionContext!.moods.isProfileBased) {
      // Simple tracking only (no learning)
      if (isLike) {
        widget.currentUser.likedMovies.add(movie);
        widget.currentUser.likedMovieIds.add(movie.id);
      } else {
        widget.currentUser.passedMovieIds.add(movie.id);
      }
      
      if (isLike) {
        likeMovie(movie);
      } else {
        passMovie(movie);
        // For mood sessions, track passed movies to avoid showing again this session
        sessionPassedMovieIds.add(movie.id);
      }
    } else {
      // For popular movies sessions (no mood context)
      if (isLike) {
        likeMovie(movie);
      } else {
        widget.currentUser.passedMovieIds.add(movie.id);
        passMovie(movie);
      }
    }
    
    // Check for group matches (simplified since everyone sees same movies)
    if (currentMode == MatchingMode.friend && isLike) {
      _checkForFriendMatch(movie);
    } else if (currentMode == MatchingMode.group && isLike) {
      _checkForGroupMatch(movie, isLike);
    }
    
    // Check if we're running low on movies
    if (currentIndex != null && currentIndex >= sessionPool.length - 5) {
      if (selectedMoods.isNotEmpty) {
        _refreshPoolIfNeeded(); // Only for mood sessions
      } else if (isInCollaborativeMode) {
        // Handle collaborative session refresh
      }
      // For popular movies sessions, we don't refill - they're designed to be finite
    }
    
    return true;
  }

  void _checkForFriendMatch(Movie movie) {
    if (selectedFriend?.likedMovieIds.contains(movie.id) == true) {
      _showMatchCelebration(movie);
    }
  }

  void _checkForGroupMatch(Movie movie, bool isLike) {
    if (!isLike) return;
    
    // For now, just check friend mode - group mode matching logic can be expanded later
    if (currentMode == MatchingMode.friend && selectedFriend?.likedMovieIds.contains(movie.id) == true) {
      _showMatchCelebration(movie);
    }
    
    // TODO: Implement group matching logic where ALL members need to like the same movie
    if (currentMode == MatchingMode.group) {
      // This is where we'd implement the "everyone likes it = match" logic
      // For now, just use the existing group logic
      groupLikes[widget.currentUser.name]?.add(movie.title);
      final everyone = [widget.currentUser.name, ...selectedGroup.map((f) => f.name)];
      final allLiked = everyone.every((name) => groupLikes[name]?.contains(movie.title) == true);
      if (allLiked) _showMatchCelebration(movie);
    }
  }

  Future<void> _markTutorialSeen() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('tutorial_seen', true);
  }

  // Add adaptive pool refresh
  Future<void> _adaptSessionPool() async {
    if (_isRefreshingPool || currentSessionContext == null) return;
    
    setState(() => _isRefreshingPool = true);
    
    try {
      final seenMovieIds = <String>{
        ...widget.currentUser.likedMovieIds,
        ...widget.currentUser.passedMovieIds,
        ...currentSessionMovieIds,
      };
      
      // SIMPLE: Generate more movies of the same mood
      final moreMovies = await MoodBasedLearningEngine.generateMoodBasedSession(
        user: widget.currentUser,
        movieDatabase: movieDatabase,
        sessionContext: currentSessionContext!,
        seenMovieIds: seenMovieIds,
        sessionPassedMovieIds: sessionPassedMovieIds,
        sessionSize: 10,
      );
      
      if (moreMovies.isNotEmpty) {
        setState(() {
          sessionPool.addAll(moreMovies);
          currentSessionMovieIds.addAll(moreMovies.map((m) => m.id));
          DebugLogger.log("✨ Added ${moreMovies.length} more mood-based movies");
        });
      }
    } catch (e) {
      DebugLogger.log("❌ Error adding more movies: $e");
    } finally {
      setState(() => _isRefreshingPool = false);
    }
  }

  // Add pool refresh when running low
  Future<void> _refreshPoolIfNeeded() async {
    if (_isRefreshingPool) return;
    
    setState(() => _isRefreshingPool = true);
    
    try {
      final remainingInBase = _basePool.length - _dynamicPool.length;
      
      if (remainingInBase > 0) {
        // Add more from base pool
        final nextBatch = _basePool
            .skip(_dynamicPool.length)
            .take(10)
            .toList();
        
        setState(() {
          sessionPool.addAll(nextBatch);
          _dynamicPool.addAll(nextBatch);
        });
      } else {
        // Generate completely new movies
        await _adaptSessionPool();
      }
    } finally {
      setState(() => _isRefreshingPool = false);
    }
  }

  // Add visual indicator for pool refresh
  Widget _buildPoolRefreshIndicator() {
    if (!_isRefreshingPool) return const SizedBox.shrink();
    
    return Positioned(
      top: 100.h,
      right: 16.w,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
        decoration: BoxDecoration(
          color: const Color(0xFFE5A00D),
          borderRadius: BorderRadius.circular(20.r),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 12.w,
              height: 12.w,
              child: CircularProgressIndicator(
                strokeWidth: 2.w,
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            ),
            SizedBox(width: 8.w),
            Text(
              'Finding new picks...',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Handle mode change
  void _switchMode(MatchingMode mode) {
    setState(() {
      currentMode = mode;
      _resetToSelection(); // Reset session when switching modes
      
      // Clear selections when switching away from those modes
      if (mode != MatchingMode.friend) {
        selectedFriend = null;
      }
      if (mode != MatchingMode.group) {
        selectedGroup.clear();
        groupLikes.clear();
      }
    });
  }

  // Add method to select a friend
  void _selectFriend(UserProfile friend) {
    setState(() {
      selectedFriend = friend;
      currentMode = MatchingMode.friend;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Show mood selection modal if requested
    if (_showMoodSelectionModal) {
      return Scaffold(
        backgroundColor: const Color(0xFF121212),
        body: SafeArea(
          child: Stack(
            children: [
              // Main mood selection widget
              MoodSelectionWidget(
                onMoodsSelected: _onMoodSelected,
                isGroupMode: currentMode != MatchingMode.solo,
                groupSize: currentMode == MatchingMode.group 
                    ? selectedGroup.length + 1 
                    : currentMode == MatchingMode.friend 
                        ? 2 
                        : 1,
              ),
              
              // Subtle cancel button at top-left (less intrusive)
              Positioned(
                top: 24.h,
                left: 24.w,
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      _showMoodSelectionModal = false;
                    });
                  },
                  child: Container(
                    padding: EdgeInsets.all(8.r),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.3),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.arrow_back_ios,
                      color: Colors.white.withValues(alpha: 0.8),
                      size: 20.sp,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text(
          _getAppBarTitle(),
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20.sp,
          ),
        ),
        actions: [],
      ),
      body: Stack(
        children: [
          Column(
            children: [
              // Mode selection (always visible)
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 7.w, vertical: 10.h),
                child: Row(
                  children: [
                    Expanded(
                      child: _buildModeButton(
                        "Solo Mode", 
                        Icons.person,
                        currentMode == MatchingMode.solo,
                        () => _switchMode(MatchingMode.solo),
                      ),
                    ),
                    SizedBox(width: 5.w),
                    Expanded(
                      child: _buildModeButton(
                        "Friend Mode",
                        Icons.people,
                        currentMode == MatchingMode.friend,
                        () => _switchMode(MatchingMode.friend),
                      ),
                    ),
                    SizedBox(width: 5.w),
                    Expanded(
                      child: _buildModeButton(
                        "Group Mode",
                        Icons.groups,
                        currentMode == MatchingMode.group,
                        () => _switchMode(MatchingMode.group),
                      ),
                    ),
                  ],
                ),
              ),
              _buildCollaborativeHeader(),
              // Session controls (when not ready to swipe)
              if (!_isReadyToSwipe) _buildSessionControls(),

              // Smart banner and indicators (when ready to swipe)
              if (_isReadyToSwipe) _buildSmartBanner(),

              // Main content
              Expanded(
                child: _isLoadingSession 
                    ? _buildLoadingState()
                    : _isReadyToSwipe 
                        ? _buildMainContent()
                        : _buildWelcomeScreen(),
              ),
            ],
          ),
          if (_isReadyToSwipe) _buildPoolRefreshIndicator(),
          _buildTutorialOverlay(),
        ],
      ),
    );
  }
  
  String _getAppBarTitle() {
    if (isInCollaborativeMode && currentSession != null) {
      final friendNames = currentSession!.participantNames
          .where((name) => name != widget.currentUser.name)
          .toList();
      
      if (friendNames.isNotEmpty) {
        if (friendNames.length == 1) {
          return "Swiping with ${friendNames.first}";
        } else {
          return "Swiping with ${friendNames.join(", ")}";
        }
      } else {
        return "Collaborative Session";
      }
    }
    
    switch (currentMode) {
      case MatchingMode.solo:
        return "Find Your Movies";
      case MatchingMode.friend:
        return selectedFriend != null 
            ? "Swiping with ${selectedFriend!.name}"
            : "Friend Mode";
      case MatchingMode.group:
        if (selectedGroup.isNotEmpty) {
          if (selectedGroup.length == 1) {
            return "Swiping with ${selectedGroup.first.name}";
          } else {
            return "Group of ${selectedGroup.length + 1}";
          }
        } else {
          return "Group Mode";
        }
    }
  }

  Widget _buildSessionControls() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      child: Column(
        children: [
          // Show end session button if session is active
          if (_hasStartedSession && SessionManager.hasActiveSession) ...[
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16.w),
              decoration: BoxDecoration(
                color: const Color(0xFF1F1F1F),
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(
                  color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.timer,
                    color: const Color(0xFFE5A00D),
                    size: 20.sp,
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Session Active",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          "Duration: ${_formatDuration(SessionManager.currentSessionDuration ?? Duration.zero)}",
                          style: TextStyle(
                            color: const Color(0xFFE5A00D),
                            fontSize: 12.sp,
                          ),
                        ),
                      ],
                    ),
                  ),
                  OutlinedButton(
                    onPressed: _endSession,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.orange,
                      side: BorderSide(color: Colors.orange),
                      minimumSize: Size(80.w, 36.h),
                    ),
                    child: Text("End Session"),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16.h),
          ],
          // Solo Mode: Popular movies + mood selection
          if (currentMode == MatchingMode.solo) ...[
            // Popular movies button (primary action)
            SizedBox(
              width: double.infinity,
              height: 56.h,
              child: ElevatedButton.icon(
                onPressed: _canStartSession() ? _startPopularMoviesSession : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE5A00D),
                  disabledBackgroundColor: Colors.grey[700],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.r),
                  ),
                ),
                icon: Icon(
                  Icons.trending_up,
                  color: _canStartSession() ? Colors.black : Colors.grey[400],
                  size: 24.sp,
                ),
                label: Text(
                  "Popular Movies",
                  style: TextStyle(
                    color: _canStartSession() ? Colors.black : Colors.grey[400],
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            
            SizedBox(height: 12.h),
            
            // Divider with "OR"
            Row(
              children: [
                Expanded(child: Divider(color: Colors.grey[600])),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.w),
                  child: Text(
                    "OR",
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(child: Divider(color: Colors.grey[600])),
              ],
            ),
            
            SizedBox(height: 12.h),
            
            // Choose mood button
            SizedBox(
              width: double.infinity,
              height: 48.h,
              child: OutlinedButton.icon(
                onPressed: _canStartSession() ? _showMoodPicker : null,
                style: OutlinedButton.styleFrom(
                  side: BorderSide(
                    color: _canStartSession() ? const Color(0xFFE5A00D) : Colors.grey[700]!,
                    width: 2.w,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.r),
                  ),
                ),
                icon: Icon(
                  Icons.mood,
                  color: _canStartSession() ? const Color(0xFFE5A00D) : Colors.grey[400],
                  size: 20.sp,
                ),
                label: Text(
                  "Choose Your Mood",
                  style: TextStyle(
                    color: _canStartSession() ? const Color(0xFFE5A00D) : Colors.grey[400],
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],

          // Friend Mode: Show invite options prominently
          if (currentMode == MatchingMode.friend) ...[
            if (selectedFriend != null) ...[
              // Friend is selected - show start matching button
              Container(
                padding: EdgeInsets.all(16.r),
                decoration: BoxDecoration(
                  color: const Color(0xFF2A2A2A),
                  borderRadius: BorderRadius.circular(12.r),
                  border: Border.all(color: const Color(0xFFE5A00D)),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: const Color(0xFFE5A00D),
                      child: Text(selectedFriend!.name[0].toUpperCase()),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Text(
                        "Ready to match with ${selectedFriend!.name}",
                        style: TextStyle(color: Colors.white, fontSize: 14.sp),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 16.h),
              
              // Two buttons: Popular movies and Choose mood
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _startPopularMoviesSession,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE5A00D),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.r)),
                      ),
                      icon: Icon(Icons.trending_up, color: Colors.black, size: 20.sp),
                      label: Text("Popular", 
                        style: TextStyle(color: Colors.black, fontSize: 14.sp, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _showMoodPicker,
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: const Color(0xFFE5A00D), width: 2.w),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.r)),
                      ),
                      icon: Icon(Icons.mood, color: const Color(0xFFE5A00D), size: 20.sp),
                      label: Text("Choose Mood", 
                        style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 14.sp, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ] else ...[
              // Main invite button
              SizedBox(
                width: double.infinity,
                height: 56.h,
                child: ElevatedButton.icon(
                  onPressed: () => _showFriendSelector(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE5A00D),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.r),
                    ),
                  ),
                  icon: Icon(
                    Icons.person_add,
                    color: Colors.black,
                    size: 24.sp,
                  ),
                  label: Text(
                    "Invite Friend",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              
              SizedBox(height: 12.h),
              
              // Optional share code button (smaller, secondary)
              SizedBox(
                width: double.infinity,
                height: 44.h,
                child: OutlinedButton.icon(
                  onPressed: () => _createSessionWithCode(),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Colors.grey[600]!, width: 1.w),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                  ),
                  icon: Icon(
                    Icons.share,
                    color: Colors.grey[400],
                    size: 20.sp,
                  ),
                  label: Text(
                    "Or share code instead",
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ],
          ],

          // Group Mode: Show group creation options
          if (currentMode == MatchingMode.group) ...[
            if (selectedGroup.isNotEmpty) ...[
              // Group selected - show session controls
              Container(
                padding: EdgeInsets.all(12.r),
                decoration: BoxDecoration(
                  color: const Color(0xFFE5A00D).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12.r),
                  border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.people, color: const Color(0xFFE5A00D), size: 16.sp),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: Text(
                        "Group: You + ${selectedGroup.map((f) => f.name).join(', ')}",
                        style: TextStyle(
                          color: const Color(0xFFE5A00D),
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: _showGroupSelectionDialog,
                      child: Icon(Icons.edit, color: const Color(0xFFE5A00D), size: 16.sp),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 16.h),
              
              // Two buttons: Popular movies and Choose mood
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _startPopularMoviesSession,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE5A00D),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.r)),
                      ),
                      icon: Icon(Icons.trending_up, color: Colors.black, size: 20.sp),
                      label: Text("Popular Movies", 
                        style: TextStyle(color: Colors.black, fontSize: 14.sp, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _showMoodPicker,
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: const Color(0xFFE5A00D), width: 2.w),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.r)),
                      ),
                      icon: Icon(Icons.mood, color: const Color(0xFFE5A00D), size: 20.sp),
                      label: Text("Choose Mood", 
                        style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 14.sp, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ] else ...[
              // No group selected
              SizedBox(
                width: double.infinity,
                height: 56.h,
                child: ElevatedButton.icon(
                  onPressed: _showGroupSelectionDialog,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE5A00D),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.r),
                    ),
                  ),
                  icon: Icon(
                    Icons.groups,
                    color: Colors.black,
                    size: 24.sp,
                  ),
                  label: Text(
                    "Select Group Members",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }

  // Add these new methods for quick session creation
  Future<void> _createSessionWithCode() async {
    setState(() => _isLoadingSession = true);
    
    try {
      final session = await SessionService.createSession(
        hostName: widget.currentUser.name,
        inviteType: InvitationType.code,
      );
      
      if (mounted) {
        _showSessionCodeDialog(session.sessionCode!);
        _startCollaborativeSession(session);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to create session: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoadingSession = false);
    }
  }

  void _showFriendSelector() {
    showDialog(
      context: context,
      builder: (context) => FriendInviteDialog(
        currentUser: widget.currentUser,
        availableFriends: widget.availableFriends,
        onSessionCreated: _startCollaborativeSession,
      ),
    );
  }

  void _showSessionCodeDialog(String sessionCode) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "Session Created! 🎉",
          style: TextStyle(color: Colors.white, fontSize: 18.sp),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Share this code with your friend:",
              style: TextStyle(color: Colors.grey[300], fontSize: 14.sp),
            ),
            SizedBox(height: 16.h),
            
            Container(
              padding: EdgeInsets.all(16.r),
              decoration: BoxDecoration(
                color: const Color(0xFFE5A00D).withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(color: const Color(0xFFE5A00D)),
              ),
              child: Text(
                sessionCode,
                style: TextStyle(
                  color: const Color(0xFFE5A00D),
                  fontSize: 32.sp,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 8.w,
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              "Got it!",
              style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 14.sp),
            ),
          ),
        ],
      ),
    );
  }

  // Welcome screen for when no session is active
  Widget _buildWelcomeScreen() {
    // Don't show welcome screen if we're in collaborative mode
    if (isInCollaborativeMode) {
      return _buildCollaborativeWaitingScreen();
    }
    
    return SingleChildScrollView(
      padding: EdgeInsets.all(32.r),
      child: ConstrainedBox(
        constraints: BoxConstraints(
          minHeight: MediaQuery.of(context).size.height * 0.4,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Mode-specific icon and message
            Icon(
              _getModeIcon(),
              size: 80.sp,
              color: const Color(0xFFE5A00D),
            ),
            SizedBox(height: 24.h),
            
            Text(
              _getWelcomeTitle(),
              style: TextStyle(
                color: Colors.white,
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16.h),
            
            Text(
              _getWelcomeSubtitle(),
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16.sp,
                height: 1.4,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // Helper methods for welcome screen
  IconData _getModeIcon() {
    switch (currentMode) {
      case MatchingMode.solo:
        return Icons.person;
      case MatchingMode.friend:
        return Icons.people;
      case MatchingMode.group:
        return Icons.groups;
    }
  }

  String _getWelcomeTitle() {
    switch (currentMode) {
      case MatchingMode.solo:
        return "Ready to find your next movie?";
      case MatchingMode.friend:
        return selectedFriend != null 
            ? "Ready to find movies with ${selectedFriend!.name}?"
            : "Select a friend to start matching!";
      case MatchingMode.group:
        return selectedGroup.isNotEmpty
            ? "Ready to find movies for your group?"
            : "Select group members to start!";
    }
  }

  String _getWelcomeSubtitle() {
    switch (currentMode) {
      case MatchingMode.solo:
        return "Browse popular trending movies, or pick a mood for something specific.";
      case MatchingMode.friend:
        return selectedFriend != null 
            ? "Browse popular movies together, or let our AI suggest perfect matches based on your mood."
            : "Choose a friend from your list to start finding movies you'll both enjoy.";
      case MatchingMode.group:
        return selectedGroup.isNotEmpty
            ? "Browse popular movies together, or get AI recommendations based on your group's mood."
            : "Add friends to create a group and find movies everyone will love.";
    }
  }

  Widget _buildModeButton(String title, IconData icon, bool isSelected, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8.r),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 8.w),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFE5A00D) : const Color(0xFF1F1F1F),
          borderRadius: BorderRadius.circular(8.r),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: Colors.white,
              size: 16.sp,
            ),
            SizedBox(width: 4.w),
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 13.sp,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Add friend selection dialog
  void _showFriendSelectionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "Select a Friend", 
          style: TextStyle(color: Colors.white, fontSize: 18.sp)
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: widget.availableFriends.isEmpty
              ? Center(
                  child: Text(
                    "You don't have any friends yet. Add some from the Friends tab!",
                    style: TextStyle(color: Colors.white70, fontSize: 15.sp),
                  ),
                )
              : ListView.builder(
                  shrinkWrap: true,
                  itemCount: widget.availableFriends.length,
                  itemBuilder: (context, index) {
                    final friend = widget.availableFriends[index];
                    final isSelected = selectedFriend?.name == friend.name;
                    
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.grey[800],
                        radius: 20.r,
                        child: Text(
                          friend.name.isNotEmpty ? friend.name[0].toUpperCase() : "?",
                          style: TextStyle(color: Colors.white, fontSize: 16.sp),
                        ),
                      ),
                      title: Text(
                        friend.name,
                        style: TextStyle(color: Colors.white, fontSize: 16.sp),
                      ),
                      subtitle: Text(
                        "Genres: ${friend.preferredGenres.take(2).join(", ")}${friend.preferredGenres.length > 2 ? "..." : ""}",
                        style: TextStyle(color: Colors.white54, fontSize: 14.sp),
                      ),
                      trailing: isSelected
                          ? Icon(Icons.check_circle, color: const Color(0xFFE5A00D), size: 24.sp)
                          : null,
                      selected: isSelected,
                      selectedTileColor: Colors.black26,
                      onTap: () {
                        Navigator.pop(context);
                        _selectFriend(friend);
                      },
                    );
                  },
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel", 
              style: TextStyle(color: Colors.white70, fontSize: 15.sp)
            ),
          ),
        ],
      ),
    );
  }

  // Add group selection dialog
  void _showGroupSelectionDialog() {
    final tempSelected = Set<String>.from(selectedGroup.map((f) => f.name));

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Text(
          "Select Group Members", 
          style: TextStyle(color: Colors.white, fontSize: 18.sp)
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: widget.availableFriends.length,
            itemBuilder: (context, index) {
              final friend = widget.availableFriends[index];
              return CheckboxListTile(
                title: Text(
                  friend.name, 
                  style: TextStyle(color: Colors.white, fontSize: 16.sp)
                ),
                value: tempSelected.contains(friend.name),
                activeColor: const Color(0xFFE5A00D),
                checkColor: Colors.black,
                onChanged: (selected) {
                  setState(() {
                    if (selected == true) {
                      tempSelected.add(friend.name);
                    } else {
                      tempSelected.remove(friend.name);
                    }
                  });
                },
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel", 
              style: TextStyle(color: Colors.white70, fontSize: 15.sp)
            ),
          ),
          ElevatedButton(
            onPressed: () {
              final group = widget.availableFriends.where((f) => tempSelected.contains(f.name)).toList();
              setState(() {
                selectedGroup = group;
                _initializeApp();
              });
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE5A00D)),
            child: Text(
              "Start Group Session", 
              style: TextStyle(color: Colors.black, fontSize: 15.sp)
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMainContent() {
    DebugLogger.log("🔍 DEBUG: _buildMainContent called");
    DebugLogger.log("🔍 DEBUG: _isReadyToSwipe: $_isReadyToSwipe");
    DebugLogger.log("🔍 DEBUG: sessionPool.length: ${sessionPool.length}");
    DebugLogger.log("🔍 DEBUG: currentMode: $currentMode");
    DebugLogger.log("🔍 DEBUG: selectedFriend: $selectedFriend");
    
    if (currentMode == MatchingMode.friend && selectedFriend == null && !isInCollaborativeMode) {
      DebugLogger.log("🔍 DEBUG: Returning _buildSelectFriendScreen");
      return _buildSelectFriendScreen();
    }

    if (sessionPool.isEmpty) {
      DebugLogger.log("🔍 DEBUG: sessionPool is empty, returning _buildEmptyState");
      return _buildEmptyState();
    }

    DebugLogger.log("🔍 DEBUG: Returning movie swiper");

    return Padding(
      padding: EdgeInsets.all(8.r),
      child: Column(
        children: [
          // Full-height swiper
          Expanded(
            child: CardSwiper(
              cardsCount: sessionPool.length,
              numberOfCardsDisplayed: 1,
              onSwipe: _onSwipe,
              cardBuilder: (context, index, percentX, percentY) {
                if (index >= sessionPool.length) return const SizedBox.shrink();

                final movie = sessionPool[index];
                
                // Fixed type casting: Convert num to double explicitly
                final leftIntensity = percentX < 0 ? (-percentX.toDouble()).clamp(0.0, 1.0) : 0.0;
                final rightIntensity = percentX > 0 ? percentX.toDouble().clamp(0.0, 1.0) : 0.0;
                
                return Container(
                  margin: EdgeInsets.all(4.r),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16.r),
                    border: Border.all(color: Colors.yellow.shade800, width: 2.w),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14.r),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        // Background color
                        Container(color: const Color(0xFF1A1A1A)),
                        
                        // Movie poster layout - OPTIMIZED FOR HEIGHT
                        Column(
                          children: [
                            // TALLER poster section
                            Expanded(
                              flex: 12,
                              child: Container(
                                width: double.infinity,
                                child: Image.network(
                                  movie.posterUrl,
                                  fit: BoxFit.contain,
                                  width: double.infinity,
                                  errorBuilder: (context, error, stackTrace) {
                                    return Container(
                                      color: Colors.grey[800],
                                      child: Icon(
                                        Icons.broken_image, 
                                        size: 100.sp, 
                                        color: Colors.white24
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                            
                            // COMPACT bottom info section
                            Container(
                              width: double.infinity,
                              padding: EdgeInsets.symmetric(vertical: 6.h, horizontal: 12.w),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  // Title
                                  Text(
                                    movie.title,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 15.sp,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  
                                  SizedBox(height: 6.h),
                                  
                                  // COMPACT view more button
                                  Container(
                                    height: 32.h,
                                    child: ElevatedButton(
                                      onPressed: () => _showMovieDetailSheet(context, movie),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: const Color(0xFFE5A00D),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(16.r),
                                        ),
                                        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                                      ),
                                      child: Text(
                                        "View more",
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13.sp,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),

                        // Left indicator overlay with gradient
                        if (leftIntensity > 0)
                          Positioned.fill(
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                  colors: [
                                    Colors.red.withAlpha((179 * leftIntensity).toInt()),
                                    Colors.red.withAlpha(0),
                                  ],
                                  stops: const [0.0, 0.3],
                                ),
                              ),
                            ),
                          ),
                          
                        // Right indicator overlay with gradient
                        if (rightIntensity > 0)
                          Positioned.fill(
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.centerRight,
                                  end: Alignment.centerLeft,
                                  colors: [
                                    Colors.green.withAlpha((179 * rightIntensity).toInt()),
                                    Colors.green.withAlpha(0),
                                  ],
                                  stops: const [0.0, 0.3],
                                ),
                              ),
                            ),
                          ),
                        
                        // Tap area for movie details
                        Positioned.fill(
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () => _showMovieDetailSheet(context, movie),
                              splashColor: Colors.white.withAlpha(26),
                              highlightColor: Colors.transparent,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // Swipe instruction text
          Padding(
            padding: EdgeInsets.only(top: 8.h),
            child: Text(
              "Swipe left to pass, right to like",
              style: TextStyle(color: Colors.grey[400], fontSize: 13.sp),
            ),
          ),
          SizedBox(height: 6.h),
        ],
      ),
    );
  }

  void _showMovieDetailSheet(BuildContext context, Movie movie) {
    final bool isInFavorites = widget.currentUser.likedMovies.contains(movie);

    showMovieDetails(
      context: context,
      movie: movie,
      currentUser: widget.currentUser,
      onAddToFavorites: isInFavorites ? null : (Movie movie) {
        setState(() {
          widget.currentUser.likedMovies.add(movie);
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${movie.title} added to favorites'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
      },
      onRemoveFromFavorites: isInFavorites ? (Movie movie) {
        setState(() {
          widget.currentUser.likedMovies.remove(movie);
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${movie.title} removed from favorites'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 2),
          ),
        );
      } : null,
      onMarkAsWatched: currentMode == MatchingMode.friend || currentMode == MatchingMode.group
          ? (Movie movie) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${movie.title} marked as watched'),
                  backgroundColor: Colors.green,
                  duration: const Duration(seconds: 2),
                ),
              );
            }
          : null,
      isInFavorites: isInFavorites,
    );
  }

  Widget _buildSelectFriendScreen() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.people_outline,
              size: 80.sp,
              color: Colors.white30,
            ),
            SizedBox(height: 16.h),
            Text(
              "Choose a friend to start finding movies you both want to watch!",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16.sp,
              ),
            ),
            SizedBox(height: 32.h),
            ElevatedButton.icon(
              onPressed: () {
                _showFriendSelectionDialog();
              },
              icon: Icon(Icons.people, color: Colors.white, size: 20.sp),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 14.h),
                minimumSize: Size(200.w, 50.h),
              ),
              label: Text(
                "Select a Friend",
                style: TextStyle(color: Colors.white, fontSize: 16.sp),
              ),
            ),
            SizedBox(height: 16.h),
            Text(
              "OR",
              style: TextStyle(
                color: Colors.white54,
                fontSize: 14.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.h),
            OutlinedButton.icon(
              onPressed: () {
                _switchMode(MatchingMode.solo);
              },
              icon: Icon(Icons.movie, color: const Color(0xFFE5A00D), size: 20.sp),
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: const Color(0xFFE5A00D), width: 1.w),
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 14.h),
                minimumSize: Size(200.w, 50.h),
              ),
              label: Text(
                "Start Solo Swiping",
                style: TextStyle(color: const Color(0xFFE5A00D), fontSize: 16.sp),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.movie_filter,
              size: 80.sp,
              color: Colors.grey,
            ),
            SizedBox(height: 24.h),
            Text(
              currentMode == MatchingMode.solo 
                  ? "No movies to swipe yet!" 
                  : "No movies to match yet!",
              style: TextStyle(
                color: Colors.white,
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.h),
            Text(
              "Try selecting 'Popular Movies' or choose a mood to get started.",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16.sp,
              ),
            ),
            SizedBox(height: 32.h),
            ElevatedButton.icon(
              onPressed: _startPopularMoviesSession,
              icon: Icon(Icons.trending_up, color: Colors.white, size: 20.sp),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
              ),
              label: Text(
                "Load Popular Movies", 
                style: TextStyle(color: Colors.white, fontSize: 16.sp)
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTutorialOverlay() {
    final tutorialPages = [
      {
        'title': 'Solo Mode',
        'description': 'Swipe right on movies you like, left on ones you don\'t. Browse popular trending movies or choose a mood for personalized recommendations!',
        'icon': Icons.person,
        'color': Colors.orange,
      },
      {
        'title': 'Friend Mode',
        'description': 'Swipe together with friends! When both you and your friend like the same movie, it\'s a match. Perfect for finding movies to watch together.',
        'icon': Icons.people,
        'color': Colors.blue,
      },
      {
        'title': 'Group Mode',
        'description': 'Swipe with your group! When EVERYONE likes the same film, it\'s a match. Great for group movie nights and finding something everyone will enjoy.',
        'icon': Icons.groups,
        'color': Colors.purple,
      },
    ];

    return _showTutorial
        ? Container(
            color: Colors.black.withAlpha((255 * 0.85).round()),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Page indicator
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    tutorialPages.length,
                    (index) => Container(
                      margin: EdgeInsets.symmetric(horizontal: 4.w),
                      width: 10.w,
                      height: 10.h,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _tutorialPage == index
                            ? const Color(0xFFE5A00D)
                            : Colors.grey,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 24.h),
                
                // Swipeable content
                Expanded(
                  child: PageView.builder(
                    controller: _tutorialPageController,
                    itemCount: tutorialPages.length,
                    onPageChanged: (index) {
                      setState(() {
                        _tutorialPage = index;
                      });
                    },
                    itemBuilder: (context, index) {
                      final page = tutorialPages[index];
                      return Padding(
                        padding: EdgeInsets.symmetric(horizontal: 32.w),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // Icon
                            Container(
                              padding: EdgeInsets.all(24.r),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: page['color'] as Color,
                                boxShadow: [
                                  BoxShadow(
                                    color: (page['color'] as Color).withAlpha((255 * 0.3).round()),
                                    blurRadius: 20.r,
                                    spreadRadius: 5.r,
                                  ),
                                ],
                              ),
                              child: Icon(
                                page['icon'] as IconData,
                                color: Colors.white,
                                size: 64.sp,
                              ),
                            ),
                            SizedBox(height: 40.h),
                            
                            // Title
                            Text(
                              page['title'] as String,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 28.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 24.h),
                            
                            // Description
                            Text(
                              page['description'] as String,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 16.sp,
                                height: 1.5,
                              ),
                            ),
                            
                            // Swipe hint
                            if (index < tutorialPages.length - 1)
                              Padding(
                                padding: EdgeInsets.only(top: 40.h),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      "Swipe right for next",
                                      style: TextStyle(
                                        color: Colors.white54,
                                        fontSize: 14.sp,
                                      ),
                                    ),
                                    SizedBox(width: 8.w),
                                    Icon(
                                      Icons.arrow_forward,
                                      color: Colors.white54,
                                      size: 16.sp,
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: 32.h),
                
                // Got it button
                ElevatedButton(
                  onPressed: () async {
                    await _markTutorialSeen();
                    setState(() {
                      _showTutorial = false;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE5A00D),
                    padding: EdgeInsets.symmetric(
                      horizontal: 32.w,
                      vertical: 12.h,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.r),
                    ),
                  ),
                  child: Text(
                    "Got it!",
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 16.sp,
                    ),
                  ),
                ),
                SizedBox(height: 40.h),
              ],
            ),
          )
        : const SizedBox.shrink();
  }

  Future<void> _loadNewMoviesFromSession(SwipeSession updatedSession) async {
    try {
      final currentMovieIds = sessionPool.map((m) => m.id).toSet();
      final newMovieIds = updatedSession.moviePool
          .where((id) => !currentMovieIds.contains(id))
          .toList();
      
      if (newMovieIds.isEmpty) {
        DebugLogger.log("📥 FRIEND: No new movies to load");
        return;
      }
      
      DebugLogger.log("📥 FRIEND: Loading ${newMovieIds.length} new movies from host");
      
      final newMovies = <Movie>[];
      
      // Load new movies from local database only
      for (final movieId in newMovieIds) {
        try {
          final movie = movieDatabase.firstWhere((m) => m.id == movieId);
          newMovies.add(movie);
        } catch (e) {
          DebugLogger.log("⚠️ FRIEND: Skipping new movie ID: $movieId (not in local database)");
          // Just skip missing movies - both users should have same database
        }
      }
      
      setState(() {
        sessionPool.addAll(newMovies);
        currentSessionMovieIds.addAll(newMovies.map((m) => m.id));
      });
      
      DebugLogger.log("✅ FRIEND: Added ${newMovies.length} new movies to pool (total: ${sessionPool.length})");
      
    } catch (e) {
      DebugLogger.log("❌ Error loading new movies from session: $e");
    }
  }

  void _startCollaborativeSession(SwipeSession session) {
    DebugLogger.log("🤝 Starting collaborative session: ${session.sessionId}");
    DebugLogger.log("   Status: ${session.status}");
    DebugLogger.log("   Participants: ${session.participantNames}");
    DebugLogger.log("   Is host: ${session.hostId == widget.currentUser.uid}");
    
    setState(() {
      currentSession = session;
      isWaitingForFriend = session.status == SessionStatus.created;
      isInCollaborativeMode = true;
      currentMode = MatchingMode.friend; // Set to friend mode
      
      // Reset session state
      _isReadyToSwipe = false;
      selectedMoods.clear();
      sessionPool.clear();
    });

    // Listen to session updates
    sessionSubscription?.cancel();
    sessionSubscription = SessionService.watchSession(session.sessionId).listen(
      (updatedSession) {
        DebugLogger.log("📡 Session update received:");
        DebugLogger.log("   Status: ${updatedSession.status}");
        DebugLogger.log("   Participants: ${updatedSession.participantNames}");
        DebugLogger.log("   Movie pool size: ${updatedSession.moviePool.length}");
        DebugLogger.log("   Current local pool size: ${sessionPool.length}");
        
        // Track previous matches to detect new ones
        final previousMatches = currentSession?.matches ?? [];
        
        // Track previous movie count to detect new movies added
        final previousMovieCount = currentSession?.moviePool.length ?? 0;
        final newMovieCount = updatedSession.moviePool.length;
        
        setState(() {
          currentSession = updatedSession;
          isWaitingForFriend = updatedSession.status == SessionStatus.created;
        });
        
        // If friend and host added new movies, reload them
        final isHost = updatedSession.hostId == widget.currentUser.uid;
        if (!isHost && newMovieCount > previousMovieCount && sessionPool.isNotEmpty) {
          DebugLogger.log("📥 FRIEND: Host added new movies (${previousMovieCount} → ${newMovieCount}), reloading...");
          _loadNewMoviesFromSession(updatedSession);
        }
        
        // When session becomes active, check for existing mood first
        if (updatedSession.status == SessionStatus.active && sessionPool.isEmpty && !_isReadyToSwipe) {
          DebugLogger.log("🎬 Session is now active - generating collaborative movie pool");
          
          // Check if movies were already generated
          final isHost = updatedSession.hostId == widget.currentUser.uid;
          if (isHost && updatedSession.moviePool.isNotEmpty) {
            DebugLogger.log("🔄 HOST: Movies already exist in session, loading them instead of regenerating");
            _generateCollaborativeSession(); // This will now load existing movies
            return;
          }
          
          // Check if we're a friend and host has now set up movies
          if (!isHost && updatedSession.moviePool.isNotEmpty && sessionPool.isEmpty) {
            DebugLogger.log("📥 FRIEND: Host has now provided movie pool, loading movies...");
            _generateCollaborativeSession(); // Retry loading now that movies are available
            return;
          }
          
          // Check if session already has a mood set by host
          if (updatedSession.hasMoodSelected && selectedMoods.isEmpty) {
            DebugLogger.log("🎭 Session has host's mood: ${updatedSession.selectedMoodName}");
            
            // Find the corresponding CurrentMood enum value
            CurrentMood? sessionMood;
            try {
              sessionMood = CurrentMood.values.firstWhere(
                (mood) => mood.toString().split('.').last == updatedSession.selectedMoodId
              );
            } catch (e) {
              DebugLogger.log("⚠️ Could not find matching mood enum for: ${updatedSession.selectedMoodId}");
              sessionMood = CurrentMood.emotional; // Fallback
            }
            
            // Auto-apply the host's mood and generate session
            setState(() {
              selectedMoods = [sessionMood!];
            });
            
            DebugLogger.log("✅ Auto-applied host's mood: ${sessionMood.displayName}");
            _generateCollaborativeSession();
            
          } else if (selectedMoods.isEmpty) {
            // No mood in session and no local moods - show mood selection
            DebugLogger.log("🔍 No mood set anywhere, showing mood selection");
            setState(() {
              _showMoodSelectionModal = true;
            });
          } else {
            // Moods already selected locally, generate the session directly
            DebugLogger.log("🔍 Using locally selected moods");
            _generateCollaborativeSession();
          }
        }
        
        // Check for new matches and show match screen
        final newMatches = updatedSession.matches.where(
          (movieId) => !previousMatches.contains(movieId)
        ).toList();
        
        for (final movieId in newMatches) {
          _handleSessionMatch(movieId);
        }
      },
      onError: (error) {
        DebugLogger.log("❌ Session stream error: $error");
        _endCollaborativeSession();
      },
    );

    DebugLogger.log("🎯 Collaborative session started successfully");
    
    // Show success message to user
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          session.hostId == widget.currentUser.uid 
              ? 'Session created! Waiting for friends...'
              : 'Successfully joined ${session.hostName}\'s session!',
        ),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _handleSessionMatch(String movieId) {    
    if (currentSession == null) {
      return;
    }
      
    // Find the movie object from our session pool
    Movie? matchedMovie;
    try {
      matchedMovie = sessionPool.firstWhere((movie) => movie.id == movieId);
    } catch (e) {
      // If movie not found in current pool, try to find it in the database
      try {
        matchedMovie = movieDatabase.firstWhere((movie) => movie.id == movieId);
      } catch (e2) {
        // Create a placeholder movie as last resort
        matchedMovie = Movie(
          id: movieId,
          title: "Matched Movie",
          posterUrl: "",
          overview: "You both liked this movie!",
          cast: [],
          genres: [],
          tags: [],
          releaseDate: DateTime.now().toIso8601String().split('T')[0],
        );
      }
    }
        
    // Get friend names
    final friendNames = currentSession!.participantNames
        .where((name) => name != widget.currentUser.name)
        .toList();
    
    DebugLogger.log("👥 Friend names for match: $friendNames");
    
    // Show the match screen
    try {
      Navigator.push(
        context,
        PageRouteBuilder(
          opaque: false,
          barrierDismissible: false,
          pageBuilder: (context, animation, secondaryAnimation) {
            DebugLogger.log("🎬 MatchCelebrationScreen widget created successfully");
            return MatchCelebrationScreen(
              movie: matchedMovie!,
              currentUser: widget.currentUser,
              matchedName: friendNames.isNotEmpty ? friendNames.join(", ") : "Your friend",
              allMatchedUsers: currentSession?.participantIds,
              currentSession: currentSession,  // ✅ ADD THIS LINE - THE FIX!
              onContinueSearching: () {
                // User wants to keep swiping in collaborative mode
                DebugLogger.log("🔄 User wants to continue collaborative searching");
              },
            );
          },
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            return FadeTransition(
              opacity: animation,
              child: child,
            );
          },
        ),
      );
      DebugLogger.log("✅ Match screen navigation completed");
    } catch (e) {
      DebugLogger.log("❌ ERROR showing match screen: $e");
    }
  }

  Future<void> _generateCollaborativeSession() async {
    DebugLogger.log("🔍 DEBUG: _generateCollaborativeSession called");
    DebugLogger.log("🔍 DEBUG: currentSession null? ${currentSession == null}");
    
    if (currentSession == null) {
      DebugLogger.log("❌ DEBUG: currentSession is null, returning");
      return;
    }

    // Check if we're the host or a friend
    final isHost = currentSession!.hostId == widget.currentUser.uid;
    DebugLogger.log("🔍 DEBUG: isHost: $isHost");

    setState(() {
      _isLoadingSession = true;
    });
    DebugLogger.log("🔍 DEBUG: Set _isLoadingSession = true");

    try {
      // Check if session already has a mood set by the host
      if (currentSession!.hasMoodSelected) {
        DebugLogger.log("🎭 Session already has mood set by host: ${currentSession!.selectedMoodName}");
        
        // Find the corresponding CurrentMood enum value
        CurrentMood? sessionMood;
        try {
          sessionMood = CurrentMood.values.firstWhere(
            (mood) => mood.toString().split('.').last == currentSession!.selectedMoodId
          );
        } catch (e) {
          DebugLogger.log("⚠️ Could not find matching mood enum for: ${currentSession!.selectedMoodId}");
          sessionMood = CurrentMood.emotional; // Fallback to a regular mood
        }
        
        // Auto-apply the host's mood to this user
        setState(() {
          selectedMoods = [sessionMood!];
          _showMoodSelectionModal = false;
        });
        
        // Create session context with the host's mood
        currentSessionContext = SessionContext(
          moods: sessionMood,
          groupMemberIds: currentSession!.participantIds,
        );
        
        DebugLogger.log("✅ Applied host's mood: ${sessionMood.displayName}");
        
      } else {
        // No mood set yet - show mood selection
        if (selectedMoods.isEmpty) {
          DebugLogger.log("🔍 DEBUG: No mood set in session and no local moods selected, showing mood selection");
          setState(() {
            _showMoodSelectionModal = true;
            _isLoadingSession = false;
          });
          return;
        }
      }
      
      DebugLogger.log("🔍 DEBUG: Selected moods: ${selectedMoods.map((m) => m.displayName).join(', ')}");

      List<Movie> collaborativePool = [];

      // Host generates, Friend loads EXACTLY the same pool
      if (isHost) {
        DebugLogger.log("👑 HOST: Generating movie pool for session");
        
        // Check if movies already exist in the session
        if (currentSession!.moviePool.isNotEmpty) {
          DebugLogger.log("🔄 HOST: Movies already exist in session, loading existing pool instead of regenerating");
          
          // Load existing movies from the session
          for (final movieId in currentSession!.moviePool) {
            try {
              final movie = movieDatabase.firstWhere((m) => m.id == movieId);
              collaborativePool.add(movie);
            } catch (e) {
              DebugLogger.log("⚠️ HOST: Movie with ID: $movieId not found in local database");
              // For host, if movies are missing from local DB, 
              // they might be from a previous session that used TMDB movies
              // We'll skip this for now to maintain consistency
            }
          }
          
          DebugLogger.log("✅ HOST: Loaded ${collaborativePool.length} existing movies from session");
          
        } else {
          // Generate new movie pool for the session
          final seenMovieIds = <String>{
            ...widget.currentUser.likedMovieIds,
            ...widget.currentUser.passedMovieIds,
            ...currentSessionMovieIds,
          };

          // Check if we have a movie database
          if (movieDatabase.isEmpty) {
            DebugLogger.log("⚠️ Movie database is empty, using popular movies");
            collaborativePool = await TMDBApi.getPopularMovies();
          } else {
            // Generate based on mood
            if (selectedMoods.length == 1) {
              // Regular mood-based session
              final context = SessionContext(
                moods: selectedMoods.first,
                groupMemberIds: currentSession!.participantIds,
              );
              try {
                collaborativePool = await MoodBasedLearningEngine.generateMoodBasedSession(
                  user: widget.currentUser,
                  movieDatabase: movieDatabase,
                  sessionContext: context,
                  seenMovieIds: seenMovieIds,
                  sessionSize: 30,
                  sessionPassedMovieIds: sessionPassedMovieIds,
                );
              } catch (e) {
                DebugLogger.log("❌ Error in generateMoodBasedSession: $e");
                collaborativePool = await TMDBApi.getPopularMovies();
              }
            } else {
              // Multi-mood session
              try {
                collaborativePool = await MoodBasedLearningEngine.generateBlendedMoodSession(
                  user: widget.currentUser,
                  movieDatabase: movieDatabase,
                  selectedMoods: selectedMoods,
                  seenMovieIds: seenMovieIds,
                  sessionPassedMovieIds: sessionPassedMovieIds,
                  sessionSize: 30,
                );
              } catch (e) {
                DebugLogger.log("❌ Error in generateBlendedMoodSession: $e");
                collaborativePool = await TMDBApi.getPopularMovies();
              }
            }
          }

          // Ensure we have movies
          if (collaborativePool.isEmpty) {
            DebugLogger.log("⚠️ Collaborative pool is empty, using popular movies");
            collaborativePool = await TMDBApi.getPopularMovies();
          }

          DebugLogger.log("🎬 HOST: Generated ${collaborativePool.length} movies for collaborative session");

          // HOST: Save movie pool to Firestore for friends to load
          try {
            await SessionService.startSession(
              currentSession!.sessionId,
              selectedMoodIds: selectedMoods.map((m) => m.toString().split('.').last).toList(),
              moviePool: collaborativePool.map((m) => m.id).toList(),
            );
            DebugLogger.log("✅ HOST: Saved movie pool to Firestore");
          } catch (e) {
            DebugLogger.log("⚠️ Could not save movie pool to Firestore: $e");
          }
        }

      } else {
        // FRIEND: Wait for host to generate movies, then load exact same pool
        DebugLogger.log("👥 FRIEND: Loading movie pool from host");
        
        if (currentSession!.moviePool.isNotEmpty) {
          DebugLogger.log("📥 FRIEND: Found ${currentSession!.moviePool.length} movie IDs in session");
          
          // Load movies from local database only (both users have same database)
          for (final movieId in currentSession!.moviePool) {
            try {
              final movie = movieDatabase.firstWhere((m) => m.id == movieId);
              collaborativePool.add(movie);
            } catch (e) {
              DebugLogger.log("⚠️ FRIEND: Skipping movie ID: $movieId (not in local database)");
              // Just skip missing movies - both users should have same database
            }
          }
          
          DebugLogger.log("✅ FRIEND: Loaded ${collaborativePool.length} movies from local database");
          
          // Verify first movie matches what host should have
          if (collaborativePool.isNotEmpty) {
            DebugLogger.log("🔍 FRIEND: First movie will be: ${collaborativePool.first.title}");
          }
          
        } else {
          DebugLogger.log("⏳ FRIEND: Waiting for host to generate movie pool...");
          setState(() {
            _isLoadingSession = false;
          });
          return; // Stay on loading screen until host generates movies
        }
      }

      // Update state and mark ready to swipe
      setState(() {
        sessionPool = List.from(collaborativePool);
        currentSessionMovieIds.clear();
        currentSessionMovieIds.addAll(sessionPool.map((m) => m.id));
        _isReadyToSwipe = true;
      });
      
      DebugLogger.log("🔍 DEBUG: Set _isReadyToSwipe = true, sessionPool.length = ${sessionPool.length}");
      if (sessionPool.isNotEmpty) {
        DebugLogger.log("🎬 First movie: ${sessionPool.first.title}");
      }

    } catch (e) {
      DebugLogger.log("❌ ERROR in _generateCollaborativeSession: $e");
      DebugLogger.log("❌ Stack trace: ${StackTrace.current}");
      
      // For collaborative sessions, try a simple fallback
      if (isHost) {
        // Host can fall back to popular movies
        try {
          final fallbackMovies = await TMDBApi.getPopularMovies();
          setState(() {
            sessionPool = fallbackMovies;
            _isReadyToSwipe = true;
          });
          
          // Save fallback movies to session
          await SessionService.startSession(
            currentSession!.sessionId,
            selectedMoodIds: selectedMoods.map((m) => m.toString().split('.').last).toList(),
            moviePool: fallbackMovies.map((m) => m.id).toList(),
          );
          DebugLogger.log("✅ HOST: Used fallback movies and saved to session");
        } catch (fallbackError) {
          DebugLogger.log("❌ Even fallback failed: $fallbackError");
          _showErrorAndReset("Failed to load movies. Please check your internet connection.");
        }
      } else {
        // Friend should wait for host, don't show error immediately
        DebugLogger.log("⏳ FRIEND: Error loading, will wait for host to retry...");
        setState(() {
          _isLoadingSession = false;
        });
      }
      
    } finally {
      setState(() {
        _isLoadingSession = false;
      });
      DebugLogger.log("🔍 DEBUG: Set _isLoadingSession = false");
    }
  }


  // Method to add more movies when running low
  Future<void> _addMoreMoviesToSession() async {
    if (currentSession == null || !isInCollaborativeMode) return;
    
    final isHost = currentSession!.hostId == widget.currentUser.uid;
    
    // Only host can add more movies
    if (!isHost) {
      DebugLogger.log("👥 FRIEND: Not host, cannot add more movies");
      return;
    }
    
    DebugLogger.log("👑 HOST: Adding more movies to session");
    
    try {
      final seenMovieIds = <String>{
        ...widget.currentUser.likedMovieIds,
        ...widget.currentUser.passedMovieIds,
        ...currentSessionMovieIds,
        ...sessionPassedMovieIds, // Include session-level passed movies
      };

      List<Movie> newMovies = [];

      // Generate more movies using the same mood context
      if (selectedMoods.length == 1) {
          // Regular mood-based session
          newMovies = await MoodBasedLearningEngine.generateMoodBasedSession(
            user: widget.currentUser,
            movieDatabase: movieDatabase,
            sessionContext: currentSessionContext!,
            seenMovieIds: seenMovieIds,
            sessionPassedMovieIds: sessionPassedMovieIds,
            sessionSize: 20,
          );
      } else {
        // Blended mood session - use existing logic
        newMovies = await MoodBasedLearningEngine.generateBlendedMoodSession(
          user: widget.currentUser,
          movieDatabase: movieDatabase,
          selectedMoods: selectedMoods,
          seenMovieIds: seenMovieIds,
          sessionPassedMovieIds: sessionPassedMovieIds,
          sessionSize: 20,
        );
      }

      if (newMovies.isNotEmpty) {
        // Add new movies to Firestore session
        final currentMoviePool = currentSession!.moviePool;
        final newMovieIds = newMovies.map((m) => m.id).toList();
        final updatedMoviePool = [...currentMoviePool, ...newMovieIds];
        DebugLogger.log("🔍 Movie pool updated: ${updatedMoviePool.length} movies");

        await SessionService.addMoviesToSession(
          currentSession!.sessionId,
          newMovieIds,
        );

        // Update local state
        setState(() {
          sessionPool.addAll(newMovies);
          currentSessionMovieIds.addAll(newMovieIds);
        });

        DebugLogger.log("✅ HOST: Added ${newMovies.length} new movies to session");
      }

    } catch (e) {
      DebugLogger.log("❌ Error adding more movies to session: $e");
    }
  }

  // Handle collaborative swipe
  bool _onCollaborativeSwipe(int previousIndex, int? currentIndex, CardSwiperDirection direction) {
    if (currentSession == null || previousIndex >= sessionPool.length) return false;

    final movie = sessionPool[previousIndex];
    final isLike = direction == CardSwiperDirection.right;

    // Record swipe in Firebase
    SessionService.recordSwipe(
      sessionId: currentSession!.sessionId,
      movieId: movie.id,
      isLike: isLike,
    );

    // SIMPLE TRACKING (no complex learning)
    if (isLike) {
      setState(() {
        widget.currentUser.likedMovies.add(movie);
        widget.currentUser.likedMovieIds.add(movie.id);
      });
    } else {
      // Track session-level passed movies
      widget.currentUser.passedMovieIds.add(movie.id);
      sessionPassedMovieIds.add(movie.id);
    }

    // Save profile
    UserProfileStorage.saveProfile(widget.currentUser);

    // Check if running low on movies and add more
    if (currentIndex != null && currentIndex >= sessionPool.length - 5) {
      final isHost = currentSession!.hostId == widget.currentUser.uid;
      if (isHost) {
        DebugLogger.log("🔄 HOST: Running low on movies, adding more...");
        _addMoreMoviesToSession();
      }
    }

    return true;
  }

  // End collaborative session
  void _endCollaborativeSession() {
    if (currentSession != null) {
      SessionService.endSession(currentSession!.sessionId);
    }
    
    sessionSubscription?.cancel();
    
    setState(() {
      currentSession = null;
      isWaitingForFriend = false;
      isInCollaborativeMode = false;
      currentMode = MatchingMode.solo;
      _resetToSelection();
    });
    
    DebugLogger.log("✅ Session ended");
  }

  // Build collaborative mode UI elements
  Widget _buildCollaborativeHeader() {
    if (!isInCollaborativeMode || currentSession == null) {
      return const SizedBox.shrink();
    }
    
    // If we're ready to swipe, don't show this header (mood banner will show instead)
    if (_isReadyToSwipe) {
      return const SizedBox.shrink();
    }
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF4A90E2).withValues(alpha: 0.9),
            const Color(0xFF357ABD).withValues(alpha: 0.9),
          ],
        ),
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Column(
        children: [
          // Main session info row
          Row(
            children: [
              // Session info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isWaitingForFriend ? "Waiting for friend..." : "Swiping together!",
                      style: TextStyle(color: Colors.white, fontSize: 16.sp, fontWeight: FontWeight.bold),
                    ),
                    if (currentSession!.sessionCode != null)
                      Text(
                        "Code: ${currentSession!.sessionCode}",
                        style: TextStyle(color: Colors.white70, fontSize: 14.sp),
                      ),
                    if (currentSession!.participantNames.length > 1)
                      Text(
                        "With: ${currentSession!.participantNames.where((name) => name != widget.currentUser.name).join(', ')}",
                        style: TextStyle(color: Colors.white70, fontSize: 12.sp),
                      ),
                  ],
                ),
              ),
              
              // Action buttons column
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Change Vibe button (only show if session has started and mood is selected)
                  if (selectedMoods.isNotEmpty || currentSession!.hasMoodSelected)
                    GestureDetector(
                      onTap: _requestMoodChange,
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 6.h),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5A00D).withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8.r),
                          border: Border.all(color: const Color(0xFFE5A00D).withValues(alpha: 0.5)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.mood, color: const Color(0xFFE5A00D), size: 16.sp),
                            SizedBox(width: 4.w),
                            Text(
                              "Change Vibe",
                              style: TextStyle(
                                color: const Color(0xFFE5A00D),
                                fontSize: 12.sp,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  
                  SizedBox(height: 8.h),
                  
                  // End Session button
                  GestureDetector(
                    onTap: _cancelSessionForBoth,
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 6.h),
                      decoration: BoxDecoration(
                        color: Colors.red.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(8.r),
                        border: Border.all(color: Colors.red.withValues(alpha: 0.5)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.close, color: Colors.red, size: 16.sp),
                          SizedBox(width: 4.w),
                          Text(
                            "End Session",
                            style: TextStyle(
                              color: Colors.red,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Collaborative waiting screen
  Widget _buildCollaborativeWaitingScreen() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(32.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Animated waiting indicator
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 100.r,
                  height: 100.r,
                  child: CircularProgressIndicator(
                    valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFE5A00D)),
                    strokeWidth: 4.w,
                  ),
                ),
                Icon(
                  Icons.people,
                  size: 40.sp,
                  color: const Color(0xFFE5A00D),
                ),
              ],
            ),
            
            SizedBox(height: 32.h),
            
            Text(
              isWaitingForFriend 
                  ? "Waiting for your friend..."
                  : currentSession != null && currentSession!.moviePool.isEmpty
                    ? "Waiting for host to set up movies..."
                    : "Get ready to swipe!",
              style: TextStyle(
                color: Colors.white,
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            
            SizedBox(height: 16.h),
            
            Text(
              isWaitingForFriend 
                  ? "They'll join using your session code"
                  : "Choose your mood and start finding movies together!",
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16.sp,
                height: 1.4,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  void _requestMoodChange() {
    setState(() {
      _showMoodSelectionModal = true;
    });
  }

  // Send mood change request to other participants
  Future<void> _sendMoodChangeRequest({required CurrentMood requestedMood}) async {
    if (currentSession == null) return;
    
    try {
      await SessionService.sendMoodChangeRequest(
        sessionId: currentSession!.sessionId,
        fromUserId: widget.currentUser.uid,
        fromUserName: widget.currentUser.name,
        requestedMoodId: requestedMood.toString().split('.').last,
        requestedMoodName: requestedMood.displayName,
      );
      
      // Show confirmation to the requester
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Mood change request sent to other participants'),
          backgroundColor: Colors.blue,
          duration: const Duration(seconds: 2),
        ),
      );
      
    } catch (e) {
      DebugLogger.log("❌ Error sending mood change request: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to send mood change request'),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  // Cancel session for all participants
  Future<void> _cancelSessionForBoth() async {
    if (currentSession == null) return;
    
    try {
      await SessionService.cancelSession(
        currentSession!.sessionId,
        cancelledBy: widget.currentUser.name,
      );
      
      _endCollaborativeSession();
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Session ended for everyone'),
          backgroundColor: Colors.orange,
        ),
      );
    } catch (e) {
      DebugLogger.log("❌ Error ending session: $e");
    }
  }

  @override
    void dispose() {
      _sessionTimer?.cancel();
      
      // End any active session when leaving matcher
      if (SessionManager.hasActiveSession) {
        final completedSession = SessionManager.endSession();
        if (completedSession != null) {
          widget.currentUser.addCompletedSession(completedSession);
          UserProfileStorage.saveProfile(widget.currentUser);
        }
      }
    sessionSubscription?.cancel();
    _tutorialPageController.dispose();
    super.dispose();
  }
}