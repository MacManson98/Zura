import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_profile.dart';

class UserService {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;

  Future<UserProfile> loadOrCreateUserProfile() async {
    final uid = _auth.currentUser!.uid;
    final docRef = _firestore.collection('users').doc(uid);
    final snapshot = await docRef.get();

    late UserProfile userProfile;

    if (snapshot.exists) {
      userProfile = UserProfile.fromJson(snapshot.data()!);
    } else {
      userProfile = UserProfile.empty();
      userProfile.name = 'New User'; // Or prompt user later
      await docRef.set(userProfile.toJson());
    }

    // 🔁 Load Firestore-based completed friend/group sessions
    final extraSessions = await userProfile.loadCollaborativeSessions(uid);

    // 🧠 Merge into sessionHistory without duplicates
    userProfile.sessionHistory = [
      ...userProfile.sessionHistory,
      ...extraSessions.where((s) => !userProfile.sessionHistory.any((existing) => existing.id == s.id)),
    ]..sort((a, b) => b.startTime.compareTo(a.startTime));

    return userProfile;
  }
}
