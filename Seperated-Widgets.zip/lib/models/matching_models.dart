enum MatchingMode { 
  solo,
  friend,
  group,
}