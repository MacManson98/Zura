import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:glassmorphism/glassmorphism.dart';
import '../../models/user_profile.dart';
import '../../models/matching_models.dart';
import '../../models/session_models.dart';

class WelcomeScreenWidget extends StatelessWidget {
  final MatchingMode currentMode;
  final bool isInCollaborativeMode;
  final UserProfile? selectedFriend;
  final List<UserProfile> selectedGroup;
  final bool isWaitingForFriend;
  final SwipeSession? currentSession;

  const WelcomeScreenWidget({
    super.key,
    required this.currentMode,
    required this.isInCollaborativeMode,
    required this.selectedFriend,
    required this.selectedGroup,
    required this.isWaitingForFriend,
    required this.currentSession,
  });

  @override
  Widget build(BuildContext context) {
    // Don't show welcome screen if we're in collaborative mode
    if (isInCollaborativeMode) {
      return _buildCollaborativeWaitingScreen();
    }
    
    return _buildWelcomeScreen(context);
  }

  Widget _buildWelcomeScreen(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(32.r),
      child: ConstrainedBox(
        constraints: BoxConstraints(
          minHeight: MediaQuery.of(context).size.height * 0.4,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Mode-specific icon container with glassmorphic design
            GlassmorphicContainer(
              width: 120.w,
              height: 120.h,
              borderRadius: 60,
              blur: 20,
              alignment: Alignment.center,
              border: 2,
              linearGradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: _getModeGradientColors(),
              ),
              borderGradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  _getModeAccentColor().withValues(alpha: 0.6),
                  Colors.white.withValues(alpha: 0.2),
                ],
              ),
              child: Container(
                padding: EdgeInsets.all(20.w),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_getModeAccentColor(), _getModeAccentColor().shade600],
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: _getModeAccentColor().withValues(alpha: 0.3),
                      blurRadius: 12.r,
                      spreadRadius: 2.r,
                    ),
                  ],
                ),
                child: Icon(
                  _getModeIcon(),
                  size: 40.sp,
                  color: Colors.white,
                ),
              ),
            ),
            
            SizedBox(height: 32.h),
            
            // Welcome title with better typography
            Text(
              _getWelcomeTitle(),
              style: TextStyle(
                color: Colors.white,
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
                height: 1.2,
              ),
              textAlign: TextAlign.center,
            ),
            
            SizedBox(height: 16.h),
            
            // Subtitle with glassmorphic background
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
              margin: EdgeInsets.symmetric(horizontal: 16.w),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(16.r),
                border: Border.all(
                  color: Colors.white.withValues(alpha: 0.1),
                  width: 1.w,
                ),
              ),
              child: Text(
                _getWelcomeSubtitle(),
                style: TextStyle(
                  color: Colors.grey[300],
                  fontSize: 14.sp,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            
            SizedBox(height: 24.h),
            
            // Mode-specific status indicators
            if (currentMode == MatchingMode.friend && selectedFriend != null) ...[
              _buildSelectedFriendIndicator(),
            ] else if (currentMode == MatchingMode.group && selectedGroup.isNotEmpty) ...[
              _buildSelectedGroupIndicator(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildCollaborativeWaitingScreen() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(32.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Animated waiting indicator with glassmorphic design
            GlassmorphicContainer(
              width: 140.w,
              height: 140.h,
              borderRadius: 70,
              blur: 20,
              alignment: Alignment.center,
              border: 2,
              linearGradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFF4A90E2).withValues(alpha: 0.2),
                  const Color(0xFF357ABD).withValues(alpha: 0.15),
                  Colors.white.withValues(alpha: 0.05),
                ],
              ),
              borderGradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFF4A90E2).withValues(alpha: 0.6),
                  Colors.white.withValues(alpha: 0.2),
                ],
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Animated circular progress
                  SizedBox(
                    width: 80.r,
                    height: 80.r,
                    child: CircularProgressIndicator(
                      valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF4A90E2)),
                      strokeWidth: 3.w,
                      backgroundColor: Colors.white.withValues(alpha: 0.1),
                    ),
                  ),
                  // Center icon
                  Container(
                    padding: EdgeInsets.all(12.w),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [const Color(0xFF4A90E2), const Color(0xFF357ABD)],
                      ),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.people,
                      size: 24.sp,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            
            SizedBox(height: 32.h),
            
            // Status text
            Text(
              isWaitingForFriend 
                  ? "Waiting for your friend..."
                  : currentSession != null && currentSession!.moviePool.isEmpty
                    ? "Waiting for host to set up movies..."
                    : "Get ready to swipe!",
              style: TextStyle(
                color: Colors.white,
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              ),
              textAlign: TextAlign.center,
            ),
            
            SizedBox(height: 16.h),
            
            // Subtitle with glassmorphic background
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
              margin: EdgeInsets.symmetric(horizontal: 16.w),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(16.r),
                border: Border.all(
                  color: Colors.white.withValues(alpha: 0.1),
                  width: 1.w,
                ),
              ),
              child: Text(
                isWaitingForFriend 
                    ? "They'll join using your session code"
                    : "Choose your mood and start finding movies together!",
                style: TextStyle(
                  color: Colors.grey[300],
                  fontSize: 14.sp,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            
            // Session code display if available
            if (currentSession?.sessionCode != null) ...[
              SizedBox(height: 24.h),
              GlassmorphicContainer(
                width: double.infinity,
                height: 60.h,
                borderRadius: 16,
                blur: 10,
                alignment: Alignment.center,
                border: 1,
                linearGradient: LinearGradient(
                  colors: [
                    Colors.white.withValues(alpha: 0.08),
                    Colors.white.withValues(alpha: 0.04),
                  ],
                ),
                borderGradient: LinearGradient(
                  colors: [
                    const Color(0xFF4A90E2).withValues(alpha: 0.4),
                    Colors.white.withValues(alpha: 0.2),
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.all(16.w),
                  child: Column(
                    children: [
                      Text(
                        "Session Code",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 4.h),
                      Text(
                        currentSession!.sessionCode!,
                        style: TextStyle(
                          color: const Color(0xFF4A90E2),
                          fontSize: 24.sp,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2.0,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSelectedFriendIndicator() {
    return GlassmorphicContainer(
      width: double.infinity,
      height: 70.h,
      borderRadius: 16,
      blur: 10,
      alignment: Alignment.center,
      border: 1,
      linearGradient: LinearGradient(
        colors: [
          Colors.blue.withValues(alpha: 0.15),
          Colors.purple.withValues(alpha: 0.1),
          Colors.white.withValues(alpha: 0.05),
        ],
      ),
      borderGradient: LinearGradient(
        colors: [
          Colors.blue.withValues(alpha: 0.4),
          Colors.white.withValues(alpha: 0.2),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(16.w),
        child: Row(
          children: [
            // Friend avatar
            Container(
              width: 40.w,
              height: 40.h,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue, Colors.purple],
                ),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  selectedFriend!.name[0].toUpperCase(),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Matching with ${selectedFriend!.name}",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    "Ready to find your perfect movie match",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 12.sp,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 20.sp,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSelectedGroupIndicator() {
    return GlassmorphicContainer(
      width: double.infinity,
      height: 70.h,
      borderRadius: 16,
      blur: 10,
      alignment: Alignment.center,
      border: 1,
      linearGradient: LinearGradient(
        colors: [
          Colors.purple.withValues(alpha: 0.15),
          Colors.pink.withValues(alpha: 0.1),
          Colors.white.withValues(alpha: 0.05),
        ],
      ),
      borderGradient: LinearGradient(
        colors: [
          Colors.purple.withValues(alpha: 0.4),
          Colors.white.withValues(alpha: 0.2),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(16.w),
        child: Row(
          children: [
            // Group icon
            Container(
              width: 40.w,
              height: 40.h,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.purple, Colors.pink],
                ),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.groups,
                color: Colors.white,
                size: 20.sp,
              ),
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Group of ${selectedGroup.length + 1} people",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    "Ready to find movies everyone will love",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 12.sp,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 20.sp,
            ),
          ],
        ),
      ),
    );
  }

  // Helper methods for welcome screen styling
  IconData _getModeIcon() {
    switch (currentMode) {
      case MatchingMode.solo:
        return Icons.person;
      case MatchingMode.friend:
        return Icons.people;
      case MatchingMode.group:
        return Icons.groups;
    }
  }

  MaterialColor _getModeAccentColor() {
    switch (currentMode) {
      case MatchingMode.solo:
        return Colors.orange;
      case MatchingMode.friend:
        return Colors.blue;
      case MatchingMode.group:
        return Colors.purple;
    }
  }

  List<Color> _getModeGradientColors() {
    switch (currentMode) {
      case MatchingMode.solo:
        return [
          const Color(0xFFE5A00D).withValues(alpha: 0.2),
          Colors.orange.withValues(alpha: 0.15),
          Colors.white.withValues(alpha: 0.05),
        ];
      case MatchingMode.friend:
        return [
          Colors.blue.withValues(alpha: 0.2),
          Colors.purple.withValues(alpha: 0.15),
          Colors.white.withValues(alpha: 0.05),
        ];
      case MatchingMode.group:
        return [
          Colors.purple.withValues(alpha: 0.2),
          Colors.pink.withValues(alpha: 0.15),
          Colors.white.withValues(alpha: 0.05),
        ];
    }
  }

  String _getWelcomeTitle() {
    switch (currentMode) {
      case MatchingMode.solo:
        return "Ready to find your next movie?";
      case MatchingMode.friend:
        return selectedFriend != null 
            ? "Ready to find movies with ${selectedFriend!.name}?"
            : "Select a friend to start matching!";
      case MatchingMode.group:
        return selectedGroup.isNotEmpty
            ? "Ready to find movies for your group?"
            : "Select group members to start!";
    }
  }

  String _getWelcomeSubtitle() {
    switch (currentMode) {
      case MatchingMode.solo:
        return "Browse popular trending movies, or pick a mood for something specific.";
      case MatchingMode.friend:
        return selectedFriend != null 
            ? "Browse popular movies together, or let our AI suggest perfect matches based on your mood."
            : "Choose a friend from your list to start finding movies you'll both enjoy.";
      case MatchingMode.group:
        return selectedGroup.isNotEmpty
            ? "Browse popular movies together, or get AI recommendations based on your group's mood."
            : "Add friends to create a group and find movies everyone will love.";
    }
  }
}