// File: lib/widgets/testing_panel.dart

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_profile.dart';
import '../utils/user_profile_storage.dart';
import '../utils/tmdb_api.dart';

class TestingPanel extends StatefulWidget {
  final UserProfile currentUser;
  final VoidCallback onDataChanged;

  const TestingPanel({
    super.key,
    required this.currentUser,
    required this.onDataChanged,
  });

  @override
  State<TestingPanel> createState() => _TestingPanelState();
}

class _TestingPanelState extends State<TestingPanel> {
  bool _isLoading = false;

  // Mock friends data
  final List<Map<String, dynamic>> _mockFriends = [
    {
      'name': 'Emma Thompson',
      'uid': 'mock_emma_123',
      'preferredGenres': ['Drama', 'Romance', 'Comedy'],
      'email': 'emma.test@example.com',
    },
    {
      'name': 'James Rodriguez',
      'uid': 'mock_james_456',
      'preferredGenres': ['Action', 'Sci-Fi', 'Thriller'],
      'email': 'james.test@example.com',
    },
    {
      'name': 'Sarah Chen',
      'uid': 'mock_sarah_789',
      'preferredGenres': ['Horror', 'Thriller', 'Mystery'],
      'email': 'sarah.test@example.com',
    },
    {
      'name': 'Alex Morgan',
      'uid': 'mock_alex_101',
      'preferredGenres': ['Comedy', 'Animation', 'Family'],
      'email': 'alex.test@example.com',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A2A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.orange.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.bug_report, color: Colors.orange, size: 20),
              const SizedBox(width: 8),
              const Text(
                'Testing Panel',
                style: TextStyle(
                  color: Colors.orange,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              if (_isLoading)
                const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.orange,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Simulate different scenarios for testing:',
            style: TextStyle(color: Colors.white70, fontSize: 14),
          ),
          const SizedBox(height: 16),
          
          // Mock Friends Section
          _buildSection(
            'Mock Friends',
            'Create test friends in Firebase',
            [
              _buildActionButton(
                'Create Mock Friends',
                'Add 4 test friends with different preferences',
                Icons.person_add,
                _createMockFriends,
              ),
              _buildActionButton(
                'Delete Mock Friends',
                'Remove all test friends from Firebase',
                Icons.person_remove,
                _deleteMockFriends,
                isDestructive: true,
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          // Movie Matches Section
          _buildSection(
            'Movie Matches',
            'Simulate matching scenarios',
            [
              _buildActionButton(
                'Create Test Matches',
                'Generate matches between you and mock friends',
                Icons.movie_filter,
                _createTestMatches,
              ),
              _buildActionButton(
                'Add Shared Likes',
                'Add movies that you and friends both like',
                Icons.favorite,
                _addSharedLikes,
              ),
              _buildActionButton(
                'Clear Match History',
                'Remove all matches from your profile',
                Icons.clear_all,
                _clearMatchHistory,
                isDestructive: true,
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          // Quick Actions Section
          _buildSection(
            'Quick Actions',
            'Fast test data generation',
            [
              _buildActionButton(
                'Full Test Setup',
                'Create friends + matches + sample data',
                Icons.rocket_launch,
                _fullTestSetup,
              ),
              _buildActionButton(
                'Reset Everything',
                'Clear all test data and start fresh',
                Icons.restore,
                _resetEverything,
                isDestructive: true,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSection(String title, String description, List<Widget> actions) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          description,
          style: const TextStyle(color: Colors.white54, fontSize: 12),
        ),
        const SizedBox(height: 12),
        ...actions,
      ],
    );
  }

  Widget _buildActionButton(
    String title,
    String description,
    IconData icon,
    VoidCallback onPressed, {
    bool isDestructive = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: _isLoading ? null : onPressed,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: isDestructive 
                ? Colors.red.withValues(alpha: 0.1)
                : Colors.black.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isDestructive 
                  ? Colors.red.withValues(alpha: 0.3)
                  : Colors.white.withValues(alpha: 0.1),
            ),
          ),
          child: Row(
            children: [
              Icon(
                icon,
                color: isDestructive ? Colors.red : Colors.white70,
                size: 18,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: isDestructive ? Colors.red : Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      description,
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios,
                color: Colors.white30,
                size: 12,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _createMockFriends() async {
    setState(() => _isLoading = true);
    
    try {
      for (final friendData in _mockFriends) {
        // Create mock friend profile
        final friendProfile = UserProfile.empty().copyWith(
          uid: friendData['uid'],
          name: friendData['name'],
          preferredGenres: Set<String>.from(friendData['preferredGenres']),
          hasCompletedOnboarding: true,
        );

        // Add some random liked movies based on their genres
        final movies = await TMDBApi.getPopularMovies();
        final friendLikes = movies
            .where((movie) => movie.genres.any((genre) => 
                friendProfile.preferredGenres.contains(genre)))
            .take(5)
            .toList();
        
        for (final movie in friendLikes) {
          friendProfile.likedMovies.add(movie);
          friendProfile.likedMovieIds.add(movie.id);
        }

        // Save to Firestore
        await FirebaseFirestore.instance
            .collection('users')
            .doc(friendData['uid'])
            .set(friendProfile.toJson());
      }

      _showSnackBar('Created ${_mockFriends.length} mock friends!', Colors.green);
    } catch (e) {
      _showSnackBar('Error creating mock friends: $e', Colors.red);
    } finally {
      setState(() => _isLoading = false);
      widget.onDataChanged();
    }
  }

  void _deleteMockFriends() async {
    setState(() => _isLoading = true);
    
    try {
      for (final friendData in _mockFriends) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(friendData['uid'])
            .delete();
      }

      _showSnackBar('Deleted all mock friends!', Colors.orange);
    } catch (e) {
      _showSnackBar('Error deleting mock friends: $e', Colors.red);
    } finally {
      setState(() => _isLoading = false);
      widget.onDataChanged();
    }
  }

  void _createTestMatches() async {
    setState(() => _isLoading = true);
    
    try {
      final movies = await TMDBApi.getPopularMovies();
      final testMatches = <Map<String, dynamic>>[];

      // Create matches with each mock friend
      for (int i = 0; i < _mockFriends.length && i < 4; i++) {
        final friend = _mockFriends[i];
        final movie = movies[i % movies.length];
        
        testMatches.add({
          'username': friend['name'],
          'movieTitle': movie.title,
          'matchDate': DateTime.now().subtract(Duration(days: i + 1)),
          'posterUrl': movie.posterUrl,
          'watched': i == 0, // First match is watched
          'watchedDate': i == 0 ? DateTime.now().subtract(const Duration(hours: 6)) : null,
          'groupName': null,
          'movie': movie.toJson(), // Convert Movie to JSON
        });
      }

      // Add a group match
      testMatches.add({
        'username': 'Movie Night Squad',
        'movieTitle': movies[4].title,
        'matchDate': DateTime.now().subtract(const Duration(days: 2)),
        'posterUrl': movies[4].posterUrl,
        'watched': false,
        'watchedDate': null,
        'groupName': 'Movie Night Squad',
        'movie': movies[4].toJson(), // Convert Movie to JSON
      });

      // Update user's match history
      widget.currentUser.matchHistory.addAll(testMatches);
      await UserProfileStorage.saveProfile(widget.currentUser);

      _showSnackBar('Created ${testMatches.length} test matches!', Colors.green);
    } catch (e) {
      _showSnackBar('Error creating test matches: $e', Colors.red);
    } finally {
      setState(() => _isLoading = false);
      widget.onDataChanged();
    }
  }

  void _addSharedLikes() async {
    setState(() => _isLoading = true);
    
    try {
      final movies = await TMDBApi.getPopularMovies();
      final sharedMovies = movies.take(3).toList();

      // Add to current user's likes
      for (final movie in sharedMovies) {
        widget.currentUser.likedMovies.add(movie);
        widget.currentUser.likedMovieIds.add(movie.id);
      }
      await UserProfileStorage.saveProfile(widget.currentUser);

      // Add to mock friends' likes
      for (final friendData in _mockFriends.take(2)) {
        final friendDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(friendData['uid'])
            .get();
        
        if (friendDoc.exists) {
          final friendProfile = UserProfile.fromJson(friendDoc.data()!);
          for (final movie in sharedMovies) {
            friendProfile.likedMovies.add(movie);
            friendProfile.likedMovieIds.add(movie.id);
          }
          
          await FirebaseFirestore.instance
              .collection('users')
              .doc(friendData['uid'])
              .set(friendProfile.toJson());
        }
      }

      _showSnackBar('Added ${sharedMovies.length} shared movie likes!', Colors.green);
    } catch (e) {
      _showSnackBar('Error adding shared likes: $e', Colors.red);
    } finally {
      setState(() => _isLoading = false);
      widget.onDataChanged();
    }
  }

  void _clearMatchHistory() async {
    setState(() => _isLoading = true);
    
    try {
      widget.currentUser.matchHistory.clear();
      await UserProfileStorage.saveProfile(widget.currentUser);
      
      _showSnackBar('Cleared all match history!', Colors.orange);
    } catch (e) {
      _showSnackBar('Error clearing match history: $e', Colors.red);
    } finally {
      setState(() => _isLoading = false);
      widget.onDataChanged();
    }
  }

  void _fullTestSetup() async {
    setState(() => _isLoading = true);
    
    try {
      // Create mock friends
      for (final friendData in _mockFriends) {
        // Create mock friend profile
        final friendProfile = UserProfile.empty().copyWith(
          uid: friendData['uid'],
          name: friendData['name'],
          preferredGenres: Set<String>.from(friendData['preferredGenres']),
          hasCompletedOnboarding: true,
        );

        // Add some random liked movies based on their genres
        final movies = await TMDBApi.getPopularMovies();
        final friendLikes = movies
            .where((movie) => movie.genres.any((genre) => 
                friendProfile.preferredGenres.contains(genre)))
            .take(5)
            .toList();
        
        for (final movie in friendLikes) {
          friendProfile.likedMovies.add(movie);
          friendProfile.likedMovieIds.add(movie.id);
        }

        // Save to Firestore
        await FirebaseFirestore.instance
            .collection('users')
            .doc(friendData['uid'])
            .set(friendProfile.toJson());
      }
      
      await Future.delayed(const Duration(seconds: 1));
      
      // Add shared likes
      final movies = await TMDBApi.getPopularMovies();
      final sharedMovies = movies.take(3).toList();

      // Add to current user's likes
      for (final movie in sharedMovies) {
        widget.currentUser.likedMovies.add(movie);
        widget.currentUser.likedMovieIds.add(movie.id);
      }
      await UserProfileStorage.saveProfile(widget.currentUser);

      // Add to mock friends' likes
      for (final friendData in _mockFriends.take(2)) {
        final friendDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(friendData['uid'])
            .get();
        
        if (friendDoc.exists) {
          final friendProfile = UserProfile.fromJson(friendDoc.data()!);
          for (final movie in sharedMovies) {
            friendProfile.likedMovies.add(movie);
            friendProfile.likedMovieIds.add(movie.id);
          }
          
          await FirebaseFirestore.instance
              .collection('users')
              .doc(friendData['uid'])
              .set(friendProfile.toJson());
        }
      }
      
      await Future.delayed(const Duration(seconds: 1));
      
      // Create test matches
      final testMatches = <Map<String, dynamic>>[];

      // Create matches with each mock friend
      for (int i = 0; i < _mockFriends.length && i < 4; i++) {
        final friend = _mockFriends[i];
        final movie = movies[i % movies.length];
        
        testMatches.add({
          'username': friend['name'],
          'movieTitle': movie.title,
          'matchDate': DateTime.now().subtract(Duration(days: i + 1)),
          'posterUrl': movie.posterUrl,
          'watched': i == 0, // First match is watched
          'watchedDate': i == 0 ? DateTime.now().subtract(const Duration(hours: 6)) : null,
          'groupName': null,
          'movie': movie,
        });
      }

      // Add a group match
      testMatches.add({
        'username': 'Movie Night Squad',
        'movieTitle': movies[4].title,
        'matchDate': DateTime.now().subtract(const Duration(days: 2)),
        'posterUrl': movies[4].posterUrl,
        'watched': false,
        'watchedDate': null,
        'groupName': 'Movie Night Squad',
        'movie': movies[4],
      });

      // Update user's match history
      widget.currentUser.matchHistory.addAll(testMatches);
      await UserProfileStorage.saveProfile(widget.currentUser);
      
      _showSnackBar('Full test setup complete! 🎉', Colors.green);
    } catch (e) {
      _showSnackBar('Error in full setup: $e', Colors.red);
    } finally {
      setState(() => _isLoading = false);
      widget.onDataChanged();
    }
  }

  void _resetEverything() async {
    setState(() => _isLoading = true);
    
    try {
      // Clear match history
      widget.currentUser.matchHistory.clear();
      widget.currentUser.likedMovies.clear();
      widget.currentUser.likedMovieIds.clear();
      await UserProfileStorage.saveProfile(widget.currentUser);
      
      // Delete mock friends
      for (final friendData in _mockFriends) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(friendData['uid'])
            .delete();
      }
      
      _showSnackBar('Reset everything! Starting fresh.', Colors.orange);
    } catch (e) {
      _showSnackBar('Error resetting: $e', Colors.red);
    } finally {
      setState(() => _isLoading = false);
      widget.onDataChanged();
    }
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        duration: const Duration(seconds: 3),
      ),
    );
  }
}