// REPLACE your entire mood_based_learning_engine.dart with this cleaned version:

import '../movie.dart';
import '../models/user_profile.dart';

// Mood-based session management (Perfect features removed)
enum CurrentMood {
  trueStory('True Stories', '📖', ['Biography', 'History', 'Drama', 'Documentary'], ['Based on a True Story', 'Real Events', 'True Story']),
  emotional('Deep & Emotional', '💭', ['Drama', 'Romance'], ['Emotional', 'Heartwarming', 'Moving']),
  thoughtful('Mind-Bending', '🤔', ['Drama', 'Sci-Fi', 'Mystery', 'Thriller'], ['Mind-Bending', 'Complex', 'Thought-Provoking', 'Twist']),
  lighthearted('Laid-Back & Fun', '🎉', ['Family', 'Animation', 'Comedy', 'TV Movie'], ['Comfort', 'Peaceful', 'Wholesome', 'Cozy', 'Funny', 'Silly', 'Upbeat']),
  scary('Thrills & Chills', '😱', ['Horror', 'Thriller'], ['Scary', 'Suspenseful', 'Dark']),
  romantic('Love Stories', '💕', ['Romance'], ['Romantic', 'Sweet', 'Heartwarming']),
  adventurous('Epic Adventure', '🗺️', ['Adventure', 'Fantasy', 'Action'], ['Epic', 'Action-Packed', 'Journey']);

  const CurrentMood(this.displayName, this.emoji, this.preferredGenres, this.preferredVibes);
  
  final String displayName;
  final String emoji;
  final List<String> preferredGenres;
  final List<String> preferredVibes;
}

class SessionContext {
  final CurrentMood moods;
  final DateTime startTime;
  final List<String> groupMemberIds;
  
  SessionContext({
    required this.moods,
    required this.groupMemberIds,
    DateTime? startTime,
  }) : startTime = startTime ?? DateTime.now();
}

class MoodBasedLearningEngine {
  
  /// Generate mood-based session for solo, friend, or group
  static Future<List<Movie>> generateMoodBasedSession({
    required UserProfile user,
    required List<Movie> movieDatabase,
    required SessionContext sessionContext,
    required Set<String> seenMovieIds,
    required Set<String> sessionPassedMovieIds,
    int sessionSize = 30,
  }) async {
    print("🎭 Generating mood session: ${sessionContext.moods.displayName}");
    print("   Target genres: ${sessionContext.moods.preferredGenres}");
    print("   Target vibes: ${sessionContext.moods.preferredVibes}");
    
    // Step 1: Filter by mood
    final moodFilteredMovies = _filterByMood(
      movieDatabase, 
      sessionContext.moods, 
      seenMovieIds, 
      sessionPassedMovieIds
    );
    
    if (moodFilteredMovies.isEmpty) {
      print("⚠️ No movies found for mood, using fallback");
      return _getFallbackMovies(movieDatabase, seenMovieIds, sessionSize);
    }
    
    // Step 2: Light personalization within mood
    final scoredMovies = _lightPersonalization(moodFilteredMovies, user);
    
    // Step 3: Sort with discovery balance (70% user preference, 30% discovery)
    final result = _balancePersonalizationWithDiscovery(scoredMovies, sessionSize);
    
    print("🎬 Generated ${result.length} mood movies with light personalization");
    print("   Sample: ${result.take(3).map((m) => m.title).join(', ')}");
    
    return result;
  }
  
  /// Generate session for group (everyone sees same movies)
  static Future<List<Movie>> generateGroupSession({
    required List<UserProfile> groupMembers,
    required List<Movie> movieDatabase,
    required SessionContext sessionContext,
    required Set<String> seenMovieIds,
    int sessionSize = 25,
  }) async {
    print("👥 Generating shared mood pool for ${groupMembers.length} people: ${sessionContext.moods.displayName}");
    
    // Step 1: Filter by mood (same for everyone)
    final moodFilteredMovies = _filterByMood(
      movieDatabase, 
      sessionContext.moods, 
      seenMovieIds, 
      <String>{} // No session passed movies for group sessions
    );
    
    if (moodFilteredMovies.isEmpty) {
      print("⚠️ No movies found for group mood, using fallback");
      return _getFallbackMovies(movieDatabase, seenMovieIds, sessionSize);
    }
    
    // Step 2: Light group personalization
    final scoredMovies = _lightGroupPersonalization(moodFilteredMovies, groupMembers);
    
    // Step 3: Create shared pool focusing on "good for tonight"
    final sharedPool = _createSharedPool(scoredMovies, sessionSize);
    
    print("🎬 Generated ${sharedPool.length} shared movies for group");
    print("   Everyone will see: ${sharedPool.take(3).map((m) => m.title).join(', ')}");
    
    return sharedPool;
  }
  
  /// Generate session for blended moods
  static Future<List<Movie>> generateBlendedMoodSession({
    required UserProfile user,
    required List<Movie> movieDatabase,
    required List<CurrentMood> selectedMoods,
    required Set<String> seenMovieIds,
    required Set<String> sessionPassedMovieIds,
    int sessionSize = 30,
  }) async {
    print("🎭 Generating blended mood session for: ${selectedMoods.map((m) => m.displayName).join(' + ')}");
    
    // Combine all preferred genres and vibes from selected moods
    final Set<String> allPreferredGenres = {};
    final Set<String> allPreferredVibes = {};
    
    for (final mood in selectedMoods) {
      allPreferredGenres.addAll(mood.preferredGenres);
      allPreferredVibes.addAll(mood.preferredVibes);
    }
    
    print("   Combined genres: ${allPreferredGenres.join(', ')}");
    print("   Combined vibes: ${allPreferredVibes.join(', ')}");
        
    // Filter movies that match any of the blended criteria
    final blendedMovies = <Movie>[];
    final excludedMovieIds = <String>{};
    excludedMovieIds.addAll(seenMovieIds);
    excludedMovieIds.addAll(sessionPassedMovieIds);
    
    for (final movie in movieDatabase) {
      if (excludedMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      
      final hasGenreMatch = movie.genres.any((g) => allPreferredGenres.contains(g));
      final hasVibeMatch = movie.tags.any((v) => allPreferredVibes.contains(v));
      
      if (hasGenreMatch || hasVibeMatch) {
        blendedMovies.add(movie);
      }
    }
    
    // Apply light personalization
    final scoredMovies = _lightPersonalization(blendedMovies, user);
    
    // Balance personalization with discovery
    final result = _balancePersonalizationWithDiscovery(scoredMovies, sessionSize);
    
    print("🎬 Generated ${result.length} blended mood movies");
    return result;
  }
  
  /// Light learning for mood interactions
  static void learnFromMoodInteraction(UserProfile user, Movie movie, SessionContext context, bool isLike) {
    print("📊 LIGHT LEARNING: ${isLike ? 'LIKE' : 'PASS'} ${movie.title} in ${context.moods.displayName} context");
    
    if (isLike) {
      // Very light learning - just for future sessions
      for (final genre in movie.genres) {
        user.genreScores[genre] = _updateScore(user.genreScores[genre] ?? 0, 0.3, true);
      }
      
      for (final vibe in movie.tags) {
        user.vibeScores[vibe] = _updateScore(user.vibeScores[vibe] ?? 0, 0.3, true);
      }
      
      user.likedMovies.add(movie);
      user.likedMovieIds.add(movie.id);
    } else {
      // Light pass learning - this is "not in mood tonight", not a dislike
      for (final genre in movie.genres) {
        user.dislikeScores[genre] = _updateScore(user.dislikeScores[genre] ?? 0, 0.1, true);
      }
      
      user.passedMovieIds.add(movie.id);
    }
    
    user.lastActivityDate = DateTime.now();
    print("   ⚠️ This learning will NOT affect current mood session - only future sessions");
  }
  
  // PRIVATE HELPER METHODS
  
  /// Filter movies by mood criteria
  static List<Movie> _filterByMood(
    List<Movie> movieDatabase, 
    CurrentMood mood, 
    Set<String> seenMovieIds, 
    Set<String> sessionPassedMovieIds
  ) {
    final moodMovies = <Movie>[];
    final targetGenres = mood.preferredGenres.toSet();
    final targetVibes = mood.preferredVibes.toSet();
    
    final excludedMovieIds = <String>{};
    excludedMovieIds.addAll(seenMovieIds);
    excludedMovieIds.addAll(sessionPassedMovieIds);

    final disqualifyingTagsPerMood = {
      'Laid-Back & Fun': {
        'Disturbing', 'Dark', 'Mind-Bending', 'Twisty', 'Grim', 'Sad', 'Philosophical',
        'Traumatic', 'Violent', 'War', 'Tragic', 'Horror', 'Slow Burn', 'Emotional',
        'Trauma', 'Gory', 'Grief', 'Serious', 'Heavy', 'Depressing', 'Romantic Drama',
        'Melancholy', 'Cerebral', 'Slasher',
      },
      'Deep & Emotional': {
        'Twisty', 'Action-Packed', 'Violent', 'Gory', 'Disturbing', 'Supernatural',
        'Slasher', 'Fantasy', 'Abstract', 'High Stakes', 'Fast-Paced', 'Experimental',
        'Over-Stylized', 'Weird', 'Silly', 'Parody', 'Horror', 'Dark Comedy', 'Stalker',
        'Cynical Humor', 'Cringe', 'Uncomfortable', 'Obsession', 'Psychological Comedy'
      },
      'Mind-Bending': {
        'Silly', 'Wholesome', 'Light-Hearted', 'Family-Friendly', 'Romantic Comedy',
        'Slapstick', 'Simple', 'Straightforward', 'Comfort', 'Cozy', 'Heartwarming',
        'Musical', 'Kids', 'Rewatchable', 'Uplifting', 'Cheesy', 'Predictable'
      },
      'Thrills & Chills': {
        'Comfort', 'Cozy', 'Peaceful', 'Wholesome', 'Heartwarming', 'Feel-Good',
        'Romantic', 'Light-Hearted', 'Family-Friendly', 'Animation', 'Musical',
        'Funny', 'Silly', 'Uplifting', 'Easy Watch', 'Kids', 'Rewatchable', 'Cheesy'
      },
      'Love Stories': {
        'Horror', 'Violent', 'Dark', 'Disturbing', 'Mind-Bending', 'Surrealism',
        'Twisty', 'Sci-Fi/Techy', 'War', 'Crime', 'Gory', 'Slasher', 'Supernatural',
        'Abstract', 'High Stakes', 'Action-Packed', 'Cynical', 'Unromantic', 'Grim',
        'Trauma', 'Philosophical', 'Experimental'
      },
      'Epic Adventure': {
        'Romantic', 'Heartwarming', 'Wholesome', 'Cozy', 'Light-Hearted', 'Slow Burn',
        'Philosophical', 'Abstract', 'Surrealism', 'Emotional', 'Musical',
        'Family-Friendly', 'Slice of Life', 'Peaceful', 'Minimalist', 'Feel-Good',
        'Domestic', 'Cerebral', 'Comedy-Driven', 'Sad', 'Tragic'
      },
      'True Stories': {
        'Sci-Fi/Techy', 'Fantasy', 'Supernatural', 'Mind-Bending', 'Surrealism',
        'Magical', 'Alien', 'Time Travel', 'Multiverse', 'Mythical', 'Epic Fantasy',
        'Superhero', 'Paranormal', 'Witchcraft', 'Space', 'Cyberpunk', 'Monster',
        'Fictional', 'Made Up', 'Alternate Reality', 'Dystopian'
      }
    };

    final disqualifyingTags = disqualifyingTagsPerMood[mood.displayName] ?? {};

    for (final movie in movieDatabase) {
      if (excludedMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;

      // Runtime check (only for Laid-Back & Fun)
      if (mood.displayName == 'Laid-Back & Fun' && movie.runtime != null && movie.runtime! > 130) continue;

      // Disqualifying tags check
      final hasConflictTag = movie.tags.any((tag) => disqualifyingTags.contains(tag));
      if (hasConflictTag) continue;

      // Must match genre OR vibe
      final hasGenreMatch = movie.genres.any((g) => targetGenres.contains(g));
      final hasVibeMatch = movie.tags.any((v) => targetVibes.contains(v));

      if (hasGenreMatch || hasVibeMatch) {
        moodMovies.add(movie);
      }
    }
    
    print("✅ Found ${moodMovies.length} movies matching mood: ${mood.displayName}");
    return moodMovies;
  }
  
  /// Light personalization for solo sessions
  static Map<Movie, double> _lightPersonalization(List<Movie> movies, UserProfile user) {
    final scoredMovies = <Movie, double>{};
    
    for (final movie in movies) {
      double score = 5.0; // Base "good for tonight" score
      
      // Light user preference boost (not heavy learning)
      for (final genre in movie.genres) {
        final userLikes = user.genreScores[genre] ?? 0;
        final userDislikes = user.dislikeScores[genre] ?? 0;
        score += (userLikes * 0.3) - (userDislikes * 0.2); // Light influence
      }
      
      for (final vibe in movie.tags) {
        final userLikes = user.vibeScores[vibe] ?? 0;
        final userDislikes = user.dislikeVibeScores[vibe] ?? 0;
        score += (userLikes * 0.3) - (userDislikes * 0.2); // Light influence
      }
      
      // Quality boost for "good tonight" choices
      if (movie.rating != null && movie.rating! > 7.0) {
        score += 1.5;
      }
      
      // Popular movies are safer "tonight" choices
      if (movie.voteCount != null && movie.voteCount! > 5000) {
        score += 1.0;
      }
      
      scoredMovies[movie] = score;
    }
    
    return scoredMovies;
  }
  
  /// Light group personalization for friend/group sessions
  static Map<Movie, double> _lightGroupPersonalization(List<Movie> movies, List<UserProfile> groupMembers) {
    final scoredMovies = <Movie, double>{};
    
    for (final movie in movies) {
      double score = 5.0; // Base "good for tonight" score
      
      // Light group preference calculation
      double groupBonus = 0.0;
      bool anyoneStronglyDislikes = false;
      
      for (final member in groupMembers) {
        double memberScore = 0.0;
        
        // Check if this member likes these genres/vibes
        for (final genre in movie.genres) {
          final memberLikes = member.genreScores[genre] ?? 0;
          final memberDislikes = member.dislikeScores[genre] ?? 0;
          memberScore += (memberLikes * 0.2) - (memberDislikes * 0.3);
          
          // Veto power: if anyone strongly dislikes it, skip
          if (memberDislikes > 4.0) {
            anyoneStronglyDislikes = true;
            break;
          }
        }
        
        for (final vibe in movie.tags) {
          final memberLikes = member.vibeScores[vibe] ?? 0;
          final memberDislikes = member.dislikeVibeScores[vibe] ?? 0;
          memberScore += (memberLikes * 0.2) - (memberDislikes * 0.3);
        }
        
        groupBonus += memberScore;
      }
      
      // Skip movies anyone strongly dislikes
      if (anyoneStronglyDislikes) continue;
      
      // Add light group preference
      score += (groupBonus / groupMembers.length);
      
      // Extra boost for crowd-pleasers
      if (movie.rating != null && movie.rating! > 7.5) {
        score += 2.0; // Higher boost for group sessions
      }
      
      scoredMovies[movie] = score;
    }
    
    return scoredMovies;
  }
  
  /// Balance personalization with discovery
  static List<Movie> _balancePersonalizationWithDiscovery(Map<Movie, double> scoredMovies, int sessionSize) {
    final sorted = scoredMovies.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    // Take top 70% based on preferences
    final topCount = (sessionSize * 0.7).round();
    final topMovies = sorted.take(topCount).map((e) => e.key).toList();
    
    // Take random 30% from remaining for discovery
    final remaining = sorted.skip(topCount).map((e) => e.key).toList();
    remaining.shuffle();
    final discoveryCount = sessionSize - topCount;
    final discoveryMovies = remaining.take(discoveryCount).toList();
    
    // Combine and shuffle for varied order
    final result = [...topMovies, ...discoveryMovies];
    result.shuffle();
    
    return result.take(sessionSize).toList();
  }
  
  /// Create shared pool for groups (everyone gets same movies)
  static List<Movie> _createSharedPool(Map<Movie, double> scoredMovies, int sessionSize) {
    final sorted = scoredMovies.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    // For groups, focus more on consensus picks (80% top-rated, 20% discovery)
    final topCount = (sessionSize * 0.8).round();
    final topMovies = sorted.take(topCount).map((e) => e.key).toList();
    
    final remaining = sorted.skip(topCount).map((e) => e.key).toList();
    remaining.shuffle();
    final discoveryCount = sessionSize - topCount;
    final discoveryMovies = remaining.take(discoveryCount).toList();
    
    // DON'T shuffle for groups - everyone needs same order
    final result = [...topMovies, ...discoveryMovies];
    
    return result.take(sessionSize).toList();
  }
  
  static List<Movie> _getFallbackMovies(List<Movie> movieDatabase, Set<String> excludedMovieIds, int count) {
    final fallbackMovies = movieDatabase
        .where((movie) => 
            !excludedMovieIds.contains(movie.id) && 
            _meetsQualityThreshold(movie) && 
            _isSfwMovie(movie))
        .toList();
    
    fallbackMovies.shuffle();
    return fallbackMovies.take(count).toList();
  }
  
  static double _updateScore(double currentScore, double weight, bool isPositive) {
    const double maxScore = 20.0;
    const double minScore = 0.0;
    
    final newScore = isPositive 
        ? currentScore + weight 
        : (currentScore - weight).clamp(minScore, double.infinity);
    return newScore.clamp(minScore, maxScore);
  }
  
  static bool _meetsQualityThreshold(Movie movie) {
    return movie.posterUrl.isNotEmpty &&
           movie.rating != null &&
           movie.rating! >= 5.0 &&
           movie.voteCount != null &&
           movie.voteCount! >= 1000;
  }
  
  static bool _isSfwMovie(Movie movie) {
    final bannedKeywords = ['porn', 'erotic', 'xxx', 'adult', 'sex', 'nude', 'strip'];
    final lcTitle = movie.title.toLowerCase();
    final lcOverview = movie.overview.toLowerCase();
    return !bannedKeywords.any((kw) => lcTitle.contains(kw) || lcOverview.contains(kw));
  }

  // Public wrappers for helper methods
  static bool meetsQualityThreshold(Movie movie) {
    return _meetsQualityThreshold(movie);
  }

  static bool isSfwMovie(Movie movie) {
    return _isSfwMovie(movie);
  }
}