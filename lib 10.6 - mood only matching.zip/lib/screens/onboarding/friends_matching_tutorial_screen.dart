// File: lib/screens/onboarding/friends_matching_tutorial_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';
import '../../models/user_profile.dart';
import '../../movie.dart';
import '../../data/popular_movies_data.dart';
import '../../main_navigation.dart';
import '../../utils/user_profile_storage.dart';
import '../matched_screen.dart';
import 'dart:async';

// Tutorial phases enum
enum TutorialPhase { 
  introduction,
  friendSelection,
  preMatchExplanation, // ✅ Explain actions BEFORE matching
  swiping,
  matchDemo,
  postMatchSummary, // ✅ Quick summary after they experience it
  completed 
}

class FriendsMatchingTutorialScreen extends StatefulWidget {
  final UserProfile profile;
  final List<Movie> movies;

  const FriendsMatchingTutorialScreen({
    super.key,
    required this.profile,
    required this.movies,
  });

  @override
  State<FriendsMatchingTutorialScreen> createState() => _FriendsMatchingTutorialScreenState();
}

class _FriendsMatchingTutorialScreenState extends State<FriendsMatchingTutorialScreen> 
    with TickerProviderStateMixin {
  
  // Current state
  TutorialPhase currentPhase = TutorialPhase.introduction;
  late List<Movie> tutorialMovies;
  UserProfile? selectedFriend;
  int currentMovieIndex = 0;
  bool hasFoundMatch = false;
  
  // Tutorial friend (mock friend for demo)
  late UserProfile demoFriend;
  
  // Movies that will create matches
  final Set<String> matchingMovieIds = {
    'avengers_endgame',
    'the_hangover', 
    'shawshank_redemption'
  };
  
  // Match history for tutorial
  List<Map<String, dynamic>> matchHistory = [];
  
  // Animation controllers
  late AnimationController _fadeController;
  late AnimationController _slideController;
  
  // Animations
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    
    _initializeAnimations();
    _initializeTutorialData();
  }
  
  void _initializeAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeOut),
    );
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
  }
  
  void _initializeTutorialData() {
    tutorialMovies = PopularMoviesData.getOnboardingMovies();
    
    // Create a demo friend for the tutorial
    demoFriend = UserProfile(
      name: 'Alex',
      uid: 'demo_alex_123',
      preferredGenres: {'Action', 'Comedy', 'Sci-Fi'},
      preferredVibes: {'Action-Packed', 'Feel-Good'},
      blockedGenres: <String>{},
      blockedAttributes: <String>{},
      likedMovies: <Movie>{},
      likedMovieIds: matchingMovieIds,
      matchedMovies: <Movie>{},
      matchedMovieIds: <String>{},
      favouriteMovieIds: <String>{},
      matchHistory: <Map<String, dynamic>>[],
    );
    
    _startAnimations();
  }
  
  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) _slideController.forward();
    });
  }
  
  void _nextPhase() {
    setState(() {
      switch (currentPhase) {
        case TutorialPhase.introduction:
          currentPhase = TutorialPhase.friendSelection;
          break;
        case TutorialPhase.friendSelection:
          currentPhase = TutorialPhase.preMatchExplanation;
          selectedFriend = demoFriend;
          break;
        case TutorialPhase.preMatchExplanation:
          currentPhase = TutorialPhase.swiping;
          break;
        case TutorialPhase.swiping:
          currentPhase = TutorialPhase.matchDemo;
          break;
        case TutorialPhase.matchDemo:
          currentPhase = TutorialPhase.postMatchSummary;
          break;
        case TutorialPhase.postMatchSummary:
          currentPhase = TutorialPhase.completed;
          break;
        case TutorialPhase.completed:
          _completeTutorial();
          break;
      }
    });
    
    // Reset animations for new phase
    _fadeController.reset();
    _slideController.reset();
    _startAnimations();
  }
  
  bool _onSwipe(int previousIndex, int? currentIndex, CardSwiperDirection direction) {
    if (previousIndex >= tutorialMovies.length) return false;
    
    final movie = tutorialMovies[previousIndex];
    final isLike = direction == CardSwiperDirection.right;
    
    if (isLike && matchingMovieIds.contains(movie.id)) {
      // This creates a match! Store it for later
      matchHistory.add({
        'movie': movie,
        'friend': {'name': 'Alex'},
        'timestamp': DateTime.now(),
      });
      
      _showMatchScreen(movie);
      return true;
    }
    
    setState(() {
      currentMovieIndex = currentIndex ?? 0;
    });
    
    return true;
  }
  
  void _showMatchScreen(Movie movie) {
    print("🎬 Showing match screen for: ${movie.title}");
    
    // Use your actual MatchedScreen
    Navigator.push(
      context,
      PageRouteBuilder(
        opaque: false,
        barrierDismissible: false,
        pageBuilder: (context, animation, secondaryAnimation) {
          return MatchedScreen(
            movie: movie,
            currentUser: widget.profile,
            matchedName: selectedFriend?.name ?? 'Alex',
          );
        },
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(
            opacity: animation,
            child: child,
          );
        },
      ),
    ).then((_) {
      print("🔙 Returned from match screen, moving to next phase");
      
      // Ensure we're in the right state when returning
      if (mounted) {
        setState(() {
          currentPhase = TutorialPhase.postMatchSummary;
        });
        
        // Reset and restart animations
        _fadeController.reset();
        _slideController.reset();
        _startAnimations();
      }
    }).catchError((error) {
      print("❌ Error in match screen navigation: $error");
      
      // Fallback: proceed to next phase anyway
      if (mounted) {
        _nextPhase();
      }
    });
  }
  
  Future<void> _completeTutorial() async {
    // ✅ FIXED: Apply matches to profile for demonstration with proper serialization
    for (final match in matchHistory) {
      widget.profile.matchHistory.add({
        'username': match['friend']['name'],
        'movieTitle': (match['movie'] as Movie).title,
        'matchDate': (match['timestamp'] as DateTime).toIso8601String(),
        'posterUrl': (match['movie'] as Movie).posterUrl,
        'watched': false,
        'watchedDate': null,
        'groupName': null,
        'movie': (match['movie'] as Movie).toJson(),
      });
    }
    
    // Mark onboarding as complete
    final finalProfile = widget.profile.copyWith(
      hasCompletedOnboarding: true,
    );
    
    // Save the complete profile
    await UserProfileStorage.saveProfile(finalProfile);
    
    // Navigate to main app
    if (mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (_) => MainNavigation(
            profile: finalProfile,
            movies: widget.movies,
          ),
        ),
        (route) => false,
      );
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print("🏗️ Building tutorial phase: $currentPhase");
    
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: SafeArea(
        child: Stack(
          children: [
            FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: _buildCurrentPhase(),
              ),
            ),
            
            // Debug indicator (remove in production)
            Positioned(
              top: 10.h,
              right: 10.w,
              child: Container(
                padding: EdgeInsets.all(8.w),
                decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.8),
                  borderRadius: BorderRadius.circular(8.r),
                ),
                child: Text(
                  currentPhase.toString().split('.').last,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 10.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            
            // Emergency skip button
            Positioned(
              bottom: 20.h,
              right: 20.w,
              child: FloatingActionButton(
                mini: true,
                backgroundColor: Colors.orange,
                onPressed: () {
                  print("🚨 Emergency skip pressed from phase: $currentPhase");
                  if (currentPhase == TutorialPhase.completed) {
                    _completeTutorial();
                  } else {
                    _nextPhase();
                  }
                },
                child: Icon(Icons.skip_next, color: Colors.white, size: 20.sp),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildCurrentPhase() {
    print("🎨 Building phase widget for: $currentPhase");
    
    try {
      switch (currentPhase) {
        case TutorialPhase.introduction:
          return _buildIntroductionPhase();
        case TutorialPhase.friendSelection:
          return _buildFriendSelectionPhase();
        case TutorialPhase.preMatchExplanation:
          return _buildPreMatchExplanationPhase();
        case TutorialPhase.swiping:
          return _buildSwipingPhase();
        case TutorialPhase.matchDemo:
          return _buildMatchDemoPhase();
        case TutorialPhase.postMatchSummary:
          return _buildPostMatchSummaryPhase();
        case TutorialPhase.completed:
          return _buildCompletedPhase();
      }
    } catch (error) {
      print("❌ Error building phase $currentPhase: $error");
      
      // Fallback UI
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error, color: Colors.red, size: 64.sp),
            SizedBox(height: 16.h),
            Text(
              "Something went wrong",
              style: TextStyle(color: Colors.white, fontSize: 18.sp),
            ),
            SizedBox(height: 16.h),
            ElevatedButton(
              onPressed: _nextPhase,
              child: Text("Continue Tutorial"),
            ),
          ],
        ),
      );
    }
  }
  
  Widget _buildIntroductionPhase() {
    return Padding(
      padding: EdgeInsets.all(24.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.people,
            size: 80.sp,
            color: const Color(0xFFE5A00D),
          ),
          
          SizedBox(height: 32.h),
          
          Text(
            "Friend Matching Tutorial 👥",
            style: TextStyle(
              fontSize: 28.sp,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 24.h),
          
          Container(
            padding: EdgeInsets.all(20.w),
            decoration: BoxDecoration(
              color: const Color(0xFF1F1F1F),
              borderRadius: BorderRadius.circular(16.r),
              border: Border.all(
                color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
                width: 1.w,
              ),
            ),
            child: Column(
              children: [
                Text(
                  "Learn how to match movies with friends! 🎬",
                  style: TextStyle(
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFFE5A00D),
                  ),
                  textAlign: TextAlign.center,
                ),
                
                SizedBox(height: 16.h),
                
                Text(
                  "We'll show you how to:\n\n• Select a friend to swipe with\n• Find movies you both like\n• Save matches and find them later",
                  style: TextStyle(
                    fontSize: 16.sp,
                    color: Colors.white70,
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          
          const Spacer(),
          
          SizedBox(
            width: double.infinity,
            height: 56.h,
            child: ElevatedButton(
              onPressed: _nextPhase,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.r),
                ),
              ),
              child: Text(
                "Let's Start! ✨",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildFriendSelectionPhase() {
    return Padding(
      padding: EdgeInsets.all(24.w),
      child: Column(
        children: [
          // Header
          Container(
            padding: EdgeInsets.all(16.w),
            child: Column(
              children: [
                Icon(
                  Icons.people_outline,
                  color: const Color(0xFFE5A00D),
                  size: 48.sp,
                ),
                SizedBox(height: 16.h),
                Text(
                  "Step 1: Select a Friend",
                  style: TextStyle(
                    fontSize: 24.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 8.h),
                Text(
                  "Choose someone to find movies with",
                  style: TextStyle(
                    fontSize: 16.sp,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
          
          SizedBox(height: 32.h),
          
          // Demo friend selection
          Expanded(
            child: Column(
              children: [
                Text(
                  "Available Friends:",
                  style: TextStyle(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                
                SizedBox(height: 16.h),
                
                // Demo friend card
                Container(
                  padding: EdgeInsets.all(16.w),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1F1F1F),
                    borderRadius: BorderRadius.circular(12.r),
                    border: Border.all(
                      color: const Color(0xFFE5A00D).withValues(alpha: 0.5),
                      width: 2.w,
                    ),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 30.r,
                        backgroundColor: Colors.blue,
                        child: Text(
                          'A',
                          style: TextStyle(
                            fontSize: 24.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      
                      SizedBox(width: 16.w),
                      
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Alex (Demo Friend)',
                              style: TextStyle(
                                fontSize: 18.sp,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              'Likes: Action, Comedy, Sci-Fi',
                              style: TextStyle(
                                fontSize: 14.sp,
                                color: Colors.white70,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      Icon(
                        Icons.arrow_forward_ios,
                        color: const Color(0xFFE5A00D),
                        size: 20.sp,
                      ),
                    ],
                  ),
                ),
                
                SizedBox(height: 24.h),
                
                Text(
                  "In the real app, you'll see your actual friends here. Tap on a friend to start swiping together!",
                  style: TextStyle(
                    fontSize: 14.sp,
                    color: Colors.white54,
                    fontStyle: FontStyle.italic,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          
          SizedBox(
            width: double.infinity,
            height: 56.h,
            child: ElevatedButton(
              onPressed: _nextPhase,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.r),
                ),
              ),
              child: Text(
                "Select Alex and Continue",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  // ✅ NEW: Explain match actions BEFORE they start swiping
  Widget _buildPreMatchExplanationPhase() {
    return Padding(
      padding: EdgeInsets.all(24.w),
      child: Column(
        children: [
          // Header
          Container(
            padding: EdgeInsets.all(16.w),
            child: Column(
              children: [
                Icon(
                  Icons.lightbulb_outline,
                  color: const Color(0xFFE5A00D),
                  size: 48.sp,
                ),
                SizedBox(height: 16.h),
                Text(
                  "When You Match...",
                  style: TextStyle(
                    fontSize: 24.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 8.h),
                Text(
                  "Here's what will happen and your options",
                  style: TextStyle(
                    fontSize: 16.sp,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
          
          SizedBox(height: 32.h),
          
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  // What happens when you match
                  Container(
                    padding: EdgeInsets.all(16.w),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.green.withValues(alpha: 0.2),
                          Colors.blue.withValues(alpha: 0.2),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                      border: Border.all(
                        color: Colors.green.withValues(alpha: 0.5),
                        width: 1.w,
                      ),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.celebration,
                              color: Colors.green,
                              size: 24.sp,
                            ),
                            SizedBox(width: 8.w),
                            Text(
                              "When You Both Like a Movie",
                              style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.bold,
                                color: Colors.green,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 8.h),
                        Text(
                          "A celebration screen will appear with the movie you matched on. You'll then see two buttons with different purposes:",
                          style: TextStyle(
                            fontSize: 14.sp,
                            color: Colors.white70,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  SizedBox(height: 24.h),
                  
                  // Save Movie option
                  _buildActionPreview(
                    icon: Icons.favorite,
                    iconColor: Colors.red,
                    title: "Save Movie",
                    subtitle: "Add to your personal favorites",
                    description: "Use this when you personally want to remember this movie. It goes to your Favorites tab where you can find it anytime.",
                    whenToUse: "Best for: Movies you absolutely must watch or want to remember personally",
                    example: "Example: A highly-rated film you've been wanting to see",
                  ),
                  
                  SizedBox(height: 20.h),
                  
                  // Continue option  
                  _buildActionPreview(
                    icon: Icons.arrow_forward,
                    iconColor: Colors.green,
                    title: "Continue",
                    subtitle: "Keep building your shared watch list",
                    description: "Use this most of the time! The match gets saved to your Matches tab and you keep swiping to find more movies together.",
                    whenToUse: "Best for: Building a list of movies to watch together",
                    example: "Example: Movies that would be fun for your next movie night",
                  ),
                  
                  SizedBox(height: 24.h),
                  
                  // Pro tip
                  Container(
                    padding: EdgeInsets.all(16.w),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          const Color(0xFFE5A00D).withValues(alpha: 0.2),
                          const Color(0xFFFF8A00).withValues(alpha: 0.2),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                      border: Border.all(
                        color: const Color(0xFFE5A00D).withValues(alpha: 0.5),
                        width: 1.w,
                      ),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.psychology,
                              color: const Color(0xFFE5A00D),
                              size: 20.sp,
                            ),
                            SizedBox(width: 8.w),
                            Text(
                              "Pro Tip!",
                              style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.bold,
                                color: const Color(0xFFE5A00D),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 8.h),
                        Text(
                          "Use 'Continue' 90% of the time to build a big shared watch list. Only use 'Save Movie' for films you absolutely want to remember personally!",
                          style: TextStyle(
                            fontSize: 14.sp,
                            color: Colors.white70,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          SizedBox(
            width: double.infinity,
            height: 56.h,
            child: ElevatedButton(
              onPressed: _nextPhase,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.r),
                ),
              ),
              child: Text(
                "Got it! Let's start swiping 🎬",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  // Helper for action previews
  Widget _buildActionPreview({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required String description,
    required String whenToUse,
    required String example,
  }) {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: const Color(0xFF1F1F1F),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(
          color: iconColor.withValues(alpha: 0.3),
          width: 1.w,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(12.w),
                decoration: BoxDecoration(
                  color: iconColor.withValues(alpha: 0.2),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  icon,
                  color: iconColor,
                  size: 24.sp,
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: iconColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          
          SizedBox(height: 12.h),
          
          Text(
            description,
            style: TextStyle(
              fontSize: 14.sp,
              color: Colors.white70,
              height: 1.4,
            ),
          ),
          
          SizedBox(height: 8.h),
          
          Container(
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  whenToUse,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: iconColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  example,
                  style: TextStyle(
                    fontSize: 11.sp,
                    color: Colors.white60,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSwipingPhase() {
    return Column(
      children: [
        // Header - similar to your matcher screen
        Container(
          padding: EdgeInsets.all(16.w),
          child: Column(
            children: [
              Row(
                children: [
                  Icon(
                    Icons.people,
                    color: const Color(0xFFE5A00D),
                    size: 24.sp,
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Swiping with Alex",
                          style: TextStyle(
                            fontSize: 20.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        Text(
                          "Swipe right on movies you both might like!",
                          style: TextStyle(
                            fontSize: 14.sp,
                            color: Colors.white70,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              
              SizedBox(height: 16.h),
              
              // Friend indicator - similar to your matcher screen
              Container(
                padding: EdgeInsets.all(12.w),
                decoration: BoxDecoration(
                  color: const Color(0xFF1F1F1F),
                  borderRadius: BorderRadius.circular(12.r),
                  border: Border.all(
                    color: Colors.blue.withValues(alpha: 0.5),
                    width: 1.w,
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 32.w,
                      height: 32.w,
                      decoration: const BoxDecoration(
                        color: Colors.blue,
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          'A',
                          style: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Text(
                        "Swiping with Alex",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Icon(
                      Icons.favorite,
                      color: Colors.red.withValues(alpha: 0.7),
                      size: 16.sp,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        // Card swiper - similar to your matcher screen
        Expanded(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: CardSwiper(
              cardsCount: tutorialMovies.length,
              numberOfCardsDisplayed: 1,
              onSwipe: _onSwipe,
              cardBuilder: (context, index, percentX, percentY) {
                if (index >= tutorialMovies.length) return const SizedBox.shrink();
                
                final movie = tutorialMovies[index];
                return _buildTutorialMovieCard(movie, percentX.toDouble(), percentY.toDouble());
              },
            ),
          ),
        ),
        
        // Bottom instruction
        Container(
          padding: EdgeInsets.all(16.w),
          child: Text(
            "Swipe right on movies you'd both want to watch!",
            style: TextStyle(
              fontSize: 14.sp,
              color: Colors.white54,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }
  
  Widget _buildTutorialMovieCard(Movie movie, double percentX, double percentY) {
    final leftIntensity = percentX < 0 ? (-percentX).clamp(0.0, 1.0) : 0.0;
    final rightIntensity = percentX > 0 ? percentX.clamp(0.0, 1.0) : 0.0;
    final willMatch = matchingMovieIds.contains(movie.id);
    
    return Container(
      margin: EdgeInsets.all(8.r),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: willMatch ? Colors.green : const Color(0xFFE5A00D),
          width: willMatch ? 3.w : 2.w,
        ),
        boxShadow: [
          BoxShadow(
            color: (willMatch ? Colors.green : const Color(0xFFE5A00D)).withValues(alpha: 0.3),
            blurRadius: willMatch ? 16.r : 8.r,
            spreadRadius: willMatch ? 4.r : 2.r,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14.r),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(color: const Color(0xFF1A1A1A)),
            
            Column(
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      Image.network(
                        movie.posterUrl,
                        fit: BoxFit.contain,
                        width: double.infinity,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: Colors.grey[800],
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.movie, size: 64.sp, color: Colors.white30),
                                SizedBox(height: 8.h),
                                Text(
                                  movie.title,
                                  style: TextStyle(color: Colors.white70, fontSize: 16.sp),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      
                      // Match potential indicator
                      if (willMatch)
                        Positioned(
                          top: 12.h,
                          left: 12.w,
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                            decoration: BoxDecoration(
                              color: Colors.green,
                              borderRadius: BorderRadius.circular(12.r),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.local_fire_department, color: Colors.white, size: 12.sp),
                                SizedBox(width: 4.w),
                                Text(
                                  "MATCH!",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10.sp,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      
                      // Alex's opinion indicator
                      Positioned(
                        top: 12.h,
                        right: 12.w,
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                          decoration: BoxDecoration(
                            color: willMatch ? Colors.green : Colors.grey[600],
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'A',
                                style: TextStyle(fontSize: 12.sp, color: Colors.white),
                              ),
                              SizedBox(width: 4.w),
                              Icon(
                                willMatch ? Icons.favorite : Icons.help_outline,
                                color: Colors.white,
                                size: 12.sp,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(16.w),
                  child: Column(
                    children: [
                      Text(
                        movie.title,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18.sp,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 8.h),
                      Wrap(
                        spacing: 6.w,
                        runSpacing: 4.h,
                        children: movie.genres.take(3).map((genre) {
                          return Container(
                            padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                            decoration: BoxDecoration(
                              color: Colors.white10,
                              borderRadius: BorderRadius.circular(12.r),
                            ),
                            child: Text(
                              genre,
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 10.sp,
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            
            // Swipe indicators
            if (leftIntensity > 0)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [
                        Colors.red.withValues(alpha: 0.8 * leftIntensity),
                        Colors.red.withValues(alpha: 0),
                      ],
                      stops: const [0.0, 0.4],
                    ),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.close, color: Colors.red, size: 64.sp * leftIntensity),
                        SizedBox(height: 8.h),
                        Text(
                          "No match",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16.sp * leftIntensity,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            
            if (rightIntensity > 0)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerRight,
                      end: Alignment.centerLeft,
                      colors: [
                        (willMatch ? Colors.green : Colors.orange).withValues(alpha: 0.8 * rightIntensity),
                        (willMatch ? Colors.green : Colors.orange).withValues(alpha: 0),
                      ],
                      stops: const [0.0, 0.4],
                    ),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          willMatch ? Icons.celebration : Icons.favorite,
                          color: willMatch ? Colors.green : Colors.orange,
                          size: 64.sp * rightIntensity,
                        ),
                        SizedBox(height: 8.h),
                        Text(
                          willMatch ? "IT'S A MATCH!" : "You like it",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16.sp * rightIntensity,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildMatchDemoPhase() {
    // This will typically be skipped because _showMatchScreen handles the flow
    return Container();
  }
  
  // ✅ Simple post-match summary
  Widget _buildPostMatchSummaryPhase() {
    return Padding(
      padding: EdgeInsets.all(24.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.check_circle,
            size: 80.sp,
            color: Colors.green,
          ),
          
          SizedBox(height: 32.h),
          
          Text(
            "Perfect! 🎉",
            style: TextStyle(
              fontSize: 28.sp,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          
          SizedBox(height: 16.h),
          
          Text(
            "You just experienced your first match!",
            style: TextStyle(
              fontSize: 18.sp,
              color: Colors.white70,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 32.h),
          
          Container(
            padding: EdgeInsets.all(20.w),
            decoration: BoxDecoration(
              color: const Color(0xFF1F1F1F),
              borderRadius: BorderRadius.circular(16.r),
              border: Border.all(
                color: Colors.green.withValues(alpha: 0.3),
                width: 1.w,
              ),
            ),
            child: Column(
              children: [
                Text(
                  "Quick Reminder:",
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                  ),
                ),
                SizedBox(height: 12.h),
                Row(
                  children: [
                    Icon(Icons.favorite, color: Colors.red, size: 16.sp),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: Text(
                        "Save Movie → Goes to Favorites tab",
                        style: TextStyle(
                          fontSize: 14.sp,
                          color: Colors.white70,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 8.h),
                Row(
                  children: [
                    Icon(Icons.arrow_forward, color: Colors.green, size: 16.sp),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: Text(
                        "Continue → Goes to Matches tab + keep swiping",
                        style: TextStyle(
                          fontSize: 14.sp,
                          color: Colors.white70,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          const Spacer(),
          
          SizedBox(
            width: double.infinity,
            height: 56.h,
            child: ElevatedButton(
              onPressed: _nextPhase,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.r),
                ),
              ),
              child: Text(
                "Finish Tutorial ✨",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildCompletedPhase() {
    return Padding(
      padding: EdgeInsets.all(24.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.celebration,
            size: 80.sp,
            color: const Color(0xFFE5A00D),
          ),
          
          SizedBox(height: 32.h),
          
          Text(
            "Tutorial Complete! 🎉",
            style: TextStyle(
              fontSize: 28.sp,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          
          SizedBox(height: 16.h),
          
          Text(
            "You're now ready to match movies with friends!",
            style: TextStyle(
              fontSize: 18.sp,
              color: Colors.white70,
            ),
            textAlign: TextAlign.center,
          ),
          
          SizedBox(height: 32.h),
          
          Container(
            padding: EdgeInsets.all(20.w),
            decoration: BoxDecoration(
              color: const Color(0xFF1F1F1F),
              borderRadius: BorderRadius.circular(16.r),
              border: Border.all(
                color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
                width: 1.w,
              ),
            ),
            child: Column(
              children: [
                Text(
                  "You now know how to:",
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFFE5A00D),
                  ),
                ),
                SizedBox(height: 12.h),
                Text(
                  "✓ Select friends to swipe with\n✓ Choose 'Save Movie' vs 'Continue' wisely\n✓ Find saved movies in Favorites tab\n✓ Find all matches in Matches tab\n✓ Mark movies as watched when you see them",
                  style: TextStyle(
                    fontSize: 14.sp,
                    color: Colors.white70,
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
                
                SizedBox(height: 16.h),
                
                // Quick reminder
                Container(
                  padding: EdgeInsets.all(12.w),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.green.withValues(alpha: 0.2),
                        Colors.blue.withValues(alpha: 0.2),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Text(
                    "💡 Remember: Use 'Continue' most of the time to build your shared watch list!",
                    style: TextStyle(
                      fontSize: 12.sp,
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          
          const Spacer(),
          
          SizedBox(
            width: double.infinity,
            height: 56.h,
            child: ElevatedButton(
              onPressed: _nextPhase,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE5A00D),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.r),
                ),
              ),
              child: Text(
                "Start Using QueueTogether! 🚀",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}