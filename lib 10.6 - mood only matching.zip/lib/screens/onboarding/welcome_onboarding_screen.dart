// File: lib/screens/onboarding/welcome_onboarding_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'swiping_tutorial_screen.dart';
import '../../models/user_profile.dart';
import '../../movie.dart';

class WelcomeOnboardingScreen extends StatefulWidget {
  final UserProfile profile;
  final List<Movie> movies;

  const WelcomeOnboardingScreen({
    super.key,
    required this.profile,
    required this.movies,
  });

  @override
  State<WelcomeOnboardingScreen> createState() => _WelcomeOnboardingScreenState();
}

class _WelcomeOnboardingScreenState extends State<WelcomeOnboardingScreen> 
    with TickerProviderStateMixin {
  
  late AnimationController _titleController;
  late AnimationController _subtitleController;
  late AnimationController _buttonController;
  late AnimationController _floatingController;
  
  late Animation<double> _titleFade;
  late Animation<Offset> _titleSlide;
  late Animation<double> _subtitleFade;
  late Animation<Offset> _subtitleSlide;
  late Animation<double> _buttonScale;
  late Animation<double> _floating;

  @override
  void initState() {
    super.initState();
    
    _titleController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _subtitleController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _buttonController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    _floatingController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    );
    
    _titleFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _titleController, curve: Curves.easeOut),
    );
    
    _titleSlide = Tween<Offset>(
      begin: const Offset(0, -0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _titleController, curve: Curves.elasticOut));
    
    _subtitleFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _subtitleController, curve: Curves.easeOut),
    );
    
    _subtitleSlide = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _subtitleController, curve: Curves.elasticOut));
    
    _buttonScale = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _buttonController, curve: Curves.elasticOut),
    );
    
    _floating = Tween<double>(begin: -10.0, end: 10.0).animate(
      CurvedAnimation(parent: _floatingController, curve: Curves.easeInOut),
    );
    
    _startAnimations();
  }
  
  void _startAnimations() async {
    await Future.delayed(const Duration(milliseconds: 300));
    _titleController.forward();
    
    await Future.delayed(const Duration(milliseconds: 400));
    _subtitleController.forward();
    
    await Future.delayed(const Duration(milliseconds: 600));
    _buttonController.forward();
    
    _floatingController.repeat(reverse: true);
  }
  
  @override
  void dispose() {
    _titleController.dispose();
    _subtitleController.dispose();
    _buttonController.dispose();
    _floatingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: SafeArea(
        child: SingleChildScrollView(  // Add this wrapper
          padding: EdgeInsets.symmetric(horizontal: 24.w),
          child: ConstrainedBox(  // Add this wrapper
            constraints: BoxConstraints(
              minHeight: MediaQuery.of(context).size.height - 
                        MediaQuery.of(context).padding.top - 
                        MediaQuery.of(context).padding.bottom,
            ),
            child: IntrinsicHeight(  // Add this wrapper
              child: Column(
                children: [
                  SizedBox(height: 40.h),
                  
                  // Animated title
                  SlideTransition(
                    position: _titleSlide,
                    child: FadeTransition(
                      opacity: _titleFade,
                      child: Column(
                        children: [
                          // App icon with floating animation
                          AnimatedBuilder(
                            animation: _floating,
                            builder: (context, child) {
                              return Transform.translate(
                                offset: Offset(0, _floating.value),
                                child: Container(
                                  width: 80.w,
                                  height: 80.w,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    gradient: const LinearGradient(
                                      colors: [Color(0xFFE5A00D), Color(0xFFFF8A00)],
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
                                        blurRadius: 20.r,
                                        spreadRadius: 2.r,
                                      ),
                                    ],
                                  ),
                                  child: Icon(
                                    Icons.movie_filter_rounded,
                                    size: 40.sp,
                                    color: Colors.white,
                                  ),
                                ),
                              );
                            },
                          ),
                          
                          SizedBox(height: 24.h),
                          
                          Text(
                            "Welcome to QueueTogether! 🍿",
                            style: TextStyle(
                              fontSize: 28.sp,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                  
                  SizedBox(height: 32.h),
                  
                  // Animated subtitle
                  SlideTransition(
                    position: _subtitleSlide,
                    child: FadeTransition(
                      opacity: _subtitleFade,
                      child: Container(
                        padding: EdgeInsets.all(20.w),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1F1F1F),
                          borderRadius: BorderRadius.circular(16.r),
                          border: Border.all(
                            color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
                            width: 1.w,
                          ),
                        ),
                        child: Column(
                          children: [
                            Text(
                              "Let's find movies you'll love! 🎬",
                              style: TextStyle(
                                fontSize: 20.sp,
                                fontWeight: FontWeight.bold,
                                color: const Color(0xFFE5A00D),
                              ),
                              textAlign: TextAlign.center,
                            ),
                            
                            SizedBox(height: 16.h),
                            
                            Text(
                              "We'll show you some popular movies. Simply swipe right on ones you'd watch and left on ones you wouldn't.",
                              style: TextStyle(
                                fontSize: 16.sp,
                                color: Colors.white70,
                                height: 1.5,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            
                            SizedBox(height: 20.h),
                            
                            // Quick features preview
                            Row(
                              children: [
                                _buildFeatureIcon(
                                  Icons.favorite, 
                                  "Learn your taste",
                                  Colors.red,
                                ),
                                SizedBox(width: 16.w),
                                _buildFeatureIcon(
                                  Icons.people, 
                                  "Match with friends",
                                  Colors.blue,
                                ),
                                SizedBox(width: 16.w),
                                _buildFeatureIcon(
                                  Icons.smart_toy, 
                                  "AI recommendations",
                                  Colors.green,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  
                  Expanded(child: SizedBox()), // This pushes content up and button down
                  
                  // Animated start button
                  ScaleTransition(
                    scale: _buttonScale,
                    child: Container(
                      width: double.infinity,
                      height: 56.h,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFE5A00D), Color(0xFFFF8A00)],
                        ),
                        borderRadius: BorderRadius.circular(16.r),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
                            blurRadius: 12.r,
                            offset: Offset(0, 4.h),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (_) => SwipingTutorialScreen(
                                profile: widget.profile,
                                movies: widget.movies,
                              ),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16.r),
                          ),
                        ),
                        child: Text(
                          "Let's Start Swiping! ➡️",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                  
                  SizedBox(height: 16.h),
                  
                  // Skip option
                  TextButton(
                    onPressed: () {
                      // Skip to main app (you can implement this)
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Skip functionality - go to main app'),
                        ),
                      );
                    },
                    child: Text(
                      "Skip for now",
                      style: TextStyle(
                        color: Colors.white54,
                        fontSize: 14.sp,
                      ),
                    ),
                  ),
                  
                  SizedBox(height: 20.h), // Reduced from 32.h
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
  
  Widget _buildFeatureIcon(IconData icon, String label, Color color) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 40.w,
            height: 40.w,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: color,
              size: 20.sp,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            label,
            style: TextStyle(
              color: Colors.white70,
              fontSize: 12.sp,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}