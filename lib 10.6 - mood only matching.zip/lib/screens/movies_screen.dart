import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/user_profile.dart';
import '../movie.dart';
import '../utils/tmdb_api.dart';
import '../utils/enhanced_learning_engine.dart';
import '../utils/movie_loader.dart';
import 'movie_detail_screen.dart';
import 'dart:async';
import '../services/firestore_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:math' as math;

class MoviesScreen extends StatefulWidget {
  final UserProfile? currentUser;
  final Function(String mode, {String? sessionId, bool resume})? onNavigateToMatcher;

  const MoviesScreen({
    super.key, 
    required this.currentUser,
    this.onNavigateToMatcher,
  });

  @override
  State<MoviesScreen> createState() => _MoviesScreenState();
}

class _MoviesScreenState extends State<MoviesScreen> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late TabController _tabController;
  final FirestoreService _firestoreService = FirestoreService();
  
  // Session-based data
  Map<String, List<Movie>> _sessionMatches = {};
  bool _isLoadingSessions = true;
  bool _showQuickPicks = false;
  Map<String, DateTime> _notTonightItems = {};
  Set<String> _removedItems = {};
  
  // Discovery Tab Variables
  List<Movie> _movieDatabase = [];
  List<Movie> _personalizedRecommendations = [];
  List<Movie> _trendingMovies = [];
  List<Movie> _becauseYouLiked = [];
  Map<String, List<Movie>> _genreDeepDives = {};
  bool _isLoadingDiscover = true;
  bool _isRefreshingDiscover = false;
  String? _selectedGenreForDeepDive;
  List<MovieSession> _activeSessions = [];
  List<MovieSession> _readyToWatchSessions = [];
  List<MovieSession> _archivedSessions = [];
  
  // Quick swipe functionality
  Set<String> _quickLikedMovieIds = {};
  Set<String> _quickPassedMovieIds = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(_handleTabChange);
    
    _loadSessionData();
    _loadDiscoverContent();
    
    WidgetsBinding.instance.addObserver(this);
  }

  Future<void> _loadSessionData() async {
    if (!mounted || widget.currentUser == null) return;
    
    setState(() => _isLoadingSessions = true);
    
    try {
      final sessionsQuery = await FirebaseFirestore.instance
          .collection('movieSessions')
          .where('participantIds', arrayContains: widget.currentUser!.uid)
          .orderBy('createdAt', descending: true)
          .limit(50)
          .get();
      
      final now = DateTime.now();
      final sessions = <MovieSession>[];
      
      for (final doc in sessionsQuery.docs) {
        final session = MovieSession.fromFirestore(doc);
        sessions.add(session);
        
        if (session.matchedMovieIds.isNotEmpty) {
          final matches = <Movie>[];
          for (final movieId in session.matchedMovieIds) {
            try {
              final movie = _movieDatabase.firstWhere((m) => m.id == movieId);
              matches.add(movie);
            } catch (e) {
              // Movie not found in local database
            }
          }
          _sessionMatches[session.id] = matches;
        }
      }
      
      _activeSessions = sessions.where((s) => 
        s.status == SessionStatus.active || 
        s.status == SessionStatus.swiping
      ).toList();
      
      _readyToWatchSessions = sessions.where((s) => 
        s.status == SessionStatus.hasMatches &&
        now.difference(s.createdAt).inHours < 24
      ).toList();
      
      _archivedSessions = sessions.where((s) => 
        (s.status == SessionStatus.hasMatches && now.difference(s.createdAt).inHours >= 24) ||
        s.status == SessionStatus.completed ||
        s.status == SessionStatus.expired
      ).where((s) => now.difference(s.createdAt).inDays <= 30).toList();
      
    } catch (e) {
      print("❌ Error loading session data: $e");
    } finally {
      if (mounted) {
        setState(() => _isLoadingSessions = false);
      }
    }
  }

  void _handleTabChange() {
    if (_tabController.index == 0) {
      _loadSessionData();
    } else if (_tabController.index == 1 && _personalizedRecommendations.isEmpty) {
      _loadDiscoverContent();
    }
  }

  

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: const Color(0xFF121212),
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: const Color(0xFF1F1F1F),
          title: const Text("Movie Nights", style: TextStyle(fontWeight: FontWeight.bold)),
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: const Color(0xFFE5A00D),
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: const [
              Tab(text: "READY TO WATCH"),
              Tab(text: "DISCOVER"),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            _buildReadyToWatchTab(),
            _buildDiscoverTab(),
          ],
        ),
      ),
    );
  }

  Widget _buildReadyToWatchTab() {
    if (_isLoadingSessions) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Color(0xFFE5A00D)),
            SizedBox(height: 16.h),
            Text(
              "Finding your perfect picks...",
              style: TextStyle(color: Colors.white70, fontSize: 16.sp),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color: Color(0xFFE5A00D),
      backgroundColor: Color(0xFF1F1F1F),
      onRefresh: _loadSessionData,
      child: SingleChildScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        child: Column(
          children: [
            // Smart header with context
            _buildSmartHeader(),
            
            // PRIMARY: Tonight's Queue (Max 5 high-confidence picks)
            _buildTonightsQueue(),
            
            // SECONDARY: Quick Context Options (Progressive disclosure)
            _buildQuickPicks(),
            
            // TERTIARY: Your Collection (Smarter personal favorites)
            _buildSmartCollection(),
            
            // QUATERNARY: More Options (Hidden until needed)
            if (_shouldShowMoreOptions()) _buildMoreOptions(),
            
            // Empty state only if absolutely nothing
            if (_getTonightsQueueItems().isEmpty && _getQuickPicksItems().isEmpty)
              _buildIntelligentEmptyState(),
            
            SizedBox(height: 32.h),
          ],
        ),
      ),
    );
  }

Widget _buildSmartHeader() {
  final timeOfDay = _getTimeOfDayContext();
  final contextMessage = _getContextualMessage();
  final primaryAction = _getPrimaryActionForContext();
  
  return Container(
    margin: EdgeInsets.all(16.w),
    padding: EdgeInsets.all(20.w),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color(0xFFE5A00D).withValues(alpha: 0.15),
          Color(0xFF1F1F1F),
        ],
      ),
      borderRadius: BorderRadius.circular(16.r),
      border: Border.all(color: Color(0xFFE5A00D).withValues(alpha: 0.3)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              _getContextIcon(),
              color: Color(0xFFE5A00D),
              size: 24.sp,
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Ready to Watch",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    contextMessage,
                    style: TextStyle(
                      color: Color(0xFFE5A00D),
                      fontSize: 14.sp,
                    ),
                  ),
                ],
              ),
            ),
            
            // Context-aware primary action
            ElevatedButton.icon(
              onPressed: primaryAction['action'],
              icon: Icon(primaryAction['icon'], size: 16.sp),
              label: Text(primaryAction['label']),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFFE5A00D),
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.r),
                ),
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
              ),
            ),
          ],
        ),
      ],
    ),
  );
}

Widget _buildTonightsQueue() {
  final queueItems = _getTonightsQueueItems();
  
  if (queueItems.isEmpty) return SizedBox.shrink();
  
  return Container(
    margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 24.h),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header with smart context
        Container(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 12.h),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                decoration: BoxDecoration(
                  color: Color(0xFFE5A00D),
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.play_circle_filled, color: Colors.black, size: 16.sp),
                    SizedBox(width: 4.w),
                    Text(
                      "TONIGHT'S QUEUE",
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 12.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Text(
                  _getQueueSubtitle(queueItems.length),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              
              // Smart refresh button
              GestureDetector(
                onTap: _refreshTonightsQueue,
                child: Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.refresh, color: Colors.white70, size: 16.sp),
                      SizedBox(width: 4.w),
                      Text(
                        "Refresh",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        
        // Primary queue items (max 5, optimized for decision-making)
        ...queueItems.asMap().entries.map((entry) {
          final index = entry.key;
          final item = entry.value;
          return Container(
            margin: EdgeInsets.only(bottom: index < queueItems.length - 1 ? 16.h : 0),
            child: _buildQueueItemCard(item, index == 0), // First item is "recommended"
          );
        }).toList(),
      ],
    ),
  );
}

Widget _buildQueueItemCard(QueueItem item, bool isRecommended) {
  return Container(
    padding: EdgeInsets.all(16.w),
    decoration: BoxDecoration(
      gradient: isRecommended 
          ? LinearGradient(
              colors: [
                Color(0xFFE5A00D).withValues(alpha: 0.2),
                Color(0xFF2A2A2A),
              ],
            )
          : null,
      color: isRecommended ? null : Color(0xFF1F1F1F),
      borderRadius: BorderRadius.circular(16.r),
      border: Border.all(
        color: isRecommended 
            ? Color(0xFFE5A00D).withValues(alpha: 0.5)
            : Colors.white.withValues(alpha: 0.1),
        width: isRecommended ? 2.w : 1.w,
      ),
    ),
    child: Row(
      children: [
        // Movie poster or session icon
        Container(
          width: 80.w,
          height: 120.h,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.r),
            color: Colors.grey[800],
          ),
          child: item.type == QueueItemType.movie
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(12.r),
                  child: Image.network(
                    item.movie!.posterUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Icon(
                      Icons.movie,
                      color: Colors.white30,
                      size: 32.sp,
                    ),
                  ),
                )
              : Container(
                  decoration: BoxDecoration(
                    color: Color(0xFFE5A00D).withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        item.session!.participantIds.length == 1 
                            ? Icons.person 
                            : Icons.group,
                        color: Color(0xFFE5A00D),
                        size: 28.sp,
                      ),
                      SizedBox(height: 4.h),
                      Text(
                        "${item.matches!.length}",
                        style: TextStyle(
                          color: Color(0xFFE5A00D),
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "matches",
                        style: TextStyle(
                          color: Color(0xFFE5A00D),
                          fontSize: 10.sp,
                        ),
                      ),
                    ],
                  ),
                ),
        ),
        
        SizedBox(width: 16.w),
        
        // Content info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Recommended badge
              if (isRecommended) ...[
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: Color(0xFFE5A00D),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  child: Text(
                    "RECOMMENDED",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 10.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(height: 8.h),
              ],
              
              // Title and context
              Text(
                item.title,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              
              SizedBox(height: 4.h),
              
              // Smart subtitle with reasoning
              Text(
                item.subtitle,
                style: TextStyle(
                  color: isRecommended ? Color(0xFFE5A00D) : Colors.white70,
                  fontSize: 13.sp,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              
              SizedBox(height: 8.h),
              
              // Context tags
              Wrap(
                spacing: 6.w,
                children: item.contextTags.map((tag) => Container(
                  padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Text(
                    tag,
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10.sp,
                    ),
                  ),
                )).toList(),
              ),
            ],
          ),
        ),
        
        SizedBox(width: 12.w),
        
        // Actions
        Column(
          children: [
            // Primary action
            ElevatedButton(
              onPressed: () => _handlePrimaryAction(item),
              style: ElevatedButton.styleFrom(
                backgroundColor: isRecommended ? Color(0xFFE5A00D) : Colors.blue,
                foregroundColor: isRecommended ? Colors.black : Colors.white,
                minimumSize: Size(80.w, 36.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18.r),
                ),
              ),
              child: Text(
                item.primaryActionLabel,
                style: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            
            SizedBox(height: 8.h),
            
            // Quick actions
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Not tonight button
                GestureDetector(
                  onTap: () => _notTonight(item),
                  child: Container(
                    padding: EdgeInsets.all(6.w),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(6.r),
                    ),
                    child: Icon(
                      Icons.schedule_outlined,
                      color: Colors.white70,
                      size: 16.sp,
                    ),
                  ),
                ),
                
                SizedBox(width: 8.w),
                
                // Remove button
                GestureDetector(
                  onTap: () => _removeFromQueue(item),
                  child: Container(
                    padding: EdgeInsets.all(6.w),
                    decoration: BoxDecoration(
                      color: Colors.red.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(6.r),
                    ),
                    child: Icon(
                      Icons.close,
                      color: Colors.red,
                      size: 16.sp,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ],
    ),
  );
}

Widget _buildQuickPicks() {
  final quickPicks = _getQuickPicksItems();
  
  if (quickPicks.isEmpty) return SizedBox.shrink();
  
  return Container(
    margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 24.h),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Expandable header
        GestureDetector(
          onTap: () => setState(() => _showQuickPicks = !_showQuickPicks),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 12.h),
            child: Row(
              children: [
                Icon(
                  Icons.flash_on,
                  color: Colors.blue,
                  size: 20.sp,
                ),
                SizedBox(width: 8.w),
                Text(
                  "Quick Picks",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(width: 8.w),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: Colors.blue.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  child: Text(
                    _getQuickPicksLabel(),
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Spacer(),
                Icon(
                  _showQuickPicks ? Icons.expand_less : Icons.expand_more,
                  color: Colors.white70,
                  size: 24.sp,
                ),
              ],
            ),
          ),
        ),
        
        // Progressive disclosure content
        if (_showQuickPicks) ...[
          SizedBox(height: 12.h),
          SizedBox(
            height: 180.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: quickPicks.length,
              itemBuilder: (context, index) {
                return _buildQuickPickCard(quickPicks[index]);
              },
            ),
          ),
        ],
      ],
    ),
  );
}

Widget _buildQuickPickCard(Movie movie) {
  return Container(
    width: 120.w,
    margin: EdgeInsets.only(right: 12.w),
    child: GestureDetector(
      onTap: () => _watchMovie(movie),
      child: Column(
        children: [
          // Poster
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.r),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    blurRadius: 8.r,
                    offset: Offset(0, 4.h),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12.r),
                child: Stack(
                  children: [
                    Image.network(
                      movie.posterUrl,
                      fit: BoxFit.cover,
                      width: double.infinity,
                      errorBuilder: (_, __, ___) => Container(
                        color: Colors.grey[800],
                        child: Icon(Icons.movie, color: Colors.white30),
                      ),
                    ),
                    
                    // Context overlay
                    Positioned(
                      top: 8.h,
                      left: 8.w,
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 3.h),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.7),
                          borderRadius: BorderRadius.circular(6.r),
                        ),
                        child: Text(
                          _getMovieContextLabel(movie),
                          style: TextStyle(
                            color: Color(0xFFE5A00D),
                            fontSize: 10.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    
                    // Quick action overlay
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.0),
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        child: Center(
                          child: Container(
                            padding: EdgeInsets.all(8.w),
                            decoration: BoxDecoration(
                              color: Color(0xFFE5A00D),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              Icons.play_arrow,
                              color: Colors.black,
                              size: 20.sp,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          
          SizedBox(height: 8.h),
          
          // Title
          Text(
            movie.title,
            style: TextStyle(
              color: Colors.white,
              fontSize: 13.sp,
              fontWeight: FontWeight.w500,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    ),
  );
}

Widget _buildSmartCollection() {
  final collectionItems = _getSmartCollectionItems();
  
  return Container(
    margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 24.h),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Container(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 12.h),
          child: Row(
            children: [
              Icon(Icons.favorite, color: Colors.red, size: 20.sp),
              SizedBox(width: 8.w),
              Text(
                "Your Collection",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Spacer(),
              if (collectionItems.isNotEmpty)
                Text(
                  "Recently liked",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14.sp,
                  ),
                ),
            ],
          ),
        ),
        
        if (collectionItems.isEmpty)
          _buildCollectionEmptyState()
        else
          SizedBox(
            height: 140.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: collectionItems.length,
              itemBuilder: (context, index) {
                return _buildCollectionMovieCard(collectionItems[index]);
              },
            ),
          ),
      ],
    ),
  );
}

Widget _buildMoreOptions() {
  return Container(
    margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 0),
    child: ExpansionTile(
      leading: Icon(Icons.more_horiz, color: Colors.white70, size: 20.sp),
      title: Text(
        "More Options",
        style: TextStyle(
          color: Colors.white,
          fontSize: 16.sp,
          fontWeight: FontWeight.bold,
        ),
      ),
      subtitle: Text(
        "Older sessions and archived content",
        style: TextStyle(
          color: Colors.white70,
          fontSize: 12.sp,
        ),
      ),
      children: [
        // Show archived sessions and older content here
        ..._getArchivedItems().map((item) => _buildArchiveListItem(item)).toList(),
      ],
    ),
  );
}

Widget _buildIntelligentEmptyState() {
  final suggestions = _getEmptyStateSuggestions();
  
  return Container(
    margin: EdgeInsets.all(32.w),
    padding: EdgeInsets.all(32.w),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color(0xFFE5A00D).withValues(alpha: 0.1),
          Colors.blue.withValues(alpha: 0.05),
        ],
      ),
      borderRadius: BorderRadius.circular(20.r),
      border: Border.all(
        color: Color(0xFFE5A00D).withValues(alpha: 0.3),
        width: 1.w,
      ),
    ),
    child: Column(
      children: [
        Icon(
          _getEmptyStateIcon(),
          size: 64.sp,
          color: Color(0xFFE5A00D),
        ),
        
        SizedBox(height: 20.h),
        
        Text(
          _getEmptyStateTitle(),
          style: TextStyle(
            color: Colors.white,
            fontSize: 24.sp,
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
        
        SizedBox(height: 8.h),
        
        Text(
          _getEmptyStateMessage(),
          style: TextStyle(
            color: Colors.white70,
            fontSize: 16.sp,
          ),
          textAlign: TextAlign.center,
        ),
        
        SizedBox(height: 24.h),
        
        // Context-aware suggestions
        ...suggestions.map((suggestion) => Container(
          margin: EdgeInsets.only(bottom: 12.h),
          child: OutlinedButton.icon(
            onPressed: suggestion['action'],
            icon: Icon(suggestion['icon'], size: 18.sp),
            label: Text(suggestion['label']),
            style: OutlinedButton.styleFrom(
              foregroundColor: Color(0xFFE5A00D),
              side: BorderSide(color: Color(0xFFE5A00D)),
              padding: EdgeInsets.symmetric(vertical: 14.h, horizontal: 20.w),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
            ),
          ),
        )).toList(),
      ],
    ),
  );
}

// Helper methods for smart functionality
TimeOfDay _getTimeOfDayContext() {
  final hour = DateTime.now().hour;
  if (hour < 12) return TimeOfDay.morning;
  if (hour < 17) return TimeOfDay.afternoon;
  if (hour < 21) return TimeOfDay.evening;
  return TimeOfDay.night;
}

String _getContextualMessage() {
  final context = _getTimeOfDayContext();
  final dayOfWeek = DateTime.now().weekday;
  
  if (dayOfWeek >= 6) { // Weekend
    switch (context) {
      case TimeOfDay.morning:
        return "Perfect weekend morning for a movie marathon";
      case TimeOfDay.afternoon:
        return "Ready for some weekend entertainment?";
      case TimeOfDay.evening:
        return "Weekend movie night awaits";
      case TimeOfDay.night:
        return "Late night comfort viewing";
    }
  } else { // Weekday
    switch (context) {
      case TimeOfDay.morning:
        return "Quick picks for your morning";
      case TimeOfDay.afternoon:
        return "Something to look forward to tonight";
      case TimeOfDay.evening:
        return "Time to unwind with a great movie";
      case TimeOfDay.night:
        return "Perfect for winding down";
    }
  }
}

IconData _getContextIcon() {
  final context = _getTimeOfDayContext();
  switch (context) {
    case TimeOfDay.morning:
      return Icons.wb_sunny;
    case TimeOfDay.afternoon:
      return Icons.wb_sunny_outlined;
    case TimeOfDay.evening:
      return Icons.movie_creation;
    case TimeOfDay.night:
      return Icons.nightlight_round;
  }
}

List<QueueItem> _getTonightsQueueItems() {
  final now = DateTime.now();
  final timeContext = _getTimeOfDayContext();
  final isWeekend = now.weekday >= 6;
  
  List<QueueItem> items = [];
  
  // PRIORITY 1: Sessions with actual matches (ready to watch together)
  for (final session in _readyToWatchSessions) {
    final matches = _sessionMatches[session.id] ?? [];
    if (matches.isNotEmpty) {
      // These are REAL matches - all participants liked these movies
      final contextualMatches = _filterMoviesForContext(matches, timeContext, isWeekend);
      
      if (contextualMatches.isNotEmpty) {
        items.add(QueueItem(
          type: QueueItemType.session,
          session: session,
          matches: contextualMatches,
          title: _getSessionTitle(session),
          subtitle: _getSessionSubtitle(session, contextualMatches.length),
          contextTags: _getSessionContextTags(session, timeContext),
          primaryActionLabel: "Pick & Watch Together",
          confidenceScore: _calculateSessionConfidence(session, timeContext),
        ));
      }
    }
  }
  
  // PRIORITY 2: Solo movies (actually watchable alone)
  final soloMovies = _getActualSoloMovies(timeContext, isWeekend);
  for (final movie in soloMovies.take(3)) {
    items.add(QueueItem(
      type: QueueItemType.movie,
      movie: movie,
      title: movie.title,
      subtitle: _getSoloMovieReasoningText(movie),
      contextTags: _getSoloMovieContextTags(movie, timeContext),
      primaryActionLabel: "Watch Solo",
      confidenceScore: _calculateMovieConfidence(movie, timeContext),
    ));
  }
  
  // Sort by confidence and take top 5
  items.sort((a, b) => b.confidenceScore.compareTo(a.confidenceScore));
  return items.take(5).toList();
}

List<Movie> _getActualSoloMovies(TimeOfDay timeContext, bool isWeekend) {
  if (widget.currentUser == null) return [];
  
  final soloMovies = <Movie>[];
  
  // METHOD 1: Get movies from solo sessions in recentLikes
  final soloLikes = widget.currentUser!.recentLikes
      .where((like) => like.sessionType == 'solo') // Only solo session likes
      .where((like) => DateTime.now().difference(like.likedAt).inDays <= 7) // Recent
      .where((like) => !_removedItems.contains(like.movieId))
      .where((like) => !_notTonightItems.containsKey(like.movieId))
      .toList();
  
  // Convert movieIds to Movie objects
  for (final like in soloLikes) {
    try {
      final movie = _movieDatabase.firstWhere((m) => m.id == like.movieId);
      if (_getTimeContextScore(movie, timeContext) > 0.0) {
        soloMovies.add(movie);
      }
    } catch (e) {
      // Movie not found in database, skip
      continue;
    }
  }
  
  // METHOD 2: If not enough solo movies, add from general liked movies
  // But only if they're not part of any active collaborative sessions
  if (soloMovies.length < 3) {
    final additionalMovies = <Movie>[];
    
    for (final movieId in widget.currentUser!.likedMovieIds) {
      if (_removedItems.contains(movieId)) continue;
      if (_notTonightItems.containsKey(movieId)) continue;
      if (soloMovies.any((m) => m.id == movieId)) continue; // Already added
      
      // Check if this movie is part of any active collaborative session
      bool isInActiveCollaboration = false;
      for (final session in [..._activeSessions, ..._readyToWatchSessions]) {
        if (session.participantIds.length > 1) { // Collaborative session
          final sessionMatches = _sessionMatches[session.id] ?? [];
          if (sessionMatches.any((m) => m.id == movieId)) {
            isInActiveCollaboration = true;
            break;
          }
        }
      }
      
      // Only add if not in active collaboration
      if (!isInActiveCollaboration) {
        try {
          final movie = _movieDatabase.firstWhere((m) => m.id == movieId);
          if (_getTimeContextScore(movie, timeContext) > 0.0) {
            additionalMovies.add(movie);
          }
        } catch (e) {
          continue;
        }
      }
    }
    
    // Sort by confidence and add the best ones
    additionalMovies.sort((a, b) {
      final aScore = _calculateMovieConfidence(a, timeContext);
      final bScore = _calculateMovieConfidence(b, timeContext);
      return bScore.compareTo(aScore);
    });
    
    soloMovies.addAll(additionalMovies.take(5 - soloMovies.length));
  }
  
  return soloMovies;
}

String _getSoloMovieReasoningText(Movie movie) {
  if (widget.currentUser == null) return "Perfect for solo viewing";
  
  // Check if this was recently liked in a solo session
  final recentSoloLike = widget.currentUser!.recentLikes
      .where((like) => like.movieId == movie.id && like.sessionType == 'solo')
      .where((like) => DateTime.now().difference(like.likedAt).inDays <= 7)
      .firstOrNull;
  
  if (recentSoloLike != null) {
    final daysAgo = DateTime.now().difference(recentSoloLike.likedAt).inDays;
    if (daysAgo == 0) return "You liked this today";
    if (daysAgo == 1) return "You liked this yesterday";
    return "You liked this $daysAgo days ago";
  }
  
  // Check for genre preference match
  final userGenres = widget.currentUser!.preferredGenres;
  final matchingGenres = movie.genres.where((g) => userGenres.contains(g)).toList();
  
  if (matchingGenres.isNotEmpty) {
    return "Perfect ${matchingGenres.first.toLowerCase()} for solo viewing";
  }
  
  // Time-based reasoning
  final timeContext = _getTimeOfDayContext();
  switch (timeContext) {
    case TimeOfDay.evening:
      return "Great for tonight's solo session";
    case TimeOfDay.night:
      return "Perfect for late night viewing";
    case TimeOfDay.afternoon:
      return "Engaging solo entertainment";
    case TimeOfDay.morning:
      return "Quick solo watch";
  }
}

List<String> _getSoloMovieContextTags(Movie movie, TimeOfDay timeContext) {
  List<String> tags = ["Solo"];
  
  // Runtime tag
  if (movie.runtime != null) {
    if (movie.runtime! <= 90) {
      tags.add("Quick");
    } else if (movie.runtime! <= 120) {
      tags.add("Standard");
    } else {
      tags.add("Epic");
    }
  }
  
  // Time context tag
  switch (timeContext) {
    case TimeOfDay.evening:
      tags.add("Tonight");
      break;
    case TimeOfDay.night:
      tags.add("Chill");
      break;
    case TimeOfDay.afternoon:
      tags.add("Now");
      break;
    case TimeOfDay.morning:
      tags.add("Morning");
      break;
  }
  
  return tags.take(3).toList();
}

List<Movie> _getQuickPicksItems() {
  final timeContext = _getTimeOfDayContext();
  final isWeekend = DateTime.now().weekday >= 6;
  
  // Context-specific quick picks
  switch (timeContext) {
    case TimeOfDay.evening:
      return _getComfortMovies().take(8).toList();
    case TimeOfDay.night:
      return _getLightMovies().take(8).toList();
    case TimeOfDay.afternoon:
      return _getEngagingMovies().take(8).toList();
    default:
      return _getShortMovies().take(8).toList();
  }
}

Widget _buildCollectionMovieCard(Movie movie) {
  return Container(
    width: 90.w,
    margin: EdgeInsets.only(right: 12.w),
    child: GestureDetector(
      onTap: () => _watchSoloMovie(movie),
      child: Column(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12.r),
              child: Stack(
                children: [
                  Image.network(
                    movie.posterUrl,
                    fit: BoxFit.cover,
                    width: double.infinity,
                    errorBuilder: (_, __, ___) => Container(
                      color: Colors.grey[800],
                      child: Icon(Icons.movie, color: Colors.white30, size: 20.sp),
                    ),
                  ),
                  Positioned(
                    top: 4.h,
                    right: 4.w,
                    child: Container(
                      padding: EdgeInsets.all(4.w),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.favorite,
                        color: Colors.white,
                        size: 12.sp,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 6.h),
          Text(
            movie.title,
            style: TextStyle(
              color: Colors.white,
              fontSize: 12.sp,
              fontWeight: FontWeight.w500,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    ),
  );
}

Widget _buildArchiveListItem(MovieSession session) {
  final isCompleted = session.status == SessionStatus.completed;
  final timeAgo = _formatRelativeDate(session.createdAt);
  
  return ListTile(
    leading: Icon(
      isCompleted ? Icons.check_circle : Icons.schedule,
      color: isCompleted ? Colors.green : Colors.orange,
      size: 20.sp,
    ),
    title: Text(
      isCompleted 
          ? session.chosenMovie?.title ?? "Movie Night"
          : "Session with ${session.participantNames.where((name) => name != widget.currentUser?.name).join(', ')}",
      style: TextStyle(
        color: Colors.white,
        fontSize: 14.sp,
      ),
    ),
    subtitle: Text(
      timeAgo,
      style: TextStyle(
        color: Colors.white70,
        fontSize: 12.sp,
      ),
    ),
    dense: true,
  );
}
  // Add this method after the other dialog methods
  void _showStartSessionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1F1F1F),
        title: Text(
          "Start New Session",
          style: TextStyle(color: Colors.white, fontSize: 18.sp),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildStartOption(
              icon: Icons.person,
              title: "Solo Session",
              subtitle: "Find movies for yourself",
              onTap: () {
                Navigator.pop(context);
                _startMatching('solo');
              },
            ),
            SizedBox(height: 12.h),
            _buildStartOption(
              icon: Icons.people,
              title: "With Friends",
              subtitle: "Match together with friends",
              onTap: () {
                Navigator.pop(context);
                _startMatching('friend');
              },
            ),
            SizedBox(height: 12.h),
            _buildStartOption(
              icon: Icons.groups,
              title: "Group Session",
              subtitle: "Multiple friends at once",
              onTap: () {
                Navigator.pop(context);
                _startMatching('group');
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStartOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(16.w),
        decoration: BoxDecoration(
          color: Color(0xFF2A2A2A),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: Color(0xFFE5A00D).withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: Color(0xFFE5A00D), size: 24.sp),
            SizedBox(width: 16.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 14.sp,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: Color(0xFFE5A00D),
              size: 16.sp,
            ),
          ],
        ),
      ),
    );
  }

  // Action Methods
  void _resumeSession(MovieSession session) {
    String mode;
    if (session.participantIds.length == 1) {
      mode = 'solo';
    } else if (session.participantIds.length == 2) {
      mode = 'friend';
    } else {
      mode = 'group';
    }
    
    _navigateToMatcher(mode, sessionId: session.id, resume: true);
  }

  void _startMovieNight(MovieSession session, List<Movie> matches) {
    _showMoviePickerDialog(session, matches);
  }

  void _openChat(MovieSession session) {
  final otherParticipants = session.participantNames
      .where((name) => name != widget.currentUser?.name)
      .toList();
  
  if (otherParticipants.length == 1) {
    Navigator.pushNamed(
      context,
      '/chat',
      arguments: {
        'friendName': otherParticipants.first,
        'sessionId': session.id,
      },
    );
  } else {
    Navigator.pushNamed(
      context,
      '/group-chat',
      arguments: {
        'sessionId': session.id,
        'groupName': 'Movie Night Group',
      },
    );
  }
}


  void _navigateToMatcher(String mode, {String? sessionId, bool resume = false}) {
    if (widget.onNavigateToMatcher != null) {
      widget.onNavigateToMatcher!(mode, sessionId: sessionId, resume: resume);
    } else {
      print("❌ No navigation callback provided");
    }
  }

  void _startMatching(String mode) {
    print("🎯 Starting $mode matching...");
    
    if (widget.onNavigateToMatcher != null) {
      widget.onNavigateToMatcher!(mode);
    } else {
      print("❌ No navigation callback provided");
    }
  }

  void _watchSoloMovie(Movie movie) {
    showMovieDetails(
      context: context,
      movie: movie,
      currentUser: widget.currentUser!,
      isInFavorites: true,
      onRemoveFromFavorites: (Movie movie) {
        setState(() {
          widget.currentUser!.likedMovieIds.remove(movie.id);
          widget.currentUser!.likedMovies.removeWhere((m) => m.id == movie.id);
        });
        
        _firestoreService.updateUserProfile(widget.currentUser!);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${movie.title} removed from likes'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 2),
          ),
        );
      },
    );
  }

  void _showMoviePickerDialog(MovieSession session, List<Movie> matches) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1F1F1F),
        title: Text(
          "Pick Tonight's Movie",
          style: TextStyle(color: Colors.white, fontSize: 18.sp),
        ),
        content: SizedBox(
          width: double.maxFinite,
          height: 300.h,
          child: GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.7,
              crossAxisSpacing: 12.w,
              mainAxisSpacing: 12.h,
            ),
            itemCount: matches.length,
            itemBuilder: (context, index) {
              final movie = matches[index];
              return GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                  _completeMovieNight(session, movie);
                },
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8.r),
                    border: Border.all(color: Color(0xFFE5A00D).withValues(alpha: 0.3)),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8.r),
                    child: Column(
                      children: [
                        Expanded(
                          child: Image.network(
                            movie.posterUrl,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            errorBuilder: (_, __, ___) => Container(
                              color: Colors.grey[800],
                              child: Icon(Icons.movie, color: Colors.white30),
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.all(8.w),
                          color: Color(0xFF2A2A2A),
                          child: Text(
                            movie.title,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel",
              style: TextStyle(color: Colors.white70),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _completeMovieNight(MovieSession session, Movie chosenMovie) async {
    try {
      await FirebaseFirestore.instance
          .collection('movieSessions')
          .doc(session.id)
          .update({
        'status': 'completed',
        'chosenMovieId': chosenMovie.id,
        'chosenMovieTitle': chosenMovie.title,
        'completedAt': DateTime.now(),
      });

      await _loadSessionData();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Great choice! Enjoy "${chosenMovie.title}"'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      print("❌ Error completing movie night: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error completing movie night'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  String _formatRelativeDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays == 0) {
      if (difference.inHours == 0) {
        return '${difference.inMinutes}m ago';
      }
      return '${difference.inHours}h ago';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }

  // DISCOVERY TAB - Keep all your existing methods
  Widget _buildDiscoverTab() {
    if (_isLoadingDiscover) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Color(0xFFE5A00D)),
            SizedBox(height: 16.h),
            Text(
              "Discovering movies for you...",
              style: TextStyle(color: Colors.white70, fontSize: 16.sp),
            ),
          ],
        ),
      );
    }
    
    return RefreshIndicator(
      color: Color(0xFFE5A00D),
      backgroundColor: Color(0xFF1F1F1F),
      onRefresh: () async {
        setState(() => _isRefreshingDiscover = true);
        await _loadDiscoverContent();
        setState(() => _isRefreshingDiscover = false);
      },
      child: SingleChildScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_isRefreshingDiscover)
              Padding(
                padding: EdgeInsets.symmetric(vertical: 24.h),
                child: Center(
                  child: CircularProgressIndicator(color: Color(0xFFE5A00D)),
                ),
              ),
            if (_personalizedRecommendations.isNotEmpty)
              _buildSection(
                title: "Perfect For You",
                subtitle: "Based on your unique taste",
                icon: Icons.auto_awesome,
                movies: _personalizedRecommendations,
                showQuickActions: true,
              ),
            if (_becauseYouLiked.length > 1)
              _buildBecauseYouLikedSection(),
            
            if (_trendingMovies.isNotEmpty)
              _buildSection(
                title: "Trending Now",
                subtitle: "Popular movies this week",
                icon: Icons.trending_up,
                movies: _trendingMovies,
                showQuickActions: true,
              ),
            
            ..._genreDeepDives.entries.map((entry) => 
              _buildSection(
                title: "More ${entry.key} Movies",
                subtitle: "Explore your favorite genre",
                icon: Icons.category,
                movies: entry.value,
                showQuickActions: true,
              ),
            ).toList(),
            
            _buildDiscoveryModeSection(),
            
            SizedBox(height: 32.h),
          ],
        ),
      ),
    );
  }

  // [Keep all your existing discovery methods here - _loadDiscoverContent, _buildSection, etc.]
  Future<void> _loadDiscoverContent() async {
    if (!mounted) return;
    
    setState(() => _isLoadingDiscover = true);
    
    try {
      _movieDatabase = await MovieDatabaseLoader.loadMovieDatabase();
      
      await Future.wait([
        _loadPersonalizedRecommendations(),
        _loadTrendingMovies(),
        _loadBecauseYouLiked(),
        _loadGenreDeepDives(),
      ]);
    } catch (e) {
      print("❌ Error loading discover content: $e");
    } finally {
      if (mounted) {
        setState(() => _isLoadingDiscover = false);
      }
    }
  }

  Widget _buildSection({
    required String title,
    required String subtitle,
    required IconData icon,
    required List<Movie> movies,
    bool showQuickActions = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(16.w, 24.h, 16.w, 12.h),
          child: Row(
            children: [
              Icon(icon, color: Color(0xFFE5A00D), size: 24.sp),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (subtitle.isNotEmpty)
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 14.sp,
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        SizedBox(
          height: showQuickActions ? 280.h : 220.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            itemCount: movies.length,
            itemBuilder: (context, index) {
              final movie = movies[index];
              return _buildDiscoveryCard(movie, showQuickActions);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildBecauseYouLikedSection() {
    final referenceMovie = _becauseYouLiked.first;
    final similarMovies = _becauseYouLiked.skip(1).toList();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(16.w, 24.h, 16.w, 12.h),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(6.r),
                child: Image.network(
                  referenceMovie.posterUrl,
                  width: 40.w,
                  height: 60.h,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    width: 40.w,
                    height: 60.h,
                    color: Colors.grey[800],
                    child: Icon(Icons.movie, size: 20.sp, color: Colors.white30),
                  ),
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Because you liked",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14.sp,
                      ),
                    ),
                    Text(
                      referenceMovie.title,
                      style: TextStyle(
                        color: Color(0xFFE5A00D),
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        SizedBox(
          height: 280.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            itemCount: similarMovies.length,
            itemBuilder: (context, index) {
              return _buildDiscoveryCard(similarMovies[index], true);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDiscoveryModeSection() {
    return Container(
      margin: EdgeInsets.fromLTRB(16.w, 24.h, 16.w, 0),
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xFF1F1F1F),
            Color(0xFF2A2A2A),
          ],
        ),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: Color(0xFFE5A00D).withValues(alpha: 0.3),
          width: 1.w,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.explore, color: Color(0xFFE5A00D), size: 24.sp),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Discovery Mode",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "Find movies outside your comfort zone",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14.sp,
                      ),
                    ),
                  ],
                ),
              ),
              Switch(
                value: widget.currentUser?.discoveryModeEnabled ?? false,
                onChanged: (value) {
                  setState(() {
                    widget.currentUser?.discoveryModeEnabled = value;
                  });
                  _firestoreService.updateUserProfile(widget.currentUser!);
                  
                  if (value) {
                    _loadDiscoverContent();
                  }
                },
                activeColor: Color(0xFFE5A00D),
              ),
            ],
          ),
          
          if (widget.currentUser?.genresToExplore.isNotEmpty ?? false) ...[
            SizedBox(height: 16.h),
            Text(
              "Unexplored genres:",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 14.sp,
              ),
            ),
            SizedBox(height: 8.h),
            Wrap(
              spacing: 8.w,
              runSpacing: 8.h,
              children: widget.currentUser!.genresToExplore.take(5).map((genre) {
                final bool isSelected = _selectedGenreForDeepDive == genre;

                return GestureDetector(
                  onTap: () {
                    setState(() => _selectedGenreForDeepDive = genre);
                    _loadGenreDeepDive(genre);
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? Color(0xFFE5A00D)
                          : Color(0xFFE5A00D).withAlpha(40),
                      borderRadius: BorderRadius.circular(20.r),
                      border: Border.all(
                        color: isSelected
                            ? Color(0xFFE5A00D)
                            : Color(0xFFE5A00D).withAlpha(120),
                        width: 1.w,
                      ),
                    ),
                    child: Text(
                      genre,
                      style: TextStyle(
                        color: isSelected ? Colors.black : Color(0xFFE5A00D),
                        fontSize: 14.sp,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _loadGenreDeepDive(String genre) async {
    final genreMovies = MovieDatabaseLoader.getMoviesByGenres(
      _movieDatabase,
      [genre],
      limit: 20,
    );
    
    if (genreMovies.isNotEmpty) {
      setState(() {
        _genreDeepDives[genre] = genreMovies;
      });
    }
  }

  void _showMovieDetails(Movie movie) {
    final isInFavorites = widget.currentUser?.likedMovieIds.contains(movie.id) ?? false;
    
    showMovieDetails(
      context: context,
      movie: movie,
      currentUser: widget.currentUser!,
      isInFavorites: isInFavorites,
      onAddToFavorites: !isInFavorites ? (Movie movie) {
        setState(() {
          widget.currentUser!.likedMovieIds.add(movie.id);
          widget.currentUser!.likedMovies.add(movie);
        });
        
        EnhancedLearningEngine.learnFromLikedMovie(widget.currentUser!, movie);
        _firestoreService.updateUserProfile(widget.currentUser!);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${movie.title} added to likes'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
        
        _loadPersonalizedRecommendations();
      } : null,
      onRemoveFromFavorites: isInFavorites ? (Movie movie) {
        setState(() {
          widget.currentUser!.likedMovieIds.remove(movie.id);
          widget.currentUser!.likedMovies.removeWhere((m) => m.id == movie.id);
        });
        
        _firestoreService.updateUserProfile(widget.currentUser!);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${movie.title} removed from likes'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 2),
          ),
        );
      } : null,
    );
  }

  Future<void> _loadPersonalizedRecommendations() async {
    if (widget.currentUser == null || _movieDatabase.isEmpty) return;
    
    try {
      final seenMovieIds = <String>{
        ...widget.currentUser!.likedMovieIds,
        ...widget.currentUser!.passedMovieIds,
        ..._quickLikedMovieIds,
        ..._quickPassedMovieIds,
      };
      
      final recommendations = await EnhancedLearningEngine.generatePersonalizedSession(
        user: widget.currentUser!,
        movieDatabase: _movieDatabase,
        seenMovieIds: seenMovieIds,
        sessionSize: 20,
      );
      
      if (mounted) {
        setState(() {
          _personalizedRecommendations = recommendations;
        });
      }
    } catch (e) {
      print("❌ Error loading personalized recommendations: $e");
    }
  }

  Future<void> _loadTrendingMovies() async {
    try {
      final trending = await TMDBApi.getPopularMovies();
      if (mounted) {
        setState(() {
          _trendingMovies = trending.take(20).toList();
        });
      }
    } catch (e) {
      print("❌ Error loading trending movies: $e");
    }
  }

  Future<void> _loadBecauseYouLiked() async {
    if (widget.currentUser == null || widget.currentUser!.likedMovies.isEmpty) return;
    
    try {
      final recentLikes = widget.currentUser!.likedMovies.toList();
      if (recentLikes.isEmpty) return;
      
      recentLikes.shuffle();
      final referenceMovie = recentLikes.first;
      
      final similarMovies = _movieDatabase.where((movie) {
        if (movie.id == referenceMovie.id) return false;
        if (widget.currentUser!.likedMovieIds.contains(movie.id)) return false;
        
        final sharedGenres = movie.genres.toSet().intersection(referenceMovie.genres.toSet());
        final sharedVibes = movie.tags.toSet().intersection(referenceMovie.tags.toSet());
        
        return sharedGenres.isNotEmpty || sharedVibes.isNotEmpty;
      }).toList();
      
      similarMovies.sort((a, b) {
        final aScore = _calculateSimilarityScore(a, referenceMovie);
        final bScore = _calculateSimilarityScore(b, referenceMovie);
        return bScore.compareTo(aScore);
      });
      
      if (mounted) {
        setState(() {
          _becauseYouLiked = similarMovies.take(15).toList();
          if (_becauseYouLiked.isNotEmpty) {
            _becauseYouLiked.insert(0, referenceMovie);
          }
        });
      }
    } catch (e) {
      print("❌ Error loading similar movies: $e");
    }
  }

  double _calculateSimilarityScore(Movie movie1, Movie movie2) {
    double score = 0;
    
    final sharedGenres = movie1.genres.toSet().intersection(movie2.genres.toSet());
    score += sharedGenres.length * 3.0;
    
    final sharedVibes = movie1.tags.toSet().intersection(movie2.tags.toSet());
    score += sharedVibes.length * 2.0;
    
    if (movie1.runtime != null && movie2.runtime != null) {
      final runtimeDiff = (movie1.runtime! - movie2.runtime!).abs();
      if (runtimeDiff < 30) score += 1.0;
    }
    
    if (movie1.rating != null && movie2.rating != null) {
      final ratingDiff = (movie1.rating! - movie2.rating!).abs();
      if (ratingDiff < 1.0) score += 1.0;
    }
    
    return score;
  }

  Future<void> _loadGenreDeepDives() async {
    if (widget.currentUser == null) return;
    
    try {
      final topGenres = widget.currentUser!.genreScores.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));
      
      for (int i = 0; i < math.min(3, topGenres.length); i++) {
        final genre = topGenres[i].key;
        final genreMovies = MovieDatabaseLoader.getMoviesByGenres(
          _movieDatabase,
          [genre],
          limit: 20,
        ).where((movie) => !widget.currentUser!.likedMovieIds.contains(movie.id)).toList();
        
        if (genreMovies.isNotEmpty) {
          _genreDeepDives[genre] = genreMovies;
        }
      }
      
      if (mounted) setState(() {});
    } catch (e) {
      print("❌ Error loading genre deep dives: $e");
    }
  }

  Widget _buildDiscoveryCard(Movie movie, bool showQuickActions) {
    final isLiked = widget.currentUser?.likedMovieIds.contains(movie.id) ?? false;
    final isPassed = _quickPassedMovieIds.contains(movie.id) || 
                     (widget.currentUser?.passedMovieIds.contains(movie.id) ?? false);
    
    if (isPassed) return SizedBox.shrink();
    
    return Container(
      width: 140.w,
      margin: EdgeInsets.only(right: 12.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              GestureDetector(
                onTap: () => _showMovieDetails(movie),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12.r),
                  child: Container(
                    height: showQuickActions ? 180.h : 200.h,
                    decoration: BoxDecoration(color: Colors.grey[800]),
                    child: Image.network(
                      movie.posterUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Center(
                        child: Icon(Icons.movie, color: Colors.white30, size: 40.sp),
                      ),
                    ),
                  ),
                ),
              ),

              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  height: 40.h,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withValues(alpha: 0.6),
                      ],
                    ),
                    borderRadius: BorderRadius.vertical(bottom: Radius.circular(12.r)),
                  ),
                ),
              ),

              if (movie.rating != null)
                Positioned(
                  top: 8.h,
                  right: 8.w,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.7),
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star, color: Color(0xFFE5A00D), size: 14.sp),
                        SizedBox(width: 2.w),
                        Text(
                          movie.rating!.toStringAsFixed(1),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              if (isLiked)
                Positioned(
                  top: 8.h,
                  left: 8.w,
                  child: Container(
                    padding: EdgeInsets.all(6.w),
                    decoration: BoxDecoration(
                      color: Colors.green,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.favorite, color: Colors.white, size: 16.sp),
                  ),
                ),
            ],
          ),

          SizedBox(height: 8.h),

          Text(
            movie.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white,
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed && _tabController.index == 0) {
      _loadSessionData();
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }
  // ========================================
// SMART HELPER METHODS FOR READY TO WATCH
// ========================================
Map<String, dynamic> _getPrimaryActionForContext() {
  final timeContext = _getTimeOfDayContext();
  final hasActiveSessions = _activeSessions.isNotEmpty;
  final hasReadySessions = _readyToWatchSessions.isNotEmpty;
  
  if (hasReadySessions) {
    return {
      'icon': Icons.movie_creation,
      'label': 'Pick Movie',
      'action': () => _showMoviePickerForBestSession(),
    };
  } else if (hasActiveSessions) {
    return {
      'icon': Icons.play_arrow,
      'label': 'Continue',
      'action': () => _resumeSession(_activeSessions.first),
    };
  } else {
    // Smart suggestion based on time
    switch (timeContext) {
      case TimeOfDay.evening:
        return {
          'icon': Icons.people,
          'label': 'Match with Friends',
          'action': () => _startMatching('friend'),
        };
      case TimeOfDay.afternoon:
        return {
          'icon': Icons.explore,
          'label': 'Discover',
          'action': () => _tabController.animateTo(1),
        };
      default:
        return {
          'icon': Icons.person,
          'label': 'Solo Session',
          'action': () => _startMatching('solo'),
        };
    }
  }
}

String _getQueueSubtitle(int itemCount) {
  final timeContext = _getTimeOfDayContext();
  final isWeekend = DateTime.now().weekday >= 6;
  
  if (itemCount == 0) return "No movies ready";
  
  if (isWeekend) {
    return itemCount == 1 
        ? "Perfect for your weekend" 
        : "$itemCount perfect picks for your weekend";
  }
  
  switch (timeContext) {
    case TimeOfDay.evening:
      return itemCount == 1 
          ? "Ready for tonight" 
          : "$itemCount great options for tonight";
    case TimeOfDay.night:
      return itemCount == 1 
          ? "Perfect for winding down" 
          : "$itemCount comfort picks";
    case TimeOfDay.afternoon:
      return itemCount == 1 
          ? "Something to look forward to" 
          : "$itemCount movies for later";
    default:
      return "$itemCount picks ready";
  }
}

String _getQuickPicksLabel() {
  final timeContext = _getTimeOfDayContext();
  
  switch (timeContext) {
    case TimeOfDay.evening:
      return "Comfort viewing";
    case TimeOfDay.night:
      return "Light & easy";
    case TimeOfDay.afternoon:
      return "Engaging stories";
    case TimeOfDay.morning:
      return "Quick watches";
  }
}

// ========================================
// CONFIDENCE SCORING ALGORITHMS
// ========================================

double _calculateSessionConfidence(MovieSession session, TimeOfDay timeContext) {
  double confidence = 0.9; // Higher base confidence for actual matches
  
  // Recency boost (newer = higher confidence)
  final hoursSinceCreated = DateTime.now().difference(session.createdAt).inHours;
  if (hoursSinceCreated < 2) confidence += 0.1;   // Very recent
  else if (hoursSinceCreated < 12) confidence += 0.05; // Recent
  else if (hoursSinceCreated > 48) confidence -= 0.2;  // Getting old
  
  // Match count boost (more matches = more options = higher confidence)
  final matchCount = _sessionMatches[session.id]?.length ?? 0;
  if (matchCount >= 5) confidence += 0.1;
  else if (matchCount >= 3) confidence += 0.05;
  else if (matchCount == 1) confidence -= 0.1; // Only one option
  
  // Social context boost
  if (session.participantIds.length > 1) {
    // Evening is prime time for social watching
    if (timeContext == TimeOfDay.evening) confidence += 0.1;
    // Weekend afternoons are also good for social viewing
    if (DateTime.now().weekday >= 6 && timeContext == TimeOfDay.afternoon) {
      confidence += 0.05;
    }
  }
  
  // Urgency boost - sessions with matches should be prioritized
  confidence += 0.2; // Boost for having actual matches
  
  return math.min(1.0, confidence);
}

double _calculateMovieConfidence(Movie movie, TimeOfDay timeContext) {
  double confidence = 0.6; // Base confidence for individual movies
  
  // User preference alignment
  if (widget.currentUser != null) {
    final userGenres = widget.currentUser!.preferredGenres;
    final userVibes = widget.currentUser!.preferredVibes;
    
    // Genre match boost
    final genreMatches = movie.genres.where((g) => userGenres.contains(g)).length;
    confidence += (genreMatches * 0.1);
    
    // Vibe match boost
    final vibeMatches = movie.tags.where((t) => userVibes.contains(t)).length;
    confidence += (vibeMatches * 0.08);
    
    // Recent like pattern boost - FIXED VERSION
    final recentLikes = widget.currentUser!.recentLikes
        .where((like) => DateTime.now().difference(like.likedAt).inDays < 7)
        .toList();
    
    for (final like in recentLikes) {
      try {
        final likedMovie = _movieDatabase.firstWhere((m) => m.id == like.movieId);
        if (likedMovie.genres.any((g) => movie.genres.contains(g))) {
          confidence += 0.05;
        }
      } catch (e) {
        // Movie not found in database, skip
        continue;
      }
    }
  }
  
  // Time context alignment
  confidence += _getTimeContextScore(movie, timeContext);
  
  // Quality score
  if (movie.rating != null && movie.rating! >= 7.5) confidence += 0.1;
  if (movie.rating != null && movie.rating! >= 8.5) confidence += 0.1;
  
  return math.min(1.0, confidence);
}

double _getTimeContextScore(Movie movie, TimeOfDay timeContext) {
  double score = 0.0;
  
  switch (timeContext) {
    case TimeOfDay.evening:
      // Favor familiar, comfortable content
      if (movie.genres.contains('Comedy') || movie.genres.contains('Romance')) {
        score += 0.1;
      }
      // Moderate runtime preference
      if (movie.runtime != null && movie.runtime! >= 90 && movie.runtime! <= 120) {
        score += 0.05;
      }
      break;
      
    case TimeOfDay.night:
      // Favor lighter content
      if (movie.genres.contains('Comedy') || movie.genres.contains('Animation')) {
        score += 0.15;
      }
      // Avoid intense genres
      if (movie.genres.contains('Horror') || movie.genres.contains('Thriller')) {
        score -= 0.2;
      }
      // Prefer shorter content
      if (movie.runtime != null && movie.runtime! <= 100) {
        score += 0.1;
      }
      break;
      
    case TimeOfDay.afternoon:
      // Good time for engaging content
      if (movie.genres.contains('Drama') || movie.genres.contains('Action')) {
        score += 0.1;
      }
      // Can handle longer content
      if (movie.runtime != null && movie.runtime! >= 100) {
        score += 0.05;
      }
      break;
      
    case TimeOfDay.morning:
      // Quick, energizing content
      if (movie.runtime != null && movie.runtime! <= 90) {
        score += 0.15;
      }
      if (movie.genres.contains('Comedy') || movie.genres.contains('Adventure')) {
        score += 0.1;
      }
      break;
  }
  
  return score;
}

// ========================================
// INTELLIGENT MOVIE FILTERING
// ========================================

List<Movie> _filterMoviesForContext(List<Movie> movies, TimeOfDay timeContext, bool isWeekend) {
  return movies.where((movie) {
    // Remove items user said "not tonight" to
    if (_notTonightItems.containsKey(movie.id)) {
      final notTonightTime = _notTonightItems[movie.id]!;
      // Remove from "not tonight" after 4 hours
      if (DateTime.now().difference(notTonightTime).inHours < 4) {
        return false;
      } else {
        _notTonightItems.remove(movie.id);
      }
    }
    
    // Remove permanently removed items
    if (_removedItems.contains(movie.id)) return false;
    
    // Context filtering
    switch (timeContext) {
      case TimeOfDay.night:
        // Avoid very long or intense content at night
        if (movie.runtime != null && movie.runtime! > 140) return false;
        if (movie.genres.contains('Horror')) return false;
        break;
      case TimeOfDay.morning:
        // Avoid very long content in morning
        if (movie.runtime != null && movie.runtime! > 120) return false;
        break;
      default:
        break;
    }
    
    return true;
  }).toList();
}

List<Movie> _getContextualSoloMovies(TimeOfDay timeContext, bool isWeekend) {
  if (widget.currentUser == null) return [];
  
  final recentLikes = widget.currentUser!.likedMovies
      .where((movie) => !_removedItems.contains(movie.id))
      .where((movie) => !_notTonightItems.containsKey(movie.id))
      .toList();
  
  // Get movies based on recent preferences and context
  final contextualMovies = recentLikes.where((movie) {
    final contextScore = _getTimeContextScore(movie, timeContext);
    return contextScore > 0.05; // Only include movies with positive context score
  }).toList();
  
  // Sort by combination of recency and context relevance
  contextualMovies.sort((a, b) {
    final aScore = _calculateMovieConfidence(a, timeContext);
    final bScore = _calculateMovieConfidence(b, timeContext);
    return bScore.compareTo(aScore);
  });
  
  return contextualMovies;
}

List<Movie> _getComfortMovies() {
  // Movies for evening wind-down
  return _movieDatabase.where((movie) {
    return movie.genres.any((genre) => 
        ['Comedy', 'Romance', 'Animation', 'Family'].contains(genre)) &&
        (movie.rating == null || movie.rating! >= 6.5) &&
        !_removedItems.contains(movie.id);
  }).take(8).toList();
}

List<Movie> _getLightMovies() {
  // Light content for late night
  return _movieDatabase.where((movie) {
    return movie.genres.any((genre) => 
        ['Comedy', 'Animation', 'Musical'].contains(genre)) &&
        (movie.runtime == null || movie.runtime! <= 110) &&
        !movie.genres.contains('Horror') &&
        !_removedItems.contains(movie.id);
  }).take(8).toList();
}

List<Movie> _getEngagingMovies() {
  // Engaging content for afternoon
  return _movieDatabase.where((movie) {
    return movie.genres.any((genre) => 
        ['Drama', 'Thriller', 'Action', 'Sci-Fi'].contains(genre)) &&
        (movie.rating == null || movie.rating! >= 7.0) &&
        !_removedItems.contains(movie.id);
  }).take(8).toList();
}

List<Movie> _getShortMovies() {
  // Quick watches for morning or busy times
  return _movieDatabase.where((movie) {
    return (movie.runtime != null && movie.runtime! <= 95) &&
        (movie.rating == null || movie.rating! >= 6.8) &&
        !_removedItems.contains(movie.id);
  }).take(8).toList();
}

List<Movie> _getSmartCollectionItems() {
  if (widget.currentUser == null) return [];
  
  // Get recently liked movies that are still relevant
  final now = DateTime.now();
  final recentLikes = widget.currentUser!.recentLikes
      .where((like) => now.difference(like.likedAt).inDays <= 14) // Last 2 weeks
      .toList();
  
  // Convert MovieLike objects to Movie objects by looking up in database
  final recentMovies = <Movie>[];
  for (final like in recentLikes) {
    try {
      final movie = _movieDatabase.firstWhere((m) => m.id == like.movieId);
      if (!_removedItems.contains(movie.id)) {
        recentMovies.add(movie);
      }
    } catch (e) {
      // Movie not found in database, skip it
      print("⚠️ Movie with ID ${like.movieId} not found in database");
    }
  }
  
  // If not enough recent, fall back to all liked movies
  if (recentMovies.length < 3) {
    final allLiked = widget.currentUser!.likedMovies
        .where((movie) => !_removedItems.contains(movie.id))
        .toList();
    
    // Sort by some intelligence (genre preference, rating, etc.)
    allLiked.sort((a, b) {
      double aScore = _calculateMovieConfidence(a, _getTimeOfDayContext());
      double bScore = _calculateMovieConfidence(b, _getTimeOfDayContext());
      return bScore.compareTo(aScore);
    });
    
    return allLiked.take(8).toList();
  }
  
  return recentMovies.take(8).toList();
}

// ========================================
// INTELLIGENT TEXT GENERATION
// ========================================

String _getSessionTitle(MovieSession session) {
  final isGroup = session.participantIds.length > 2;
  final isSolo = session.participantIds.length == 1;
  
  if (isSolo) return "Your Solo Picks";
  if (isGroup) return "Group Session";
  
  final otherName = session.participantNames
      .firstWhere((name) => name != widget.currentUser?.name, orElse: () => "Friend");
  
  return "With $otherName";
}

String _getSessionSubtitle(MovieSession session, int matchCount) {
  final timeAgo = _formatRelativeTime(session.createdAt);
  final isGroup = session.participantIds.length > 2;
  
  if (matchCount == 1) {
    return "1 perfect match • $timeAgo";
  } else if (matchCount <= 3) {
    return "$matchCount great matches • $timeAgo";
  } else {
    return "$matchCount amazing options • $timeAgo";
  }
}

List<String> _getSessionContextTags(MovieSession session, TimeOfDay timeContext) {
  List<String> tags = [];
  
  // Add session type
  if (session.participantIds.length == 1) {
    tags.add("Solo");
  } else if (session.participantIds.length == 2) {
    tags.add("Duo");
  } else {
    tags.add("Group");
  }
  
  // Add time context
  switch (timeContext) {
    case TimeOfDay.evening:
      tags.add("Prime time");
      break;
    case TimeOfDay.night:
      tags.add("Wind down");
      break;
    case TimeOfDay.afternoon:
      tags.add("Perfect timing");
      break;
    case TimeOfDay.morning:
      tags.add("Morning watch");
      break;
  }
  
  // Add recency
  final hoursAgo = DateTime.now().difference(session.createdAt).inHours;
  if (hoursAgo < 2) {
    tags.add("Fresh matches");
  } else if (hoursAgo < 24) {
    tags.add("Recent");
  }
  
  return tags;
}

String _getMovieReasoningText(Movie movie) {
  if (widget.currentUser == null) return "Recommended for you";
  
  // Check for genre preference match
  final userGenres = widget.currentUser!.preferredGenres;
  final matchingGenres = movie.genres.where((g) => userGenres.contains(g)).toList();
  
  if (matchingGenres.isNotEmpty) {
    return "You love ${matchingGenres.first.toLowerCase()} movies";
  }
  
  // Check for recent similar likes
  final recentSimilarLikes = widget.currentUser!.recentLikes
      .where((like) => DateTime.now().difference(like.likedAt).inDays < 7)
      .toList();
  
  for (final like in recentSimilarLikes) {
    try {
      final likedMovie = _movieDatabase.firstWhere((m) => m.id == like.movieId);
      if (likedMovie.genres.any((g) => movie.genres.contains(g))) {
        return "Similar to ${likedMovie.title}";
      }
    } catch (e) {
      // Movie not found, continue to next
      continue;
    }
  }
  
  // Quality-based reasoning
  if (movie.rating != null) {
    if (movie.rating! >= 8.5) return "Exceptional ${movie.rating!.toStringAsFixed(1)}/10";
    if (movie.rating! >= 8.0) return "Highly rated ${movie.rating!.toStringAsFixed(1)}/10";
    if (movie.rating! >= 7.5) return "Great reviews ${movie.rating!.toStringAsFixed(1)}/10";
  }
  
  // Time-based reasoning
  final timeContext = _getTimeOfDayContext();
  switch (timeContext) {
    case TimeOfDay.evening:
      return "Perfect for tonight";
    case TimeOfDay.night:
      return "Easy watching";
    case TimeOfDay.afternoon:
      return "Engaging story";
    case TimeOfDay.morning:
      return "Quick watch";
  }
}

List<String> _getMovieContextTags(Movie movie, TimeOfDay timeContext) {
  List<String> tags = [];
  
  // Runtime tag
  if (movie.runtime != null) {
    if (movie.runtime! <= 90) {
      tags.add("Quick");
    } else if (movie.runtime! <= 120) {
      tags.add("Standard");
    } else {
      tags.add("Epic");
    }
  }
  
  // Quality tag
  if (movie.rating != null) {
    if (movie.rating! >= 8.5) {
      tags.add("Exceptional");
    } else if (movie.rating! >= 8.0) {
      tags.add("Excellent");
    } else if (movie.rating! >= 7.5) {
      tags.add("Great");
    }
  }
  
  // Context tag
  switch (timeContext) {
    case TimeOfDay.evening:
      if (movie.genres.contains('Comedy') || movie.genres.contains('Romance')) {
        tags.add("Comfort");
      }
      break;
    case TimeOfDay.night:
      if (!movie.genres.contains('Horror') && !movie.genres.contains('Thriller')) {
        tags.add("Relaxing");
      }
      break;
    default:
      break;
  }
  
  return tags.take(2).toList(); // Limit to 2 tags to avoid clutter
}

String _getMovieContextLabel(Movie movie) {
  final timeContext = _getTimeOfDayContext();
  
  if (movie.runtime != null && movie.runtime! <= 90) return "Quick";
  
  switch (timeContext) {
    case TimeOfDay.evening:
      return "Tonight";
    case TimeOfDay.night:
      return "Chill";
    case TimeOfDay.afternoon:
      return "Now";
    case TimeOfDay.morning:
      return "AM";
  }
}

// ========================================
// USER ACTIONS & MANAGEMENT
// ========================================

void _refreshTonightsQueue() {
  setState(() {
    // Clear temporary exclusions older than 24 hours
    _notTonightItems.removeWhere((key, value) => 
        DateTime.now().difference(value).inHours > 24);
  });
  _loadSessionData();
}

void _notTonight(QueueItem item) {
  setState(() {
    if (item.type == QueueItemType.movie && item.movie != null) {
      _notTonightItems[item.movie!.id] = DateTime.now();
    } else if (item.type == QueueItemType.session && item.session != null) {
      _notTonightItems[item.session!.id] = DateTime.now();
    }
  });
  
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text('Hidden from tonight\'s queue'),
      duration: Duration(seconds: 2),
      action: SnackBarAction(
        label: 'Undo',
        onPressed: () {
          setState(() {
            if (item.type == QueueItemType.movie && item.movie != null) {
              _notTonightItems.remove(item.movie!.id);
            } else if (item.type == QueueItemType.session && item.session != null) {
              _notTonightItems.remove(item.session!.id);
            }
          });
        },
      ),
    ),
  );
}

void _removeFromQueue(QueueItem item) {
  setState(() {
    if (item.type == QueueItemType.movie && item.movie != null) {
      _removedItems.add(item.movie!.id);
    } else if (item.type == QueueItemType.session && item.session != null) {
      _removedItems.add(item.session!.id);
    }
  });
  
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text('Removed from ready to watch'),
      backgroundColor: Colors.red,
      duration: Duration(seconds: 3),
      action: SnackBarAction(
        label: 'Undo',
        textColor: Colors.white,
        onPressed: () {
          setState(() {
            if (item.type == QueueItemType.movie && item.movie != null) {
              _removedItems.remove(item.movie!.id);
            } else if (item.type == QueueItemType.session && item.session != null) {
              _removedItems.remove(item.session!.id);
            }
          });
        },
      ),
    ),
  );
}

void _handlePrimaryAction(QueueItem item) {
  if (item.type == QueueItemType.movie && item.movie != null) {
    _watchMovie(item.movie!);
  } else if (item.type == QueueItemType.session && item.session != null) {
    _startMovieNight(item.session!, item.matches!);
  }
}

void _watchMovie(Movie movie) {
  // Navigate to movie detail or start watching
  showMovieDetails(
    context: context,
    movie: movie,
    currentUser: widget.currentUser!,
    isInFavorites: widget.currentUser!.likedMovieIds.contains(movie.id),
  );
}

void _showMoviePickerForBestSession() {
  if (_readyToWatchSessions.isNotEmpty) {
    final bestSession = _readyToWatchSessions.first;
    final matches = _sessionMatches[bestSession.id] ?? [];
    if (matches.isNotEmpty) {
      _startMovieNight(bestSession, matches);
    }
  }
}

// ========================================
// EMPTY STATE INTELLIGENCE
// ========================================

bool _shouldShowMoreOptions() {
  return _archivedSessions.isNotEmpty;
}

IconData _getEmptyStateIcon() {
  final timeContext = _getTimeOfDayContext();
  
  switch (timeContext) {
    case TimeOfDay.evening:
      return Icons.movie_creation;
    case TimeOfDay.night:
      return Icons.bedtime;
    case TimeOfDay.afternoon:
      return Icons.explore;
    default:
      return Icons.play_circle_outline;
  }
}

String _getEmptyStateTitle() {
  final timeContext = _getTimeOfDayContext();
  final isWeekend = DateTime.now().weekday >= 6;
  
  if (isWeekend) {
    return "Perfect Weekend for Movies";
  }
  
  switch (timeContext) {
    case TimeOfDay.evening:
      return "Ready for Movie Night?";
    case TimeOfDay.night:
      return "Something to Wind Down?";
    case TimeOfDay.afternoon:
      return "Discover Your Next Favorite";
    default:
      return "Start Your Movie Journey";
  }
}

String _getEmptyStateMessage() {
  final timeContext = _getTimeOfDayContext();
  final hasActiveSessions = _activeSessions.isNotEmpty;
  
  if (hasActiveSessions) {
    return "Continue your active sessions to build up matches for tonight";
  }
  
  switch (timeContext) {
    case TimeOfDay.evening:
      return "Start a session to find perfect movies for tonight";
    case TimeOfDay.night:
      return "Create a solo session for late night comfort viewing";
    case TimeOfDay.afternoon:
      return "Build your queue by matching solo or with friends";
    default:
      return "Start matching to build your ready-to-watch queue";
  }
}

List<Map<String, dynamic>> _getEmptyStateSuggestions() {
  final timeContext = _getTimeOfDayContext();
  final isWeekend = DateTime.now().weekday >= 6;
  final hasActiveSessions = _activeSessions.isNotEmpty;
  
  List<Map<String, dynamic>> suggestions = [];
  
  if (hasActiveSessions) {
    suggestions.add({
      'icon': Icons.play_arrow,
      'label': 'Continue Matching',
      'action': () => _resumeSession(_activeSessions.first),
    });
  }
  
  if (timeContext == TimeOfDay.evening || isWeekend) {
    suggestions.add({
      'icon': Icons.people,
      'label': 'Match with Friends',
      'action': () => _startMatching('friend'),
    });
  }
  
  suggestions.add({
    'icon': Icons.person,
    'label': 'Solo Session',
    'action': () => _startMatching('solo'),
  });
  
  if (suggestions.length < 3) {
    suggestions.add({
      'icon': Icons.explore,
      'label': 'Discover Movies',
      'action': () => _tabController.animateTo(1),
    });
  }
  
  return suggestions;
}

Widget _buildCollectionEmptyState() {
  return Container(
    padding: EdgeInsets.all(24.w),
    decoration: BoxDecoration(
      color: Color(0xFF1F1F1F),
      borderRadius: BorderRadius.circular(16.r),
      border: Border.all(
        color: Colors.white.withValues(alpha: 0.1),
        width: 1.w,
      ),
    ),
    child: Row(
      children: [
        Icon(
          Icons.favorite_border,
          size: 32.sp,
          color: Colors.red.withValues(alpha: 0.6),
        ),
        SizedBox(width: 16.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Build Your Collection",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                "Like movies while swiping to create your personal favorites",
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 14.sp,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

// ========================================
// UTILITY METHODS
// ========================================

String _formatRelativeTime(DateTime dateTime) {
  final now = DateTime.now();
  final difference = now.difference(dateTime);
  
  if (difference.inMinutes < 60) {
    return '${difference.inMinutes}m ago';
  } else if (difference.inHours < 24) {
    return '${difference.inHours}h ago';
  } else if (difference.inDays == 1) {
    return 'Yesterday';
  } else if (difference.inDays < 7) {
    return '${difference.inDays} days ago';
  } else {
    return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
  }
}


List<dynamic> _getArchivedItems() {
  return _archivedSessions.take(5).toList();
}
}

enum TimeOfDay { morning, afternoon, evening, night }
enum QueueItemType { movie, session }

class QueueItem {
  final QueueItemType type;
  final Movie? movie;
  final MovieSession? session;
  final List<Movie>? matches;
  final String title;
  final String subtitle;
  final List<String> contextTags;
  final String primaryActionLabel;
  final double confidenceScore;
  
  QueueItem({
    required this.type,
    this.movie,
    this.session,
    this.matches,
    required this.title,
    required this.subtitle,
    required this.contextTags,
    required this.primaryActionLabel,
    required this.confidenceScore,
  });
}

// Session data models (keep these the same)
class MovieSession {
  final String id;
  final List<String> participantIds;
  final List<String> participantNames;
  final DateTime createdAt;
  final SessionStatus status;
  final List<String> matchedMovieIds;
  final Movie? chosenMovie;
  final DateTime? completedAt;

  MovieSession({
    required this.id,
    required this.participantIds,
    required this.participantNames,
    required this.createdAt,
    required this.status,
    required this.matchedMovieIds,
    this.chosenMovie,
    this.completedAt,
  });

  factory MovieSession.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return MovieSession(
      id: doc.id,
      participantIds: List<String>.from(data['participantIds'] ?? []),
      participantNames: List<String>.from(data['participantNames'] ?? []),
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      status: SessionStatus.values.firstWhere(
        (e) => e.toString().split('.').last == data['status'],
        orElse: () => SessionStatus.active,
      ),
      matchedMovieIds: List<String>.from(data['matchedMovieIds'] ?? []),
      chosenMovie: data['chosenMovieTitle'] != null 
          ? Movie(
              id: data['chosenMovieId'] ?? '',
              title: data['chosenMovieTitle'] ?? '',
              posterUrl: '',
              overview: '',
              cast: [],
              genres: [],
              tags: [],
            )
          : null,
      completedAt: data['completedAt'] != null 
          ? (data['completedAt'] as Timestamp).toDate()
          : null,
    );
  }
}

enum SessionStatus {
  active,
  swiping,
  hasMatches,
  completed,
  expired,
}