import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'dart:math' as math;
import '../models/user_profile.dart';
import '../movie.dart';
import '../utils/user_profile_storage.dart';
import '../services/firestore_service.dart';

class MatchedScreen extends StatefulWidget {
  final Movie movie;
  final UserProfile currentUser;
  final String? matchedName;

  const MatchedScreen({
    Key? key,
    required this.movie,
    required this.currentUser,
    this.matchedName,
  }) : super(key: key);

  @override
  State<MatchedScreen> createState() => _MatchedScreenState();
}

class _MatchedScreenState extends State<MatchedScreen> with TickerProviderStateMixin {
  bool _isMatchSaved = false;

  // Enhanced animation controllers
  late final AnimationController _mainController = AnimationController(
    duration: const Duration(milliseconds: 1200),
    vsync: this,
  );
  
  late final AnimationController _pulseController = AnimationController(
    duration: const Duration(milliseconds: 1000),
    vsync: this,
  );
  
  late final AnimationController _confettiController = AnimationController(
    duration: const Duration(milliseconds: 3000),
    vsync: this,
  );
  
  // Enhanced animations
  late final Animation<double> _scaleAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
    CurvedAnimation(parent: _mainController, curve: const Interval(0.0, 0.6, curve: Curves.elasticOut))
  );
  
  late final Animation<double> _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
    CurvedAnimation(parent: _mainController, curve: const Interval(0.2, 0.8, curve: Curves.easeOut))
  );
  
  late final Animation<double> _slideAnimation = Tween<double>(begin: 100.0, end: 0.0).animate(
    CurvedAnimation(parent: _mainController, curve: const Interval(0.4, 1.0, curve: Curves.easeOutCubic))
  );
  
  late final Animation<double> _pulseAnimation = Tween<double>(begin: 1.0, end: 1.1).animate(
    CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut)
  );

  // Enhanced confetti
  final List<ConfettiParticle> _particles = [];
  final int _particleCount = 80;

  @override
  void initState() {
    super.initState();
    
    _generateParticles();
    
    // Automatically save the match when screen opens
    _saveMatchAutomatically();
    
    // Start animations sequence
    _mainController.forward();
    _pulseController.repeat(reverse: true);
    
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) {
        _confettiController.forward();
      }
    });
  }

  Future<void> _saveMatchAutomatically() async {
    try {
      final matchEntry = {
        'username': widget.matchedName ?? 'Matched user',
        'movieTitle': widget.movie.title,
        'movieId': widget.movie.id, // 🆕 Add movie ID
        'matchDate': DateTime.now(),
        'posterUrl': widget.movie.posterUrl,
        'watched': false,
        'archived': false, // 🆕 Add archive field for compatibility
        'watchedDate': null,
        'archivedDate': null, // 🆕 Add archive date field
        'groupName': null,
        'movie': widget.movie.toJson(), // 🔧 FIXED: Convert to JSON instead of raw object
      };

      // Add to current user's match history
      widget.currentUser.matchHistory.add(matchEntry);
      
      // Save to persistent storage
      await UserProfileStorage.saveProfile(widget.currentUser);
      
      // 🆕 OPTIONAL: Also save to Firestore if you want cloud backup
      try {
        await FirestoreService().saveMatchToFirestore(widget.currentUser.uid, widget.movie);
      } catch (firestoreError) {
        print("⚠️ Firestore save failed (but local save succeeded): $firestoreError");
        // Don't throw here - local save is more important
      }
      
      setState(() {
        _isMatchSaved = true;
      });
      
      print("✅ Match automatically saved: ${widget.movie.title}");
      
    } catch (e) {
      print("❌ Error saving match: $e");
      
      // Show error to user
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to save match. Please try again.'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 3),
          ),
        );
      }
    }
  }

  void _generateParticles() {
    final random = math.Random();
    final colors = [
      const Color(0xFFFFD700), // Gold
      const Color(0xFFFF6B6B), // Red
      const Color(0xFF4ECDC4), // Teal
      const Color(0xFF45B7D1), // Blue
      const Color(0xFF96CEB4), // Green
      const Color(0xFFFFC0CB), // Pink
    ];
    
    for (int i = 0; i < _particleCount; i++) {
      final color = colors[random.nextInt(colors.length)];
      final size = random.nextDouble() * 12.r + 6.r;
      final startX = random.nextDouble() * 500.w - 250.w;
      final startY = random.nextDouble() * -100.h - 100.h;
      final velocity = Offset(
        (random.nextDouble() - 0.5) * 200.w,
        random.nextDouble() * 400.h + 200.h,
      );
      final rotationSpeed = (random.nextDouble() - 0.5) * 0.3;
      
      _particles.add(ConfettiParticle(
        color: color,
        size: size,
        position: Offset(startX, startY),
        velocity: velocity,
        rotationSpeed: rotationSpeed,
      ));
    }
  }

  @override
  void dispose() {
    _mainController.dispose();
    _pulseController.dispose();
    _confettiController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.5,
            colors: [
              Color(0xFF2A1810), // Dark brown center
              Color(0xFF1A1A1A), // Dark edges
              Colors.black,
            ],
          ),
        ),
        child: Stack(
          children: [
            // Enhanced confetti layer
            AnimatedBuilder(
              animation: _confettiController,
              builder: (context, child) {
                for (var particle in _particles) {
                  particle.update(_confettiController.value);
                }
                return CustomPaint(
                  size: Size.infinite,
                  painter: EnhancedConfettiPainter(particles: _particles),
                );
              },
            ),
            
            // Main content
            SafeArea(
              child: AnimatedBuilder(
                animation: _mainController,
                builder: (context, child) {
                  return Opacity(
                    opacity: _fadeAnimation.value,
                    child: Transform.scale(
                      scale: _scaleAnimation.value,
                      child: Column(
                        children: [
                          SizedBox(height: 24.h),
                          
                          // Enhanced match header
                          AnimatedBuilder(
                            animation: _pulseController,
                            builder: (context, child) {
                              return Transform.scale(
                                scale: _pulseAnimation.value,
                                child: Container(
                                  padding: EdgeInsets.symmetric(horizontal: 32.w, vertical: 16.h),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    borderRadius: BorderRadius.circular(50.r),
                                    boxShadow: [
                                      BoxShadow(
                                        color: const Color(0xFFFFD700).withValues(alpha: 0.5),
                                        blurRadius: 20.r,
                                        spreadRadius: 5.r,
                                      ),
                                    ],
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.favorite,
                                        color: Colors.red,
                                        size: 24.sp,
                                      ),
                                      SizedBox(width: 12.w),
                                      Text(
                                        "IT'S A MATCH!",
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 24.sp,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 1.2,
                                        ),
                                      ),
                                      SizedBox(width: 12.w),
                                      Icon(
                                        Icons.favorite,
                                        color: Colors.red,
                                        size: 24.sp,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                          
                          SizedBox(height: 40.h),
                          
                          // Enhanced user avatars with connection line
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 40.w),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                _buildUserAvatar(
                                  name: "You", 
                                  initial: widget.currentUser.name.isNotEmpty ? widget.currentUser.name[0] : "U",
                                  color: const Color(0xFF4ECDC4),
                                ),
                                
                                // Connection line with heart
                                Expanded(
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Container(
                                        height: 3.h,
                                        margin: EdgeInsets.symmetric(horizontal: 20.w),
                                        decoration: BoxDecoration(
                                          gradient: const LinearGradient(
                                            colors: [Color(0xFF4ECDC4), Color(0xFFFF6B6B)],
                                          ),
                                          borderRadius: BorderRadius.circular(2.r),
                                        ),
                                      ),
                                      Container(
                                        padding: EdgeInsets.all(6.r),
                                        decoration: BoxDecoration(
                                          color: Colors.red,
                                          shape: BoxShape.circle,
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.red.withValues(alpha: 0.3),
                                              blurRadius: 8.r,
                                              spreadRadius: 1.r,
                                            ),
                                          ],
                                        ),
                                        child: Icon(
                                          Icons.favorite,
                                          color: Colors.white,
                                          size: 14.sp,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                
                                _buildUserAvatar(
                                  name: widget.matchedName ?? "Friend", 
                                  initial: widget.matchedName?.isNotEmpty == true ? widget.matchedName![0] : "F",
                                  color: const Color(0xFFFF6B6B),
                                ),
                              ],
                            ),
                          ),
                          
                          SizedBox(height: 24.h),
                          
                          // Enhanced movie card - NO SCROLL, COMPACT FIT
                          Expanded(
                            child: Transform.translate(
                              offset: Offset(0, _slideAnimation.value),
                              child: Container(
                                margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 8.h),
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      Color(0xFF2D2D2D),
                                      Color(0xFF1A1A1A),
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(20.r),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.3),
                                      blurRadius: 15.r,
                                      spreadRadius: 3.r,
                                      offset: Offset(0, 5.h),
                                    ),
                                  ],
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(16.r),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      // Movie poster - SMALLER
                                      Container(
                                        width: 100.w,
                                        height: 150.h,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(12.r),
                                          boxShadow: [
                                            BoxShadow(
                                              color: const Color(0xFFFFD700).withValues(alpha: 0.3),
                                              blurRadius: 10.r,
                                              spreadRadius: 2.r,
                                            ),
                                          ],
                                        ),
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(12.r),
                                          child: Image.network(
                                            widget.movie.posterUrl,
                                            fit: BoxFit.cover,
                                            errorBuilder: (context, error, stackTrace) {
                                              return Container(
                                                decoration: BoxDecoration(
                                                  gradient: LinearGradient(
                                                    colors: [Colors.grey[800]!, Colors.grey[600]!],
                                                  ),
                                                ),
                                                child: Icon(
                                                  Icons.movie,
                                                  size: 30.sp,
                                                  color: Colors.white54,
                                                ),
                                              );
                                            },
                                          ),
                                        ),
                                      ),
                                      
                                      // Movie title - COMPACT
                                      Text(
                                        widget.movie.title,
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 18.sp,
                                          fontWeight: FontWeight.bold,
                                          height: 1.1,
                                        ),
                                        textAlign: TextAlign.center,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      
                                      // Enhanced genre tags - MINIMAL
                                      if (widget.movie.genres.isNotEmpty)
                                        Wrap(
                                          alignment: WrapAlignment.center,
                                          spacing: 6.w,
                                          children: widget.movie.genres.take(2).map((genre) => 
                                            Container(
                                              padding: EdgeInsets.symmetric(
                                                horizontal: 8.w, 
                                                vertical: 3.h,
                                              ),
                                              decoration: BoxDecoration(
                                                gradient: const LinearGradient(
                                                  colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
                                                ),
                                                borderRadius: BorderRadius.circular(12.r),
                                              ),
                                              child: Text(
                                                genre,
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 10.sp,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                              ),
                                            )
                                          ).toList(),
                                        ),
                                      
                                      // Buttons - COMPACT
                                      Row(
                                        children: [
                                          // Save Match button
                                          Expanded(
                                            child: ElevatedButton.icon(
                                              onPressed: _isMatchSaved ? null : () async {
                                                await FirestoreService().saveMatchToFirestore(widget.currentUser.uid, widget.movie);
                                                setState(() {
                                                  _isMatchSaved = true;
                                                });

                                                ScaffoldMessenger.of(context).showSnackBar(
                                                  SnackBar(
                                                    content: Text('${widget.movie.title} saved to Matches!'),
                                                    backgroundColor: const Color(0xFF4CAF50),
                                                    behavior: SnackBarBehavior.floating,
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.circular(8.r),
                                                    ),
                                                  ),
                                                );
                                              },
                                              icon: Icon(
                                                _isMatchSaved ? Icons.check_circle : Icons.bookmark_add, 
                                                size: 14.sp
                                              ),
                                              label: Text(
                                                _isMatchSaved ? "Saved!" : "Save",
                                                style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.bold),
                                              ),
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: _isMatchSaved ? const Color(0xFF4CAF50) : const Color(0xFFFFD700),
                                                foregroundColor: Colors.black,
                                                padding: EdgeInsets.symmetric(vertical: 10.h),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(10.r),
                                                ),
                                                elevation: 3,
                                              ),
                                            ),
                                          ),
                                          
                                          SizedBox(width: 10.w),
                                          
                                          // Keep Swiping button
                                          Expanded(
                                            child: OutlinedButton.icon(
                                              onPressed: () {
                                                Navigator.pop(context);
                                              },
                                              icon: Icon(Icons.arrow_forward, size: 14.sp),
                                              label: Text(
                                                "Continue",
                                                style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.bold),
                                              ),
                                              style: OutlinedButton.styleFrom(
                                                foregroundColor: Colors.white,
                                                side: BorderSide(color: Colors.white30, width: 1.2.w),
                                                padding: EdgeInsets.symmetric(vertical: 10.h),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(10.r),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserAvatar({
    required String name,
    required String initial,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          width: 60.w,
          height: 60.h,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [color, color.withValues(alpha: 0.7)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: color.withValues(alpha: 0.3),
                blurRadius: 12.r,
                spreadRadius: 2.r,
              ),
            ],
          ),
          child: Center(
            child: Text(
              initial.toUpperCase(),
              style: TextStyle(
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
        SizedBox(height: 8.h),
        Text(
          name,
          style: TextStyle(
            color: Colors.white,
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

// Enhanced confetti particle
class ConfettiParticle {
  Color color;
  double size;
  Offset position;
  Offset velocity;
  double rotationSpeed;
  double rotation = 0;
  double life = 1.0;
  
  ConfettiParticle({
    required this.color,
    required this.size,
    required this.position,
    required this.velocity,
    required this.rotationSpeed,
  });
  
  void update(double dt) {
    // Update position with physics
    position = Offset(
      position.dx + velocity.dx * dt,
      position.dy + velocity.dy * dt,
    );
    
    // Apply gravity
    velocity = Offset(velocity.dx * 0.99, velocity.dy + 300 * dt);
    
    // Update rotation and life
    rotation += rotationSpeed * dt;
    life -= dt * 0.3;
    
    // Reset if off screen or dead
    if (position.dy > 1000 || life <= 0) {
      final random = math.Random();
      position = Offset(
        random.nextDouble() * 500 - 250,
        random.nextDouble() * -100 - 100,
      );
      velocity = Offset(
        (random.nextDouble() - 0.5) * 200,
        random.nextDouble() * 400 + 200,
      );
      life = 1.0;
    }
  }
}

// Enhanced confetti painter
class EnhancedConfettiPainter extends CustomPainter {
  final List<ConfettiParticle> particles;
  
  EnhancedConfettiPainter({required this.particles});
  
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    
    for (var particle in particles) {
      final paint = Paint()
        ..color = particle.color.withValues(alpha: particle.life)
        ..style = PaintingStyle.fill;
      
      final position = center + particle.position;
      
      canvas.save();
      canvas.translate(position.dx, position.dy);
      canvas.rotate(particle.rotation);
      
      // Enhanced shapes with variety
      final shapeType = particle.hashCode % 4;
      
      switch (shapeType) {
        case 0: // Rectangle
          canvas.drawRRect(
            RRect.fromRectAndRadius(
              Rect.fromCenter(center: Offset.zero, width: particle.size, height: particle.size * 0.6),
              Radius.circular(particle.size * 0.1),
            ),
            paint,
          );
          break;
        case 1: // Circle
          canvas.drawCircle(Offset.zero, particle.size / 2, paint);
          break;
        case 2: // Star
          _drawStar(canvas, paint, particle.size);
          break;
        case 3: // Heart
          _drawHeart(canvas, paint, particle.size);
          break;
      }
      
      canvas.restore();
    }
  }
  
  void _drawStar(Canvas canvas, Paint paint, double size) {
    final path = Path();
    final radius = size / 2;
    final innerRadius = radius * 0.4;
    
    for (int i = 0; i < 10; i++) {
      final angle = (i * math.pi) / 5;
      final r = i.isEven ? radius : innerRadius;
      final x = r * math.cos(angle - math.pi / 2);
      final y = r * math.sin(angle - math.pi / 2);
      
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();
    canvas.drawPath(path, paint);
  }
  
  void _drawHeart(Canvas canvas, Paint paint, double size) {
    final path = Path();
    final scale = size / 20;
    
    path.moveTo(0, 5 * scale);
    path.cubicTo(-5 * scale, -5 * scale, -10 * scale, 0, -5 * scale, 5 * scale);
    path.cubicTo(-5 * scale, 0, 0, 2.5 * scale, 0, 5 * scale);
    path.cubicTo(0, 2.5 * scale, 5 * scale, 0, 5 * scale, 5 * scale);
    path.cubicTo(10 * scale, 0, 5 * scale, -5 * scale, 0, 5 * scale);
    
    canvas.drawPath(path, paint);
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}