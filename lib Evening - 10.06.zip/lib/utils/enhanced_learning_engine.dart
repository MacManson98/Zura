// File: lib/utils/enhanced_learning_engine.dart

import '../movie.dart';
import '../models/user_profile.dart';
import 'dart:math';

class EnhancedLearningEngine {
  // Weight constants for different interaction types
  static const double likeWeight = 1.5;
  static const double passWeight = 0.7;
  static const double recentBoostMultiplier = 1.8;
  static const double decayFactor = 0.995; // Daily decay
  static const double maxScore = 50.0; // Prevent runaway scores
  static const double minScore = 0.0;
  static const int momentumThreshold = 3; // Consecutive likes/passes to trigger momentum
  // Quality thresholds for movie recommendations
  static const double minRating = 5.0;
  static const int minVoteCount = 1000;
  static const double sessionLearningBoost = 2.0; // Extra weight for in-session learning

  static final Map<String, int> _sessionGenreLikes = {};
  static final Map<String, int> _sessionGenrePasses = {};
  static final Map<String, int> _sessionVibeLikes = {};
  static final Map<String, int> _sessionVibePasses = {};
  static final List<String> _recentSwipes = []; // Track last 10 swipes
  static String? _currentSessionMomentum;

  /// Main learning function when user likes a movie
  static void learnFromLikedMovie(UserProfile user, Movie movie, {bool isSessionLearning = false}) {
  _applyRecencyDecay(user);
  

  // Track session momentum
  if (isSessionLearning) {
    _recentSwipes.add('like');
    if (_recentSwipes.length > 10) _recentSwipes.removeAt(0);


    for (final vibe in movie.tags) {
      _sessionVibeLikes[vibe] = (_sessionVibeLikes[vibe] ?? 0) + 1;
    }

    _detectMomentum();
  }

  // Apply session boost if in active session
  final double finalWeight = isSessionLearning 
      ? likeWeight * recentBoostMultiplier * sessionLearningBoost
      : likeWeight * recentBoostMultiplier;

  // ✅ Apply genre learning
  for (final genre in movie.genres) {
    user.genreScores[genre] = _updateScore(
      user.genreScores[genre] ?? 0,
      finalWeight,
      true,
    );
  }

  // ✅ Apply vibe learning
  for (final vibe in movie.tags) {
    user.vibeScores[vibe] = _updateScore(
      user.vibeScores[vibe] ?? 0,
      finalWeight,
      true,
    );
  }

  // ✅ Record user activity
  user.likedMovies.add(movie);
  user.lastActivityDate = DateTime.now();

  print("✅ Learned from LIKE: ${movie.title}");
}
  // Add momentum detection
  static void _detectMomentum() {
    // Check genre momentum
    for (final entry in _sessionGenreLikes.entries) {
      if (entry.value >= momentumThreshold) {
        _currentSessionMomentum = entry.key;
        print("🔥 Momentum detected: ${entry.key} genre!");
        break;
      }
    }
    
    // Check if user is being too picky
    final recentPasses = _recentSwipes.where((s) => s == 'pass').length;
    if (recentPasses >= 7 && _recentSwipes.length >= 10) {
      print("😕 User seems picky - need to diversify!");
      _currentSessionMomentum = 'picky';
    }
  }

  // Get current session insights
  static Map<String, dynamic> getSessionInsights() {
    final totalSwipes = _recentSwipes.length;
    final likes = _recentSwipes.where((s) => s == 'like').length;
    final passes = _recentSwipes.where((s) => s == 'pass').length;
    
    return {
      'totalSwipes': totalSwipes,
      'recentLikesCount': likes,
      'recentPassesCount': passes,
      'likeRate': totalSwipes > 0 ? likes / totalSwipes : 0.0,
      'currentMomentum': _sessionGenreLikes,
      'isInMomentum': _currentSessionMomentum != null,
      'momentumType': _currentSessionMomentum,
      'dominantGenre': _getDominantGenre(),
    };
  }

  static String? _getDominantGenre() {
    if (_sessionGenreLikes.isEmpty) return null;
    
    final sorted = _sessionGenreLikes.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    return sorted.first.value >= 2 ? sorted.first.key : null;
  }

  static bool _shouldDiversify() {
    final insights = getSessionInsights();
    final likeRate = insights['likeRate'] as double;
    
    // Diversify if user is too picky or too accepting
    return likeRate < 0.2 || likeRate > 0.8 || _currentSessionMomentum == 'picky';
  }

  // Adaptive session generation based on current momentum
  static Future<List<Movie>> generateAdaptiveSession({
    required UserProfile user,
    required List<Movie> movieDatabase,
    required Set<String> seenMovieIds,
    int sessionSize = 20,
    bool prioritizeSessionMomentum = false,
  }) async {
    final insights = getSessionInsights();
    final shouldDiversify = _shouldDiversify();

    final dominantGenre = insights['dominantGenre'] as String?;
    
    print("🎯 Adaptive generation: Diversify=$shouldDiversify, Momentum=$dominantGenre");
    
    if (prioritizeSessionMomentum && dominantGenre != null && !shouldDiversify) {
      // User is in a groove - give them more of what they want
      return _generateMomentumMovies(
        movieDatabase,
        user,
        seenMovieIds,
        dominantGenre,
        sessionSize,
      );
    } else if (shouldDiversify) {
      // User needs variety
      return _generateDiscoveryMovies(
        movieDatabase,
        user,
        seenMovieIds,
        sessionSize,
      );
    } else {
      // Standard personalized generation
      return generatePersonalizedSession(
        user: user,
        movieDatabase: movieDatabase,
        seenMovieIds: seenMovieIds,
        sessionSize: sessionSize,
      );
    }
  }

  // Generate movies for momentum state
  static List<Movie> _generateMomentumMovies(
    List<Movie> movieDatabase,
    UserProfile user,
    Set<String> seenMovieIds,
    String dominantGenre,
    int count,
  ) {
    final momentumMovies = <Movie>[];
    
    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (momentumMovies.length >= count) break;
      if (!_isSfwMovie(movie)) continue;
      
      // Must contain the momentum genre
      if (movie.genres.contains(dominantGenre)) {
        // Bonus if it has user's preferred vibes too
        final hasPreferredVibe = movie.tags.any((v) => 
          (user.vibeScores[v] ?? 0) > 2.0
        );
        
        if (hasPreferredVibe || movie.rating! > 7.5) {
          momentumMovies.add(movie);
        }
      }
    }
    
    momentumMovies.shuffle();
    return momentumMovies;
  }

  // Generate discovery movies when user needs variety
  static List<Movie> _generateDiscoveryMovies(
    List<Movie> movieDatabase,
    UserProfile user,
    Set<String> seenMovieIds,
    int count,
  ) {
    final topGenres = user.genreScores.entries
        .toList()
        ..sort((a, b) => b.value.compareTo(a.value));
    final dominantGenres = topGenres.take(3).map((e) => e.key).toSet();

    final discoveryMovies = <Movie>[];

    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      if (discoveryMovies.length >= count) break;

      final hasCurveballGenre = movie.genres.any((g) => !dominantGenres.contains(g));
      print("🎯 Curveball? ${movie.title} — genres: ${movie.genres}");

      if (hasCurveballGenre && (movie.rating ?? 0) > 6.5) {
        discoveryMovies.add(movie);
      }
    }

    // Fallback to wildcards if not enough found
    if (discoveryMovies.length < count) {
      final additional = _getWildcardMovies(
        movieDatabase,
        seenMovieIds,
        count - discoveryMovies.length,
      );
      discoveryMovies.addAll(additional);
    }

    discoveryMovies.shuffle();
    return discoveryMovies;
  }


  // Reset session tracking
  static void resetSessionTracking() {
    _sessionGenreLikes.clear();
    _sessionGenrePasses.clear();
    _sessionVibeLikes.clear();
    _sessionVibePasses.clear();
    _recentSwipes.clear();
    _currentSessionMomentum = null;
  }

  // Check if we should adapt the session
  static bool shouldAdaptSession() {
    final insights = getSessionInsights();
    final totalSwipes = insights['totalSwipes'] as int;
    
    // Adapt every 5 swipes after the first 10
    return totalSwipes >= 10 && totalSwipes % 5 == 0;
  }
  
  /// Learning function when user passes on a movie
  static void learnFromPassedMovie(UserProfile user, Movie movie, {bool isSessionLearning = false}) {
    _applyRecencyDecay(user);

    user.genreFatigue.clear(); // Reset fatigue for a fresh session
    
    final double finalWeight = 2.5; // Stronger penalty

    
    // Gently reduce preference for genres
    for (final genre in movie.genres) {
      user.dislikeScores[genre] = _updateScore(
        user.dislikeScores[genre] ?? 0, 
        finalWeight, 
        true
      );
    }
    
    // Reduce preference for vibes
    for (final vibe in movie.tags) {
      user.dislikeVibeScores[vibe] = _updateScore(
        user.dislikeVibeScores[vibe] ?? 0, 
        finalWeight, 
        true
      );
    }

        // Track genre fatigue
    for (final genre in movie.genres) {
      user.genreFatigue[genre] = (user.genreFatigue[genre] ?? 0) + 1;

      if (user.genreFatigue[genre]! >= 3) {
        user.dislikeScores[genre] = _updateScore(
          user.dislikeScores[genre] ?? 0,
          1.5,
          true,
        );
        print("⚠️ Fatigue detected in genre: $genre");
      }
    }

    
    // Track that this movie was passed
    user.passedMovieIds.add(movie.id);
    user.lastActivityDate = DateTime.now();
    
    print("❌ Learned from PASS: ${movie.title}");
  }
  
  /// Generate a personalized movie session for the user
  static Future<List<Movie>> generatePersonalizedSession({
    required UserProfile user,
    required List<Movie> movieDatabase,
    required Set<String> seenMovieIds, // Already liked, passed, or in current session
    int sessionSize = 50,
  }) async {
    _applyRecencyDecay(user);
    
    final Set<Movie> sessionPool = {};
    
    // Get user's top preferences
    final topGenres = _getTopScoresWithFatiguePenalty(
      user.genreScores,
      user.dislikeScores,
      user.genreFatigue,
      maxItems: 3,
    );
    print("🎯 Targeting Genres (filtered): ${topGenres.map((e) => e.key).join(', ')}");

    final topVibes = _getTopScores(user.vibeScores, user.dislikeVibeScores, maxItems: 3);    
    print("🎯 Targeting: Genres=${topGenres.map((e) => e.key).join(',')}, Vibes=${topVibes.map((e) => e.key).join(',')}");
    
    // Phase 1: Core recommendations (60% of session)
    final coreCount = (sessionSize * 0.6).round();
    final coreMovies = _getCoreRecommendations(
      movieDatabase, 
      user, 
      seenMovieIds, 
      topGenres, 
      topVibes,
      coreCount
    );
    sessionPool.addAll(coreMovies);
    
    // Phase 2: Similar to recent likes (20% of session)
    final similarCount = (sessionSize * 0.2).round();
    final similarMovies = _getSimilarToRecentLikes(
      movieDatabase,
      user,
      seenMovieIds,
      similarCount
    );
    sessionPool.addAll(similarMovies);
    
    // Phase 3: Discovery/Curveball movies (15% of session)
    final discoveryCount = (sessionSize * 0.15).round();
    final discoveryMovies = _getDiscoveryMovies(
      movieDatabase,
      user,
      seenMovieIds,
      discoveryCount
    );
    sessionPool.addAll(discoveryMovies);

    final highFatigueGenres = user.genreFatigue.entries.where((e) => e.value >= 4).map((e) => e.key).toSet();
      if (highFatigueGenres.length >= 3) {
        print("🚨 High genre fatigue detected: $highFatigueGenres");
        final rescueMovies = _getDiscoveryMovies(movieDatabase, user, seenMovieIds, 5);
        sessionPool.addAll(rescueMovies);
      }

    
    // Phase 4: High-quality wildcard movies (5% of session)
    final wildcardCount = sessionSize - sessionPool.length;
    if (wildcardCount > 0) {
      final wildcardMovies = _getWildcardMovies(
        movieDatabase,
        seenMovieIds,
        wildcardCount
      );
      sessionPool.addAll(wildcardMovies);
    }
    
    final finalSession = sessionPool.toList()..shuffle();
    print("📱 Generated session: ${finalSession.length} movies (${coreCount} core, ${similarMovies.length} similar, ${discoveryMovies.length} discovery)");
    
    return finalSession;
  }
  
  /// Get core recommendations based on user's top preferences
  static List<Movie> _getCoreRecommendations(
    List<Movie> movieDatabase,
    UserProfile user,
    Set<String> seenMovieIds,
    List<MapEntry<String, double>> topGenres,
    List<MapEntry<String, double>> topVibes,
    int count
  ) {
    final scored = <Movie, double>{};

    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;

      double score = 0.0;

      // ✅ Genre scoring with fatigue penalty
      for (final genre in movie.genres) {
        final genreScore = user.genreScores[genre] ?? 0;
        final dislikeScore = user.dislikeScores[genre] ?? 0;
        final fatigue = user.genreFatigue[genre] ?? 0;

        score += (genreScore - dislikeScore * 0.75 - fatigue * 1.5);
      }

      // ✅ Vibe scoring
      for (final vibe in movie.tags) {
        final vibeScore = user.vibeScores[vibe] ?? 0;
        final dislikeScore = user.dislikeVibeScores[vibe] ?? 0;
        score += (vibeScore - dislikeScore * 1.5);
      }

      // ✅ Runtime preference
      if (movie.runtime != null) {
        final runtimeCategory = _categorizeRuntime(movie.runtime!);
        score += (user.runtimePreferences[runtimeCategory] ?? 0) * 0.3;
      }

      // ✅ Quality boost for highly rated films
      if (movie.rating != null && movie.rating! > 7.0) {
        score += 2.0;
      }

      // ✅ Language preference
      if (movie.originalLanguage != null) {
        score += (user.languagePreferences[movie.originalLanguage!] ?? 0) * 0.2;
      }

      // ✅ Popularity bonus
      if (movie.voteCount != null) {
        score += log(movie.voteCount! + 1) * 0.1;
      }

      scored[movie] = score;
    }

    final sorted = scored.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return sorted.take(count).map((e) => e.key).toList();
  }

  
  /// Get movies similar to user's recent likes
  static List<Movie> _getSimilarToRecentLikes(
    List<Movie> movieDatabase,
    UserProfile user,
    Set<String> seenMovieIds,
    int count
  ) {
    if (user.likedMovies.isEmpty) return [];
    print("ℹ️ Skipping similar recommendations (likedMovies empty)");

    for (final movie in user.likedMovies.take(5)) {
      print("🧩 Liked: ${movie.title} → ${movie.genres.join(', ')} | ${movie.tags.join(', ')}");
    }

    // Get user's most recent likes (last 10)
    final recentLikes = user.likedMovies.toList()..shuffle();
    final recentLikesSubset = recentLikes.take(min(10, recentLikes.length));
    
    final similarMovies = <Movie, double>{};
    
    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (!_isSfwMovie(movie)) continue;
      
      double similarityScore = 0;
      
      for (final likedMovie in recentLikesSubset) {
        // Genre overlap
        final sharedGenres = movie.genres.toSet().intersection(likedMovie.genres.toSet());
        similarityScore += sharedGenres.length * 2.0;
        
        // Vibe overlap
        final sharedVibes = movie.tags.toSet().intersection(likedMovie.tags.toSet());
        similarityScore += sharedVibes.length * 1.5;
        
        // Runtime similarity
        if (movie.runtime != null && likedMovie.runtime != null) {
          final runtimeDiff = (movie.runtime! - likedMovie.runtime!).abs();
          if (runtimeDiff < 30) { // Within 30 minutes
            similarityScore += 1.0;
          }
        }
      }
      
      if (similarityScore > 0) {
        similarMovies[movie] = similarityScore;
      }
    }
    
    final sorted = similarMovies.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    return sorted.take(count).map((e) => e.key).toList();
  }
  
  /// Get discovery movies from unexplored genres/vibes
  static List<Movie> _getDiscoveryMovies(
    List<Movie> movieDatabase,
    UserProfile user,
    Set<String> seenMovieIds,
    int count
  ) {
    // Find genres and vibes the user hasn't strongly disliked
    final allGenres = {'Action', 'Comedy', 'Drama', 'Horror', 'Romance', 'Sci-Fi', 'Fantasy', 'Thriller', 'Mystery', 'Animation'};
    final allVibes = {'Feel-Good', 'Emotional', 'Mind-Bending', 'Romantic', 'Action-Packed', 'Scary', 'Artsy/Indie', 'Dark/Disturbing', 'Funny', 'Epic'};
    
    final unexploredGenres = allGenres.where((g) => 
      (user.genreScores[g] ?? 0) < 2.0 && (user.dislikeScores[g] ?? 0) < 3.0
    ).toList();
    
    final unexploredVibes = allVibes.where((v) => 
      (user.vibeScores[v] ?? 0) < 2.0 && (user.dislikeVibeScores[v] ?? 0) < 3.0
    ).toList();
    
    final discoveryMovies = <Movie>[];
    
    for (final movie in movieDatabase) {
      if (seenMovieIds.contains(movie.id)) continue;
      if (!_meetsQualityThreshold(movie)) continue;
      if (discoveryMovies.length >= count) break;
      if (!_isSfwMovie(movie)) continue;
      
      // Must be highly rated for discovery
      if (movie.rating == null || movie.rating! < 7.0) continue;
      
      final hasUnexploredGenre = movie.genres.any((g) => unexploredGenres.contains(g));
      final hasUnexploredVibe = movie.tags.any((v) => unexploredVibes.contains(v));
      
      if (hasUnexploredGenre || hasUnexploredVibe) {
        discoveryMovies.add(movie);
print("🎯 Discovery matches found: ${discoveryMovies.length}");
      }
    }
    
    discoveryMovies.shuffle();
    return discoveryMovies.take(count).toList();
    
  }
  
  /// Get high-quality wildcard movies as fallback
  static List<Movie> _getWildcardMovies(
    List<Movie> movieDatabase,
    Set<String> seenMovieIds,
    int count
  ) {
    final wildcards = movieDatabase.where((movie) =>
      !seenMovieIds.contains(movie.id) &&
      movie.rating != null &&
      movie.rating! > 8.0 &&
      movie.voteCount != null &&
      movie.voteCount! > 1000
    ).toList();
    
    wildcards.shuffle();
    return wildcards.take(count).toList();
  }
  
  /// Helper functions
  static void _applyRecencyDecay(UserProfile user) {
    final daysSinceLastActivity = DateTime.now().difference(user.lastActivityDate).inDays;
    if (daysSinceLastActivity < 1) return;
    
    final decayAmount = pow(decayFactor, daysSinceLastActivity);
    
    user.genreScores.updateAll((key, value) => (value * decayAmount).clamp(minScore, maxScore));
    user.vibeScores.updateAll((key, value) => (value * decayAmount).clamp(minScore, maxScore));
    user.subGenreScores.updateAll((key, value) => (value * decayAmount).clamp(minScore, maxScore));
    user.keywordScores.updateAll((key, value) => (value * decayAmount).clamp(minScore, maxScore));
    user.dislikeScores.updateAll((key, value) => (value * decayAmount).clamp(minScore, maxScore));
    user.dislikeVibeScores.updateAll((key, value) => (value * decayAmount).clamp(minScore, maxScore));
  }
  
  static double _updateScore(double currentScore, double weight, bool isPositive) {
    final newScore = isPositive 
        ? currentScore + weight 
        : (currentScore - weight).clamp(minScore, double.infinity);
    return newScore.clamp(minScore, maxScore);
  }
  
  static List<MapEntry<String, double>> _getTopScores(
    Map<String, double> scores, 
    Map<String, double> dislikeScores, 
    {int maxItems = 5}
  ) {
    final adjustedScores = <String, double>{};
    
    for (final entry in scores.entries) {
      final dislikeScore = dislikeScores[entry.key] ?? 0;
      final adjustedScore = entry.value - (dislikeScore * 0.5);
      if (adjustedScore > 0) {
        adjustedScores[entry.key] = adjustedScore;
      }
    }
    
    final sorted = adjustedScores.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    return sorted.take(maxItems).toList();
  }

  static List<MapEntry<String, double>> _getTopScoresWithFatiguePenalty(
    Map<String, double> scores,
    Map<String, double> dislikeScores,
    Map<String, int> fatigueScores,
    {int maxItems = 5}
  ) {
    final adjustedScores = <String, double>{};

    for (final entry in scores.entries) {
      final dislike = dislikeScores[entry.key] ?? 0;
      final fatigue = fatigueScores[entry.key] ?? 0;
      final adjusted = entry.value - (dislike * 0.75) - (fatigue * 1.0);

      if (adjusted > 0) {
        adjustedScores[entry.key] = adjusted;
      }
    }

    final sorted = adjustedScores.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return sorted.take(maxItems).toList();
  }

  
  static String _categorizeRuntime(int runtime) {
    if (runtime < 90) return 'short';
    if (runtime < 130) return 'medium';
    return 'long';
  }
  
  static bool _meetsQualityThreshold(Movie movie) {
    return movie.posterUrl.isNotEmpty &&
           movie.rating != null &&
           movie.rating! >= minRating &&
           movie.voteCount != null &&
           movie.voteCount! >= minVoteCount;
  }
  static bool _isSfwMovie(Movie movie) {
    final bannedKeywords = [
      'porn', 'erotic', 'xxx', 'adult', 'sex', 'nude', 'strip', 'kamasutra',
      'brothel', 'prostitute', 'incest', 'hardcore'
    ];

    final lcTitle = movie.title.toLowerCase();
    final lcOverview = movie.overview.toLowerCase();

    return !bannedKeywords.any((kw) => lcTitle.contains(kw) || lcOverview.contains(kw));
  }

  /// Analytics function to understand user's taste evolution
  static Map<String, dynamic> analyzeTasteProfile(UserProfile user) {
    final topGenres = _getTopScoresWithFatiguePenalty(
      user.genreScores,
      user.dislikeScores,
      user.genreFatigue,
      maxItems: 5,
    );

    final topVibes = _getTopScores(
      user.vibeScores,
      user.dislikeVibeScores,
      maxItems: 5,
    );

    final discoveryScore = user.genreScores.keys.length;
    final explorationTrend = user.isExploringNewGenres ? 'expanding' : 'consistent';

    final fatiguedGenres = user.genreFatigue.entries
        .where((e) => e.value >= 3)
        .map((e) => e.key)
        .toList();

    return {
      'topGenres': topGenres.map((e) => {'name': e.key, 'score': e.value}).toList(),
      'topVibes': topVibes.map((e) => {'name': e.key, 'score': e.value}).toList(),
      'discoveryScore': discoveryScore,
      'explorationTrend': explorationTrend,
      'totalMoviesLiked': user.likedMovies.length,
      'daysSinceLastActivity': DateTime.now().difference(user.lastActivityDate).inDays,
      'fatiguedGenres': fatiguedGenres,
    };
  }

  static Map<String, int> get sessionGenreLikes => _sessionGenreLikes;
  static Map<String, int> get sessionVibeLikes => _sessionVibeLikes;
  static Map<String, int> get sessionVibePasses => _sessionVibePasses;
  static Map<String, int> get sessionGenrePasses => _sessionGenrePasses; // ✅ Make it mutable
  static String? get currentSessionMomentum => _currentSessionMomentum;
}