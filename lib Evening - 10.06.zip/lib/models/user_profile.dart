import '/movie.dart';
class MovieLike {
  final String movieId;
  final DateTime likedAt;
  final String sessionType; // "solo", "friend", "group"
  
  MovieLike({
    required this.movieId, 
    required this.likedAt, 
    required this.sessionType
  });
  
  factory MovieLike.fromJson(Map<String, dynamic> json) {
    return MovieLike(
      movieId: json['movieId'],
      likedAt: DateTime.parse(json['likedAt']),
      sessionType: json['sessionType'] ?? 'solo',
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'movieId': movieId,
      'likedAt': likedAt.toIso8601String(),
      'sessionType': sessionType,
    };
  }
}

class UserProfile {
  String uid;
  String name;
  Set<String> preferredGenres;
  Set<String> preferredVibes;
  Set<String> blockedGenres;
  Set<String> blockedAttributes;
  Set<Movie> likedMovies;
  Set<Movie> matchedMovies;
  Set<String> matchedMovieIds;
  Set<String> likedMovieIds;
  Set<String> favouriteMovieIds;
  Map<String, double> genreScores;
  Map<String, double> vibeScores;
  List<Map<String, dynamic>> matchHistory;
  final bool hasCompletedOnboarding;
  final List<String> friendIds;
  List<MovieLike> recentLikes;
  Map<String, DateTime> passedTimestamps;
  
  // 🆕 Enhanced learning fields for sophisticated recommendations
  Map<String, int> genreFatigue ={};
  Map<String, double> dislikeScores;        // Track genre dislikes
  Map<String, double> dislikeVibeScores;    // Track vibe dislikes
  Map<String, double> subGenreScores;       // Specific sub-genre preferences
  Map<String, double> actorScores;          // Actor preferences
  Map<String, double> dislikeActorScores;   // Actor dislikes
  Map<String, double> keywordScores;        // Keyword/theme preferences
  Map<String, double> runtimePreferences;   // Runtime category preferences (short/medium/long)
  Map<String, double> ratingPreferences;    // Rating preferences (low/medium/high/exceptional)
  Map<String, double> languagePreferences;  // Language preferences
  DateTime lastActivityDate;                // For recency weighting
  bool discoveryModeEnabled;                // Exploration toggle
  Set<String> passedMovieIds;               // Movies they've passed on
  bool hasSeenMatcher = false; // This will be saved to Firestore
  


  UserProfile({
    required this.uid,
    this.name = '',
    this.friendIds = const [], // ✅ This was already in constructor
    required this.preferredGenres,
    required this.preferredVibes,
    required this.blockedGenres,
    required this.blockedAttributes,
    required this.likedMovies,
    required this.matchedMovies,
    required this.matchedMovieIds,
    required this.likedMovieIds,
    required this.favouriteMovieIds,
    required this.matchHistory,
    this.hasCompletedOnboarding = false,
    this.hasSeenMatcher = false,
    Map<String, double>? genreScores,
    Map<String, double>? vibeScores,
    // Enhanced parameters
    Map<String, double>? dislikeScores,
    Map<String, double>? dislikeVibeScores,
    Map<String, double>? subGenreScores,
    Map<String, double>? actorScores,
    Map<String, double>? dislikeActorScores,
    Map<String, double>? keywordScores,
    Map<String, double>? runtimePreferences,
    Map<String, double>? ratingPreferences,
    Map<String, double>? languagePreferences,
    DateTime? lastActivityDate,
    this.discoveryModeEnabled = false,
    Set<String>? passedMovieIds,
    List<MovieLike>? recentLikes,
    Map<String, DateTime>? passedTimestamps,

  })  : genreScores = genreScores ?? {},
        vibeScores = vibeScores ?? {},
        dislikeScores = dislikeScores ?? {},
        dislikeVibeScores = dislikeVibeScores ?? {},
        subGenreScores = subGenreScores ?? {},
        actorScores = actorScores ?? {},
        dislikeActorScores = dislikeActorScores ?? {},
        keywordScores = keywordScores ?? {},
        runtimePreferences = runtimePreferences ?? {},
        ratingPreferences = ratingPreferences ?? {},
        languagePreferences = languagePreferences ?? {},
        lastActivityDate = lastActivityDate ?? DateTime.now(),
        passedMovieIds = passedMovieIds ?? {},
        recentLikes = recentLikes ?? [],
        passedTimestamps = passedTimestamps ?? {};

  factory UserProfile.empty() {
    return UserProfile(
      uid: '',
      name: '',
      friendIds: const [], // ✅ Added friendIds to empty factory
      preferredGenres: {},
      preferredVibes: {},
      blockedGenres: {},
      blockedAttributes: {},
      likedMovies: {},
      matchedMovies: {},
      matchedMovieIds: {},
      likedMovieIds: {},
      favouriteMovieIds: {},
      genreScores: {},
      vibeScores: {},
      matchHistory: [],
      dislikeScores: {},
      dislikeVibeScores: {},
      subGenreScores: {},
      actorScores: {},
      dislikeActorScores: {},
      keywordScores: {},
      runtimePreferences: {},
      ratingPreferences: {},
      languagePreferences: {},
      discoveryModeEnabled: false,
      passedMovieIds: {},
      recentLikes: [],
      passedTimestamps: {},
    );
  }

  UserProfile copyWith({
    String? uid,
    String? name,
    List<String>? friendIds, // ✅ Added friendIds to copyWith
    Set<String>? preferredGenres,
    Set<String>? preferredVibes,
    Set<String>? blockedGenres,
    Set<String>? blockedAttributes,
    Set<Movie>? likedMovies,
    Set<Movie>? matchedMovies,
    Set<String>? matchedMovieIds,
    Set<String>? likedMovieIds,
    Set<String>? favouriteMovieIds,
    Map<String, double>? genreScores,
    Map<String, double>? vibeScores,
    List<Map<String, dynamic>>? matchHistory,
    bool? hasCompletedOnboarding,
    bool? hasSeenMatcher, // ✅ Added missing hasSeenMatcher
    // Enhanced copyWith parameters
    Map<String, double>? dislikeScores,
    Map<String, double>? dislikeVibeScores,
    Map<String, double>? subGenreScores,
    Map<String, double>? actorScores,
    Map<String, double>? dislikeActorScores,
    Map<String, double>? keywordScores,
    Map<String, double>? runtimePreferences,
    Map<String, double>? ratingPreferences,
    Map<String, double>? languagePreferences,
    DateTime? lastActivityDate,
    bool? discoveryModeEnabled,
    Set<String>? passedMovieIds,
    List<MovieLike>? recentLikes,
    Map<String, DateTime>? passedTimestamps,
  }) {
    return UserProfile(
      uid: uid ?? this.uid,
      name: name ?? this.name,
      friendIds: friendIds ?? this.friendIds, // ✅ Added friendIds
      preferredGenres: preferredGenres ?? this.preferredGenres,
      preferredVibes: preferredVibes ?? this.preferredVibes,
      blockedGenres: blockedGenres ?? this.blockedGenres,
      blockedAttributes: blockedAttributes ?? this.blockedAttributes,
      likedMovies: likedMovies ?? this.likedMovies,
      matchedMovies: matchedMovies ?? this.matchedMovies,
      matchedMovieIds: matchedMovieIds ?? this.matchedMovieIds,
      likedMovieIds: likedMovieIds ?? this.likedMovieIds,
      favouriteMovieIds: favouriteMovieIds ?? this.favouriteMovieIds,
      genreScores: genreScores ?? this.genreScores,
      vibeScores: vibeScores ?? this.vibeScores,
      matchHistory: matchHistory ?? this.matchHistory,
      hasCompletedOnboarding: hasCompletedOnboarding ?? this.hasCompletedOnboarding,
      hasSeenMatcher: hasSeenMatcher ?? this.hasSeenMatcher, // ✅ Added missing field
      dislikeScores: dislikeScores ?? this.dislikeScores,
      dislikeVibeScores: dislikeVibeScores ?? this.dislikeVibeScores,
      subGenreScores: subGenreScores ?? this.subGenreScores,
      actorScores: actorScores ?? this.actorScores,
      dislikeActorScores: dislikeActorScores ?? this.dislikeActorScores,
      keywordScores: keywordScores ?? this.keywordScores,
      runtimePreferences: runtimePreferences ?? this.runtimePreferences,
      ratingPreferences: ratingPreferences ?? this.ratingPreferences,
      languagePreferences: languagePreferences ?? this.languagePreferences,
      lastActivityDate: lastActivityDate ?? this.lastActivityDate,
      discoveryModeEnabled: discoveryModeEnabled ?? this.discoveryModeEnabled,
      passedMovieIds: passedMovieIds ?? this.passedMovieIds,
      recentLikes: recentLikes ?? this.recentLikes,
      passedTimestamps: passedTimestamps ?? this.passedTimestamps,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'uid': uid,
      'name': name,
      'friendIds': friendIds, // ✅ Added friendIds to JSON
      'preferredGenres': preferredGenres.toList(),
      'preferredVibes': preferredVibes.toList(),
      'blockedGenres': blockedGenres.toList(),
      'blockedAttributes': blockedAttributes.toList(),
      'likedMovieIds': likedMovieIds.toList(),
      'favouriteMovieIds': favouriteMovieIds.toList(),
      'matchedMovieIds': matchedMovieIds.toList(),
      'genreScores': genreScores,
      'vibeScores': vibeScores,
      'matchHistory': matchHistory,
      'hasCompletedOnboarding': hasCompletedOnboarding,
      'hasSeenMatcher': hasSeenMatcher,
      // Enhanced fields in JSON
      'dislikeScores': dislikeScores,
      'dislikeVibeScores': dislikeVibeScores,
      'subGenreScores': subGenreScores,
      'actorScores': actorScores,
      'dislikeActorScores': dislikeActorScores,
      'keywordScores': keywordScores,
      'runtimePreferences': runtimePreferences,
      'ratingPreferences': ratingPreferences,
      'languagePreferences': languagePreferences,
      'lastActivityDate': lastActivityDate.toIso8601String(),
      'discoveryModeEnabled': discoveryModeEnabled,
      'passedMovieIds': passedMovieIds.toList(),
      'recentLikes': recentLikes.map((like) => like.toJson()).toList(),
      'passedTimestamps': passedTimestamps.map((k, v) => MapEntry(k, v.toIso8601String())),
      
    };
  }

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      uid: json['uid'] ?? '',
      name: json['name'] ?? '',
      friendIds: List<String>.from(json['friendIds'] ?? []), // ✅ Added friendIds from JSON
      preferredGenres: Set<String>.from(json['preferredGenres'] ?? []),
      preferredVibes: Set<String>.from(json['preferredVibes'] ?? []),
      blockedGenres: Set<String>.from(json['blockedGenres'] ?? []),
      blockedAttributes: Set<String>.from(json['blockedAttributes'] ?? []),
      likedMovieIds: Set<String>.from(json['likedMovieIds'] ?? []),
      favouriteMovieIds: Set<String>.from(json['favouriteMovieIds'] ?? []),
      matchedMovieIds: Set<String>.from(json['matchedMovieIds'] ?? []),
      matchedMovies: {},
      likedMovies: {},
      genreScores: Map<String, double>.from(json['genreScores'] ?? {}),
      vibeScores: Map<String, double>.from(json['vibeScores'] ?? {}),
      matchHistory: (json['matchHistory'] as List<dynamic>? ?? [])
          .map((entry) => Map<String, dynamic>.from(entry))
          .toList(),
      hasCompletedOnboarding: json['hasCompletedOnboarding'] ?? false,
      hasSeenMatcher: json['hasSeenMatcher'] ?? false,
      // Enhanced fields from JSON
      dislikeScores: Map<String, double>.from(json['dislikeScores'] ?? {}),
      dislikeVibeScores: Map<String, double>.from(json['dislikeVibeScores'] ?? {}),
      subGenreScores: Map<String, double>.from(json['subGenreScores'] ?? {}),
      actorScores: Map<String, double>.from(json['actorScores'] ?? {}),
      dislikeActorScores: Map<String, double>.from(json['dislikeActorScores'] ?? {}),
      keywordScores: Map<String, double>.from(json['keywordScores'] ?? {}),
      runtimePreferences: Map<String, double>.from(json['runtimePreferences'] ?? {}),
      ratingPreferences: Map<String, double>.from(json['ratingPreferences'] ?? {}),
      languagePreferences: Map<String, double>.from(json['languagePreferences'] ?? {}),
      lastActivityDate: json['lastActivityDate'] != null 
          ? DateTime.parse(json['lastActivityDate'])
          : DateTime.now(),
      discoveryModeEnabled: json['discoveryModeEnabled'] ?? false,
      passedMovieIds: Set<String>.from(json['passedMovieIds'] ?? []),
      recentLikes: (json['recentLikes'] as List<dynamic>?)
        ?.map((item) => MovieLike.fromJson(item as Map<String, dynamic>))
        .toList() ?? [],
          passedTimestamps: (json['passedTimestamps'] as Map<String, dynamic>?)
        ?.map((k, v) => MapEntry(k, DateTime.parse(v))) ?? {},
    );
  }

  // Helper methods for taste evolution and analytics
  
  /// Check if user is exploring new genres recently
  bool get isExploringNewGenres {
    final recentLikes = likedMovies.where((movie) => 
      DateTime.now().difference(lastActivityDate).inDays < 30
    );
    
    final newGenresExplored = recentLikes
        .expand((movie) => movie.genres)
        .where((genre) => !preferredGenres.contains(genre))
        .toSet();
    
    return newGenresExplored.length >= 2;
  }
  
  /// Get genres the user might want to explore
  List<String> get genresToExplore {
    const allGenres = ['Action', 'Comedy', 'Drama', 'Horror', 'Romance', 'Sci-Fi', 'Fantasy', 'Thriller', 'Mystery', 'Animation'];
    
    return allGenres.where((genre) => 
      !preferredGenres.contains(genre) && 
      (dislikeScores[genre] ?? 0) < 3 // Haven't strongly disliked
    ).toList();
  }
  
  /// Calculate overall preference strength for a genre (likes - dislikes)
  double getGenrePreference(String genre) {
    final likes = genreScores[genre] ?? 0;
    final dislikes = dislikeScores[genre] ?? 0;
    return likes - (dislikes * 0.5); // Dislikes weigh less than likes
  }
  
  /// Get user's top actors by preference
  List<String> get topActors {
    final actorEntries = actorScores.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return actorEntries.take(10).map((e) => e.key).toList();
  }
  
  /// Get user's taste diversity score (how varied their preferences are)
  double get tasteDiversityScore {
    final totalGenres = genreScores.keys.length;
    final strongPreferences = genreScores.values.where((score) => score > 5.0).length;
    
    if (totalGenres == 0) return 0.0;
    return (totalGenres - strongPreferences) / totalGenres;
  }
  
  /// Check if user prefers a specific runtime category
  String get preferredRuntimeCategory {
    if (runtimePreferences.isEmpty) return 'medium';
    
    final sorted = runtimePreferences.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    return sorted.first.key;
  }

  // ✅ Added helper methods for friendship functionality
  
  /// Check if user is friends with another user
  bool isFriendsWith(String userId) {
    return friendIds.contains(userId);
  }
  
  /// Get number of friends
  int get friendCount => friendIds.length;
  
  /// Check if user has any friends
  bool get hasFriends => friendIds.isNotEmpty;
}