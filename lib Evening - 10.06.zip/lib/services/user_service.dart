import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_profile.dart';

class UserService {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;

  Future<UserProfile> loadOrCreateUserProfile() async {
    final uid = _auth.currentUser!.uid;
    final docRef = _firestore.collection('users').doc(uid);
    final snapshot = await docRef.get();

    if (snapshot.exists) {
      return UserProfile.fromJson(snapshot.data()!);
    } else {
      // Create new empty profile
      final newProfile = UserProfile.empty();
      newProfile.name = 'New User'; // Or prompt user later

      await docRef.set(newProfile.toJson());
      return newProfile;
    }
  }
}
