import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'dart:math' as math;
import '../models/user_profile.dart';
import '../movie.dart';
import '../utils/user_profile_storage.dart';
import '../services/firestore_service.dart';
import '../utils/tmdb_api.dart';
import '../screens/movie_detail_screen.dart';
import 'dart:ui';
import '../widgets/streaming_options_widget.dart';

// Helper classes for streaming providers
class StreamingProvider {
  final String providerName;
  final String logoUrl;
  
  StreamingProvider({required this.providerName, required this.logoUrl});
}

class CleanProviders {
  final List<StreamingProvider> subscription;
  final List<StreamingProvider> rental;
  
  CleanProviders({required this.subscription, required this.rental});
  
  int get totalCount => subscription.length + rental.length;
}

class MatchedScreen extends StatefulWidget {
  final Movie movie;
  final UserProfile currentUser;
  final String? matchedName;
  final List<String>? allMatchedUsers;

  const MatchedScreen({
    Key? key,
    required this.movie,
    required this.currentUser,
    this.matchedName,
    this.allMatchedUsers,
  }) : super(key: key);

  @override
  State<MatchedScreen> createState() => _MatchedScreenState();
}

class _MatchedScreenState extends State<MatchedScreen> with TickerProviderStateMixin {
  bool _isMatchSaved = false;
  bool _isLoadingDetails = true;
  bool _isLoadingStreaming = true;
  bool _isExtractingColors = true;
  Movie? _enrichedMovie;
  WatchProviders? _streamingOptions;
  
  // Dynamic colors extracted from poster using Flutter's built-in method
  Color _dominantColor = const Color(0xFF6C5CE7);
  Color _vibrantColor = const Color(0xFFFFD700);
  Color _mutedColor = const Color(0xFF455A64);

  // Animation controllers
  late final AnimationController _mainController = AnimationController(
    duration: const Duration(milliseconds: 1800),
    vsync: this,
  );
  
  late final AnimationController _pulseController = AnimationController(
    duration: const Duration(milliseconds: 1400),
    vsync: this,
  );
  
  late final AnimationController _confettiController = AnimationController(
    duration: const Duration(milliseconds: 4500),
    vsync: this,
  );
  
  late final AnimationController _shimmerController = AnimationController(
    duration: const Duration(milliseconds: 1800),
    vsync: this,
  );
  
  // Refined animations
  late final Animation<double> _scaleAnimation = Tween<double>(begin: 0.2, end: 1.0).animate(
    CurvedAnimation(parent: _mainController, curve: const Interval(0.0, 0.8, curve: Curves.elasticOut))
  );
  
  late final Animation<double> _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
    CurvedAnimation(parent: _mainController, curve: const Interval(0.3, 1.0, curve: Curves.easeOutCubic))
  );
  
  late final Animation<double> _slideAnimation = Tween<double>(begin: 100.0, end: 0.0).animate(
    CurvedAnimation(parent: _mainController, curve: const Interval(0.5, 1.0, curve: Curves.easeOutBack))
  );
  
  late final Animation<double> _pulseAnimation = Tween<double>(begin: 1.0, end: 1.12).animate(
    CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut)
  );

  final List<ConfettiParticle> _particles = [];
  final int _particleCount = 60;

  @override
  void initState() {
    super.initState();
    _initializeScreen();
  }

  Future<void> _initializeScreen() async {
    // Start color extraction first
    await _extractColorsFromPoster();
    
    // Generate particles with extracted colors
    _generateParticles();
    
    // Start animations
    _initializeAnimations();
    
    // Load other data
    _saveMatchAutomatically();
    _enrichMovieData();
  }

  Future<void> _extractColorsFromPoster() async {
    try {
      print("🎨 Extracting colors from: ${widget.movie.posterUrl}");
      
      // Use Flutter's built-in ColorScheme.fromImageProvider
      final colorScheme = await ColorScheme.fromImageProvider(
        provider: NetworkImage(widget.movie.posterUrl),
        brightness: Brightness.dark,
      );
      
      if (mounted) {
        setState(() {
          // Post-process extracted colors to make them more movie-appropriate
          _dominantColor = _enhanceColorForTheme(colorScheme.primary);
          _vibrantColor = _enhanceColorForTheme(colorScheme.secondary);
          _mutedColor = _enhanceColorForTheme(colorScheme.tertiary);
          
          _isExtractingColors = false;
        });
        
        print("🎨 Successfully extracted and enhanced colors:");
        print("   Primary (Dominant): $_dominantColor");
        print("   Secondary (Vibrant): $_vibrantColor");
        print("   Tertiary (Muted): $_mutedColor");
      }
    } catch (e) {
      print("❌ Color extraction failed: $e");
      // Fallback to genre-based colors
      _generateFallbackColors();
    }
  }

  Color _enhanceColorForTheme(Color extractedColor) {
    final genres = widget.movie.genres;
    final title = widget.movie.title.toLowerCase();
    
    // Enhanced movie-specific theming
    if (title.contains('matrix')) {
      // Matrix movies: Green digital theme
      return const Color(0xFF00FF00); // Bright matrix green
    } else if (genres.contains('Horror') || genres.contains('Thriller')) {
      // Horror: Dark, blood-red tones
      return Color.fromARGB(
        255,
        math.min(255, ((extractedColor.r * 255.0).round() * 1.3).round()),
        ((extractedColor.g * 255.0).round() * 0.3).round().clamp(0, 80),
        ((extractedColor.b * 255.0).round() * 0.4).round().clamp(0, 100),
      );
    } else if (genres.contains('Sci-Fi')) {
      // Sci-Fi: Cool blues and cyans
      return Color.fromARGB(
        255,
        ((extractedColor.r * 255.0).round() * 0.5).round().clamp(20, 150),
        ((extractedColor.g * 255.0).round() * 0.9).round().clamp(80, 200),
        math.min(255, ((extractedColor.b * 255.0).round() * 1.4).round()),
      );
    } else if (genres.contains('Action')) {
      // Action: Orange/red intensity
      return Color.fromARGB(
        255,
        math.min(255, ((extractedColor.r * 255.0).round() * 1.2).round()),
        ((extractedColor.g * 255.0).round() * 0.7).round().clamp(30, 180),
        ((extractedColor.b * 255.0).round() * 0.6).round().clamp(20, 150),
      );
    } else if (genres.contains('Romance')) {
      // Romance: Warm pinks and golds
      return Color.fromARGB(
        255,
        math.min(255, ((extractedColor.r * 255.0).round() * 1.1).round()),
        ((extractedColor.g * 255.0).round() * 0.8).round().clamp(40, 200),
        ((extractedColor.b * 255.0).round() * 0.9).round().clamp(60, 220),
      );
    }
    
    // Default: Just ensure good contrast
    return Color.fromARGB(
      255,
      (extractedColor.r * 255.0).round().clamp(40, 220),
      (extractedColor.g * 255.0).round().clamp(40, 220),
      (extractedColor.b * 255.0).round().clamp(40, 220),
    );
  }

  void _generateFallbackColors() {
    final genres = widget.movie.genres;
    final title = widget.movie.title.toLowerCase();
    
    if (title.contains('matrix')) {
      // Matrix trilogy: Classic green-on-black digital theme
      _dominantColor = const Color(0xFF001100); // Very dark green
      _vibrantColor = const Color(0xFF00FF41); // Bright matrix green
      _mutedColor = const Color(0xFF003300); // Dark green
    } else if (genres.contains('Horror') || genres.contains('Thriller')) {
      // Horror/Thriller: Dark, ominous reds
      _dominantColor = const Color(0xFF2C0000); // Very dark red
      _vibrantColor = const Color(0xFFFF3030); // Bright red
      _mutedColor = const Color(0xFF1A0000); // Black-red
    } else if (genres.contains('Sci-Fi')) {
      // Sci-Fi: Cool futuristic blues
      _dominantColor = const Color(0xFF001122); // Dark blue
      _vibrantColor = const Color(0xFF00AAFF); // Bright blue
      _mutedColor = const Color(0xFF000B1A); // Very dark blue
    } else if (genres.contains('Action')) {
      // Action: Fiery oranges
      _dominantColor = const Color(0xFF331100); // Dark orange
      _vibrantColor = const Color(0xFFFF6600); // Bright orange
      _mutedColor = const Color(0xFF1A0800); // Dark brown
    } else if (genres.contains('Romance')) {
      _dominantColor = const Color(0xFF330022);
      _vibrantColor = const Color(0xFFFF69B4);
      _mutedColor = const Color(0xFF1A0011);
    } else if (genres.contains('Comedy')) {
      _dominantColor = const Color(0xFF223300);
      _vibrantColor = const Color(0xFFFFDD00);
      _mutedColor = const Color(0xFF111A00);
    } else {
      // Default fallback
      _dominantColor = const Color(0xFF2D2B47);
      _vibrantColor = const Color(0xFF6C5CE7);
      _mutedColor = const Color(0xFF1A1A2E);
    }
    
    setState(() {
      _isExtractingColors = false;
    });
  }

  void _initializeAnimations() {
    _mainController.forward();
    _pulseController.repeat(reverse: true);
    _shimmerController.repeat();
    
    Future.delayed(const Duration(milliseconds: 1000), () {
      if (mounted) _confettiController.forward();
    });
  }

  Future<void> _enrichMovieData() async {
    try {
      final results = await Future.wait([
        TMDBApi.fetchFullMovieById(widget.movie.id),
        TMDBApi.getWatchProviders(widget.movie.id),
      ]);
      
      if (mounted) {
        setState(() {
          _enrichedMovie = results[0] as Movie?;
          _streamingOptions = results[1] as WatchProviders?;
          _isLoadingDetails = false;
          _isLoadingStreaming = false;
        });
      }
    } catch (e) {
      print("Failed to enrich movie data: $e");
      if (mounted) {
        setState(() {
          _enrichedMovie = widget.movie;
          _isLoadingDetails = false;
          _isLoadingStreaming = false;
        });
      }
    }
  }

  Future<void> _saveMatchAutomatically() async {
    try {
      final matchEntry = {
        'username': widget.matchedName ?? 'Matched user',
        'movieTitle': widget.movie.title,
        'movieId': widget.movie.id,
        'matchDate': DateTime.now(),
        'posterUrl': widget.movie.posterUrl,
        'watched': false,
        'archived': false,
        'watchedDate': null,
        'archivedDate': null,
        'groupName': widget.allMatchedUsers?.length != null && widget.allMatchedUsers!.length > 1 
            ? "Group Match" : null,
        'movie': widget.movie.toJson(),
      };

      widget.currentUser.matchHistory.add(matchEntry);
      await UserProfileStorage.saveProfile(widget.currentUser);
      
      try {
        await FirestoreService().saveMatchToFirestore(widget.currentUser.uid, widget.movie);
      } catch (firestoreError) {
        print("⚠️ Firestore save failed: $firestoreError");
      }
      
      if (mounted) {
        setState(() => _isMatchSaved = true);
      }
      
    } catch (e) {
      print("❌ Error saving match: $e");
    }
  }

  void _generateParticles() {
    final random = math.Random();
    final title = widget.movie.title.toLowerCase();
    
    // Movie-specific confetti/particles
    List<Color> confettiColors;
    
    if (title.contains('matrix')) {
      // Matrix: Digital rain effect
      confettiColors = [
        const Color(0xFF00FF41), // Bright green
        const Color(0xFF00DD30), // Medium green
        const Color(0xFF00BB20), // Darker green
        Colors.white.withValues(alpha: 0.8),
      ];
    } else {
      // Use extracted colors for confetti with additional accent colors
      confettiColors = [
        _dominantColor,
        _dominantColor.withValues(alpha: 0.8),
        _vibrantColor,
        _vibrantColor.withValues(alpha: 0.7),
        _mutedColor.withValues(alpha: 0.9),
        // Add some universal celebration colors
        const Color(0xFFFFD700), // Gold
        const Color(0xFFFF6B6B), // Coral
        Colors.white.withValues(alpha: 0.8),
        Colors.white.withValues(alpha: 0.6),
      ];
    }

    for (int i = 0; i < _particleCount; i++) {
      final color = confettiColors[random.nextInt(confettiColors.length)];
      final size = random.nextDouble() * 10.r + 4.r;
      final startX = random.nextDouble() * 400.w - 200.w;
      final startY = random.nextDouble() * -120.h - 60.h;
      final velocity = Offset(
        (random.nextDouble() - 0.5) * 140.w,
        random.nextDouble() * 280.h + 120.h,
      );
      final rotationSpeed = (random.nextDouble() - 0.5) * 5.0;
      
      _particles.add(ConfettiParticle(
        color: color,
        size: size,
        position: Offset(startX, startY),
        velocity: velocity,
        rotationSpeed: rotationSpeed,
        isMatrixStyle: title.contains('matrix'),
      ));
    }
  }

  @override
  void dispose() {
    _mainController.dispose();
    _pulseController.dispose();
    _confettiController.dispose();
    _shimmerController.dispose();
    super.dispose();
  }

  Movie get displayMovie => _enrichedMovie ?? widget.movie;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              _dominantColor.withValues(alpha: 0.8), // Slightly more transparent
              _dominantColor.withValues(alpha: 0.6),
              _mutedColor.withValues(alpha: 0.8),
              Colors.black.withValues(alpha: 0.9), // Slightly less black
            ],
          ),
        ),
        child: Stack(
          children: [
            // Less darkened poster background for better visibility
            Positioned.fill(
              child: Image.network(
                widget.movie.posterUrl,
                fit: BoxFit.cover,
                color: Colors.black.withValues(alpha: 0.2), // Reduced from 0.35 to 0.2
                colorBlendMode: BlendMode.darken,
                errorBuilder: (context, error, stackTrace) => Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_dominantColor, _mutedColor, Colors.black87],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
            ),
            
            // Blur effect - reduced intensity for better poster visibility
            Positioned.fill(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8), // Reduced from 18 to 8
                child: Container(
                  color: Colors.black.withValues(alpha: 0.15), // Reduced from 0.25 to 0.15
                ),
              ),
            ),

            // Enhanced color overlay for better blending with extracted colors
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      _dominantColor.withValues(alpha: 0.2), // Reduced opacity
                      _mutedColor.withValues(alpha: 0.3),
                      Colors.black.withValues(alpha: 0.5),
                    ],
                  ),
                ),
              ),
            ),

            // Confetti animation
            AnimatedBuilder(
              animation: _confettiController,
              builder: (context, child) {
                for (var particle in _particles) {
                  particle.update(_confettiController.value);
                }
                return CustomPaint(
                  size: Size.infinite,
                  painter: EnhancedConfettiPainter(particles: _particles),
                );
              },
            ),
            
            // Main content
            SafeArea(
              child: AnimatedBuilder(
                animation: _mainController,
                builder: (context, child) {
                  return Opacity(
                    opacity: _fadeAnimation.value,
                    child: Transform.scale(
                      scale: _scaleAnimation.value,
                      child: Column(
                        children: [
                          SizedBox(height: 16.h),
                          
                          // Match celebration header
                          _buildMatchHeader(),
                          
                          SizedBox(height: 20.h),
                          
                          // User avatars section
                          _buildUserAvatars(),
                          
                          SizedBox(height: 20.h),
                          
                          // Movie preview card
                          Expanded(
                            child: Transform.translate(
                              offset: Offset(0, _slideAnimation.value),
                              child: _buildMoviePreviewCard(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            // Color extraction loading overlay
            if (_isExtractingColors)
              Positioned.fill(
                child: Container(
                  color: Colors.black.withValues(alpha: 0.7),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 40.w,
                          height: 40.h,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 3.w,
                          ),
                        ),
                        SizedBox(height: 16.h),
                        Text(
                          "Analyzing movie poster colors...",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14.sp,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildMatchHeader() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Transform.scale(
          scale: _pulseAnimation.value,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _vibrantColor,
                  _vibrantColor.withValues(alpha: 0.85),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(50.r),
              boxShadow: [
                BoxShadow(
                  color: _vibrantColor.withValues(alpha: 0.5),
                  blurRadius: 25.r,
                  spreadRadius: 4.r,
                ),
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 10.r,
                  spreadRadius: 1.r,
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.favorite, color: Colors.red[700], size: 20.sp),
                SizedBox(width: 8.w),
                Text(
                  "IT'S A MATCH!",
                  style: TextStyle(
                    color: _getContrastColor(_vibrantColor),
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  ),
                ),
                SizedBox(width: 8.w),
                Icon(Icons.favorite, color: Colors.red[700], size: 20.sp),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildUserAvatars() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 24.w),
      child: Row(
        children: [
          // Left user avatar - fixed width
          Expanded(
            flex: 2,
            child: _buildUserAvatar(
              name: "You", 
              initial: widget.currentUser.name.isNotEmpty ? widget.currentUser.name[0] : "U",
              color: _dominantColor,
            ),
          ),
          
          // Enhanced connection line with heart - flexible
          Expanded(
            flex: 3,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  height: 4.h,
                  margin: EdgeInsets.symmetric(horizontal: 16.w),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_dominantColor, _vibrantColor],
                    ),
                    borderRadius: BorderRadius.circular(2.r),
                    boxShadow: [
                      BoxShadow(
                        color: _vibrantColor.withValues(alpha: 0.4),
                        blurRadius: 8.r,
                        spreadRadius: 1.r,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(8.r),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Colors.red, Color(0xFFE91E63)],
                    ),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.red.withValues(alpha: 0.5),
                        blurRadius: 12.r,
                        spreadRadius: 2.r,
                      ),
                    ],
                  ),
                  child: Icon(
                    Icons.favorite,
                    color: Colors.white,
                    size: 16.sp,
                  ),
                ),
              ],
            ),
          ),
          
          // Right user avatar - fixed width
          Expanded(
            flex: 2,
            child: _buildUserAvatar(
              name: widget.allMatchedUsers?.length != null && widget.allMatchedUsers!.length > 1 
                  ? "Group" 
                  : (widget.matchedName ?? "Friend"), 
              initial: widget.allMatchedUsers?.length != null && widget.allMatchedUsers!.length > 1 
                  ? "G" 
                  : (widget.matchedName?.isNotEmpty == true ? widget.matchedName![0] : "F"),
              color: _vibrantColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserAvatar({
    required String name,
    required String initial,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          width: 56.w,
          height: 56.h,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [color, color.withValues(alpha: 0.8)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: color.withValues(alpha: 0.5),
                blurRadius: 15.r,
                spreadRadius: 2.r,
              ),
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.3),
                blurRadius: 8.r,
                spreadRadius: 1.r,
              ),
            ],
          ),
          child: Center(
            child: Text(
              initial.toUpperCase(),
              style: TextStyle(
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
                color: _getContrastColor(color),
              ),
            ),
          ),
        ),
        SizedBox(height: 8.h),
        SizedBox(
          width: 100.w,
          child: Text(
            name,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              shadows: [
                Shadow(
                  color: Colors.black.withValues(alpha: 0.5),
                  blurRadius: 4.r,
                ),
              ],
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildMoviePreviewCard() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 2.h),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _mutedColor.withValues(alpha: 0.95),
            _mutedColor.withValues(alpha: 0.8),
            Colors.black87,
          ],
        ),
        borderRadius: BorderRadius.circular(28.r),
        border: Border.all(
          color: _vibrantColor.withValues(alpha: 0.4),
          width: 2.w,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.6),
            blurRadius: 25.r,
            spreadRadius: 5.r,
            offset: Offset(0, 10.h),
          ),
          BoxShadow(
            color: _dominantColor.withValues(alpha: 0.3),
            blurRadius: 20.r,
            spreadRadius: 2.r,
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(18.r),
        child: Column(
          children: [
            // Movie preview section - better proportions
            Flexible(
              flex: 3,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Movie poster - optimized size
                  SizedBox(
                    width: 85.w,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16.r),
                        boxShadow: [
                          BoxShadow(
                            color: _vibrantColor.withValues(alpha: 0.4),
                            blurRadius: 12.r,
                            spreadRadius: 2.r,
                          ),
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.5),
                            blurRadius: 8.r,
                            spreadRadius: 1.r,
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16.r),
                        child: AspectRatio(
                          aspectRatio: 2 / 3,
                          child: Image.network(
                            displayMovie.posterUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) => Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [_mutedColor, _dominantColor.withValues(alpha: 0.7)],
                                ),
                              ),
                              child: Icon(Icons.movie, size: 35.sp, color: Colors.white54),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  
                  SizedBox(width: 14.w),
                  
                  // Movie info - flexible content
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Title with dynamic color shadow
                        Text(
                          displayMovie.title,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18.sp,
                            fontWeight: FontWeight.bold,
                            height: 1.2,
                            shadows: [
                              Shadow(
                                color: _dominantColor.withValues(alpha: 0.5),
                                blurRadius: 6.r,
                              ),
                            ],
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        
                        SizedBox(height: 10.h),
                        
                        // Quick details with themed colors
                        if (!_isLoadingDetails) ...[
                          if (displayMovie.rating != null)
                            _buildQuickDetail(
                              icon: Icons.star,
                              text: '${displayMovie.rating!.toStringAsFixed(1)}/10',
                              color: _vibrantColor,
                            ),
                          
                          if (displayMovie.runtime != null)
                            _buildQuickDetail(
                              icon: Icons.schedule,
                              text: _formatRuntime(displayMovie.runtime!),
                              color: _dominantColor,
                            ),
                          
                          if (displayMovie.releaseDate != null)
                            _buildQuickDetail(
                              icon: Icons.calendar_today,
                              text: _getYearFromDate(displayMovie.releaseDate!),
                              color: _vibrantColor.withValues(alpha: 0.8),
                            ),
                        ] else ...[
                          _buildShimmerLoader(),
                        ],
                        
                        SizedBox(height: 10.h),
                        
                        // Genre badges with better overflow handling
                        if (displayMovie.genres.isNotEmpty)
                          ConstrainedBox(
                            constraints: BoxConstraints(maxHeight: 50.h),
                            child: Wrap(
                              spacing: 6.w,
                              runSpacing: 4.h,
                              children: displayMovie.genres.take(4).map((genre) =>
                                Container(
                                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 3.h),
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [_vibrantColor, _vibrantColor.withValues(alpha: 0.8)],
                                    ),
                                    borderRadius: BorderRadius.circular(10.r),
                                    boxShadow: [
                                      BoxShadow(
                                        color: _vibrantColor.withValues(alpha: 0.3),
                                        blurRadius: 4.r,
                                        spreadRadius: 1.r,
                                      ),
                                    ],
                                  ),
                                  child: Text(
                                    genre,
                                    style: TextStyle(
                                      color: _getContrastColor(_vibrantColor),
                                      fontSize: 9.sp,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                )
                              ).toList(),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            
            SizedBox(height: 16.h), // Reduced spacing since streaming section is more compact
            
            // ✨ UPDATED: More integrated streaming section
            _buildStreamingSection(),
            
            SizedBox(height: 18.h), // Slightly more space before action buttons
            
            // ✨ UPDATED: Clean action buttons (no more "Let's Watch!")
            _buildActionSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickDetail({
    required IconData icon,
    required String text,
    required Color color,
  }) {
    return Padding(
      padding: EdgeInsets.only(bottom: 4.h),
      child: Row(
        children: [
          Icon(icon, color: color, size: 14.sp),
          SizedBox(width: 5.w),
          Text(
            text,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.95),
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShimmerLoader() {
    return AnimatedBuilder(
      animation: _shimmerController,
      builder: (context, child) {
        return Column(
          children: List.generate(3, (index) {
            return Padding(
              padding: EdgeInsets.only(bottom: 8.h),
              child: Container(
                width: (120 - index * 20).w,
                height: 16.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.r),
                  gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: [
                      _mutedColor.withValues(alpha: 0.5),
                      _dominantColor.withValues(alpha: 0.3),
                      _mutedColor.withValues(alpha: 0.5),
                    ],
                    stops: [
                      (_shimmerController.value - 0.5).clamp(0.0, 1.0),
                      _shimmerController.value.clamp(0.0, 1.0),
                      (_shimmerController.value + 0.5).clamp(0.0, 1.0),
                    ],
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }

  // ✨ FIXED: More compact and properly integrated streaming section
  Widget _buildStreamingSection() {
    // Simply return the StreamingOptionsWidget directly - it handles everything!
    return StreamingOptionsWidget(
      movie: displayMovie,
      isLoading: _isLoadingStreaming,
      streamingOptions: _streamingOptions,
      dominantColor: _dominantColor,
      vibrantColor: _vibrantColor,
      mutedColor: _mutedColor,
      getContrastColor: _getContrastColor,
    );
  }
  // ✨ UPDATED: Cleaner, more streamlined action section
  Widget _buildActionSection() {
    return Column(
      children: [
        // Single "Details" button - understated since streaming is the main action
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () {
              showMovieDetails(
                context: context,
                movie: displayMovie,
                currentUser: widget.currentUser,
                isInFavorites: _isMatchSaved,
              );
            },
            icon: Icon(Icons.info_outline, size: 16.sp),
            label: Text(
              "Movie Details",
              style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w500),
            ),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white.withValues(alpha: 0.8),
              side: BorderSide(color: Colors.white.withValues(alpha: 0.3), width: 1.w),
              padding: EdgeInsets.symmetric(vertical: 14.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              backgroundColor: Colors.white.withValues(alpha: 0.05),
            ),
          ),
        ),
        
        SizedBox(height: 16.h),
        
        // Continue button - subtle
        SizedBox(
          width: double.infinity,
          child: TextButton.icon(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.refresh, size: 14.sp),
            label: Text(
              "Find More Matches",
              style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.w400),
            ),
            style: TextButton.styleFrom(
              foregroundColor: Colors.white.withValues(alpha: 0.6),
              padding: EdgeInsets.symmetric(vertical: 12.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.r),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // Helper method to get contrasting text color
  Color _getContrastColor(Color color) {
    return color.computeLuminance() > 0.5 ? Colors.black : Colors.white;
  }

  String _formatRuntime(int minutes) {
    final hours = minutes ~/ 60;
    final mins = minutes % 60;
    return hours > 0 ? '${hours}h ${mins}m' : '${mins}m';
  }

  String _getYearFromDate(String dateString) {
    try {
      final date = DateTime.parse(dateString);
      return date.year.toString();
    } catch (e) {
      return dateString;
    }
  }
}

// Enhanced confetti particle system with movie-specific effects
class ConfettiParticle {
  Color color;
  double size;
  Offset position;
  Offset velocity;
  double rotationSpeed;
  double rotation = 0;
  double life = 1.0;
  double opacity = 1.0;
  bool isMatrixStyle;
  
  ConfettiParticle({
    required this.color,
    required this.size,
    required this.position,
    required this.velocity,
    required this.rotationSpeed,
    this.isMatrixStyle = false,
  });
  
  void update(double dt) {
    if (isMatrixStyle) {
      // Matrix digital rain - falls straight down
      position = Offset(
        position.dx,
        position.dy + velocity.dy * dt * 1.5, // Faster fall for digital rain
      );
      
      // No horizontal movement or rotation for Matrix style
      life -= dt * 0.15; // Slower fade for trail effect
    } else {
      // Normal confetti physics
      position = Offset(
        position.dx + velocity.dx * dt,
        position.dy + velocity.dy * dt,
      );
      
      velocity = Offset(
        velocity.dx * 0.98, // Air resistance
        velocity.dy + 350 * dt, // Gravity
      );
      
      rotation += rotationSpeed * dt;
      life -= dt * 0.25;
    }
    
    opacity = (life * 1.2).clamp(0.0, 1.0);
    
    // Reset particle when it goes off screen or dies
    if (position.dy > 1200 || life <= 0) {
      final random = math.Random();
      position = Offset(
        random.nextDouble() * 400 - 200,
        random.nextDouble() * -100 - 50,
      );
      velocity = Offset(
        isMatrixStyle ? 0 : (random.nextDouble() - 0.5) * 140,
        random.nextDouble() * 280 + 120,
      );
      life = 1.0;
      opacity = 1.0;
    }
  }
}

class EnhancedConfettiPainter extends CustomPainter {
  final List<ConfettiParticle> particles;
  
  EnhancedConfettiPainter({required this.particles});
  
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    
    for (var particle in particles) {
      final paint = Paint()
        ..color = particle.color.withValues(alpha: particle.opacity)
        ..style = PaintingStyle.fill;
      
      final position = center + particle.position;
      
      if (particle.isMatrixStyle) {
        // Draw Matrix-style digital rain characters
        _drawMatrixCharacter(canvas, position, particle, paint);
      } else {
        // Draw normal confetti shapes
        canvas.save();
        canvas.translate(position.dx, position.dy);
        canvas.rotate(particle.rotation);
        
        // Draw different shapes based on particle hash
        final shapeType = particle.hashCode % 4;
        switch (shapeType) {
          case 0:
            // Rectangle
            canvas.drawRRect(
              RRect.fromRectAndRadius(
                Rect.fromCenter(
                  center: Offset.zero, 
                  width: particle.size, 
                  height: particle.size * 0.6,
                ),
                Radius.circular(particle.size * 0.1),
              ),
              paint,
            );
            break;
          case 1:
            // Circle
            canvas.drawCircle(Offset.zero, particle.size / 2, paint);
            break;
          case 2:
            // Star
            _drawStar(canvas, paint, particle.size);
            break;
          case 3:
            // Diamond
            _drawDiamond(canvas, paint, particle.size);
            break;
        }
        
        canvas.restore();
      }
    }
  }
  
  void _drawMatrixCharacter(Canvas canvas, Offset position, ConfettiParticle particle, Paint paint) {
    // Simple Matrix-style rectangular "characters"
    final rect = Rect.fromCenter(
      center: position,
      width: particle.size * 0.4,
      height: particle.size,
    );
    canvas.drawRect(rect, paint);
    
    // Add a subtle glow effect
    final glowPaint = Paint()
      ..color = particle.color.withValues(alpha: particle.opacity * 0.3)
      ..style = PaintingStyle.fill
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);
    
    final glowRect = Rect.fromCenter(
      center: position,
      width: particle.size * 0.6,
      height: particle.size * 1.2,
    );
    canvas.drawRect(glowRect, glowPaint);
  }
  
  void _drawStar(Canvas canvas, Paint paint, double size) {
    final path = Path();
    final radius = size / 2;
    final innerRadius = radius * 0.4;
    
    for (int i = 0; i < 10; i++) {
      final angle = (i * math.pi) / 5;
      final r = i.isEven ? radius : innerRadius;
      final x = r * math.cos(angle - math.pi / 2);
      final y = r * math.sin(angle - math.pi / 2);
      
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();
    canvas.drawPath(path, paint);
  }
  
  void _drawDiamond(Canvas canvas, Paint paint, double size) {
    final path = Path();
    final half = size / 2;
    
    path.moveTo(0, -half);
    path.lineTo(half, 0);
    path.lineTo(0, half);
    path.lineTo(-half, 0);
    path.close();
    
    canvas.drawPath(path, paint);
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}