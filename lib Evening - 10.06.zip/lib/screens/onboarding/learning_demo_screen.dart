// File: lib/screens/onboarding/learning_demo_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';
import '../../models/user_profile.dart';
import '../../movie.dart';
import '../../data/movie_json_loader.dart';
import '../../utils/enhanced_learning_engine.dart';
import 'friends_matching_tutorial_screen.dart';
import 'dart:async';
import 'dart:math' as math;

class LearningDemoScreen extends StatefulWidget {
  final UserProfile profile;
  final List<Movie> movies;
  final List<String> tutorialLikes;
  final List<String> tutorialPasses;

  const LearningDemoScreen({
    super.key,
    required this.profile,
    required this.movies,
    required this.tutorialLikes,
    required this.tutorialPasses,
  });

  @override
  State<LearningDemoScreen> createState() => _LearningDemoScreenState();
}

class _LearningDemoScreenState extends State<LearningDemoScreen> 
    with TickerProviderStateMixin {
  
  List<Movie> learningMovies = [];
  late UserProfile workingProfile;
  
  // Learning state
  int swipeCount = 0;
  final int minSwipesRequired = 12;
  bool showingLearningInsights = false;
  bool hasShownMidwayInsight = false;
  bool canProceed = false;
  
  // Real-time insights
  Map<String, double> currentGenreScores = {};
  Map<String, double> currentVibeScores = {};
  String dominantGenre = '';
  String dominantVibe = '';
  double diversityScore = 0.0;
  
  // Track actual movie counts per genre
  Map<String, int> genreMovieCounts = {};
  Map<String, int> vibeMovieCounts = {};
  
  // Animation controllers
  late AnimationController _insightController;
  late AnimationController _progressController;
  late AnimationController _learningController;
  late AnimationController _brainController;
  
  // Animations
  late Animation<double> _insightFade;
  late Animation<Offset> _insightSlide;
  late Animation<double> _progressPulse;
  late Animation<double> _learningScale;
  late Animation<double> _brainRotation;
  
  // UI state
  Timer? _insightTimer;
  bool showInsightOverlay = false;
  String currentInsightMessage = '';
  
  // Tracking for dynamic recommendations
  final List<String> recentLikes = [];
  final List<String> recentPasses = [];
  final Map<String, int> genreMomentum = {};
@override
void initState() {
  super.initState();
  _initializeAnimations();
  _initializeData(); // Create a new method to handle all async initialization
}

Future<void> _initializeData() async {
  // Initialize profile first
  workingProfile = widget.profile.copyWith();
  
  // Apply tutorial learning (async)
  await _applyTutorialLearning();
  
  // Setup movies (async) 
  await _setupMovies();
  
  // Initialize tracking
  currentGenreScores = Map.from(workingProfile.genreScores);
  currentVibeScores = Map.from(workingProfile.vibeScores);
  
  // Update insights
  _updateInsights();
  
  // Start the demo
  _startLearningDemo();
  
  // Trigger rebuild now that data is loaded
  if (mounted) {
    setState(() {
      // Data is now loaded
    });
  }
}

// Remove the old _initializeProfile() method since it's now handled in _initializeData()

Future<void> _applyTutorialLearning() async { // Add Future<void> here!
  final allMovies = await MovieJsonLoader.loadOnboardingMovies();
  
  print("🎬 Available movie IDs: ${allMovies.map((m) => m.id).toList()}");
  print("❤️ Tutorial likes: ${widget.tutorialLikes}");
  print("👎 Tutorial passes: ${widget.tutorialPasses}");
  
  // Process tutorial likes
  for (final movieId in widget.tutorialLikes) {
    print("🔍 Looking for liked movie ID: $movieId");
    try {
      final movie = allMovies.firstWhere((m) => m.id == movieId);
      EnhancedLearningEngine.learnFromLikedMovie(workingProfile, movie);
      _updateMovieCounts(movie, true);
      print("✅ Found and processed: ${movie.title}");
    } catch (e) {
      print("❌ Failed to find movie with ID: $movieId - Error: $e");
    }
  }
  
  // Process tutorial passes
  for (final movieId in widget.tutorialPasses) {
    print("🔍 Looking for passed movie ID: $movieId");
    try {
      final movie = allMovies.firstWhere((m) => m.id == movieId);
      EnhancedLearningEngine.learnFromPassedMovie(workingProfile, movie);
      print("✅ Found and processed: ${movie.title}");
    } catch (e) {
      print("❌ Failed to find movie with ID: $movieId - Error: $e");
    }
  }
  
  _updateInsights();
}

Future<void> _setupMovies() async { // Make sure this is also async
  // Start with remaining popular movies
  final allPopular = await MovieJsonLoader.loadOnboardingMovies();
  final usedIds = {...widget.tutorialLikes, ...widget.tutorialPasses};
  
  learningMovies = allPopular.where((m) => !usedIds.contains(m.id)).toList();
  
  // Add some diverse options to demonstrate learning
  learningMovies.shuffle();
}
  
  void _initializeAnimations() {
    _insightController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    _progressController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _learningController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _brainController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    
    _insightFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _insightController, curve: Curves.easeOut),
    );
    
    _insightSlide = Tween<Offset>(
      begin: const Offset(0, -1),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _insightController, curve: Curves.elasticOut));
    
    _progressPulse = Tween<double>(begin: 1.0, end: 1.1).animate(
      CurvedAnimation(parent: _progressController, curve: Curves.easeInOut),
    );
    
    _learningScale = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _learningController, curve: Curves.elasticOut),
    );
    
    _brainRotation = Tween<double>(begin: 0.0, end: 2 * math.pi).animate(
      CurvedAnimation(parent: _brainController, curve: Curves.linear),
    );
  }
  
  void _startLearningDemo() {
    _progressController.repeat(reverse: true);
    _brainController.repeat();
    
    // Show initial insight
    Future.delayed(const Duration(seconds: 2), () {
      _showInsight("I'm learning your taste as you swipe! 🧠");
    });
  }
  
  bool _onSwipe(int previousIndex, int? currentIndex, CardSwiperDirection direction) {
    if (previousIndex >= learningMovies.length) return false;
    
    final movie = learningMovies[previousIndex];
    final isLike = direction == CardSwiperDirection.right;
    
    // Apply learning
    if (isLike) {
      EnhancedLearningEngine.learnFromLikedMovie(workingProfile, movie);
      recentLikes.add(movie.id);
      _trackGenreMomentum(movie.genres, true);
      _updateMovieCounts(movie, true);
    } else {
      EnhancedLearningEngine.learnFromPassedMovie(workingProfile, movie);
      recentPasses.add(movie.id);
      _trackGenreMomentum(movie.genres, false);
    }
    
    setState(() {
      swipeCount++;
    });
    
    _updateInsights();
    _checkLearningMilestones();
    
    return true;
  }
  
  void _trackGenreMomentum(List<String> genres, bool isLike) {
    for (final genre in genres) {
      if (isLike) {
        genreMomentum[genre] = (genreMomentum[genre] ?? 0) + 1;
      } else {
        genreMomentum[genre] = (genreMomentum[genre] ?? 0) - 1;
      }
    }
  }

  void _updateMovieCounts(Movie movie, bool isLike) {
    if (isLike) {
      // Count actual movies liked per genre
      for (final genre in movie.genres) {
        genreMovieCounts[genre] = (genreMovieCounts[genre] ?? 0) + 1;
      }
      
      // Count actual movies liked per vibe/tag
      for (final tag in movie.tags) {
        vibeMovieCounts[tag] = (vibeMovieCounts[tag] ?? 0) + 1;
      }
    }
  }
  
  void _updateInsights() {
    currentGenreScores = Map.from(workingProfile.genreScores);
    currentVibeScores = Map.from(workingProfile.vibeScores);
    
    // Find dominant preferences
    if (currentGenreScores.isNotEmpty) {
      dominantGenre = currentGenreScores.entries
          .reduce((a, b) => a.value > b.value ? a : b).key;
    }
    
    if (currentVibeScores.isNotEmpty) {
      dominantVibe = currentVibeScores.entries
          .reduce((a, b) => a.value > b.value ? a : b).key;
    }
    
    // Calculate meaningful diversity score (0-10 scale)
    final totalMoviesLiked = widget.tutorialLikes.length + recentLikes.length;
    final uniqueGenres = genreMovieCounts.keys.length;
    
    if (totalMoviesLiked > 0) {
      // Score based on variety and engagement
      diversityScore = math.min(10.0, (uniqueGenres * 2.0) + (totalMoviesLiked * 0.5));
    } else {
      diversityScore = 0.0;
    }
  }
  
  void _checkLearningMilestones() {
    // Show insights at specific milestones
    if (swipeCount == 3) {
      _showInsight("I'm starting to see your preferences! 📊");
    } else if (swipeCount == 6 && !hasShownMidwayInsight) {
      hasShownMidwayInsight = true;
      _showDetailedInsight();
    } else if (swipeCount == 9) {
      _showInsight("Your taste profile is getting clearer! 🎯");
    } else if (swipeCount >= minSwipesRequired && !canProceed) {
      setState(() {
        canProceed = true;
      });
      _showCompletionInsight();
    }
    
    // Dynamic feedback based on momentum
    _checkMomentumInsights();
  }
  
  void _checkMomentumInsights() {
    // Check for genre momentum
    final strongGenres = genreMomentum.entries.where((e) => e.value >= 3).toList();
    if (strongGenres.isNotEmpty && swipeCount > 4) {
      final genre = strongGenres.first.key;
      _showInsight("I notice you love $genre movies! 🔥");
    }
    
    // Check for exploration
    if (currentGenreScores.keys.length >= 4 && swipeCount > 6) {
      _showInsight("Great variety! You're exploring different genres 🌟");
    }
  }
  
  void _showInsight(String message) {
    if (showInsightOverlay) return; // Don't overlap insights
    
    setState(() {
      currentInsightMessage = message;
      showInsightOverlay = true;
    });
    
    _insightController.forward();
    
    _insightTimer = Timer(const Duration(seconds: 3), () {
      _hideInsight();
    });
  }
  
  void _showDetailedInsight() {
    String insight = "Interesting! ";
    
    if (dominantGenre.isNotEmpty) {
      insight += "You seem to prefer $dominantGenre movies. ";
    }
    
    if (diversityScore > 6.0) {
      insight += "You're quite adventurous with different genres! 🎭";
    } else {
      insight += "You know what you like! 🎯";
    }
    
    _showInsight(insight);
  }
  
  void _showCompletionInsight() {
    _showInsight("Perfect! I've learned enough to give you great recommendations! ✨");
    
    Future.delayed(const Duration(seconds: 4), () {
      _showLearningResults();
    });
  }
  
  void _hideInsight() {
    _insightController.reverse().then((_) {
      setState(() {
        showInsightOverlay = false;
      });
    });
  }
  
  void _showLearningResults() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (context) => _buildLearningResultsModal(),
    );
  }
  
  Widget _buildLearningResultsModal() {
    // Sort by actual movie counts instead of scores
    final topGenres = genreMovieCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final topVibes = vibeMovieCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    final totalMoviesLiked = widget.tutorialLikes.length + recentLikes.length;
    
    return Container(
      height: MediaQuery.of(context).size.height * 0.8,
      decoration: BoxDecoration(
        color: const Color(0xFF1F1F1F),
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
      ),
      child: Padding(
        padding: EdgeInsets.all(24.w),
        child: Column(
          children: [
            // Header
            Container(
              width: 40.w,
              height: 4.h,
              decoration: BoxDecoration(
                color: Colors.white30,
                borderRadius: BorderRadius.circular(2.r),
              ),
            ),
            
            SizedBox(height: 24.h),
            
            // Title with brain icon
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedBuilder(
                  animation: _brainRotation,
                  builder: (context, child) {
                    return Transform.rotate(
                      angle: _brainRotation.value,
                      child: Container(
                        padding: EdgeInsets.all(12.w),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5A00D).withValues(alpha: .2),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.psychology,
                          color: const Color(0xFFE5A00D),
                          size: 32.sp,
                        ),
                      ),
                    );
                  },
                ),
                SizedBox(width: 16.w),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Learning Complete! 🎉",
                      style: TextStyle(
                        fontSize: 24.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      "Here's what I learned about you:",
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            
            SizedBox(height: 32.h),
            
            // Results content
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Stats overview
                    Container(
                      padding: EdgeInsets.all(16.w),
                      decoration: BoxDecoration(
                        color: const Color(0xFF2A2A2A),
                        borderRadius: BorderRadius.circular(12.r),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _buildStatItem("Movies Swiped", "${swipeCount + widget.tutorialLikes.length + widget.tutorialPasses.length}"),
                          _buildStatItem("Genres Explored", "${genreMovieCounts.keys.length}"),
                        ],
                      ),
                    ),
                    
                    SizedBox(height: 24.h),
                    
                    // Top genres with movie counts
                    Text(
                      "Your Favorite Genres 🎬",
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(height: 12.h),
                    
                    if (topGenres.isNotEmpty) ...[
                      ...topGenres.take(3).map((entry) => _buildGenreCountBar(
                        entry.key,
                        entry.value,
                        totalMoviesLiked,
                        _getGenreColor(entry.key),
                      )).toList(),
                    ] else ...[
                      Container(
                        padding: EdgeInsets.all(16.w),
                        decoration: BoxDecoration(
                          color: const Color(0xFF2A2A2A),
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        child: Text(
                          "Keep liking movies to see your preferences!",
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 14.sp,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                    
                    SizedBox(height: 24.h),
                    
                    // Top vibes with movie counts
                    Text(
                      "Your Movie Vibes ✨",
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(height: 12.h),
                    
                    if (topVibes.isNotEmpty) ...[
                      ...topVibes.take(3).map((entry) => _buildGenreCountBar(
                        entry.key,
                        entry.value,
                        totalMoviesLiked,
                        _getVibeColor(entry.key),
                      )).toList(),
                    ] else ...[
                      Container(
                        padding: EdgeInsets.all(16.w),
                        decoration: BoxDecoration(
                          color: const Color(0xFF2A2A2A),
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        child: Text(
                          "Keep swiping to discover your movie vibes!",
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 14.sp,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                    
                    SizedBox(height: 24.h),
                    
                    // Personality insight
                    Container(
                      padding: EdgeInsets.all(16.w),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            const Color(0xFFE5A00D).withValues(alpha: .2),
                            const Color(0xFFFF8A00).withValues(alpha: .2),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(12.r),
                        border: Border.all(
                          color: const Color(0xFFE5A00D).withValues(alpha: .5),
                          width: 1.w,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Your Movie Personality 🎭",
                            style: TextStyle(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.bold,
                              color: const Color(0xFFE5A00D),
                            ),
                          ),
                          SizedBox(height: 8.h),
                          Text(
                            _getPersonalityDescription(),
                            style: TextStyle(
                              fontSize: 14.sp,
                              color: Colors.white70,
                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            // Continue button
            SizedBox(
              width: double.infinity,
              height: 48.h,
              child: ElevatedButton(
                onPressed: _proceedToNextStep,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE5A00D),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                ),
                child: Text(
                  "Continue to Friend Matching 👥",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildStatItem(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 20.sp,
            fontWeight: FontWeight.bold,
            color: const Color(0xFFE5A00D),
          ),
        ),
        SizedBox(height: 4.h),
        Text(
          label,
          style: TextStyle(
            fontSize: 12.sp,
            color: Colors.white70,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
  
  // NEW: Genre count bar showing actual movie counts
  Widget _buildGenreCountBar(String name, int movieCount, int totalMovies, Color color) {
    final percentage = totalMovies > 0 ? (movieCount / totalMovies) : 0.0;
    
    return Padding(
      padding: EdgeInsets.only(bottom: 12.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                name,
                style: TextStyle(
                  fontSize: 14.sp,
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                "$movieCount movie${movieCount != 1 ? 's' : ''}",
                style: TextStyle(
                  fontSize: 12.sp,
                  color: color,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          SizedBox(height: 6.h),
          Container(
            height: 6.h,
            decoration: BoxDecoration(
              color: Colors.white10,
              borderRadius: BorderRadius.circular(3.r),
            ),
            child: FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: percentage,
              child: Container(
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(3.r),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  String _getPersonalityDescription() {
    if (dominantGenre.isEmpty) {
      return "You're still exploring! Keep swiping to discover your preferences.";
    }
    
    String description = "You're a ";
    
    switch (dominantGenre.toLowerCase()) {
      case 'action':
        description += "Thrill Seeker! You love excitement, adventure, and high-energy entertainment.";
        break;
      case 'comedy':
        description += "Fun Lover! You enjoy laughs, good vibes, and lighthearted entertainment.";
        break;
      case 'drama':
        description += "Story Enthusiast! You appreciate deep narratives, character development, and meaningful plots.";
        break;
      case 'horror':
        description += "Brave Soul! You enjoy thrills, scares, and the adrenaline rush of suspense.";
        break;
      case 'romance':
        description += "Romantic at Heart! You love emotional connections, relationships, and feel-good stories.";
        break;
      case 'sci-fi':
        description += "Future Thinker! You're fascinated by possibilities, technology, and imaginative concepts.";
        break;
      case 'fantasy':
        description += "Dreamer! You love magical worlds, epic adventures, and escaping into incredible stories.";
        break;
      default:
        description += "Unique Viewer! You have diverse tastes that span multiple genres.";
    }
    
    if (diversityScore > 6.0) {
      description += " Plus, you're quite adventurous and open to different types of movies!";
    }
    
    return description;
  }
  
  Color _getGenreColor(String genre) {
    switch (genre.toLowerCase()) {
      case 'action': return Colors.red;
      case 'comedy': return Colors.orange;
      case 'drama': return Colors.blue;
      case 'horror': return Colors.purple;
      case 'romance': return Colors.pink;
      case 'sci-fi': return Colors.cyan;
      case 'fantasy': return Colors.deepPurple;
      case 'thriller': return Colors.indigo;
      default: return const Color(0xFFE5A00D);
    }
  }
  
  Color _getVibeColor(String vibe) {
    switch (vibe.toLowerCase()) {
      case 'feel-good': return Colors.green;
      case 'emotional': return Colors.blue;
      case 'mind-bending': return Colors.purple;
      case 'action-packed': return Colors.red;
      case 'romantic': return Colors.pink;
      default: return const Color(0xFFE5A00D);
    }
  }
  
  void _proceedToNextStep() {
    // Apply learning to actual profile
    widget.profile.genreScores.addAll(currentGenreScores);
    widget.profile.vibeScores.addAll(currentVibeScores);
    
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => FriendsMatchingTutorialScreen(
          profile: widget.profile,
          movies: widget.movies,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _insightController.dispose();
    _progressController.dispose();
    _learningController.dispose();
    _brainController.dispose();
    _insightTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final progress = swipeCount / minSwipesRequired;
    
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                // Header with learning indicators
                Container(
                  padding: EdgeInsets.all(16.w),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          AnimatedBuilder(
                            animation: _brainRotation,
                            builder: (context, child) {
                              return Transform.rotate(
                                angle: _brainRotation.value * 0.1, // Subtle rotation
                                child: Icon(
                                  Icons.psychology,
                                  color: const Color(0xFFE5A00D),
                                  size: 24.sp,
                                ),
                              );
                            },
                          ),
                          SizedBox(width: 12.w),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "AI Learning Mode 🧠",
                                  style: TextStyle(
                                    fontSize: 20.sp,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                                Text(
                                  "I'm learning your taste in real-time!",
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    color: Colors.white70,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      
                      SizedBox(height: 16.h),
                      
                      // Progress bar
                      Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Learning Progress",
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                Text(
                                  "$swipeCount / $minSwipesRequired",
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    color: const Color(0xFFE5A00D),
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 8.h),
                            AnimatedBuilder(
                              animation: _progressPulse,
                              builder: (context, child) {
                                return Transform.scale(
                                  scale: progress >= 1.0 ? _progressPulse.value : 1.0,
                                  child: LinearProgressIndicator(
                                    value: progress.clamp(0.0, 1.0),
                                    backgroundColor: Colors.white24,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      progress >= 1.0 ? Colors.green : const Color(0xFFE5A00D),
                                    ),
                                    minHeight: 6.h,
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Live insights bar
                if (dominantGenre.isNotEmpty)
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 16.w),
                    padding: EdgeInsets.all(12.w),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          _getGenreColor(dominantGenre).withValues(alpha: .2),
                          _getGenreColor(dominantGenre).withValues(alpha: .1),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(8.r),
                      border: Border.all(
                        color: _getGenreColor(dominantGenre).withValues(alpha: .5),
                        width: 1.w,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.trending_up,
                          color: _getGenreColor(dominantGenre),
                          size: 16.sp,
                        ),
                        SizedBox(width: 8.w),
                        Text(
                          "Currently loving: $dominantGenre movies",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                
                SizedBox(height: 16.h),
                
                // Card swiper
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.w),
                    child: learningMovies.isNotEmpty
                        ? CardSwiper(
                            cardsCount: learningMovies.length,
                            numberOfCardsDisplayed: 1,
                            onSwipe: _onSwipe,
                            cardBuilder: (context, index, percentX, percentY) {
                              if (index >= learningMovies.length) return const SizedBox.shrink();
                              
                              final movie = learningMovies[index];
                              return _buildLearningCard(movie, percentX.toDouble(), percentY.toDouble());
                            },
                          )
                        : _buildNoMoreMovies(),
                  ),
                ),
                
                // Bottom instruction
                Container(
                  padding: EdgeInsets.all(16.w),
                  child: Column(
                    children: [
                      if (canProceed)
                        ElevatedButton(
                          onPressed: _showLearningResults,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFE5A00D),
                            minimumSize: Size(double.infinity, 48.h),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.r),
                            ),
                          ),
                          child: Text(
                            "See My Learning Results! 🎉",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16.sp,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        )
                      else
                        Text(
                          "Keep swiping! I'm learning with each choice you make.",
                          style: TextStyle(
                            fontSize: 14.sp,
                            color: Colors.white54,
                          ),
                          textAlign: TextAlign.center,
                        ),
                    ],
                  ),
                ),
              ],
            ),
            
            // Learning insight overlay
            if (showInsightOverlay)
              SlideTransition(
                position: _insightSlide,
                child: FadeTransition(
                  opacity: _insightFade,
                  child: Container(
                    margin: EdgeInsets.only(top: 100.h, left: 16.w, right: 16.w),
                    padding: EdgeInsets.all(16.w),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFE5A00D), Color(0xFFFF8A00)],
                      ),
                      borderRadius: BorderRadius.circular(12.r),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFE5A00D).withValues(alpha: .3),
                          blurRadius: 12.r,
                          offset: Offset(0, 4.h),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        AnimatedBuilder(
                          animation: _learningScale,
                          builder: (context, child) {
                            return Transform.scale(
                              scale: _learningScale.value,
                              child: Icon(
                                Icons.lightbulb,
                                color: Colors.white,
                                size: 24.sp,
                              ),
                            );
                          },
                        ),
                        SizedBox(width: 12.w),
                        Expanded(
                          child: Text(
                            currentInsightMessage,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14.sp,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildLearningCard(Movie movie, double percentX, double percentY) {
    final leftIntensity = percentX < 0 ? (-percentX).clamp(0.0, 1.0) : 0.0;
    final rightIntensity = percentX > 0 ? percentX.clamp(0.0, 1.0) : 0.0;
    
    return Container(
      margin: EdgeInsets.all(8.r),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: const Color(0xFFE5A00D),
          width: 2.w,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFE5A00D).withValues(alpha: .2),
            blurRadius: 8.r,
            offset: Offset(0, 4.h),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14.r),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Background
            Container(color: const Color(0xFF1A1A1A)),
            
            // Movie content
            Column(
              children: [
                // Poster
                Expanded(
                  child: Stack(
                    children: [
                      Image.network(
                        movie.posterUrl,
                        fit: BoxFit.contain,
                        width: double.infinity,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: Colors.grey[800],
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.movie,
                                  size: 64.sp,
                                  color: Colors.white30,
                                ),
                                SizedBox(height: 8.h),
                                Text(
                                  movie.title,
                                  style: TextStyle(
                                    color: Colors.white70,
                                    fontSize: 16.sp,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      
                      // Learning indicators
                      Positioned(
                        top: 12.h,
                        left: 12.w,
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: .7),
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.psychology,
                                color: const Color(0xFFE5A00D),
                                size: 12.sp,
                              ),
                              SizedBox(width: 4.w),
                              Text(
                                "Learning",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Movie info
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(16.w),
                  child: Column(
                    children: [
                      Text(
                        movie.title,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18.sp,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 8.h),
                      
                      // Genre chips with learning colors
                      Wrap(
                        spacing: 6.w,
                        runSpacing: 4.h,
                        children: movie.genres.take(3).map((genre) {
                          final isLearned = currentGenreScores.containsKey(genre);
                          return Container(
                            padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                            decoration: BoxDecoration(
                              color: isLearned 
                                  ? _getGenreColor(genre).withValues(alpha: .3)
                                  : Colors.white10,
                              borderRadius: BorderRadius.circular(12.r),
                              border: isLearned 
                                  ? Border.all(color: _getGenreColor(genre), width: 1.w)
                                  : null,
                            ),
                            child: Text(
                              genre,
                              style: TextStyle(
                                color: isLearned ? _getGenreColor(genre) : Colors.white70,
                                fontSize: 10.sp,
                                fontWeight: isLearned ? FontWeight.bold : FontWeight.normal,
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                      
                      SizedBox(height: 12.h),
                      
                      // Rating if available
                      if (movie.rating != null)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.star,
                              color: Colors.amber,
                              size: 16.sp,
                            ),
                            SizedBox(width: 4.w),
                            Text(
                              "${movie.rating!.toStringAsFixed(1)}/10",
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12.sp,
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              ],
            ),
            
            // Swipe indicators with enhanced feedback
            if (leftIntensity > 0)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [
                        Colors.red.withValues(alpha: .8 * leftIntensity),
                        Colors.red.withValues(alpha: 0),
                      ],
                      stops: const [0.0, 0.4],
                    ),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.close,
                          color: Colors.red,
                          size: 64.sp * leftIntensity,
                        ),
                        SizedBox(height: 8.h),
                        Text(
                          "Learning you don't like this",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12.sp * leftIntensity,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            
            if (rightIntensity > 0)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerRight,
                      end: Alignment.centerLeft,
                      colors: [
                        Colors.green.withValues(alpha: .8 * rightIntensity),
                        Colors.green.withValues(alpha: 0),
                      ],
                      stops: const [0.0, 0.4],
                    ),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.favorite,
                          color: Colors.green,
                          size: 64.sp * rightIntensity,
                        ),
                        SizedBox(height: 8.h),
                        Text(
                          "Learning your preferences",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12.sp * rightIntensity,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildNoMoreMovies() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.psychology,
            size: 64.sp,
            color: const Color(0xFFE5A00D),
          ),
          SizedBox(height: 16.h),
          Text(
            "Learning Complete! 🎉",
            style: TextStyle(
              fontSize: 24.sp,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            "I've analyzed your preferences",
            style: TextStyle(
              fontSize: 16.sp,
              color: Colors.white70,
            ),
          ),
          SizedBox(height: 24.h),
          ElevatedButton(
            onPressed: _showLearningResults,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFE5A00D),
              padding: EdgeInsets.symmetric(horizontal: 32.w, vertical: 12.h),
            ),
            child: Text(
              "See Results",
              style: TextStyle(
                color: Colors.white,
                fontSize: 16.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}