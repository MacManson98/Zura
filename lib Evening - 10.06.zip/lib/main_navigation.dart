import 'package:flutter/material.dart';
import 'screens/matcher_screen.dart';
import 'screens/friends_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/home_screen.dart';
import 'models/user_profile.dart';
import 'movie.dart';
import 'custom_nav_bar.dart';
import 'screens/movies_screen.dart';
import 'services/friendship_service.dart';
import 'services/session_service.dart';
import 'screens/notifications_screen.dart';
import 'models/session_models.dart'; // ✅ ADD THIS IMPORT

class MainNavigation extends StatefulWidget {
  final UserProfile profile;
  final List<Movie> movies;

  const MainNavigation({
    super.key,
    required this.profile,
    required this.movies,
  });

  // ✅ ADD: Static callback that matcher can set
  static void Function(SwipeSession)? _globalSessionCallback;
  
  static void setSessionCallback(void Function(SwipeSession) callback) {
    _globalSessionCallback = callback;
  }
  
  static void clearSessionCallback() {
    _globalSessionCallback = null;
  }

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;
  
  static const int matchesTabIndex = 1;
  static const int matcherTabIndex = 2;

  UserProfile? _selectedFriend;
  MatchingMode _matcherMode = MatchingMode.solo;
  List<UserProfile> _availableFriends = [];
  late Widget _matcherScreen;

  @override
  void initState() {
    super.initState();
    _initializeUserSession();
    _matcherScreen = _buildMatcherScreen();
  }

  // ✅ Enhanced initialization with cleanup
  Future<void> _initializeUserSession() async {
    try {
      // Load friends
      await _loadFriends();
      
      // Clean up user's old data (run in background)
      _performUserCleanup();
    } catch (e) {
      print('Error initializing user session: $e');
    }
  }

  // ✅ User-specific cleanup
  Future<void> _performUserCleanup() async {
    try {
      print("🧹 Cleaning up user data for ${widget.profile.name}...");
      
      // Clean up user's old invitations
      await SessionService.cleanupUserInvitations(widget.profile.uid);
      
      print("✅ User cleanup completed");
    } catch (e) {
      print("Note: User cleanup failed: $e");
      // Don't affect user experience if cleanup fails
    }
  }

  Future<void> _loadFriends() async {
    try {
      final friends = await FriendshipService.getFriends(widget.profile.uid);
      if (mounted) {
        setState(() {
          _availableFriends = friends;
          _matcherScreen = _buildMatcherScreen();
        });
      }
    } catch (e) {
      print('Error loading friends: $e');
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _goToMatchesTab() {
    _onItemTapped(matchesTabIndex);
  }

  void _goToMatcherTab() {
    _onItemTapped(matcherTabIndex);
  }

  void _goToFriendMatcher(UserProfile friend) {
    print("🟢 Switching to Matcher tab with ${friend.name}");
    setState(() {
      _selectedFriend = friend;
      _matcherMode = MatchingMode.friend;
      _matcherScreen = _buildMatcherScreen();
      _selectedIndex = matcherTabIndex;
    });
  }

  Widget _buildMatcherScreen() {
    return MatcherScreen(
      allMovies: widget.movies,
      currentUser: widget.profile,
      availableFriends: _availableFriends,
      selectedFriend: _selectedFriend,
      mode: _matcherMode,
    );
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(
        profile: widget.profile,
        movies: widget.movies,
        onNavigateToMatches: _goToMatchesTab,
        onNavigateToMatcher: _goToMatcherTab,
      ),
      MoviesScreen(
        currentUser: widget.profile,
        onNavigateToMatcher: _setMatcherMode
      ),
      _matcherScreen,
      FriendsScreen(
        currentUser: widget.profile,
        allMovies: widget.movies,
        onShowMatches: _goToMatchesTab,
        onMatchWithFriend: _goToFriendMatcher,
      ),
      ProfileScreen(
        currentUser: widget.profile,
        onNavigateToMatches: _goToMatchesTab,
      ),
    ];

    return Stack(
      children: [
        Scaffold(
          backgroundColor: const Color(0xFF121212),
          body: IndexedStack(
            index: _selectedIndex,
            children: screens,
          ),
          bottomNavigationBar: CustomNavBar(
            selectedIndex: _selectedIndex,
            onItemTapped: _onItemTapped,
          ),
        ),
        Positioned(
          top: MediaQuery.of(context).padding.top + 10,
          right: 16,
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: SessionService.watchPendingInvitations(),
            builder: (context, snapshot) {
              final hasNotifications = snapshot.hasData && snapshot.data!.isNotEmpty;
              final notificationCount = snapshot.hasData ? snapshot.data!.length : 0;

              return GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => NotificationsScreen(
                        currentUser: widget.profile,
                        allMovies: widget.movies,
                        onSessionJoined: (session) {
                          print("📥 MAIN NAV: Session joined from notifications: ${session.sessionId}");
                          
                          // If matcher screen has registered a callback, use it directly
                          if (MainNavigation._globalSessionCallback != null) {
                            print("📥 MAIN NAV: Using direct matcher callback");
                            
                            // Switch to matcher tab first
                            setState(() {
                              _selectedIndex = 2; // Switch to matcher tab
                            });
                            
                            // Then call the callback
                            MainNavigation._globalSessionCallback!(session);
                            return;
                          }
                          
                          // If no callback registered, just switch to matcher tab
                          print("📥 MAIN NAV: No callback registered, just switching to matcher");
                          setState(() {
                            _selectedIndex = 2;
                          });
                        },
                      ),
                    ),
                  );
                },
                child: Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: hasNotifications 
                        ? const Color(0xFFE5A00D).withValues(alpha: 0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Icon(
                        hasNotifications 
                            ? Icons.notifications 
                            : Icons.notifications_none_outlined,
                        size: 28, 
                        color: hasNotifications 
                            ? const Color(0xFFE5A00D)
                            : Colors.white,
                      ),
                      
                      if (hasNotifications && notificationCount > 0)
                        Positioned(
                          right: -4,
                          top: -4,
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFFE5A00D), Color(0xFFD4940A)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: const Color(0xFF121212),
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFE5A00D).withValues(alpha: 0.3),
                                  blurRadius: 4,
                                  offset: Offset(0, 1),
                                ),
                              ],
                            ),
                            constraints: BoxConstraints(
                              minWidth: 18,
                              minHeight: 18,
                            ),
                            child: Text(
                              notificationCount > 9 ? '9+' : notificationCount.toString(),
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                height: 1.0,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  void _setMatcherMode(String mode, {String? sessionId, bool resume = false}) {
    setState(() {
      // Update matcher mode
      switch (mode) {
        case 'solo':
          _matcherMode = MatchingMode.solo;
          _selectedFriend = null;
          break;
        case 'friend':
          _matcherMode = MatchingMode.friend;
          // _selectedFriend can be null - user will select in matcher
          break;
        case 'group':
          _matcherMode = MatchingMode.group;
          _selectedFriend = null;
          break;
      }
      
      // Rebuild matcher screen with new mode
      _matcherScreen = _buildMatcherScreen();
      
      // Switch to matcher tab (tab index 2)
      _selectedIndex = 2; // matcherTabIndex
    });
    
    print("🎯 Switched to Matcher tab in $mode mode");
  }
}